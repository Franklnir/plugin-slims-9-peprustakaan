<?php
/**
 * Plugin Name: Backup Plugin
 * Plugin URI: https://slims.web.id
 * Description: Kelola plugin dengan aksi hapus, download plugin, dan tombol detail untuk melihat fungsi plugin.
 * Version: 1.1.1
 * Author: Irsyad
 * Author URI:
 */

use SLiMS\Plugins;

if (!class_exists(Plugins::class)) {
    return;
}

$label = function_exists('__') ? __('Plugins') : 'Plugins';
$description = function_exists('__')
    ? __('Enhanced plugin manager with download, delete, and detail view')
    : 'Enhanced plugin manager with download, delete, and detail view';

$plugin = Plugins::getInstance();
$plugin->registerMenu('system', $label, __DIR__ . '/index.php', $description);
