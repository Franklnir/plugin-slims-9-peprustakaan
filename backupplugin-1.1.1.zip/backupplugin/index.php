<?php
/**
 * Backup Plugin manager page.
 */

use SLiMS\DB;
use SLiMS\Filesystems\Storage;
use SLiMS\Migration\Runner;
use SLiMS\Parcel\Package;
use SLiMS\Plugins;

defined('INDEX_AUTH') or die('Direct access not allowed!');

require SB . 'admin/default/session.inc.php';
require SB . 'admin/default/session_check.inc.php';

require SIMBIO . 'simbio_GUI/table/simbio_table.inc.php';
require SIMBIO . 'simbio_GUI/form_maker/simbio_form_table_AJAX.inc.php';
require SIMBIO . 'simbio_GUI/paging/simbio_paging.inc.php';
require SIMBIO . 'simbio_DB/datagrid/simbio_dbgrid.inc.php';
require SIMBIO . 'simbio_DB/simbio_dbop.inc.php';

if (!function_exists('backupplugin_json_response')) {
    function backupplugin_json_response(bool $status, string $message, array $extra = []): void
    {
        header('Content-Type: application/json');
        echo json_encode(array_merge(['status' => $status, 'message' => $message], $extra));
        exit();
    }
}

if (!function_exists('backupplugin_escape_attr')) {
    function backupplugin_escape_attr($value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('backupplugin_escape_html')) {
    function backupplugin_escape_html($value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('backupplugin_build_delete_target')) {
    function backupplugin_build_delete_target(string $pluginPath, string $pluginsRoot): array
    {
        $relativePath = ltrim(substr($pluginPath, strlen($pluginsRoot)), DIRECTORY_SEPARATOR);
        $segments = $relativePath !== '' ? explode(DIRECTORY_SEPARATOR, $relativePath) : [];

        if (count($segments) <= 1) {
            return [$relativePath, false];
        }

        return [$segments[0], true];
    }
}

if (!function_exists('backupplugin_sanitize_file_name')) {
    function backupplugin_sanitize_file_name(string $value, string $fallback = 'plugin-backup'): string
    {
        $value = strtolower(trim($value));
        $value = preg_replace('/[^a-z0-9._-]+/', '-', $value);
        $value = trim((string) $value, '-.');
        return $value !== '' ? $value : $fallback;
    }
}

if (!function_exists('backupplugin_format_size')) {
    function backupplugin_format_size(int $bytes): string
    {
        if ($bytes <= 0) {
            return '0 B';
        }

        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $size = (float) $bytes;
        $unitIndex = 0;

        while ($size >= 1024 && $unitIndex < count($units) - 1) {
            $size /= 1024;
            $unitIndex++;
        }

        $precision = $size >= 10 || $unitIndex === 0 ? 0 : 1;
        return number_format($size, $precision) . ' ' . $units[$unitIndex];
    }
}

if (!function_exists('backupplugin_collect_source_metrics')) {
    function backupplugin_collect_source_metrics(string $pluginPath, ?string $pluginsRoot): array
    {
        $sourcePath = $pluginPath;
        $sourceName = basename($pluginPath);
        $sourceType = __('Single file plugin');

        if ($pluginsRoot && $pluginPath !== '' && strpos($pluginPath, $pluginsRoot . DIRECTORY_SEPARATOR) === 0) {
            [$deleteTarget, $isDirectory] = backupplugin_build_delete_target($pluginPath, $pluginsRoot);
            if ($deleteTarget !== '') {
                $candidate = $isDirectory
                    ? $pluginsRoot . DIRECTORY_SEPARATOR . $deleteTarget
                    : $pluginPath;

                if (file_exists($candidate)) {
                    $sourcePath = $candidate;
                    $sourceName = basename($candidate);
                    $sourceType = $isDirectory ? __('Directory plugin') : __('Single file plugin');
                }
            }
        }

        $totalFiles = 0;
        $totalDirectories = 0;
        $totalSize = 0;

        if (is_dir($sourcePath)) {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($sourcePath, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST
            );

            foreach ($iterator as $item) {
                if ($item->isDir()) {
                    $totalDirectories++;
                    continue;
                }

                $totalFiles++;
                $totalSize += (int) $item->getSize();
            }
        } elseif (is_file($sourcePath)) {
            $totalFiles = 1;
            $totalSize = (int) filesize($sourcePath);
        }

        return [
            'source_name' => $sourceName !== '' ? $sourceName : '-',
            'source_type' => $sourceType,
            'total_files' => $totalFiles,
            'total_directories' => $totalDirectories,
            'total_size' => backupplugin_format_size($totalSize),
        ];
    }
}

if (!function_exists('backupplugin_add_path_to_zip')) {
    function backupplugin_add_path_to_zip(ZipArchive $zip, string $source, string $basePath): void
    {
        if (is_dir($source)) {
            $zip->addEmptyDir($basePath);
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($source, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST
            );

            foreach ($iterator as $item) {
                $itemPath = $item->getPathname();
                $relative = str_replace($source . DIRECTORY_SEPARATOR, '', $itemPath);
                $relative = str_replace('\\', '/', $relative);
                $zipPath = $basePath . '/' . $relative;

                if ($item->isDir()) {
                    $zip->addEmptyDir($zipPath);
                    continue;
                }

                $zip->addFile($itemPath, $zipPath);
            }

            return;
        }

        $zip->addEmptyDir($basePath);
        $zip->addFile($source, $basePath . '/' . basename($source));
    }
}

if (!function_exists('backupplugin_remove_path')) {
    function backupplugin_remove_path(string $path): bool
    {
        if (!file_exists($path)) {
            return true;
        }

        if (is_file($path) || is_link($path)) {
            return @unlink($path);
        }

        $items = scandir($path);
        if ($items === false) {
            return false;
        }

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            if (!backupplugin_remove_path($path . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }

        return @rmdir($path);
    }
}

if (!function_exists('backupplugin_download_archive')) {
    function backupplugin_download_archive(object $plugin, string $pluginPath, string $pluginsRoot): void
    {
        if (!class_exists('ZipArchive')) {
            http_response_code(500);
            exit(__('Extension ZIP is not exists.'));
        }

        [$deleteTarget, $isDirectory] = backupplugin_build_delete_target($pluginPath, $pluginsRoot);
        $source = $isDirectory ? $pluginsRoot . DIRECTORY_SEPARATOR . $deleteTarget : $pluginPath;

        if (!file_exists($source)) {
            http_response_code(404);
            exit(__('Plugin file is not found'));
        }

        $archiveBaseName = $isDirectory
            ? basename($source)
            : preg_replace('/\.plugin$/', '', pathinfo($pluginPath, PATHINFO_FILENAME));
        $archiveBaseName = backupplugin_sanitize_file_name($archiveBaseName, 'plugin-backup');

        $tempFile = tempnam(sys_get_temp_dir(), 'slims-plugin-');
        if ($tempFile === false) {
            http_response_code(500);
            exit(__('Failed to prepare temporary file'));
        }

        @unlink($tempFile);
        $zipFile = $tempFile . '.zip';
        $zip = new ZipArchive();
        $status = $zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE);

        if ($status !== true) {
            http_response_code(500);
            exit(__('Failed to create plugin archive'));
        }

        backupplugin_add_path_to_zip($zip, $source, $archiveBaseName);
        $zip->close();

        $versionSuffix = trim((string) ($plugin->version ?? ''));
        $downloadName = $archiveBaseName . ($versionSuffix !== '' ? '-' . backupplugin_sanitize_file_name($versionSuffix, 'v1') : '') . '.zip';

        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $downloadName . '"');
        header('Content-Length: ' . (string) filesize($zipFile));
        header('Cache-Control: private, max-age=0, must-revalidate');
        header('Pragma: public');

        readfile($zipFile);
        @unlink($zipFile);
        exit();
    }
}

// privileges checking
$can_read = utility::havePrivilege('system', 'r');
$can_write = utility::havePrivilege('system', 'w');

if (!$can_read) {
    die('<div class="errorBox">' . __('You don\'t have enough privileges to view this section') . '</div>');
}

$plugins = Plugins::getInstance();

if (method_exists(\Composer\InstalledVersions::class, 'getInstalledPackagesByType')) {
    foreach (\Composer\InstalledVersions::getInstalledPackagesByType('slims-plugin') as $package) {
        $plugins->addLocation(\Composer\InstalledVersions::getInstallPath($package));
    }
}

$pluginsRoot = realpath(SB . 'plugins');
$selfPluginPath = realpath(__DIR__ . '/backupplugin.plugin.php');
$selfUrl = AWB . 'plugin_container.php?mod=system&id=' . md5(realpath(__DIR__ . '/index.php'));
$zipAvailable = class_exists('ZipArchive');
$writeDisabledAttr = $can_write ? '' : 'disabled title="' . backupplugin_escape_attr(__('You don\'t have enough privileges to perform this action')) . '"';

if (count($_POST) === 0) {
    $_POST = json_decode(file_get_contents('php://input'), true) ?: [];
}

if (isset($_POST['action']) && $_POST['action'] === 'delete') {
    if (!$can_write) {
        backupplugin_json_response(false, __('You don\'t have enough privileges to perform this action'));
    }

    $pluginId = trim((string) ($_POST['plugin_id'] ?? ''));
    $runDown = !empty($_POST['runDown']);

    if ($pluginId === '') {
        backupplugin_json_response(false, __('Plugin id is required'));
    }

    $pluginList = $plugins->getPlugins();
    $plugin = $pluginList[$pluginId] ?? null;

    if (!$plugin) {
        backupplugin_json_response(false, __('Plugin not found'));
    }

    $pluginPath = realpath($plugin->path ?? '');
    if (!$pluginPath || !is_file($pluginPath)) {
        backupplugin_json_response(false, __('Plugin file is not found'));
    }

    if ($selfPluginPath && $pluginPath === $selfPluginPath) {
        backupplugin_json_response(false, __('This plugin cannot delete itself'));
    }

    if (!$pluginsRoot || strpos($pluginPath, $pluginsRoot . DIRECTORY_SEPARATOR) !== 0) {
        backupplugin_json_response(false, __('Deletion is only allowed for plugins inside plugins folder'));
    }

    [$deleteTarget, $deleteIsDir] = backupplugin_build_delete_target($pluginPath, $pluginsRoot);

    if ($deleteTarget === '') {
        backupplugin_json_response(false, __('Invalid plugin path'));
    }

    try {
        if ($runDown && ($plugin->migration->is_exist ?? false)) {
            Runner::path($plugin->path)->setVersion($plugin->migration->{Plugins::DATABASE_VERSION})->runDown();
        }

        $db = DB::getInstance();
        $query = $db->prepare('DELETE FROM plugins WHERE id = :id');
        $query->bindValue(':id', $pluginId);
        $run = $query->execute();

        if (!$run) {
            $error = $db->errorInfo();
            $message = is_array($error) ? implode(' | ', array_filter($error)) : (string) $error;
            $message = trim($message) !== '' ? $message : __('Failed to update database');
            backupplugin_json_response(false, $message);
        }

        $warning = null;
        try {
            $disk = Storage::plugin();
            if ($deleteIsDir) {
                $disk->deleteDirectory($deleteTarget);
            } else {
                $disk->delete($deleteTarget);
            }
        } catch (Throwable $exception) {
            $filesystemTarget = $deleteIsDir
                ? $pluginsRoot . DIRECTORY_SEPARATOR . $deleteTarget
                : $pluginsRoot . DIRECTORY_SEPARATOR . $deleteTarget;

            if (!backupplugin_remove_path($filesystemTarget)) {
                $warning = $exception->getMessage();
            }
        }

        backupplugin_json_response(true, __('Plugin deleted successfully'), $warning ? [
            'warning' => __('Plugin deleted from database, but failed to remove files') . ': ' . $warning,
        ] : []);
    } catch (Throwable $exception) {
        backupplugin_json_response(false, $exception->getMessage());
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'download') {
    $pluginId = trim((string) ($_GET['plugin_id'] ?? ''));

    if ($pluginId === '') {
        http_response_code(400);
        exit(__('Plugin id is required'));
    }

    $pluginList = $plugins->getPlugins();
    $plugin = $pluginList[$pluginId] ?? null;

    if (!$plugin) {
        http_response_code(404);
        exit(__('Plugin not found'));
    }

    $pluginPath = realpath($plugin->path ?? '');
    if (!$pluginPath || !is_file($pluginPath)) {
        http_response_code(404);
        exit(__('Plugin file is not found'));
    }

    if (!$pluginsRoot || strpos($pluginPath, $pluginsRoot . DIRECTORY_SEPARATOR) !== 0) {
        http_response_code(403);
        exit(__('Download is only allowed for plugins inside plugins folder'));
    }

    backupplugin_download_archive($plugin, $pluginPath, $pluginsRoot);
}

if (isset($_GET['view']) && !empty($_GET['view'])) {
    $_SESSION['view'] = $_GET['view'];
}

if (isset($_GET['upload'])) {
    $package = Package::prepare(SB . 'files/temp/test.zip');
    ob_start();

    if ($package && $package->isCompressorExists()) {
        $form = new simbio_form_table_AJAX('mainForm', MWB . 'system/plugin_action.php', 'post');
        $form->submit_button_attr = 'name="upload" value="' . __('Save') . '" class="s-btn btn btn-default"';
        $form->table_attr = 'id="dataList" cellpadding="0" cellspacing="0"';
        $form->table_header_attr = 'class="alterCell"';
        $form->table_content_attr = 'class="alterCell2"';

        $form->addAnything(__('Plugin'), simbio_form_element::textField('file', 'plugin', '', ''));
        $form->addSelectList('enable', __('Enable plugin'), [[0, __('No')], [1, __('Yes')]], '', 'class="form-control"', '');

        echo $form->printOut();
    } else {
        echo '<div class="alert alert-danger">' . __('Extension ZIP is not exists.') . '</div>';
    }

    $content = ob_get_clean();
    require SB . '/admin/' . $sysconf['admin_template']['dir'] . '/notemplate_page_tpl.php';
    exit();
}

$pluginActives = $plugins->getActive();
$isListView = !isset($_SESSION['view']) || $_SESSION['view'] === 'list';
?>
<div class="menuBox">
    <div class="menuBoxInner masterFileIcon">
        <div class="per_title">
            <h2><?php echo __('Plugin List'); ?></h2>
        </div>
        <div class="sub_section">
            <div class="btn-group">
                <a title="<?= __('Install plugin from .zip file') ?>" href="<?= $selfUrl . '&upload=yes' ?>" class="notAJAX openPopUp btn btn-primary"><?= __('Upload Plugin') ?></a>&nbsp;
                <a href="<?= $selfUrl . '&view=' . ($isListView ? 'card' : 'list') ?>" class="btn btn-sm btn-outline-secondary items-center flex p-2">
                    <?php if ($isListView): ?>
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-grid" viewBox="0 0 16 16">
                            <path d="M1 2.5A1.5 1.5 0 0 1 2.5 1h3A1.5 1.5 0 0 1 7 2.5v3A1.5 1.5 0 0 1 5.5 7h-3A1.5 1.5 0 0 1 1 5.5v-3zM2.5 2a.5.5 0 0 0-.5.5v3a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-3a.5.5 0 0 0-.5-.5h-3zm6.5.5A1.5 1.5 0 0 1 10.5 1h3A1.5 1.5 0 0 1 15 2.5v3A1.5 1.5 0 0 1 13.5 7h-3A1.5 1.5 0 0 1 9 5.5v-3zm1.5-.5a.5.5 0 0 0-.5.5v3a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-3a.5.5 0 0 0-.5-.5h-3zM1 10.5A1.5 1.5 0 0 1 2.5 9h3A1.5 1.5 0 0 1 7 10.5v3A1.5 1.5 0 0 1 5.5 15h-3A1.5 1.5 0 0 1 1 13.5v-3zm1.5-.5a.5.5 0 0 0-.5.5v3a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-3a.5.5 0 0 0-.5-.5h-3zm6.5.5A1.5 1.5 0 0 1 10.5 9h3a1.5 1.5 0 0 1 1.5 1.5v3a1.5 1.5 0 0 1-1.5 1.5h-3A1.5 1.5 0 0 1 9 13.5v-3zm1.5-.5a.5.5 0 0 0-.5.5v3a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-3a.5.5 0 0 0-.5-.5h-3z"></path>
                        </svg>
                    <?php else: ?>
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-view-list" viewBox="0 0 16 16">
                            <path d="M3 4.5h10a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2zm0 1a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1H3zM1 2a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 0 1h-13A.5.5 0 0 1 1 2zm0 12a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 0 1h-13A.5.5 0 0 1 1 14z"></path>
                        </svg>
                    <?php endif; ?>
                </a>
            </div>
            <div id="search" method="get" class="form-inline"><?= __('Search') ?>
                <input type="text" name="keywords" onkeyup="searchPlugin(this)" class="form-control col-md-3">
            </div>
        </div>
    </div>
</div>

<div class="alert alert-info mx-3" style="margin-top: 12px;">
    <?= __('Enhanced plugin manager: use the action buttons to view detail, download, or delete a plugin.') ?>
</div>

<style>
    .backupplugin-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
    }

    .backupplugin-actions .btn {
        white-space: nowrap;
    }

    .backupplugin-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 88px;
        padding: 6px 12px;
        border-radius: 8px;
        border: 1px solid transparent;
        font-size: 12px;
        font-weight: 700;
        line-height: 1.2;
        color: #ffffff !important;
        text-decoration: none !important;
        cursor: pointer;
        transition: opacity 0.2s ease, transform 0.2s ease;
    }

    .backupplugin-btn:hover {
        opacity: 0.92;
        color: #ffffff !important;
        text-decoration: none !important;
        transform: translateY(-1px);
    }

    .backupplugin-btn-delete {
        background: #dc2626;
        border-color: #b91c1c;
    }

    .backupplugin-btn-download {
        background: #2563eb;
        border-color: #1d4ed8;
    }

    .backupplugin-btn-detail {
        background: #0f766e;
        border-color: #0d5f59;
    }

    .backupplugin-btn.is-disabled {
        opacity: 0.55;
        cursor: not-allowed;
        transform: none;
    }

    .backupplugin-card-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
        justify-content: space-between;
    }

    .backupplugin-detail-overlay {
        position: fixed;
        inset: 0;
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 1055;
    }

    .backupplugin-detail-overlay.is-open {
        display: flex;
    }

    .backupplugin-detail-backdrop {
        position: absolute;
        inset: 0;
        background: rgba(15, 23, 42, 0.52);
    }

    .backupplugin-detail-dialog {
        position: relative;
        width: min(720px, calc(100vw - 32px));
        max-height: calc(100vh - 48px);
        overflow: auto;
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 24px 60px rgba(15, 23, 42, 0.24);
        padding: 24px;
    }

    .backupplugin-detail-head {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 16px;
        margin-bottom: 18px;
    }

    .backupplugin-detail-title {
        margin: 0;
        font-size: 24px;
        font-weight: 700;
        color: #14213d;
    }

    .backupplugin-detail-subtitle {
        margin-top: 6px;
        color: #4b5563;
    }

    .backupplugin-close {
        border: 0;
        background: #f3f4f6;
        color: #111827;
        border-radius: 999px;
        width: 36px;
        height: 36px;
        font-size: 20px;
        line-height: 1;
        cursor: pointer;
    }

    .backupplugin-detail-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 12px;
        margin-bottom: 16px;
    }

    .backupplugin-detail-item {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 12px;
        padding: 14px;
    }

    .backupplugin-detail-label {
        display: block;
        margin-bottom: 6px;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        color: #6b7280;
    }

    .backupplugin-detail-value {
        color: #111827;
        word-break: break-word;
    }

    .backupplugin-detail-purpose {
        background: linear-gradient(135deg, #eff6ff, #f8fafc);
        border: 1px solid #bfdbfe;
        border-radius: 14px;
        padding: 18px;
    }

    .backupplugin-detail-purpose h4 {
        margin: 0 0 8px;
        font-size: 16px;
        color: #1d4ed8;
    }

    .backupplugin-detail-purpose p {
        margin: 0;
        color: #1f2937;
        white-space: pre-line;
    }

    .backupplugin-detail-badges {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-top: 14px;
    }

    .backupplugin-detail-badge {
        display: inline-flex;
        align-items: center;
        padding: 6px 10px;
        border-radius: 999px;
        background: rgba(29, 78, 216, 0.08);
        color: #1d4ed8;
        font-size: 12px;
        font-weight: 700;
    }

    .backupplugin-detail-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 16px;
    }

    .backupplugin-detail-actions .backupplugin-btn {
        min-width: 140px;
    }

    .backupplugin-btn-site {
        background: #334155;
        border-color: #1e293b;
    }
</style>

<?php if ($isListView): ?>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col"><?= __('Plugin') ?></th>
            <th scope="col"><?= __('Description') ?></th>
            <th scope="col"><?= __('Enable/Disable') ?></th>
            <th scope="col"><?= __('Action') ?></th>
        </tr>
        </thead>
        <tbody>
<?php else: ?>
    <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 mx-3">
<?php endif; ?>
<?php
$n = 1;
foreach ($plugins->getPlugins() as $plugin) {
    $hash = md5($plugin->path);
    $version = '';

    if (isset($pluginActives[$hash])) {
        $enableDisable = __('Enabled');
        $isActive = 'checked';

        $version = (json_decode($pluginActives[$hash]->options ?? ''))->version ?? '';
        if ($version !== $plugin->version && $plugin->migration->is_exist) {
            $enableDisable = __('Disabled');
            $isActive = '';
        }
    } else {
        $enableDisable = __('Disabled');
        $isActive = '';
    }

    $pluginPath = realpath($plugin->path ?? '');
    $isLocalPlugin = $pluginPath && $pluginsRoot && strpos($pluginPath, $pluginsRoot . DIRECTORY_SEPARATOR) === 0;
    $canDelete = $can_write && $isLocalPlugin;
    if ($selfPluginPath && $pluginPath === $selfPluginPath) {
        $canDelete = false;
    }

    $deleteBlockedReason = '';
    if (!$can_write) {
        $deleteBlockedReason = __('You don\'t have enough privileges to perform this action');
    } elseif ($selfPluginPath && $pluginPath === $selfPluginPath) {
        $deleteBlockedReason = __('This plugin cannot delete itself');
    } elseif (!$isLocalPlugin) {
        $deleteBlockedReason = __('Deletion is only allowed for plugins inside plugins folder');
    }

    $downloadBlockedReason = '';
    if (!$zipAvailable) {
        $downloadBlockedReason = __('Extension ZIP is not exists.');
    } elseif (!$isLocalPlugin) {
        $downloadBlockedReason = __('Download is only allowed for plugins inside plugins folder');
    }

    $toggleDisabledAttr = $can_write ? '' : $writeDisabledAttr;
    $pluginName = backupplugin_escape_attr($plugin->name ?? '');
    $pluginDescription = trim((string) ($plugin->description ?? ''));
    $pluginPurpose = $pluginDescription !== '' ? $pluginDescription : __('No description provided for this plugin.');
    $pluginDescriptionDisplay = $pluginDescription !== '' ? $pluginDescription : __('No description provided for this plugin.');
    $pluginMetrics = backupplugin_collect_source_metrics($pluginPath ?: (string) ($plugin->path ?? ''), $pluginsRoot ?: null);
    $pluginVersion = backupplugin_escape_attr($plugin->version ?? '-');
    $pluginAuthor = backupplugin_escape_attr($plugin->author ?? '-');
    $pluginAuthorUriRaw = trim((string) ($plugin->author_uri ?? ''));
    $pluginUriRaw = trim((string) ($plugin->uri ?? ''));
    $pluginAuthorUri = backupplugin_escape_attr($pluginAuthorUriRaw !== '' ? $pluginAuthorUriRaw : '-');
    $pluginUri = backupplugin_escape_attr($pluginUriRaw !== '' ? $pluginUriRaw : '-');
    $pluginFsPath = backupplugin_escape_attr($pluginPath ?: ($plugin->path ?? '-'));
    $pluginStatus = backupplugin_escape_attr($enableDisable);
    $pluginMigration = backupplugin_escape_attr(($plugin->migration->is_exist ?? false) ? __('Available') : __('Not available'));
    $pluginPurposeAttr = backupplugin_escape_attr($pluginPurpose);
    $pluginSourceType = backupplugin_escape_attr($pluginMetrics['source_type'] ?? '-');
    $pluginSourceName = backupplugin_escape_attr($pluginMetrics['source_name'] ?? '-');
    $pluginTotalFiles = backupplugin_escape_attr((string) ($pluginMetrics['total_files'] ?? 0));
    $pluginTotalDirectories = backupplugin_escape_attr((string) ($pluginMetrics['total_directories'] ?? 0));
    $pluginTotalSize = backupplugin_escape_attr($pluginMetrics['total_size'] ?? '0 B');
    $downloadUrl = backupplugin_escape_attr($selfUrl . '&action=download&plugin_id=' . rawurlencode($hash));
    $hasMigration = (int) ($plugin->migration->is_exist ?? 0);
    $detailButton = '<button type="button" class="btn btn-sm backupplugin-btn backupplugin-btn-detail" '
        . 'data-name="' . $pluginName . '" '
        . 'data-purpose="' . $pluginPurposeAttr . '" '
        . 'data-description="' . $pluginPurposeAttr . '" '
        . 'data-version="' . $pluginVersion . '" '
        . 'data-author="' . $pluginAuthor . '" '
        . 'data-author-uri="' . $pluginAuthorUri . '" '
        . 'data-author-uri-link="' . backupplugin_escape_attr($pluginAuthorUriRaw) . '" '
        . 'data-plugin-uri="' . $pluginUri . '" '
        . 'data-plugin-uri-link="' . backupplugin_escape_attr($pluginUriRaw) . '" '
        . 'data-path="' . $pluginFsPath . '" '
        . 'data-status="' . $pluginStatus . '" '
        . 'data-migration="' . $pluginMigration . '" '
        . 'data-source-type="' . $pluginSourceType . '" '
        . 'data-source-name="' . $pluginSourceName . '" '
        . 'data-total-files="' . $pluginTotalFiles . '" '
        . 'data-total-directories="' . $pluginTotalDirectories . '" '
        . 'data-total-size="' . $pluginTotalSize . '" '
        . 'data-download-url="' . $downloadUrl . '" '
        . 'data-download-disabled-reason="' . backupplugin_escape_attr($downloadBlockedReason) . '" '
        . 'onclick="showPluginDetail(this)">'
        . __('Detail')
        . '</button>';
    $downloadButton = '<button type="button" class="btn btn-sm backupplugin-btn backupplugin-btn-download' . ($downloadBlockedReason !== '' ? ' is-disabled' : '') . '" data-url="' . $downloadUrl . '" data-disabled-reason="' . backupplugin_escape_attr($downloadBlockedReason) . '" onclick="downloadPlugin(this)">'
        . __('Download')
        . '</button>';
    $deleteButton = '<button type="button" class="btn btn-sm backupplugin-btn backupplugin-btn-delete' . ($deleteBlockedReason !== '' ? ' is-disabled' : '') . '" data-plugin-id="' . $hash . '" data-name="' . $pluginName . '" data-has-migration="' . $hasMigration . '" data-disabled-reason="' . backupplugin_escape_attr($deleteBlockedReason) . '" onclick="deletePlugin(this)">'
        . __('Delete')
        . '</button>';
    $actionButtons = '<div class="backupplugin-actions">' . $detailButton . $downloadButton . $deleteButton . '</div>';

    if ($isListView) {
        echo '<tr id="section' . $n . '">'
            . '<th scope="row">' . $n . '</th>'
            . '<td width="300px" class="plugin-title" data-section="' . $n . '">' . backupplugin_escape_html($plugin->name ?? '') . '</td>'
            . '<td>'
            . '<div class="mb-2">' . backupplugin_escape_html($pluginDescriptionDisplay) . '</div>'
            . '<div>' . backupplugin_escape_html(__('Version')) . ' <code>' . backupplugin_escape_html($plugin->version ?? '-') . '</code> | '
            . backupplugin_escape_html(__('By')) . ' <a target="_blank" href="' . backupplugin_escape_attr($plugin->author_uri ?? '#') . '">' . backupplugin_escape_html($plugin->author ?? '-') . '</a> | '
            . '<a target="_blank" href="' . backupplugin_escape_attr($plugin->uri ?? '#') . '">' . backupplugin_escape_html(__('View Detail')) . '</a></div>'
            . '</td>'
            . '<td><div class="custom-control custom-switch">'
            . '<input onchange="enablePlugin(event, ' . (int) ($plugin->migration->is_exist ?? 0) . ')" type="checkbox" class="custom-control-input" id="' . $hash . '" ' . $isActive . ' ' . $toggleDisabledAttr . '>'
            . '<label class="custom-control-label" for="' . $hash . '">' . backupplugin_escape_html($enableDisable) . '</label>'
            . '</div></td>'
            . '<td>' . $actionButtons . '</td>'
            . '</tr>';
    } else {
        echo '<div id="section' . $n . '" class="col my-3">'
            . '<div class="card">'
            . '<div class="card-body">'
            . '<h5 class="card-title plugin-title" data-section="' . $n . '">' . backupplugin_escape_html($plugin->name ?? '') . '</h5>'
            . '<p class="card-text">' . backupplugin_escape_html($pluginDescriptionDisplay) . '</p>'
            . '<p class="card-text"><small>'
            . backupplugin_escape_html(__('Version')) . ' <code>' . backupplugin_escape_html($plugin->version ?? '-') . '</code> | '
            . backupplugin_escape_html(__('By')) . ' <a target="_blank" href="' . backupplugin_escape_attr($plugin->author_uri ?? '#') . '">' . backupplugin_escape_html($plugin->author ?? '-') . '</a> | '
            . '<a target="_blank" href="' . backupplugin_escape_attr($plugin->uri ?? '#') . '">' . backupplugin_escape_html(__('View Detail')) . '</a>'
            . '</small></p>'
            . '<hr/>'
            . '<div class="backupplugin-card-actions">'
            . $actionButtons
            . '<div class="custom-control custom-switch">'
            . '<input onchange="enablePlugin(event, ' . (int) ($plugin->migration->is_exist ?? 0) . ')" type="checkbox" class="custom-control-input" id="' . $hash . '" ' . $isActive . ' ' . $toggleDisabledAttr . '>'
            . '<label class="custom-control-label" for="' . $hash . '">' . backupplugin_escape_html($enableDisable) . '</label>'
            . '</div></div></div></div></div>';
    }

    $n++;
}
?>
<?php if ($isListView): ?>
        </tbody>
    </table>
<?php else: ?>
    </div>
<?php endif; ?>

<div id="backupplugin-detail-overlay" class="backupplugin-detail-overlay" aria-hidden="true">
    <div class="backupplugin-detail-backdrop" onclick="hidePluginDetail()"></div>
    <div class="backupplugin-detail-dialog" role="dialog" aria-modal="true" aria-labelledby="backupplugin-detail-title">
        <div class="backupplugin-detail-head">
            <div>
                <h3 id="backupplugin-detail-title" class="backupplugin-detail-title"><?= __('Plugin Detail') ?></h3>
                <div id="backupplugin-detail-subtitle" class="backupplugin-detail-subtitle"></div>
            </div>
            <button type="button" class="backupplugin-close" onclick="hidePluginDetail()" aria-label="<?= __('Close') ?>">&times;</button>
        </div>
        <div id="backupplugin-detail-content"></div>
    </div>
</div>

<script>
    const backupPluginLabels = {
        deletePlugin: <?= json_encode(__('Delete plugin')) ?>,
        deleteMigration: <?= json_encode(__('Plugin has migration. Run migration down too? This will drop plugin tables/data.')) ?>,
        deleting: <?= json_encode(__('Deleting...')) ?>,
        detailTitle: <?= json_encode(__('Plugin Detail')) ?>,
        purpose: <?= json_encode(__('Plugin Function')) ?>,
        description: <?= json_encode(__('Description')) ?>,
        version: <?= json_encode(__('Version')) ?>,
        author: <?= json_encode(__('Author')) ?>,
        authorUri: <?= json_encode(__('Author URI')) ?>,
        pluginUri: <?= json_encode(__('Plugin URI')) ?>,
        status: <?= json_encode(__('Status')) ?>,
        migration: <?= json_encode(__('Migration')) ?>,
        sourceType: <?= json_encode(__('Source Type')) ?>,
        sourceName: <?= json_encode(__('Source Name')) ?>,
        totalFiles: <?= json_encode(__('Total Files')) ?>,
        totalDirectories: <?= json_encode(__('Total Folders')) ?>,
        totalSize: <?= json_encode(__('Total Size')) ?>,
        path: <?= json_encode(__('Path')) ?>,
        noDescription: <?= json_encode(__('No description provided for this plugin.')) ?>,
        plugin: <?= json_encode(__('Plugin')) ?>,
        openPluginSite: <?= json_encode(__('Open Plugin Website')) ?>,
        downloadPlugin: <?= json_encode(__('Download Plugin')) ?>
    };
    const backupPluginEndpoint = <?= json_encode($selfUrl) ?>;

    function enablePlugin(e, m = false) {
        if (e.target.disabled) return;

        let runDown = false;
        if (!e.target.checked && m) {
            runDown = confirm("<?= __('Plugin has been disabled.\nRun Migration too? This may will drop this plugin\'s table and the data can not be restored!') ?>");
        }

        fetch('<?= MWB ?>system/plugin_action.php', {
            method: 'POST',
            body: JSON.stringify({
                format: 'json',
                enable: e.target.checked,
                id: e.target.getAttribute('id'),
                runDown
            })
        })
            .then(res => res.json())
            .then(res => {
                if (res.status) {
                    parent.toastr.success(res.message, 'Plugin');
                } else {
                    parent.toastr.error(res.message, 'Plugin');
                    e.target.checked = !e.target.checked;
                }
                labelMod(e);
            })
            .catch(err => {
                parent.toastr.error(err, 'Plugin');
                e.target.checked = !e.target.checked;
                labelMod(e);
            });
    }

    function labelMod(e) {
        const label = document.querySelector('label[for="' + e.target.getAttribute('id') + '"]');
        if (!label) return;
        label.innerHTML = e.target.checked ? '<?= __('Enabled') ?>' : '<?= __('Disabled') ?>';
    }

    function searchPlugin(input) {
        const keyword = input.value.trim();
        const escapedKeyword = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(escapedKeyword, 'i');

        document.querySelectorAll('.plugin-title').forEach(el => {
            const section = document.getElementById('section' + el.dataset.section);
            if (!section) return;

            if (keyword !== '' && !regex.test(el.textContent)) {
                section.classList.add('d-none');
            } else {
                section.classList.remove('d-none');
            }
        });
    }

    function deletePlugin(button) {
        if (!button) return;

        const disabledReason = button.getAttribute('data-disabled-reason');
        if (disabledReason) {
            if (parent.toastr) parent.toastr.warning(disabledReason, 'Plugin');
            else alert(disabledReason);
            return;
        }

        const pluginName = button.getAttribute('data-name') || backupPluginLabels.plugin;
        const hasMigration = button.getAttribute('data-has-migration') === '1';

        if (!confirm(backupPluginLabels.deletePlugin + ' ' + pluginName + '?')) return;

        let runDown = false;
        if (hasMigration) {
            runDown = confirm(backupPluginLabels.deleteMigration);
        }

        const originalText = button.innerText;
        button.disabled = true;
        button.innerText = backupPluginLabels.deleting;

        fetch(backupPluginEndpoint, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                action: 'delete',
                plugin_id: button.getAttribute('data-plugin-id'),
                runDown
            })
        })
            .then(res => res.json())
            .then(res => {
                if (res.status) {
                    parent.toastr.success(res.message, 'Plugin');
                    if (res.warning) parent.toastr.warning(res.warning, 'Plugin');
                    window.location.reload();
                    return;
                }

                parent.toastr.error(res.message || 'Error', 'Plugin');
                button.disabled = false;
                button.innerText = originalText;
            })
            .catch(err => {
                parent.toastr.error(err, 'Plugin');
                button.disabled = false;
                button.innerText = originalText;
            });
    }

    function downloadPlugin(button) {
        if (!button) return;
        const disabledReason = button.getAttribute('data-disabled-reason');
        if (disabledReason) {
            if (parent.toastr) parent.toastr.warning(disabledReason, 'Plugin');
            else alert(disabledReason);
            return;
        }
        const url = button.getAttribute('data-url');
        if (!url) return;
        const link = document.createElement('a');
        link.href = url;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        document.body.appendChild(link);
        link.click();
        link.remove();
    }

    function escapeHtml(value) {
        return String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function hasValue(value) {
        return !!value && value !== '-' && value !== '#';
    }

    function renderDetailItem(label, value) {
        return `
            <div class="backupplugin-detail-item">
                <span class="backupplugin-detail-label">${escapeHtml(label)}</span>
                <div class="backupplugin-detail-value">${escapeHtml(value || '-')}</div>
            </div>
        `;
    }

    function buildDetailActions(button) {
        const actions = [];
        const downloadUrl = button.getAttribute('data-download-url') || '';
        const downloadDisabledReason = button.getAttribute('data-download-disabled-reason') || '';
        const pluginUriLink = button.getAttribute('data-plugin-uri-link') || '';

        actions.push(`
            <button
                type="button"
                class="btn btn-sm backupplugin-btn backupplugin-btn-download${downloadDisabledReason ? ' is-disabled' : ''}"
                data-url="${escapeHtml(downloadUrl)}"
                data-disabled-reason="${escapeHtml(downloadDisabledReason)}"
                onclick="downloadPlugin(this)"
            >${escapeHtml(backupPluginLabels.downloadPlugin)}</button>
        `);

        if (hasValue(pluginUriLink)) {
            actions.push(`
                <a
                    class="btn btn-sm backupplugin-btn backupplugin-btn-site"
                    href="${escapeHtml(pluginUriLink)}"
                    target="_blank"
                    rel="noopener noreferrer"
                >${escapeHtml(backupPluginLabels.openPluginSite)}</a>
            `);
        }

        return `<div class="backupplugin-detail-actions">${actions.join('')}</div>`;
    }

    function showPluginDetail(button) {
        if (!button) return;

        const overlay = document.getElementById('backupplugin-detail-overlay');
        const title = document.getElementById('backupplugin-detail-title');
        const subtitle = document.getElementById('backupplugin-detail-subtitle');
        const content = document.getElementById('backupplugin-detail-content');
        if (!overlay || !title || !subtitle || !content) return;

        const name = button.getAttribute('data-name') || backupPluginLabels.plugin;
        const purpose = button.getAttribute('data-purpose') || backupPluginLabels.noDescription;

        title.textContent = backupPluginLabels.detailTitle;
        subtitle.textContent = name;
        content.innerHTML = `
            <div class="backupplugin-detail-purpose">
                <h4>${escapeHtml(backupPluginLabels.purpose)}</h4>
                <p>${escapeHtml(purpose)}</p>
                <div class="backupplugin-detail-badges">
                    <span class="backupplugin-detail-badge">${escapeHtml(button.getAttribute('data-status') || '-')}</span>
                    <span class="backupplugin-detail-badge">${escapeHtml(button.getAttribute('data-migration') || '-')}</span>
                </div>
            </div>
            ${buildDetailActions(button)}
            <div class="backupplugin-detail-grid" style="margin-top:16px;">
                ${renderDetailItem(backupPluginLabels.description, button.getAttribute('data-description'))}
                ${renderDetailItem(backupPluginLabels.version, button.getAttribute('data-version'))}
                ${renderDetailItem(backupPluginLabels.author, button.getAttribute('data-author'))}
                ${renderDetailItem(backupPluginLabels.authorUri, button.getAttribute('data-author-uri'))}
                ${renderDetailItem(backupPluginLabels.pluginUri, button.getAttribute('data-plugin-uri'))}
                ${renderDetailItem(backupPluginLabels.status, button.getAttribute('data-status'))}
                ${renderDetailItem(backupPluginLabels.migration, button.getAttribute('data-migration'))}
                ${renderDetailItem(backupPluginLabels.sourceType, button.getAttribute('data-source-type'))}
                ${renderDetailItem(backupPluginLabels.sourceName, button.getAttribute('data-source-name'))}
                ${renderDetailItem(backupPluginLabels.totalFiles, button.getAttribute('data-total-files'))}
                ${renderDetailItem(backupPluginLabels.totalDirectories, button.getAttribute('data-total-directories'))}
                ${renderDetailItem(backupPluginLabels.totalSize, button.getAttribute('data-total-size'))}
                ${renderDetailItem(backupPluginLabels.path, button.getAttribute('data-path'))}
            </div>
        `;

        overlay.classList.add('is-open');
        overlay.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
    }

    function hidePluginDetail() {
        const overlay = document.getElementById('backupplugin-detail-overlay');
        if (!overlay) return;
        overlay.classList.remove('is-open');
        overlay.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
    }

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            hidePluginDetail();
        }
    });
</script>
