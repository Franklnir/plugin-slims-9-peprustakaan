<?php

defined('INDEX_AUTH') or die('Direct access not allowed!');

require_once __DIR__ . '/shared.php';

lapordata_require_admin_session();

$canRead = utility::havePrivilege('bibliography', 'r');
if (!$canRead) {
    die('<div class="errorBox">' . __('You don\'t have enough privileges to access this area!') . '</div>');
}

$baseAction = AWB . 'plugin_container.php';
$legacyCsvUrl = AWB . 'bibliography/item_export.php';
$pluginMenuId = lapordata_current_plugin_menu_id('bibliography', __FILE__);
$filters = lapordata_collect_item_export_filters();
$filterPack = lapordata_build_item_export_filter_sql($dbs, $filters);
$normalizedFilters = $filterPack['filters'];
$options = $filterPack['options'];

$currentAction = trim((string) ($_GET['lapordata_action'] ?? ''));
if ($currentAction === 'export_item_location') {
    lapordata_export_item_location_excel($dbs, $sysconf, $filters);
}
?>
<style>
  .lapordata-panel {
    margin-bottom: 18px;
    border: 1px solid #cbd5e1;
    border-radius: 14px;
    background: linear-gradient(135deg, #f8fafc, #eef2ff);
    box-shadow: 0 10px 24px rgba(15, 23, 42, 0.08);
  }
  .lapordata-panel-head {
    padding: 18px 20px;
  }
  .lapordata-panel-head h3 {
    margin: 0 0 6px;
    color: #0f172a;
    font-size: 22px;
  }
  .lapordata-panel-head p {
    margin: 0;
    color: #475569;
  }
  .lapordata-export-toolbar {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
    justify-content: space-between;
    gap: 14px;
  }
  .lapordata-export-summary {
    flex: 1 1 340px;
    min-width: 280px;
  }
  .lapordata-toolbar-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: flex-start;
  }
  .lapordata-dropdown {
    position: relative;
  }
  .lapordata-dropdown-menu {
    position: absolute;
    right: 0;
    top: calc(100% + 10px);
    display: none;
    width: min(780px, calc(100vw - 60px));
    padding: 16px;
    border: 1px solid #cbd5e1;
    border-radius: 14px;
    background: #ffffff;
    box-shadow: 0 18px 38px rgba(15, 23, 42, 0.14);
    z-index: 50;
  }
  .lapordata-dropdown.is-open .lapordata-dropdown-menu {
    display: block;
  }
  .lapordata-panel .lapordata-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 12px;
  }
  .lapordata-panel label {
    display: block;
    margin-bottom: 6px;
    font-weight: 700;
    color: #0f172a;
  }
  .lapordata-panel .lapordata-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 14px;
  }
  .lapordata-panel .lapordata-note {
    margin-top: 12px;
    padding: 10px 12px;
    border-radius: 10px;
    background: rgba(30, 64, 175, 0.08);
    color: #0f172a;
    font-size: 13px;
  }
  .lapordata-core-box {
    padding: 16px 18px;
    border: 1px dashed #cbd5e1;
    border-radius: 12px;
    background: #ffffff;
  }
  .lapordata-core-box h4 {
    margin: 0 0 8px;
    color: #0f172a;
    font-size: 18px;
  }
  .lapordata-core-box p {
    margin: 0;
    color: #475569;
  }
  @media (max-width: 767px) {
    .lapordata-toolbar-actions,
    .lapordata-dropdown {
      width: 100%;
    }
    .lapordata-toolbar-actions > .btn,
    .lapordata-dropdown > .btn {
      width: 100%;
    }
    .lapordata-dropdown-menu {
      position: static;
      width: 100%;
      margin-top: 10px;
    }
  }
</style>

<div class="lapordata-panel">
  <div class="lapordata-panel-head">
    <div class="lapordata-export-toolbar">
      <div class="lapordata-export-summary">
        <h3>Export Excel Buku per Lokasi</h3>
        <p>Unduh laporan Excel koleksi per lokasi dengan filter yang lebih lengkap dan tampilan tabel yang lebih rapi.</p>
      </div>
      <div class="lapordata-toolbar-actions">
        <div class="lapordata-dropdown" id="lapordataItemExportDropdown">
          <button type="button" class="btn btn-success" onclick="toggleLapordataItemExportDropdown(event)">Export Excel</button>
          <div class="lapordata-dropdown-menu">
            <form method="get" action="<?php echo htmlspecialchars($baseAction); ?>">
              <input type="hidden" name="mod" value="bibliography">
              <input type="hidden" name="id" value="<?php echo htmlspecialchars($pluginMenuId); ?>">
              <div class="lapordata-grid">
                <div>
                  <label for="lapordataItemLocation">Lokasi Buku</label>
                  <select id="lapordataItemLocation" name="location_id" class="form-control">
                    <option value="all">Semua lokasi</option>
                    <?php foreach (($options['locations'] ?? []) as $value => $label) { ?>
                      <option value="<?php echo htmlspecialchars((string) $value); ?>"<?php echo $normalizedFilters['location_id'] === (string) $value ? ' selected' : ''; ?>><?php echo htmlspecialchars((string) $label); ?></option>
                    <?php } ?>
                  </select>
                </div>
                <div>
                  <label for="lapordataItemCollType">Tipe Koleksi</label>
                  <select id="lapordataItemCollType" name="coll_type_id" class="form-control">
                    <option value="all">Semua tipe</option>
                    <?php foreach (($options['coll_types'] ?? []) as $value => $label) { ?>
                      <option value="<?php echo htmlspecialchars((string) $value); ?>"<?php echo $normalizedFilters['coll_type_id'] === (string) $value ? ' selected' : ''; ?>><?php echo htmlspecialchars((string) $label); ?></option>
                    <?php } ?>
                  </select>
                </div>
                <div>
                  <label for="lapordataItemStatus">Status Item</label>
                  <select id="lapordataItemStatus" name="item_status_id" class="form-control">
                    <option value="all">Semua status</option>
                    <?php foreach (($options['item_statuses'] ?? []) as $value => $label) { ?>
                      <option value="<?php echo htmlspecialchars((string) $value); ?>"<?php echo $normalizedFilters['item_status_id'] === (string) $value ? ' selected' : ''; ?>><?php echo htmlspecialchars((string) $label); ?></option>
                    <?php } ?>
                  </select>
                </div>
                <div>
                  <label for="lapordataItemSource">Sumber Pengadaan</label>
                  <select id="lapordataItemSource" name="source" class="form-control">
                    <option value="all">Semua sumber</option>
                    <?php foreach (($options['sources'] ?? []) as $value => $label) { ?>
                      <option value="<?php echo htmlspecialchars((string) $value); ?>"<?php echo $normalizedFilters['source'] === (string) $value ? ' selected' : ''; ?>><?php echo htmlspecialchars((string) $label); ?></option>
                    <?php } ?>
                  </select>
                </div>
                <div>
                  <label for="lapordataItemDateFrom">Tanggal Terima Dari</label>
                  <input id="lapordataItemDateFrom" type="date" name="date_from" class="form-control" value="<?php echo htmlspecialchars((string) $normalizedFilters['date_from']); ?>">
                </div>
                <div>
                  <label for="lapordataItemDateTo">Tanggal Terima Sampai</label>
                  <input id="lapordataItemDateTo" type="date" name="date_to" class="form-control" value="<?php echo htmlspecialchars((string) $normalizedFilters['date_to']); ?>">
                </div>
                <div>
                  <label>&nbsp;</label>
                  <div class="form-control" style="display:flex; align-items:center; gap:8px;">
                    <input id="lapordataItemAllDates" type="checkbox" name="all_dates" value="1"<?php echo !empty($normalizedFilters['all_dates']) ? ' checked' : ''; ?>>
                    <label for="lapordataItemAllDates" style="margin:0; font-weight:600;">Semua tanggal</label>
                  </div>
                </div>
              </div>
              <div class="lapordata-actions">
                <a class="btn btn-default" href="<?php echo htmlspecialchars($baseAction . '?mod=bibliography&id=' . rawurlencode($pluginMenuId)); ?>">Reset Filter</a>
                <button type="submit" name="lapordata_action" value="export_item_location" class="btn btn-success">Download Excel</button>
              </div>
              <div class="lapordata-note">
                File Excel berisi sheet <strong>Ringkasan</strong>, <strong>Rekap Lokasi</strong>, dan <strong>Data Item</strong> dengan kolom yang lebih lebar dan teks yang tetap terbaca di dalam tabel.
              </div>
            </form>
          </div>
        </div>
        <a class="btn btn-default notAJAX" target="_blank" href="<?php echo htmlspecialchars($legacyCsvUrl); ?>">Buka CSV Lama</a>
      </div>
    </div>
  </div>
</div>

<div class="lapordata-core-box">
  <h4>CSV Bawaan Tetap Aman</h4>
  <p>Core SLiMS tidak diubah. Kalau masih butuh format CSV bawaan, gunakan tombol <strong>Buka CSV Lama</strong> di atas.</p>
</div>

<script>
  function toggleLapordataItemExportDropdown(event) {
    if (event) event.stopPropagation();
    var dropdown = document.getElementById('lapordataItemExportDropdown');
    if (!dropdown) return;
    dropdown.classList.toggle('is-open');
  }

  document.addEventListener('click', function (event) {
    var dropdown = document.getElementById('lapordataItemExportDropdown');
    if (!dropdown) return;
    if (!dropdown.contains(event.target)) {
      dropdown.classList.remove('is-open');
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      var dropdown = document.getElementById('lapordataItemExportDropdown');
      if (dropdown) {
        dropdown.classList.remove('is-open');
      }
    }
  });
</script>
