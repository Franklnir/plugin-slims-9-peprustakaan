<?php

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use SLiMS\Plugins;

if (!function_exists('lapordata_normalize_menu_label')) {
    function lapordata_normalize_menu_label($label): string
    {
        $normalized = preg_replace('/\s+/u', ' ', trim((string) $label));
        return strtolower((string) $normalized);
    }
}

if (!function_exists('lapordata_approval_menu_label')) {
    function lapordata_approval_menu_label(): string
    {
        if (function_exists('updatefiturnewTranslate')) {
            $label = trim((string) updatefiturnewTranslate('menu_approval'));
            if ($label !== '') {
                return $label;
            }
        }

        if (function_exists('peminjamanTranslate')) {
            $label = trim((string) peminjamanTranslate('menu_approval'));
            if ($label !== '') {
                return $label;
            }
        }

        return 'Approval Peminjaman';
    }
}

if (!function_exists('lapordata_approval_menu_aliases')) {
    function lapordata_approval_menu_aliases(): array
    {
        $aliases = [
            lapordata_approval_menu_label(),
            'Approval Peminjaman',
            'Peminjaman Approval',
            'Loan Approval'
        ];

        $normalized = [];
        foreach ($aliases as $alias) {
            $alias = trim((string) $alias);
            if ($alias !== '') {
                $normalized[$alias] = $alias;
            }
        }

        return array_values($normalized);
    }
}

if (!function_exists('lapordata_internal_approval_menu_label')) {
    function lapordata_internal_approval_menu_label(): string
    {
        return '__LAPORDATA_APPROVAL_EXPORT__';
    }
}

if (!function_exists('lapordata_biblio_item_export_menu_label')) {
    function lapordata_biblio_item_export_menu_label(): string
    {
        return 'Biblio Item Export';
    }
}

if (!function_exists('lapordata_biblio_item_export_menu_aliases')) {
    function lapordata_biblio_item_export_menu_aliases(): array
    {
        return [
            lapordata_biblio_item_export_menu_label(),
            'Item Export',
            'Biblio Item Export'
        ];
    }
}

if (!function_exists('lapordata_internal_biblio_item_export_menu_label')) {
    function lapordata_internal_biblio_item_export_menu_label(): string
    {
        return '__LAPORDATA_BIBLIO_ITEM_EXPORT__';
    }
}

if (!function_exists('lapordata_prefer_module_menu')) {
    function lapordata_prefer_module_menu(
        Plugins $plugin,
        string $moduleName,
        string $preferredPath,
        array $labelAliases = [],
        array $knownPaths = [],
        string $preferredLabel = '',
        ?string $preferredDescription = null
    ): void {
        $moduleMenus = $plugin->getMenus($moduleName);
        if (!is_array($moduleMenus) || count($moduleMenus) < 2) {
            return;
        }

        $preferredRealPath = realpath($preferredPath);
        if ($preferredRealPath === false) {
            return;
        }

        $aliases = [];
        foreach ($labelAliases as $alias) {
            $normalizedAlias = lapordata_normalize_menu_label($alias);
            if ($normalizedAlias !== '') {
                $aliases[] = $normalizedAlias;
            }
        }
        $aliases = array_values(array_unique($aliases));

        $normalizedKnownPaths = [];
        foreach ($knownPaths as $knownPath) {
            $realPath = realpath($knownPath);
            if ($realPath !== false) {
                $normalizedKnownPaths[] = str_replace('\\', '/', $realPath);
            }
        }
        $normalizedKnownPaths = array_values(array_unique($normalizedKnownPaths));

        $candidateMenus = [];
        foreach ($moduleMenus as $menuId => $menuMeta) {
            $menuLabel = isset($menuMeta[0]) ? lapordata_normalize_menu_label($menuMeta[0]) : '';
            $menuPath = isset($menuMeta[3]) ? realpath((string) $menuMeta[3]) : false;
            $normalizedPath = $menuPath ? str_replace('\\', '/', $menuPath) : '';

            $matchesPreferred = $menuPath && $menuPath === $preferredRealPath;
            $matchesAlias = $menuLabel !== '' && in_array($menuLabel, $aliases, true);
            $matchesKnownPath = $normalizedPath !== '' && in_array($normalizedPath, $normalizedKnownPaths, true);

            if ($matchesPreferred || $matchesAlias || $matchesKnownPath) {
                $candidateMenus[(string) $menuId] = [
                    'path' => $menuPath,
                    'url' => isset($menuMeta[1]) ? (string) $menuMeta[1] : ''
                ];
            }
        }

        if (count($candidateMenus) <= 1) {
            return;
        }

        $keepMenuId = '';
        foreach ($candidateMenus as $menuId => $menuMeta) {
            if (($menuMeta['path'] ?? null) === $preferredRealPath) {
                $keepMenuId = $menuId;
                break;
            }
        }

        if ($keepMenuId === '') {
            $keepMenuId = (string) array_key_first($candidateMenus);
        }

        $removeMenuIds = [];
        foreach ($candidateMenus as $menuId => $menuMeta) {
            if ($menuId !== $keepMenuId) {
                $removeMenuIds[] = $menuId;
            }
        }

        if (empty($removeMenuIds)) {
            return;
        }

        try {
            $pluginReflection = new ReflectionObject($plugin);
            while (!$pluginReflection->hasProperty('menus') && ($parent = $pluginReflection->getParentClass())) {
                $pluginReflection = $parent;
            }

            if (!$pluginReflection->hasProperty('menus')) {
                return;
            }

            $menusProperty = $pluginReflection->getProperty('menus');
            $menusProperty->setAccessible(true);
            $allMenus = $menusProperty->getValue($plugin);
            if (!isset($allMenus[$moduleName]) || !is_array($allMenus[$moduleName])) {
                return;
            }

            if (isset($allMenus[$moduleName][$keepMenuId])) {
                if ($preferredLabel !== '') {
                    $allMenus[$moduleName][$keepMenuId][0] = $preferredLabel;
                }
                if ($preferredDescription !== null) {
                    $allMenus[$moduleName][$keepMenuId][2] = $preferredDescription;
                }
            }

            foreach ($removeMenuIds as $removeMenuId) {
                unset($allMenus[$moduleName][$removeMenuId]);
            }
            $menusProperty->setValue($plugin, $allMenus);
        } catch (Throwable $exception) {
            return;
        }

        try {
            $groupMenu = \SLiMS\GroupMenu::getInstance();
            $groupReflection = new ReflectionObject($groupMenu);
            if ($groupReflection->hasProperty('group')) {
                $groupProperty = $groupReflection->getProperty('group');
                $groupProperty->setAccessible(true);
                $groupData = $groupProperty->getValue($groupMenu);
                if (is_array($groupData)) {
                    foreach ($groupData as $groupName => $groupMenus) {
                        if (!is_array($groupMenus)) {
                            continue;
                        }

                        $groupData[$groupName] = array_values(array_filter($groupMenus, static function ($menuId) use ($removeMenuIds) {
                            return !in_array((string) $menuId, $removeMenuIds, true);
                        }));
                    }
                    $groupProperty->setValue($groupMenu, $groupData);
                }
            }

            if ($groupReflection->hasProperty('plugin_in_group')) {
                $pluginInGroupProperty = $groupReflection->getProperty('plugin_in_group');
                $pluginInGroupProperty->setAccessible(true);
                $pluginIds = $pluginInGroupProperty->getValue($groupMenu);
                if (is_array($pluginIds)) {
                    $pluginIds = array_values(array_filter($pluginIds, static function ($menuId) use ($removeMenuIds) {
                        return !in_array((string) $menuId, $removeMenuIds, true);
                    }));
                    $pluginInGroupProperty->setValue($groupMenu, $pluginIds);
                }
            }
        } catch (Throwable $exception) {
            // keep submenu cleanup best-effort only
        }

        if (isset($_SESSION['priv'][$moduleName]['menus']) && is_array($_SESSION['priv'][$moduleName]['menus'])) {
            $allowedMenus = $_SESSION['priv'][$moduleName]['menus'];
            $removedMenuHashes = [];
            foreach ($removeMenuIds as $removeMenuId) {
                $removedUrl = (string) ($candidateMenus[$removeMenuId]['url'] ?? '');
                if ($removedUrl !== '') {
                    $removedMenuHashes[] = md5($removedUrl);
                }
            }

            $keptMenuUrl = (string) ($candidateMenus[$keepMenuId]['url'] ?? '');
            $keptMenuHash = $keptMenuUrl !== '' ? md5($keptMenuUrl) : '';
            if ($keptMenuHash !== '') {
                $hadRemovedHash = false;
                foreach ($removedMenuHashes as $removedHash) {
                    if (in_array($removedHash, $allowedMenus, true)) {
                        $hadRemovedHash = true;
                        break;
                    }
                }

                if ($hadRemovedHash && !in_array($keptMenuHash, $allowedMenus, true)) {
                    $allowedMenus[] = $keptMenuHash;
                }
            }

            if (!empty($removedMenuHashes)) {
                $allowedMenus = array_values(array_diff($allowedMenus, $removedMenuHashes));
            }

            $_SESSION['priv'][$moduleName]['menus'] = array_values(array_unique($allowedMenus));
        }
    }
}

if (!function_exists('lapordata_require_admin_session')) {
    function lapordata_require_admin_session(): void
    {
        global $sanitizer, $sysconf;

        if (session_status() !== PHP_SESSION_ACTIVE) {
            require SB . 'admin/default/session.inc.php';
        }
        require SB . 'admin/default/session_check.inc.php';
    }
}

if (!function_exists('lapordata_current_plugin_menu_id')) {
    function lapordata_current_plugin_menu_id(string $moduleName, string $filePath): string
    {
        $requestId = trim((string) ($_GET['id'] ?? ''));
        if ($requestId !== '') {
            return $requestId;
        }

        if (!class_exists(Plugins::class)) {
            return md5(realpath($filePath) ?: $filePath);
        }

        $pluginMenus = Plugins::getInstance()->getMenus($moduleName);
        $realFilePath = realpath($filePath);
        if ($realFilePath !== false && is_array($pluginMenus)) {
            foreach ($pluginMenus as $menuId => $menuMeta) {
                $menuPath = isset($menuMeta[3]) ? realpath((string) $menuMeta[3]) : false;
                if ($menuPath && $menuPath === $realFilePath) {
                    return (string) $menuId;
                }
            }
        }

        return md5($realFilePath ?: $filePath);
    }
}

if (!function_exists('lapordata_current_opac_page')) {
    function lapordata_current_opac_page(): string
    {
        return trim((string) ($_GET['p'] ?? ''));
    }
}

if (!function_exists('lapordata_is_visitor_opac_page')) {
    function lapordata_is_visitor_opac_page(): bool
    {
        return lapordata_current_opac_page() === 'visitor';
    }
}

if (!function_exists('lapordata_member_lookup_image_url')) {
    function lapordata_member_lookup_image_url(string $memberImage, int $width = 72): string
    {
        $imageFile = trim($memberImage);
        if ($imageFile === '' || !defined('IMGBS') || !is_file(IMGBS . 'persons/' . $imageFile)) {
            $imageFile = 'person.png';
        }

        $thumbWidth = max(48, $width);
        return SWB . 'lib/minigalnano/createthumb.php?filename=images/persons/' . rawurlencode($imageFile) . '&width=' . $thumbWidth;
    }
}

if (!function_exists('lapordata_lookup_member_suggestions')) {
    function lapordata_lookup_member_suggestions(mysqli $dbs, string $keyword, int $limit = 8): array
    {
        $keyword = preg_replace('/\s+/u', ' ', trim($keyword));
        if ($keyword === '') {
            return [];
        }

        $limit = max(1, min(12, $limit));
        $escapedKeyword = $dbs->escape_string($keyword);
        $escapedLikeAnywhere = '%' . $escapedKeyword . '%';
        $escapedLikePrefix = $escapedKeyword . '%';
        $items = [];

        $sql = "
            SELECT
                member_id,
                member_name,
                COALESCE(NULLIF(TRIM(inst_name), ''), '-') AS inst_name,
                COALESCE(NULLIF(TRIM(member_image), ''), '') AS member_image
            FROM member
            WHERE (
                COALESCE(member_id, '') LIKE '{$escapedLikeAnywhere}'
                OR COALESCE(member_name, '') LIKE '{$escapedLikeAnywhere}'
                OR COALESCE(inst_name, '') LIKE '{$escapedLikeAnywhere}'
            )
            ORDER BY
                CASE
                    WHEN member_id = '{$escapedKeyword}' THEN 0
                    WHEN member_name = '{$escapedKeyword}' THEN 1
                    WHEN member_id LIKE '{$escapedLikePrefix}' THEN 2
                    WHEN member_name LIKE '{$escapedLikePrefix}' THEN 3
                    WHEN inst_name LIKE '{$escapedLikePrefix}' THEN 4
                    ELSE 5
                END,
                member_name ASC,
                member_id ASC
            LIMIT {$limit}
        ";

        if ($query = $dbs->query($sql)) {
            while ($row = $query->fetch_assoc()) {
                $memberId = trim((string) ($row['member_id'] ?? ''));
                $memberName = trim((string) ($row['member_name'] ?? ''));
                if ($memberId === '' || $memberName === '') {
                    continue;
                }

                $institution = trim((string) ($row['inst_name'] ?? '-'));
                $items[] = [
                    'member_id' => $memberId,
                    'member_name' => $memberName,
                    'institution' => $institution !== '' ? $institution : '-',
                    'image_url' => lapordata_member_lookup_image_url((string) ($row['member_image'] ?? ''))
                ];
            }
            $query->free_result();
        }

        return $items;
    }
}

if (!function_exists('lapordata_output_json')) {
    function lapordata_output_json(array $payload): void
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}

if (!function_exists('lapordata_handle_visitor_member_lookup_request')) {
    function lapordata_handle_visitor_member_lookup_request(mysqli $dbs): void
    {
        if (!lapordata_is_visitor_opac_page()) {
            return;
        }

        if ((string) ($_GET['lapordata_member_lookup'] ?? '') !== '1') {
            return;
        }

        $keyword = trim((string) ($_GET['q'] ?? ''));
        if ($keyword === '') {
            lapordata_output_json([
                'ok' => true,
                'items' => []
            ]);
        }

        lapordata_output_json([
            'ok' => true,
            'items' => lapordata_lookup_member_suggestions($dbs, $keyword)
        ]);
    }
}

if (!function_exists('lapordata_inject_visitor_member_lookup_assets')) {
    function lapordata_inject_visitor_member_lookup_assets($opac): void
    {
        if (!is_object($opac) || !lapordata_is_visitor_opac_page()) {
            return;
        }

        $lookupUrl = 'index.php?p=visitor&lapordata_member_lookup=1';
        $lookupUrlJs = json_encode($lookupUrl, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $searchPlaceholderJs = json_encode('Ketik ID atau nama anggota', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $searchHintJs = json_encode('Cari anggota dengan nama atau ID, lalu pilih dari daftar supaya data yang dikirim tetap ID anggota asli.', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $searchingTextJs = json_encode('Mencari anggota...', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $emptyTextJs = json_encode('Anggota tidak ditemukan.', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $errorTextJs = json_encode('Autocomplete anggota gagal dimuat.', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $pickedTextJs = json_encode('Anggota terpilih', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $assetBlock = <<<HTML
<style>
  .lapordata-member-help {
    margin-top: 8px;
    font-size: 12px;
    font-weight: 600;
    line-height: 1.5;
    color: #334155;
  }
  .lapordata-member-dropdown {
    position: absolute;
    top: calc(100% + 10px);
    left: 0;
    right: 0;
    z-index: 80;
    max-height: 320px;
    overflow-y: auto;
    background: #ffffff;
    border: 1px solid rgba(148, 163, 184, 0.45);
    border-radius: 18px;
    box-shadow: 0 20px 45px rgba(15, 23, 42, 0.18);
  }
  .lapordata-member-dropdown.is-hidden,
  .lapordata-member-picked.is-hidden {
    display: none !important;
  }
  .lapordata-member-option,
  .lapordata-member-empty {
    display: flex;
    width: 100%;
    align-items: center;
    gap: 12px;
    padding: 11px 14px;
    border: 0;
    background: transparent;
    text-align: left;
  }
  .lapordata-member-option {
    cursor: pointer;
  }
  .lapordata-member-option + .lapordata-member-option,
  .lapordata-member-empty + .lapordata-member-option,
  .lapordata-member-option + .lapordata-member-empty {
    border-top: 1px solid rgba(226, 232, 240, 0.95);
  }
  .lapordata-member-option:hover,
  .lapordata-member-option.is-active {
    background: rgba(59, 130, 246, 0.08);
  }
  .lapordata-member-avatar {
    width: 42px;
    height: 42px;
    flex: 0 0 42px;
    border-radius: 999px;
    object-fit: cover;
    border: 1px solid rgba(148, 163, 184, 0.35);
    background: #f8fafc;
  }
  .lapordata-member-meta {
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .lapordata-member-name {
    display: block;
    color: #0f172a;
    font-size: 14px;
    font-weight: 800;
    line-height: 1.35;
    word-break: break-word;
  }
  .lapordata-member-sub {
    display: block;
    color: #475569;
    font-size: 12px;
    font-weight: 600;
    line-height: 1.4;
    word-break: break-word;
  }
  .lapordata-member-picked {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-top: 10px;
    padding: 10px 12px;
    border: 1px solid rgba(148, 163, 184, 0.38);
    border-radius: 18px;
    background: #f8fafc;
  }
  .lapordata-member-picked-badge {
    display: inline-block;
    margin-bottom: 3px;
    color: #1d4ed8;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 0.25px;
    text-transform: uppercase;
  }
  .lapordata-member-empty {
    color: #475569;
    font-size: 13px;
    font-weight: 600;
    justify-content: center;
  }
  @media (max-width: 767px) {
    .lapordata-member-dropdown {
      border-radius: 16px;
    }
    .lapordata-member-option,
    .lapordata-member-empty {
      padding: 10px 12px;
    }
    .lapordata-member-avatar {
      width: 38px;
      height: 38px;
      flex-basis: 38px;
    }
  }
</style>
<script>
(function ($) {
  if (!$ || !$.fn) {
    return;
  }

  var lookupUrl = {$lookupUrlJs};
  var searchPlaceholder = {$searchPlaceholderJs};
  var searchHint = {$searchHintJs};
  var searchingText = {$searchingTextJs};
  var emptyText = {$emptyTextJs};
  var loadErrorText = {$errorTextJs};
  var pickedText = {$pickedTextJs};

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function normalizeText(value) {
    return $.trim(String(value || '')).toLowerCase();
  }

  function renderOptionMarkup(item) {
    var institution = $.trim(item.institution || '') || '-';
    return ''
      + '<img class="lapordata-member-avatar" src="' + escapeHtml(item.image_url || '') + '" alt="' + escapeHtml(item.member_name || item.member_id || 'member') + '">'
      + '<span class="lapordata-member-meta">'
      + '<span class="lapordata-member-name">' + escapeHtml(item.member_name || '-') + '</span>'
      + '<span class="lapordata-member-sub">ID: ' + escapeHtml(item.member_id || '-') + ' | ' + escapeHtml(institution) + '</span>'
      + '</span>';
  }

  function attachLookup() {
    var form = $('#visitorCounterForm').first();
    var input = form.find('#memberID, input[name="memberID"]').first();
    var typeSelect = form.find('#visitorType, select[name="visitorType"]').first();

    if (!form.length || !input.length || !typeSelect.length) {
      return false;
    }

    if (input.data('lapordataLookupReady')) {
      return true;
    }
    input.data('lapordataLookupReady', true);

    var fieldContainer = input.closest('.magangkp-field, .form-group').first();
    if (!fieldContainer.length) {
      fieldContainer = input.parent();
    }
    fieldContainer.css('position', 'relative');
    input.attr('autocomplete', 'off');

    var hidden = $('<input>', {
      type: 'hidden',
      id: 'lapordataMemberSelectedId'
    });
    var helper = $('<div class="lapordata-member-help"></div>').text(searchHint);
    var picked = $('<div class="lapordata-member-picked is-hidden"></div>');
    var dropdown = $('<div class="lapordata-member-dropdown is-hidden" role="listbox"></div>');

    input.after(hidden);
    input.after(helper);
    input.after(picked);
    input.after(dropdown);

    var currentItems = [];
    var activeIndex = -1;
    var requestSeq = 0;
    var debounceTimer = 0;

    function isMemberMode() {
      return normalizeText(typeSelect.val()) === 'member';
    }

    function hideDropdown() {
      dropdown.addClass('is-hidden').empty();
      currentItems = [];
      activeIndex = -1;
    }

    function updatePicked(item) {
      if (!item || !item.member_id) {
        picked.addClass('is-hidden').empty();
        return;
      }

      picked
        .html(
          '<img class="lapordata-member-avatar" src="' + escapeHtml(item.image_url || '') + '" alt="' + escapeHtml(item.member_name || item.member_id || 'member') + '">'
          + '<span class="lapordata-member-meta">'
          + '<span class="lapordata-member-picked-badge">' + escapeHtml(pickedText) + '</span>'
          + '<span class="lapordata-member-name">' + escapeHtml(item.member_name || '-') + '</span>'
          + '<span class="lapordata-member-sub">ID: ' + escapeHtml(item.member_id || '-') + ' | ' + escapeHtml(item.institution || '-') + '</span>'
          + '</span>'
        )
        .removeClass('is-hidden');
    }

    function clearSelection(resetDisplay) {
      hidden.val('');
      input.removeData('lapordataSelectedMember');
      if (resetDisplay === true) {
        input.val('');
      }
      updatePicked(null);
    }

    function selectItem(item) {
      hidden.val(item.member_id || '');
      input.val(item.member_name || item.member_id || '');
      input.data('lapordataSelectedMember', item);
      updatePicked(item);
      helper.text(searchHint);
      hideDropdown();
    }

    function updateActiveOption() {
      dropdown.find('.lapordata-member-option').removeClass('is-active');
      if (activeIndex < 0) {
        return;
      }

      var activeNode = dropdown.find('.lapordata-member-option').eq(activeIndex);
      activeNode.addClass('is-active');
      if (activeNode.length && typeof activeNode[0].scrollIntoView === 'function') {
        activeNode[0].scrollIntoView({block: 'nearest'});
      }
    }

    function renderDropdown(items) {
      dropdown.empty();
      currentItems = $.isArray(items) ? items.slice(0) : [];

      if (!currentItems.length) {
        activeIndex = -1;
        dropdown
          .removeClass('is-hidden')
          .append($('<div class="lapordata-member-empty"></div>').text(emptyText));
        return;
      }

      activeIndex = 0;
      $.each(currentItems, function (index, item) {
        var option = $('<button type="button" class="lapordata-member-option"></button>');
        option.attr('data-index', index);
        option.html(renderOptionMarkup(item));
        dropdown.append(option);
      });
      dropdown.removeClass('is-hidden');
      updateActiveOption();
    }

    function maybeAutoPick(query, items) {
      if (!$.isArray(items) || items.length !== 1) {
        return false;
      }

      var onlyItem = items[0];
      var normalizedQuery = normalizeText(query);
      if (normalizedQuery === '') {
        return false;
      }

      if (normalizeText(onlyItem.member_id) === normalizedQuery || normalizeText(onlyItem.member_name) === normalizedQuery) {
        selectItem(onlyItem);
        return true;
      }

      return false;
    }

    function fetchSuggestions(query) {
      if (!isMemberMode()) {
        hideDropdown();
        return;
      }

      requestSeq += 1;
      var seq = requestSeq;
      helper.text(searchingText);

      $.ajax({
        url: lookupUrl,
        type: 'GET',
        dataType: 'json',
        cache: false,
        data: {q: query}
      }).done(function (response) {
        if (seq !== requestSeq) {
          return;
        }

        var items = $.isArray(response && response.items) ? response.items : [];
        if (!items.length) {
          helper.text(emptyText);
          renderDropdown([]);
          return;
        }

        helper.text(searchHint);
        if (maybeAutoPick(query, items)) {
          return;
        }
        renderDropdown(items);
      }).fail(function () {
        if (seq !== requestSeq) {
          return;
        }
        helper.text(loadErrorText);
        hideDropdown();
      });
    }

    function scheduleLookup(query) {
      window.clearTimeout(debounceTimer);
      debounceTimer = window.setTimeout(function () {
        fetchSuggestions(query);
      }, 180);
    }

    function refreshByType() {
      if (isMemberMode()) {
        input.attr('placeholder', searchPlaceholder);
        helper.show().text(searchHint);
        if (hidden.val()) {
          picked.removeClass('is-hidden');
        }
        return;
      }

      hideDropdown();
      clearSelection(false);
      helper.hide();
    }

    input.on('input', function () {
      if (!isMemberMode()) {
        return;
      }

      clearSelection(false);
      var query = $.trim(input.val());
      if (query === '') {
        helper.text(searchHint);
        hideDropdown();
        return;
      }

      scheduleLookup(query);
    });

    input.on('focus', function () {
      if (!isMemberMode()) {
        return;
      }

      var query = $.trim(input.val());
      if (query !== '' && !hidden.val()) {
        scheduleLookup(query);
      }
    });

    input.on('keydown', function (event) {
      if (dropdown.hasClass('is-hidden') || !currentItems.length) {
        return;
      }

      if (event.key === 'ArrowDown') {
        event.preventDefault();
        activeIndex = (activeIndex + 1) % currentItems.length;
        updateActiveOption();
      } else if (event.key === 'ArrowUp') {
        event.preventDefault();
        activeIndex = (activeIndex - 1 + currentItems.length) % currentItems.length;
        updateActiveOption();
      } else if (event.key === 'Enter' && activeIndex >= 0) {
        event.preventDefault();
        selectItem(currentItems[activeIndex]);
      } else if (event.key === 'Escape') {
        hideDropdown();
      }
    });

    input.on('blur', function () {
      window.setTimeout(function () {
        hideDropdown();
      }, 180);
    });

    dropdown.on('mousedown', '.lapordata-member-option', function (event) {
      event.preventDefault();
    });

    dropdown.on('click', '.lapordata-member-option', function () {
      var index = parseInt($(this).attr('data-index') || '-1', 10);
      if (index < 0 || !currentItems[index]) {
        return;
      }

      selectItem(currentItems[index]);
      input.focus();
    });

    typeSelect.on('change', refreshByType);

    var formNode = form.get(0);
    if (formNode && !formNode.__lapordataMemberLookupCapture) {
      formNode.__lapordataMemberLookupCapture = true;
      formNode.addEventListener('submit', function () {
        if (!isMemberMode()) {
          return;
        }

        var selectedId = $.trim(hidden.val());
        if (selectedId === '') {
          return;
        }

        var displayValue = input.val();
        input.val(selectedId);
        window.setTimeout(function () {
          input.val(displayValue);
        }, 0);
      }, true);
    }

    $(document).on('ajaxComplete.lapordataMemberLookup', function (_event, _xhr, settings) {
      var requestUrl = String((settings && settings.url) || '');
      if (requestUrl.indexOf('index.php?p=visitor') === -1) {
        return;
      }

      if ($.trim(input.val()) === '') {
        clearSelection(false);
        helper.text(searchHint);
      }
    });

    refreshByType();
    return true;
  }

  function bootLookupWithRetry() {
    var attempts = 0;
    var timer = window.setInterval(function () {
      attempts += 1;
      if (attachLookup() || attempts >= 30) {
        window.clearInterval(timer);
      }
    }, 250);
  }

  $(bootLookupWithRetry);
  $(window).on('load', bootLookupWithRetry);
})(window.jQuery);
</script>
HTML;

        $opac->js = ($opac->js ?? '') . $assetBlock;
    }
}

if (!function_exists('lapordata_boot_visitor_member_lookup')) {
    function lapordata_boot_visitor_member_lookup($opac): void
    {
        global $dbs;

        if (!lapordata_is_visitor_opac_page()) {
            return;
        }

        if ($dbs instanceof mysqli) {
            lapordata_handle_visitor_member_lookup_request($dbs);
        }

        lapordata_inject_visitor_member_lookup_assets($opac);
    }
}

if (!function_exists('lapordata_truthy')) {
    function lapordata_truthy($value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        $normalized = strtolower(trim((string) $value));
        return in_array($normalized, ['1', 'true', 'yes', 'on'], true);
    }
}

if (!function_exists('lapordata_safe_date')) {
    function lapordata_safe_date($value, string $fallback = ''): string
    {
        $value = trim((string) $value);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return $fallback;
        }

        $date = DateTime::createFromFormat('Y-m-d', $value);
        if (!$date || $date->format('Y-m-d') !== $value) {
            return $fallback;
        }

        return $value;
    }
}

if (!function_exists('lapordata_has_column')) {
    function lapordata_has_column(mysqli $dbs, string $column, string $table): bool
    {
        $tableEsc = $dbs->escape_string($table);
        $columnEsc = $dbs->escape_string($column);
        if ($query = $dbs->query("SHOW COLUMNS FROM `{$tableEsc}` LIKE '{$columnEsc}'")) {
            $exists = $query->num_rows > 0;
            $query->free_result();
            return $exists;
        }

        return false;
    }
}

if (!function_exists('lapordata_has_table')) {
    function lapordata_has_table(mysqli $dbs, string $table): bool
    {
        $tableEsc = $dbs->escape_string($table);
        if ($query = $dbs->query("SHOW TABLES LIKE '{$tableEsc}'")) {
            $exists = $query->num_rows > 0;
            $query->free_result();
            return $exists;
        }

        return false;
    }
}

if (!function_exists('lapordata_format_datetime')) {
    function lapordata_format_datetime($value): string
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '-';
        }

        $timestamp = strtotime($value);
        if ($timestamp === false) {
            return $value;
        }

        return date('d-m-Y H:i:s', $timestamp);
    }
}

if (!function_exists('lapordata_format_date_label')) {
    function lapordata_format_date_label($value): string
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '-';
        }

        $timestamp = strtotime($value);
        if ($timestamp === false) {
            return $value;
        }

        return date('d-m-Y', $timestamp);
    }
}

if (!function_exists('lapordata_visitor_type_label')) {
    function lapordata_visitor_type_label(string $type): string
    {
        $map = [
            'member' => 'Member',
            'non_member' => 'Non Member',
            'rombongan' => 'Rombongan',
            'all' => 'Semua'
        ];

        return $map[$type] ?? ucfirst(str_replace('_', ' ', $type));
    }
}

if (!function_exists('lapordata_collect_visitor_filters')) {
    function lapordata_collect_visitor_filters(): array
    {
        $today = date('Y-m-d');
        $dateFrom = lapordata_safe_date($_GET['date_from'] ?? $today, $today);
        $dateUntil = lapordata_safe_date($_GET['date_until'] ?? $today, $today);

        if ($dateFrom !== '' && $dateUntil !== '' && $dateFrom > $dateUntil) {
            [$dateFrom, $dateUntil] = [$dateUntil, $dateFrom];
        }

        $visitorType = trim((string) ($_GET['visitor_type'] ?? 'all'));
        if (!in_array($visitorType, ['all', 'member', 'non_member', 'rombongan'], true)) {
            $visitorType = 'all';
        }

        $visitLocation = trim((string) ($_GET['visit_location'] ?? 'all'));
        if ($visitLocation === '') {
            $visitLocation = 'all';
        }

        return [
            'date_from' => $dateFrom,
            'date_until' => $dateUntil,
            'all_dates' => lapordata_truthy($_GET['all_dates'] ?? false),
            'visitor_type' => $visitorType,
            'visit_location' => $visitLocation
        ];
    }
}

if (!function_exists('lapordata_get_visitor_location_options')) {
    function lapordata_get_visitor_location_options(mysqli $dbs, array $sysconf): array
    {
        $options = [];

        if ($settingQuery = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='lokasimaps_locations' LIMIT 1")) {
            if ($settingRow = $settingQuery->fetch_assoc()) {
                $stored = @unserialize((string) ($settingRow['setting_value'] ?? ''));
                if (is_array($stored)) {
                    foreach ($stored as $locationRow) {
                        if (!is_array($locationRow)) {
                            continue;
                        }

                        $label = trim(strip_tags((string) ($locationRow['label'] ?? '')));
                        if ($label !== '') {
                            $options[$label] = $label;
                        }
                    }
                }
            }
            $settingQuery->free_result();
        }

        if (lapordata_has_column($dbs, 'visit_location', 'visitor_count')) {
            $sql = "SELECT DISTINCT TRIM(COALESCE(visit_location, '')) AS visit_location
                    FROM visitor_count
                    WHERE visit_location IS NOT NULL AND TRIM(visit_location) <> ''
                    ORDER BY visit_location ASC";
            if ($query = $dbs->query($sql)) {
                while ($row = $query->fetch_assoc()) {
                    $label = trim((string) ($row['visit_location'] ?? ''));
                    if ($label !== '') {
                        $options[$label] = $label;
                    }
                }
                $query->free_result();
            }
        }

        if (count($options) < 1) {
            $fallbackLocation = trim(strip_tags((string) ($sysconf['library_name'] ?? 'Lokasi Utama')));
            if ($fallbackLocation !== '') {
                $options[$fallbackLocation] = $fallbackLocation;
            }
        }

        return array_values($options);
    }
}

if (!function_exists('lapordata_build_visitor_context')) {
    function lapordata_build_visitor_context(mysqli $dbs, array $sysconf): array
    {
        $hasGroupCount = lapordata_has_column($dbs, 'group_count', 'visitor_count');
        $hasVisitorType = lapordata_has_column($dbs, 'visitor_type', 'visitor_count');
        $hasVisitorPurpose = lapordata_has_column($dbs, 'visitor_purpose', 'visitor_count');
        $hasGroupPurpose = lapordata_has_column($dbs, 'group_purpose', 'visitor_count');
        $hasVisitorGender = lapordata_has_column($dbs, 'visitor_gender', 'visitor_count');
        $hasMemberGender = lapordata_has_column($dbs, 'gender', 'member');
        $hasMemberTypeId = lapordata_has_column($dbs, 'member_type_id', 'member');
        $hasMemberTypeTable = lapordata_has_table($dbs, 'mst_member_type');
        $hasMemberTypeName = $hasMemberTypeTable
            ? lapordata_has_column($dbs, 'member_type_name', 'mst_member_type')
            : false;
        $hasGroupMale = lapordata_has_column($dbs, 'group_gender_male', 'visitor_count');
        $hasGroupFemale = lapordata_has_column($dbs, 'group_gender_female', 'visitor_count');
        $hasVisitLocation = lapordata_has_column($dbs, 'visit_location', 'visitor_count');

        $weightExpr = $hasGroupCount
            ? "CASE WHEN vc.group_count IS NULL OR vc.group_count < 1 THEN 1 ELSE vc.group_count END"
            : "1";

        $resolvedTypeExpr = $hasVisitorType
            ? "CASE
                WHEN COALESCE(vc.visitor_type, '') <> '' THEN vc.visitor_type
                WHEN COALESCE(vc.member_id, '') <> '' THEN 'member'
                WHEN COALESCE(vc.member_name, '') LIKE '%Rombongan%' THEN 'rombongan'
                ELSE 'non_member'
              END"
            : "CASE
                WHEN COALESCE(vc.member_id, '') <> '' THEN 'member'
                WHEN COALESCE(vc.member_name, '') LIKE '%Rombongan%' THEN 'rombongan'
                ELSE 'non_member'
              END";

        $purposeExpr = "'Belum diisi'";
        if ($hasVisitorPurpose && $hasGroupPurpose) {
            $purposeExpr = "CASE
                WHEN {$resolvedTypeExpr} = 'rombongan'
                    THEN COALESCE(NULLIF(TRIM(vc.group_purpose), ''), NULLIF(TRIM(vc.visitor_purpose), ''), 'Belum diisi')
                ELSE COALESCE(NULLIF(TRIM(vc.visitor_purpose), ''), 'Belum diisi')
            END";
        } elseif ($hasVisitorPurpose) {
            $purposeExpr = "COALESCE(NULLIF(TRIM(vc.visitor_purpose), ''), 'Belum diisi')";
        } elseif ($hasGroupPurpose) {
            $purposeExpr = "COALESCE(NULLIF(TRIM(vc.group_purpose), ''), 'Belum diisi')";
        }

        $maleSingleExpr = $hasVisitorGender
            ? "CASE
                WHEN LOWER(REPLACE(TRIM(COALESCE(vc.visitor_gender, '')), '-', ' ')) IN ('1', 'laki laki', 'laki', 'pria', 'male', 'l', 'm') THEN 1
                ELSE 0
              END"
            : "0";
        $femaleSingleExpr = $hasVisitorGender
            ? "CASE
                WHEN LOWER(REPLACE(TRIM(COALESCE(vc.visitor_gender, '')), '-', ' ')) IN ('0', 'perempuan', 'wanita', 'female', 'p', 'f') THEN 1
                ELSE 0
              END"
            : "0";
        $maleMemberExpr = $hasMemberGender
            ? "CASE WHEN COALESCE(CAST(m.gender AS CHAR), '') IN ('1', 'male', 'Male', 'M', 'm') THEN 1 ELSE 0 END"
            : "0";
        $femaleMemberExpr = $hasMemberGender
            ? "CASE WHEN COALESCE(CAST(m.gender AS CHAR), '') IN ('0', 'female', 'Female', 'F', 'f') THEN 1 ELSE 0 END"
            : "0";

        $maleExpr = "CASE
            WHEN {$resolvedTypeExpr} = 'rombongan' THEN " . ($hasGroupMale ? "COALESCE(vc.group_gender_male, 0)" : "0") . "
            WHEN {$resolvedTypeExpr} = 'member' THEN {$maleMemberExpr}
            WHEN {$resolvedTypeExpr} = 'non_member' THEN {$maleSingleExpr}
            ELSE 0
        END";

        $femaleExpr = "CASE
            WHEN {$resolvedTypeExpr} = 'rombongan' THEN " . ($hasGroupFemale ? "COALESCE(vc.group_gender_female, 0)" : "0") . "
            WHEN {$resolvedTypeExpr} = 'member' THEN {$femaleMemberExpr}
            WHEN {$resolvedTypeExpr} = 'non_member' THEN {$femaleSingleExpr}
            ELSE 0
        END";

        $visitLocationExpr = $hasVisitLocation
            ? "COALESCE(NULLIF(TRIM(vc.visit_location), ''), '-')"
            : "'-'";
        $memberTypeExpr = ($hasMemberTypeId && $hasMemberTypeTable && $hasMemberTypeName)
            ? "COALESCE(NULLIF(TRIM(mt.member_type_name), ''), '-')"
            : "'-'";
        $memberTypeJoinSql = ($hasMemberTypeId && $hasMemberTypeTable && $hasMemberTypeName)
            ? "LEFT JOIN mst_member_type mt ON mt.member_type_id = m.member_type_id"
            : "";

        return [
            'weight_expr' => $weightExpr,
            'resolved_type_expr' => $resolvedTypeExpr,
            'purpose_expr' => $purposeExpr,
            'male_expr' => $maleExpr,
            'female_expr' => $femaleExpr,
            'visit_location_expr' => $visitLocationExpr,
            'member_type_expr' => $memberTypeExpr,
            'member_type_join_sql' => $memberTypeJoinSql,
            'has_visit_location' => $hasVisitLocation,
            'visit_location_options' => lapordata_get_visitor_location_options($dbs, $sysconf)
        ];
    }
}

if (!function_exists('lapordata_build_visitor_filter_sql')) {
    function lapordata_build_visitor_filter_sql(mysqli $dbs, array $filters, array $context): array
    {
        $normalized = $filters;
        $where = [];

        if (empty($normalized['all_dates'])) {
            $where[] = "vc.checkin_date >= '" . $dbs->escape_string($normalized['date_from'] . ' 00:00:00') . "'";
            $where[] = "vc.checkin_date <= '" . $dbs->escape_string($normalized['date_until'] . ' 23:59:59') . "'";
        }

        if ($normalized['visitor_type'] !== 'all') {
            $where[] = $context['resolved_type_expr'] . " = '" . $dbs->escape_string($normalized['visitor_type']) . "'";
        }

        if (!empty($context['has_visit_location']) && $normalized['visit_location'] !== 'all') {
            $where[] = "TRIM(COALESCE(vc.visit_location, '')) = '" . $dbs->escape_string($normalized['visit_location']) . "'";
        }

        return [
            'filters' => $normalized,
            'where_sql' => count($where) > 0 ? implode(' AND ', $where) : '1=1'
        ];
    }
}

if (!function_exists('lapordata_fetch_visitor_summary')) {
    function lapordata_fetch_visitor_summary(mysqli $dbs, array $context, string $whereSql): array
    {
        $summary = [
            'row_total' => 0,
            'person_total' => 0,
            'member_total' => 0,
            'non_member_total' => 0,
            'rombongan_total' => 0
        ];

        $summarySql = "
            SELECT
                COUNT(vc.visitor_id) AS row_total,
                COALESCE(SUM({$context['weight_expr']}), 0) AS person_total,
                COALESCE(SUM(CASE WHEN {$context['resolved_type_expr']} = 'member' THEN {$context['weight_expr']} ELSE 0 END), 0) AS member_total,
                COALESCE(SUM(CASE WHEN {$context['resolved_type_expr']} = 'non_member' THEN {$context['weight_expr']} ELSE 0 END), 0) AS non_member_total,
                COALESCE(SUM(CASE WHEN {$context['resolved_type_expr']} = 'rombongan' THEN {$context['weight_expr']} ELSE 0 END), 0) AS rombongan_total
            FROM visitor_count vc
            WHERE {$whereSql}
        ";

        if ($result = $dbs->query($summarySql)) {
            if ($row = $result->fetch_assoc()) {
                $summary['row_total'] = (int) ($row['row_total'] ?? 0);
                $summary['person_total'] = (int) ($row['person_total'] ?? 0);
                $summary['member_total'] = (int) ($row['member_total'] ?? 0);
                $summary['non_member_total'] = (int) ($row['non_member_total'] ?? 0);
                $summary['rombongan_total'] = (int) ($row['rombongan_total'] ?? 0);
            }
            $result->free_result();
        }

        return $summary;
    }
}

if (!function_exists('lapordata_fetch_visitor_rows')) {
    function lapordata_fetch_visitor_rows(mysqli $dbs, array $context, string $whereSql): array
    {
        $rows = [];
        $sql = "
            SELECT
                vc.visitor_id,
                vc.checkin_date,
                COALESCE(vc.member_id, '') AS member_id,
                COALESCE(vc.member_name, '') AS member_name,
                COALESCE(vc.institution, '') AS institution,
                {$context['visit_location_expr']} AS visit_location,
                {$context['resolved_type_expr']} AS visitor_type_resolved,
                {$context['purpose_expr']} AS purpose_resolved,
                {$context['member_type_expr']} AS member_type_display,
                {$context['weight_expr']} AS person_total,
                {$context['male_expr']} AS male_total,
                {$context['female_expr']} AS female_total
            FROM visitor_count vc
            LEFT JOIN member m ON m.member_id = vc.member_id
            {$context['member_type_join_sql']}
            WHERE {$whereSql}
            ORDER BY vc.checkin_date DESC, vc.visitor_id DESC
        ";

        if ($result = $dbs->query($sql)) {
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            $result->free_result();
        }

        return $rows;
    }
}

if (!function_exists('lapordata_require_approval_helpers')) {
    function lapordata_require_approval_helpers(): void
    {
        if (!function_exists('peminjamanBuildAdminFilterSql')) {
            $helperPath = SB . 'plugins/MagangKp/peminjaman/lib.php';
            if (is_file($helperPath)) {
                require_once $helperPath;
            }
        }
    }
}

if (!function_exists('lapordata_approval_base_file')) {
    function lapordata_approval_base_file(): string
    {
        $preferred = SB . 'plugins/MagangKp/updateterbaru/approval.php';
        if (is_file($preferred)) {
            return $preferred;
        }

        return SB . 'plugins/MagangKp/peminjaman/approval.php';
    }
}

if (!function_exists('lapordata_collect_approval_filters')) {
    function lapordata_collect_approval_filters(): array
    {
        $today = date('Y-m-d');
        $status = trim((string) ($_GET['status'] ?? 'all'));
        $actionType = trim((string) ($_GET['action_type'] ?? 'all'));
        $visitLocation = trim((string) ($_GET['visit_location'] ?? 'all'));
        $dateFrom = lapordata_safe_date($_GET['date_from'] ?? $today, $today);
        $dateTo = lapordata_safe_date($_GET['date_to'] ?? $today, $today);

        $allowedStatus = ['all', 'pending', 'processing', 'approved', 'rejected', 'partial', 'failed'];
        if (!in_array($status, $allowedStatus, true)) {
            $status = 'all';
        }

        $allowedAction = ['all', 'loan', 'return', 'extend', 'renew', 'renewal'];
        if (!in_array($actionType, $allowedAction, true)) {
            $actionType = 'all';
        }

        if ($visitLocation === '') {
            $visitLocation = 'all';
        }

        if ($dateFrom !== '' && $dateTo !== '' && $dateFrom > $dateTo) {
            [$dateFrom, $dateTo] = [$dateTo, $dateFrom];
        }

        return [
            'status' => $status,
            'action_type' => $actionType,
            'visit_location' => $visitLocation,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'keyword' => ''
        ];
    }
}

if (!function_exists('lapordata_get_approval_location_options')) {
    function lapordata_get_approval_location_options(mysqli $dbs, array $sysconf): array
    {
        lapordata_require_approval_helpers();

        $options = [];
        if (function_exists('peminjamanGetLocationOptions')) {
            foreach (peminjamanGetLocationOptions($dbs, $sysconf) as $location) {
                $label = trim((string) $location);
                if ($label !== '') {
                    $options[$label] = $label;
                }
            }
        }

        if (function_exists('peminjamanGetDistinctVisitLocations')) {
            foreach (peminjamanGetDistinctVisitLocations($dbs) as $location) {
                $label = trim((string) $location);
                if ($label !== '') {
                    $options[$label] = $label;
                }
            }
        }

        return array_values($options);
    }
}

if (!function_exists('lapordata_build_approval_filter_sql')) {
    function lapordata_build_approval_filter_sql(mysqli $dbs, array $filters): array
    {
        lapordata_require_approval_helpers();

        if (function_exists('peminjamanBuildAdminFilterSql')) {
            return peminjamanBuildAdminFilterSql($dbs, $filters);
        }

        return [
            'where_sql' => '',
            'status' => $filters['status'] ?? 'all',
            'action_type' => $filters['action_type'] ?? 'all',
            'visit_location' => $filters['visit_location'] ?? 'all',
            'keyword' => '',
            'date_from' => $filters['date_from'] ?? '',
            'date_to' => $filters['date_to'] ?? ''
        ];
    }
}

if (!function_exists('lapordata_action_label')) {
    function lapordata_action_label(string $action): string
    {
        lapordata_require_approval_helpers();

        if (function_exists('peminjamanActionLabel')) {
            return (string) peminjamanActionLabel($action);
        }

        $map = [
            'loan' => 'Pinjam',
            'return' => 'Kembali',
            'extend' => 'Perpanjang',
            'renew' => 'Perpanjang',
            'renewal' => 'Perpanjang'
        ];

        return $map[$action] ?? ucfirst($action);
    }
}

if (!function_exists('lapordata_status_label')) {
    function lapordata_status_label(string $status): string
    {
        lapordata_require_approval_helpers();

        if (function_exists('peminjamanStatusLabel')) {
            return (string) peminjamanStatusLabel($status);
        }

        $map = [
            'pending' => 'Pending',
            'processing' => 'Processing',
            'approved' => 'Approved',
            'rejected' => 'Rejected',
            'partial' => 'Partial',
            'failed' => 'Failed'
        ];

        return $map[$status] ?? ucfirst($status);
    }
}

if (!function_exists('lapordata_fetch_approval_dataset')) {
    function lapordata_fetch_approval_dataset(mysqli $dbs, array $filters): array
    {
        lapordata_require_approval_helpers();

        $filterData = lapordata_build_approval_filter_sql($dbs, $filters);
        $effectiveWhereSql = trim((string) ($filterData['where_sql'] ?? ''));
        $effectiveWhereSql = $effectiveWhereSql !== '' ? (' ' . $effectiveWhereSql) : '';

        $rows = [];
        $sql = "SELECT
                    r.request_id,
                    r.request_code,
                    r.member_id,
                    r.member_name,
                    r.member_email,
                    r.member_type_name,
                    r.visit_location,
                    r.action_type,
                    r.status,
                    r.request_note,
                    r.admin_note,
                    r.process_result,
                    r.requested_at,
                    r.decided_at,
                    r.processed_at,
                    r.admin_username
                FROM peminjaman_request AS r{$effectiveWhereSql}
                ORDER BY r.requested_at DESC, r.request_id DESC";

        if ($query = $dbs->query($sql)) {
            while ($row = $query->fetch_assoc()) {
                $rows[] = $row;
            }
            $query->free_result();
        }

        $itemMap = [];
        if (count($rows) > 0) {
            $idList = array_map(static function ($row) {
                return (int) ($row['request_id'] ?? 0);
            }, $rows);
            $idList = array_values(array_filter($idList, static function ($value) {
                return $value > 0;
            }));

            if (count($idList) > 0) {
                $idListSql = implode(',', $idList);
                $itemSql = "SELECT
                                ri.request_item_id,
                                ri.request_id,
                                ri.item_code,
                                ri.loan_id,
                                ri.item_status,
                                ri.process_message,
                                COALESCE(b.title, '-') AS title,
                                COALESCE(loc.location_name, '-') AS item_location,
                                COALESCE(loan_by_id.is_lent, 0) AS loan_is_lent,
                                COALESCE(loan_by_id.is_return, 0) AS loan_is_return,
                                COALESCE(loan_by_id.due_date, '') AS loan_due_date,
                                COALESCE(loan_by_id.return_date, '') AS loan_return_date,
                                COALESCE(loan_by_id.renewed, 0) AS loan_renewed,
                                COALESCE(loan_by_id.loan_date, '') AS loan_loan_date
                            FROM peminjaman_request_item AS ri
                            LEFT JOIN item AS i ON ri.item_code = i.item_code
                            LEFT JOIN biblio AS b ON i.biblio_id = b.biblio_id
                            LEFT JOIN mst_location AS loc ON i.location_id = loc.location_id
                            LEFT JOIN loan AS loan_by_id ON (ri.loan_id IS NOT NULL AND ri.loan_id > 0 AND loan_by_id.loan_id = ri.loan_id)
                            WHERE ri.request_id IN ({$idListSql})
                            ORDER BY ri.request_id ASC, ri.request_item_id ASC";

                if ($itemQuery = $dbs->query($itemSql)) {
                    while ($itemRow = $itemQuery->fetch_assoc()) {
                        $requestId = (int) ($itemRow['request_id'] ?? 0);
                        if (!isset($itemMap[$requestId])) {
                            $itemMap[$requestId] = [];
                        }
                        $itemMap[$requestId][] = $itemRow;
                    }
                    $itemQuery->free_result();
                }

                $itemCodeSet = [];
                foreach ($itemMap as $itemRows) {
                    foreach ($itemRows as $itemRow) {
                        $itemCode = trim((string) ($itemRow['item_code'] ?? ''));
                        if ($itemCode !== '') {
                            $itemCodeSet[$itemCode] = $itemCode;
                        }
                    }
                }

                $onLoanMap = [];
                if (count($itemCodeSet) > 0 && function_exists('peminjamanGetOnLoanCountMapByItemCodes')) {
                    $onLoanMap = peminjamanGetOnLoanCountMapByItemCodes($dbs, array_values($itemCodeSet));
                }

                foreach ($itemMap as $requestId => $itemRows) {
                    foreach ($itemRows as $index => $itemRow) {
                        $code = trim((string) ($itemRow['item_code'] ?? ''));
                        $itemMap[$requestId][$index]['currently_on_loan'] = $code !== '' ? (int) ($onLoanMap[$code] ?? 0) : 0;
                    }
                }

                foreach ($rows as &$rowRef) {
                    $requestId = (int) ($rowRef['request_id'] ?? 0);
                    $rowItems = $itemMap[$requestId] ?? [];
                    $rowRef['item_total'] = count($rowItems);
                    $rowRef['item_approved'] = 0;
                    $rowRef['item_failed'] = 0;
                    $rowRef['item_rejected'] = 0;
                    $itemList = [];

                    foreach ($rowItems as $itemRow) {
                        $statusKey = strtolower(trim((string) ($itemRow['item_status'] ?? '')));
                        if ($statusKey === 'approved') {
                            $rowRef['item_approved']++;
                        } elseif ($statusKey === 'failed') {
                            $rowRef['item_failed']++;
                        } elseif ($statusKey === 'rejected') {
                            $rowRef['item_rejected']++;
                        }

                        $itemCode = trim((string) ($itemRow['item_code'] ?? ''));
                        $loanId = (int) ($itemRow['loan_id'] ?? 0);
                        if ($itemCode === '') {
                            $itemList[] = '#LOAN-' . max(0, $loanId);
                        } elseif ($loanId > 0) {
                            $itemList[] = $itemCode . ' (#' . $loanId . ')';
                        } else {
                            $itemList[] = $itemCode;
                        }
                    }

                    $rowRef['item_list'] = implode(', ', $itemList);
                }
                unset($rowRef);
            }
        }

        if (count($rows) > 0) {
            $buildLoanCycleKey = static function (array $requestRow, array $requestItems): string {
                $loanIds = [];
                foreach ($requestItems as $requestItem) {
                    $loanId = (int) ($requestItem['loan_id'] ?? 0);
                    if ($loanId > 0) {
                        $loanIds[$loanId] = true;
                    }
                }

                if (count($loanIds) < 1) {
                    return 'request:' . (int) ($requestRow['request_id'] ?? 0);
                }

                $ids = array_keys($loanIds);
                sort($ids, SORT_NUMERIC);
                return 'loan:' . implode(',', $ids);
            };

            $cycleBuckets = [];
            $cycleOrder = [];
            foreach ($rows as $rowData) {
                $requestId = (int) ($rowData['request_id'] ?? 0);
                $cycleKey = $buildLoanCycleKey($rowData, $itemMap[$requestId] ?? []);
                $statusNorm = strtolower(trim((string) ($rowData['status'] ?? 'pending')));

                if (!isset($cycleBuckets[$cycleKey])) {
                    $cycleBuckets[$cycleKey] = [
                        'fallback' => $rowData,
                        'preferred' => null
                    ];
                    $cycleOrder[] = $cycleKey;
                }

                if ($statusNorm === 'pending') {
                    $cycleBuckets[$cycleKey]['preferred'] = $rowData;
                    continue;
                }

                if ($statusNorm === 'processing') {
                    $currentPreferred = $cycleBuckets[$cycleKey]['preferred'];
                    $currentPreferredStatus = strtolower(trim((string) ($currentPreferred['status'] ?? '')));
                    if ($currentPreferred === null || $currentPreferredStatus !== 'pending') {
                        $cycleBuckets[$cycleKey]['preferred'] = $rowData;
                    }
                }
            }

            $collapsedRows = [];
            foreach ($cycleOrder as $cycleKey) {
                $bucket = $cycleBuckets[$cycleKey];
                $collapsedRows[] = $bucket['preferred'] ?? $bucket['fallback'];
            }
            $rows = $collapsedRows;
        }

        $keptRequestIds = [];
        foreach ($rows as $row) {
            $requestId = (int) ($row['request_id'] ?? 0);
            if ($requestId > 0) {
                $keptRequestIds[$requestId] = true;
            }
        }
        foreach (array_keys($itemMap) as $requestId) {
            if (!isset($keptRequestIds[(int) $requestId])) {
                unset($itemMap[$requestId]);
            }
        }

        $summary = [
            'total_requests' => count($rows),
            'total_items' => 0,
            'pending' => 0,
            'processing' => 0,
            'approved' => 0,
            'rejected' => 0,
            'partial' => 0,
            'failed' => 0
        ];

        foreach ($rows as $row) {
            $summary['total_items'] += (int) ($row['item_total'] ?? 0);
            $status = strtolower(trim((string) ($row['status'] ?? 'pending')));
            if (isset($summary[$status])) {
                $summary[$status]++;
            }
        }

        return [
            'filters' => $filterData,
            'rows' => $rows,
            'item_map' => $itemMap,
            'summary' => $summary
        ];
    }
}

if (!function_exists('lapordata_build_approval_item_rows')) {
    function lapordata_build_approval_item_rows(array $rows, array $itemMap): array
    {
        $flatRows = [];
        foreach ($rows as $row) {
            $requestId = (int) ($row['request_id'] ?? 0);
            $items = $itemMap[$requestId] ?? [];
            foreach ($items as $itemRow) {
                $flatRows[] = [
                    'request_code' => (string) ($row['request_code'] ?? '-'),
                    'request_id' => $requestId,
                    'requested_at' => (string) ($row['requested_at'] ?? ''),
                    'member_id' => (string) ($row['member_id'] ?? ''),
                    'member_name' => (string) ($row['member_name'] ?? ''),
                    'action_type' => (string) ($row['action_type'] ?? ''),
                    'request_status' => (string) ($row['status'] ?? ''),
                    'item_code' => (string) ($itemRow['item_code'] ?? ''),
                    'title' => (string) ($itemRow['title'] ?? '-'),
                    'item_location' => (string) ($itemRow['item_location'] ?? '-'),
                    'item_status' => (string) ($itemRow['item_status'] ?? ''),
                    'loan_id' => (int) ($itemRow['loan_id'] ?? 0),
                    'currently_on_loan' => (int) ($itemRow['currently_on_loan'] ?? 0),
                    'loan_loan_date' => (string) ($itemRow['loan_loan_date'] ?? ''),
                    'loan_due_date' => (string) ($itemRow['loan_due_date'] ?? ''),
                    'loan_return_date' => (string) ($itemRow['loan_return_date'] ?? ''),
                    'process_message' => (string) ($itemRow['process_message'] ?? '')
                ];
            }
        }

        return $flatRows;
    }
}

if (!function_exists('lapordata_item_export_no_location_token')) {
    function lapordata_item_export_no_location_token(): string
    {
        return '__NO_LOCATION__';
    }
}

if (!function_exists('lapordata_item_source_label')) {
    function lapordata_item_source_label($source): string
    {
        $source = trim((string) $source);
        $map = [
            '1' => 'Beli',
            '2' => 'Hadiah/Hibah'
        ];

        if (isset($map[$source])) {
            return $map[$source];
        }

        return $source !== '' ? $source : '-';
    }
}

if (!function_exists('lapordata_collect_item_export_filters')) {
    function lapordata_collect_item_export_filters(): array
    {
        $today = date('Y-m-d');
        $startOfYear = date('Y-01-01');
        $dateFrom = lapordata_safe_date($_GET['date_from'] ?? $startOfYear, $startOfYear);
        $dateTo = lapordata_safe_date($_GET['date_to'] ?? $today, $today);

        if ($dateFrom !== '' && $dateTo !== '' && $dateFrom > $dateTo) {
            [$dateFrom, $dateTo] = [$dateTo, $dateFrom];
        }

        return [
            'location_id' => trim((string) ($_GET['location_id'] ?? 'all')),
            'coll_type_id' => trim((string) ($_GET['coll_type_id'] ?? 'all')),
            'item_status_id' => trim((string) ($_GET['item_status_id'] ?? 'all')),
            'source' => trim((string) ($_GET['source'] ?? 'all')),
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'all_dates' => lapordata_truthy($_GET['all_dates'] ?? '1')
        ];
    }
}

if (!function_exists('lapordata_get_item_location_options')) {
    function lapordata_get_item_location_options(mysqli $dbs): array
    {
        $options = [];
        if ($query = $dbs->query("SELECT location_id, location_name FROM mst_location ORDER BY location_name ASC")) {
            while ($row = $query->fetch_assoc()) {
                $locationId = trim((string) ($row['location_id'] ?? ''));
                $locationName = trim((string) ($row['location_name'] ?? ''));
                if ($locationId === '' || $locationName === '') {
                    continue;
                }

                $options[$locationId] = $locationName;
            }
            $query->free_result();
        }

        if ($query = $dbs->query("SELECT COUNT(*) AS total FROM item WHERE location_id IS NULL OR TRIM(COALESCE(location_id, '')) = ''")) {
            $row = $query->fetch_assoc();
            if ((int) ($row['total'] ?? 0) > 0) {
                $options[lapordata_item_export_no_location_token()] = 'Tanpa lokasi';
            }
            $query->free_result();
        }

        return $options;
    }
}

if (!function_exists('lapordata_get_item_coll_type_options')) {
    function lapordata_get_item_coll_type_options(mysqli $dbs): array
    {
        $options = [];
        if ($query = $dbs->query("SELECT coll_type_id, coll_type_name FROM mst_coll_type ORDER BY coll_type_name ASC")) {
            while ($row = $query->fetch_assoc()) {
                $id = trim((string) ($row['coll_type_id'] ?? ''));
                $name = trim((string) ($row['coll_type_name'] ?? ''));
                if ($id === '' || $name === '') {
                    continue;
                }
                $options[$id] = $name;
            }
            $query->free_result();
        }

        return $options;
    }
}

if (!function_exists('lapordata_get_item_status_options')) {
    function lapordata_get_item_status_options(mysqli $dbs): array
    {
        $options = [];
        if ($query = $dbs->query("SELECT item_status_id, item_status_name FROM mst_item_status ORDER BY item_status_name ASC")) {
            while ($row = $query->fetch_assoc()) {
                $id = trim((string) ($row['item_status_id'] ?? ''));
                $name = trim((string) ($row['item_status_name'] ?? ''));
                if ($id === '' || $name === '') {
                    continue;
                }
                $options[$id] = $name;
            }
            $query->free_result();
        }

        return $options;
    }
}

if (!function_exists('lapordata_get_item_source_options')) {
    function lapordata_get_item_source_options(mysqli $dbs): array
    {
        $options = [
            '1' => lapordata_item_source_label('1'),
            '2' => lapordata_item_source_label('2')
        ];

        if ($query = $dbs->query("SELECT DISTINCT COALESCE(source, '') AS source_value FROM item ORDER BY source_value ASC")) {
            while ($row = $query->fetch_assoc()) {
                $sourceValue = trim((string) ($row['source_value'] ?? ''));
                if ($sourceValue === '' || isset($options[$sourceValue])) {
                    continue;
                }
                $options[$sourceValue] = lapordata_item_source_label($sourceValue);
            }
            $query->free_result();
        }

        return $options;
    }
}

if (!function_exists('lapordata_build_item_export_filter_sql')) {
    function lapordata_build_item_export_filter_sql(mysqli $dbs, array $filters): array
    {
        $locationOptions = lapordata_get_item_location_options($dbs);
        $collTypeOptions = lapordata_get_item_coll_type_options($dbs);
        $itemStatusOptions = lapordata_get_item_status_options($dbs);
        $sourceOptions = lapordata_get_item_source_options($dbs);

        $normalized = [
            'location_id' => isset($locationOptions[(string) ($filters['location_id'] ?? '')])
                ? (string) $filters['location_id']
                : 'all',
            'coll_type_id' => isset($collTypeOptions[(string) ($filters['coll_type_id'] ?? '')])
                ? (string) $filters['coll_type_id']
                : 'all',
            'item_status_id' => isset($itemStatusOptions[(string) ($filters['item_status_id'] ?? '')])
                ? (string) $filters['item_status_id']
                : 'all',
            'source' => isset($sourceOptions[(string) ($filters['source'] ?? '')])
                ? (string) $filters['source']
                : 'all',
            'date_from' => lapordata_safe_date((string) ($filters['date_from'] ?? ''), date('Y-01-01')),
            'date_to' => lapordata_safe_date((string) ($filters['date_to'] ?? ''), date('Y-m-d')),
            'all_dates' => !empty($filters['all_dates'])
        ];

        if ($normalized['date_from'] !== '' && $normalized['date_to'] !== '' && $normalized['date_from'] > $normalized['date_to']) {
            [$normalized['date_from'], $normalized['date_to']] = [$normalized['date_to'], $normalized['date_from']];
        }

        $where = ['1=1'];

        if ($normalized['location_id'] !== 'all') {
            if ($normalized['location_id'] === lapordata_item_export_no_location_token()) {
                $where[] = "(i.location_id IS NULL OR TRIM(COALESCE(i.location_id, '')) = '')";
            } else {
                $where[] = "i.location_id = '" . $dbs->escape_string($normalized['location_id']) . "'";
            }
        }

        if ($normalized['coll_type_id'] !== 'all') {
            $where[] = "CAST(i.coll_type_id AS CHAR) = '" . $dbs->escape_string($normalized['coll_type_id']) . "'";
        }

        if ($normalized['item_status_id'] !== 'all') {
            $where[] = "i.item_status_id = '" . $dbs->escape_string($normalized['item_status_id']) . "'";
        }

        if ($normalized['source'] !== 'all') {
            $where[] = "CAST(COALESCE(i.source, '') AS CHAR) = '" . $dbs->escape_string($normalized['source']) . "'";
        }

        if (empty($normalized['all_dates'])) {
            $where[] = "DATE(i.received_date) >= '" . $dbs->escape_string($normalized['date_from']) . "'";
            $where[] = "DATE(i.received_date) <= '" . $dbs->escape_string($normalized['date_to']) . "'";
        }

        return [
            'filters' => $normalized,
            'where_sql' => implode(' AND ', $where),
            'options' => [
                'locations' => $locationOptions,
                'coll_types' => $collTypeOptions,
                'item_statuses' => $itemStatusOptions,
                'sources' => $sourceOptions
            ]
        ];
    }
}

if (!function_exists('lapordata_fetch_item_location_dataset')) {
    function lapordata_fetch_item_location_dataset(mysqli $dbs, array $filters): array
    {
        $filterPack = lapordata_build_item_export_filter_sql($dbs, $filters);
        $normalizedFilters = $filterPack['filters'];
        $whereSql = $filterPack['where_sql'];

        $rows = [];
        $sql = "SELECT
                    i.item_id,
                    i.biblio_id,
                    i.item_code,
                    COALESCE(NULLIF(TRIM(b.title), ''), '-') AS title,
                    COALESCE(NULLIF(TRIM(loc.location_name), ''), 'Tanpa lokasi') AS location_name,
                    COALESCE(NULLIF(TRIM(i.call_number), ''), '-') AS call_number,
                    COALESCE(NULLIF(TRIM(i.inventory_code), ''), '-') AS inventory_code,
                    COALESCE(NULLIF(TRIM(ct.coll_type_name), ''), '-') AS coll_type_name,
                    COALESCE(NULLIF(TRIM(st.item_status_name), ''), '-') AS item_status_name,
                    COALESCE(NULLIF(TRIM(spl.supplier_name), ''), '-') AS supplier_name,
                    COALESCE(NULLIF(TRIM(i.order_no), ''), '-') AS order_no,
                    COALESCE(NULLIF(TRIM(i.site), ''), '-') AS site,
                    COALESCE(NULLIF(TRIM(i.invoice), ''), '-') AS invoice,
                    COALESCE(NULLIF(TRIM(i.price_currency), ''), '-') AS price_currency,
                    COALESCE(i.source, '') AS source_value,
                    COALESCE(i.price, 0) AS price,
                    COALESCE(DATE_FORMAT(i.received_date, '%Y-%m-%d'), '') AS received_date,
                    COALESCE(DATE_FORMAT(i.input_date, '%Y-%m-%d %H:%i:%s'), '') AS input_date,
                    COALESCE(DATE_FORMAT(i.last_update, '%Y-%m-%d %H:%i:%s'), '') AS last_update
                FROM item AS i
                LEFT JOIN biblio AS b ON i.biblio_id = b.biblio_id
                LEFT JOIN mst_location AS loc ON i.location_id = loc.location_id
                LEFT JOIN mst_coll_type AS ct ON i.coll_type_id = ct.coll_type_id
                LEFT JOIN mst_item_status AS st ON i.item_status_id = st.item_status_id
                LEFT JOIN mst_supplier AS spl ON i.supplier_id = spl.supplier_id
                WHERE {$whereSql}
                ORDER BY location_name ASC, title ASC, i.item_code ASC";

        if ($query = $dbs->query($sql)) {
            while ($row = $query->fetch_assoc()) {
                $rows[] = $row;
            }
            $query->free_result();
        }

        $summary = [
            'total_items' => count($rows),
            'total_titles' => 0,
            'total_locations' => 0,
            'buy_total' => 0,
            'grant_total' => 0,
            'no_location_total' => 0
        ];
        $uniqueTitles = [];
        $uniqueLocations = [];
        $locationSummaryMap = [];

        foreach ($rows as $row) {
            $biblioId = (string) ($row['biblio_id'] ?? '');
            $locationName = (string) ($row['location_name'] ?? 'Tanpa lokasi');
            $sourceValue = (string) ($row['source_value'] ?? '');
            $lastUpdate = (string) ($row['last_update'] ?? '');

            if ($biblioId !== '') {
                $uniqueTitles[$biblioId] = true;
            }
            $uniqueLocations[$locationName] = true;

            if ($sourceValue === '1') {
                $summary['buy_total']++;
            } elseif ($sourceValue === '2') {
                $summary['grant_total']++;
            }

            if ($locationName === 'Tanpa lokasi') {
                $summary['no_location_total']++;
            }

            if (!isset($locationSummaryMap[$locationName])) {
                $locationSummaryMap[$locationName] = [
                    'location_name' => $locationName,
                    'item_total' => 0,
                    'title_ids' => [],
                    'buy_total' => 0,
                    'grant_total' => 0,
                    'last_update' => ''
                ];
            }

            $locationSummaryMap[$locationName]['item_total']++;
            if ($biblioId !== '') {
                $locationSummaryMap[$locationName]['title_ids'][$biblioId] = true;
            }
            if ($sourceValue === '1') {
                $locationSummaryMap[$locationName]['buy_total']++;
            } elseif ($sourceValue === '2') {
                $locationSummaryMap[$locationName]['grant_total']++;
            }
            if ($lastUpdate !== '' && ($locationSummaryMap[$locationName]['last_update'] === '' || $lastUpdate > $locationSummaryMap[$locationName]['last_update'])) {
                $locationSummaryMap[$locationName]['last_update'] = $lastUpdate;
            }
        }

        $summary['total_titles'] = count($uniqueTitles);
        $summary['total_locations'] = count($uniqueLocations);

        $locationSummaries = [];
        foreach ($locationSummaryMap as $locationSummary) {
            $locationSummary['title_total'] = count($locationSummary['title_ids']);
            unset($locationSummary['title_ids']);
            $locationSummaries[] = $locationSummary;
        }

        usort($locationSummaries, static function (array $left, array $right): int {
            return strcmp((string) ($left['location_name'] ?? ''), (string) ($right['location_name'] ?? ''));
        });

        return [
            'filters' => $normalizedFilters,
            'options' => $filterPack['options'],
            'rows' => $rows,
            'summary' => $summary,
            'location_summaries' => $locationSummaries
        ];
    }
}

if (!function_exists('lapordata_prepare_spreadsheet')) {
    function lapordata_prepare_spreadsheet(string $title): Spreadsheet
    {
        $spreadsheet = new Spreadsheet();
        $spreadsheet->getProperties()
            ->setCreator('Lapor Data Plugin')
            ->setLastModifiedBy('Lapor Data Plugin')
            ->setTitle($title)
            ->setSubject($title)
            ->setDescription($title);

        return $spreadsheet;
    }
}

if (!function_exists('lapordata_render_title_block')) {
    function lapordata_render_title_block(Worksheet $sheet, string $title, string $subtitle, string $lastColumn): void
    {
        $sheet->mergeCells("A1:{$lastColumn}1");
        $sheet->mergeCells("A2:{$lastColumn}2");
        $sheet->setCellValue('A1', $title);
        $sheet->setCellValue('A2', $subtitle);

        $sheet->getStyle("A1:{$lastColumn}1")->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 16,
                'color' => ['rgb' => 'FFFFFF']
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical' => Alignment::VERTICAL_CENTER
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => '0F172A']
            ]
        ]);

        $sheet->getStyle("A2:{$lastColumn}2")->applyFromArray([
            'font' => [
                'italic' => true,
                'size' => 11,
                'color' => ['rgb' => '1E293B']
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical' => Alignment::VERTICAL_CENTER
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => 'DBEAFE']
            ]
        ]);

        $sheet->getRowDimension(1)->setRowHeight(28);
        $sheet->getRowDimension(2)->setRowHeight(22);
    }
}

if (!function_exists('lapordata_write_section_heading')) {
    function lapordata_write_section_heading(Worksheet $sheet, string $title, int $row, string $lastColumn): int
    {
        $sheet->mergeCells("A{$row}:{$lastColumn}{$row}");
        $sheet->setCellValue("A{$row}", $title);
        $sheet->getStyle("A{$row}:{$lastColumn}{$row}")->applyFromArray([
            'font' => [
                'bold' => true,
                'size' => 12,
                'color' => ['rgb' => 'FFFFFF']
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => '1D4ED8']
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_LEFT,
                'vertical' => Alignment::VERTICAL_CENTER
            ]
        ]);
        $sheet->getRowDimension($row)->setRowHeight(20);
        return $row + 1;
    }
}

if (!function_exists('lapordata_write_label_value_block')) {
    function lapordata_write_label_value_block(Worksheet $sheet, array $pairs, int $startRow, string $lastColumn): int
    {
        $row = $startRow;
        foreach ($pairs as $label => $value) {
            $sheet->setCellValue("A{$row}", $label);
            $sheet->mergeCells("B{$row}:{$lastColumn}{$row}");
            $sheet->setCellValue("B{$row}", (string) $value);

            $sheet->getStyle("A{$row}")->applyFromArray([
                'font' => [
                    'bold' => true,
                    'color' => ['rgb' => '0F172A']
                ],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => 'E2E8F0']
                ],
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_TOP
                ],
                'borders' => [
                    'allBorders' => [
                        'borderStyle' => Border::BORDER_THIN,
                        'color' => ['rgb' => 'CBD5E1']
                    ]
                ]
            ]);

            $sheet->getStyle("B{$row}:{$lastColumn}{$row}")->applyFromArray([
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_TOP,
                    'wrapText' => true
                ],
                'borders' => [
                    'allBorders' => [
                        'borderStyle' => Border::BORDER_THIN,
                        'color' => ['rgb' => 'CBD5E1']
                    ]
                ]
            ]);

            $row++;
        }

        return $row;
    }
}

if (!function_exists('lapordata_write_table_sheet')) {
    function lapordata_write_table_sheet(
        Worksheet $sheet,
        string $title,
        string $subtitle,
        array $headers,
        array $rows,
        array $widths = [],
        array $wrapColumns = []
    ): void {
        $lastColumn = Coordinate::stringFromColumnIndex(count($headers));
        lapordata_render_title_block($sheet, $title, $subtitle, $lastColumn);

        $headerRow = 4;
        $columnIndex = 1;
        foreach ($headers as $header) {
            $columnLetter = Coordinate::stringFromColumnIndex($columnIndex);
            $sheet->setCellValue($columnLetter . $headerRow, $header);
            $columnIndex++;
        }

        $sheet->getStyle("A{$headerRow}:{$lastColumn}{$headerRow}")->applyFromArray([
            'font' => [
                'bold' => true,
                'color' => ['rgb' => 'FFFFFF']
            ],
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical' => Alignment::VERTICAL_CENTER,
                'wrapText' => true
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'color' => ['rgb' => '0F766E']
            ],
            'borders' => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                    'color' => ['rgb' => '0F172A']
                ]
            ]
        ]);

        $rowIndex = $headerRow + 1;
        foreach ($rows as $rowValues) {
            $columnIndex = 1;
            foreach ($rowValues as $value) {
                $columnLetter = Coordinate::stringFromColumnIndex($columnIndex);
                $sheet->setCellValueExplicit($columnLetter . $rowIndex, (string) $value, \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
                $columnIndex++;
            }
            $rowIndex++;
        }

        $lastDataRow = max($headerRow, $rowIndex - 1);
        if ($lastDataRow >= $headerRow) {
            $sheet->getStyle("A{$headerRow}:{$lastColumn}{$lastDataRow}")->applyFromArray([
                'borders' => [
                    'allBorders' => [
                        'borderStyle' => Border::BORDER_THIN,
                        'color' => ['rgb' => 'CBD5E1']
                    ]
                ],
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_TOP,
                    'wrapText' => true
                ]
            ]);
        }

        for ($row = $headerRow + 1; $row <= $lastDataRow; $row++) {
            if (($row - $headerRow) % 2 === 0) {
                $sheet->getStyle("A{$row}:{$lastColumn}{$row}")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('F8FAFC');
            }
            $sheet->getStyle("A{$row}")->applyFromArray([
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_CENTER
                ],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => 'F1F5F9']
                ]
            ]);
            $sheet->getRowDimension($row)->setRowHeight(-1);
        }

        foreach ($wrapColumns as $columnLetter) {
            $sheet->getStyle("{$columnLetter}" . ($headerRow + 1) . ":{$columnLetter}{$lastDataRow}")
                ->getAlignment()
                ->setWrapText(true);
        }

        foreach ($widths as $column => $width) {
            $sheet->getColumnDimension($column)->setWidth($width);
        }

        for ($columnIndex = 1; $columnIndex <= count($headers); $columnIndex++) {
            $columnLetter = Coordinate::stringFromColumnIndex($columnIndex);
            if (!isset($widths[$columnLetter])) {
                $sheet->getColumnDimension($columnLetter)->setWidth(18);
            }
        }

        $sheet->freezePane('A5');
        $sheet->setAutoFilter("A{$headerRow}:{$lastColumn}{$headerRow}");
    }
}

if (!function_exists('lapordata_send_spreadsheet')) {
    function lapordata_send_spreadsheet(Spreadsheet $spreadsheet, string $filename): void
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        header('Pragma: public');

        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit();
    }
}

if (!function_exists('lapordata_export_visitor_excel')) {
    function lapordata_export_visitor_excel(mysqli $dbs, array $sysconf, array $filters): void
    {
        $context = lapordata_build_visitor_context($dbs, $sysconf);
        $filterPack = lapordata_build_visitor_filter_sql($dbs, $filters, $context);
        $normalizedFilters = $filterPack['filters'];
        $whereSql = $filterPack['where_sql'];

        $summary = lapordata_fetch_visitor_summary($dbs, $context, $whereSql);
        $rows = lapordata_fetch_visitor_rows($dbs, $context, $whereSql);

        $spreadsheet = lapordata_prepare_spreadsheet('Laporan Visitor Lengkap');
        $summarySheet = $spreadsheet->getActiveSheet();
        $summarySheet->setTitle('Ringkasan');
        lapordata_render_title_block(
            $summarySheet,
            'Laporan Visitor Lengkap',
            'Export dibuat pada ' . date('d-m-Y H:i:s'),
            'E'
        );

        $row = 4;
        $row = lapordata_write_section_heading($summarySheet, 'Filter Laporan', $row, 'E');
        $row = lapordata_write_label_value_block($summarySheet, [
            'Rentang Tanggal' => !empty($normalizedFilters['all_dates'])
                ? 'Semua tanggal'
                : lapordata_format_date_label($normalizedFilters['date_from']) . ' s/d ' . lapordata_format_date_label($normalizedFilters['date_until']),
            'Tipe Visitor' => lapordata_visitor_type_label((string) $normalizedFilters['visitor_type']),
            'Lokasi Kunjungan' => $normalizedFilters['visit_location'] !== 'all' ? $normalizedFilters['visit_location'] : 'Semua lokasi'
        ], $row, 'E');

        $row += 1;
        $row = lapordata_write_section_heading($summarySheet, 'Ringkasan Data', $row, 'E');
        lapordata_write_label_value_block($summarySheet, [
            'Total Baris' => (string) $summary['row_total'],
            'Total Orang' => (string) $summary['person_total'],
            'Total Member' => (string) $summary['member_total'],
            'Total Non Member' => (string) $summary['non_member_total'],
            'Total Rombongan' => (string) $summary['rombongan_total']
        ], $row, 'E');

        foreach (['A' => 24, 'B' => 22, 'C' => 22, 'D' => 22, 'E' => 22] as $column => $width) {
            $summarySheet->getColumnDimension($column)->setWidth($width);
        }

        $dataSheet = $spreadsheet->createSheet();
        $dataSheet->setTitle('Data Visitor');
        $dataRows = [];
        $number = 1;
        foreach ($rows as $rowData) {
            $dataRows[] = [
                $number++,
                lapordata_format_datetime($rowData['checkin_date'] ?? ''),
                (string) ($rowData['member_id'] ?? '-'),
                (string) ($rowData['member_name'] ?? '-'),
                (string) ($rowData['institution'] ?? '-'),
                (string) ($rowData['visit_location'] ?? '-'),
                lapordata_visitor_type_label((string) ($rowData['visitor_type_resolved'] ?? 'non_member')),
                (string) ($rowData['purpose_resolved'] ?? 'Belum diisi'),
                (string) ($rowData['member_type_display'] ?? '-'),
                (string) ((int) ($rowData['person_total'] ?? 0)),
                (string) ((int) ($rowData['male_total'] ?? 0)),
                (string) ((int) ($rowData['female_total'] ?? 0))
            ];
        }

        if (count($dataRows) < 1) {
            $dataRows[] = [1, '-', '-', 'Tidak ada data sesuai filter', '-', '-', '-', '-', '-', '0', '0', '0'];
        }

        lapordata_write_table_sheet(
            $dataSheet,
            'Data Visitor Lengkap',
            'Filter mengikuti halaman kelola visitor lengkap',
            ['No', 'Check-in', 'Member ID', 'Nama', 'Institusi', 'Lokasi', 'Tipe Visitor', 'Tujuan', 'Tipe Member', 'Jumlah', 'Laki-laki', 'Perempuan'],
            $dataRows,
            ['A' => 6, 'B' => 22, 'C' => 16, 'D' => 26, 'E' => 26, 'F' => 22, 'G' => 18, 'H' => 30, 'I' => 18, 'J' => 12, 'K' => 12, 'L' => 12],
            ['D', 'E', 'H']
        );

        $filename = 'lapordata-visitor-' . date('Ymd-His') . '.xlsx';
        lapordata_send_spreadsheet($spreadsheet, $filename);
    }
}

if (!function_exists('lapordata_export_approval_excel')) {
    function lapordata_export_approval_excel(mysqli $dbs, array $sysconf, array $filters): void
    {
        $dataset = lapordata_fetch_approval_dataset($dbs, $filters);
        $rows = $dataset['rows'];
        $itemMap = $dataset['item_map'];
        $summary = $dataset['summary'];
        $normalizedFilters = $dataset['filters'];
        $itemRows = lapordata_build_approval_item_rows($rows, $itemMap);

        $spreadsheet = lapordata_prepare_spreadsheet('Laporan Approval Peminjaman');
        $summarySheet = $spreadsheet->getActiveSheet();
        $summarySheet->setTitle('Ringkasan');
        lapordata_render_title_block(
            $summarySheet,
            'Laporan Approval Peminjaman',
            'Export dibuat pada ' . date('d-m-Y H:i:s'),
            'E'
        );

        $row = 4;
        $row = lapordata_write_section_heading($summarySheet, 'Filter Laporan', $row, 'E');
        $row = lapordata_write_label_value_block($summarySheet, [
            'Status' => $normalizedFilters['status'] !== 'all'
                ? lapordata_status_label((string) $normalizedFilters['status'])
                : 'Semua status',
            'Jenis Aksi' => $normalizedFilters['action_type'] !== 'all'
                ? lapordata_action_label((string) $normalizedFilters['action_type'])
                : 'Semua aksi',
            'Lokasi' => $normalizedFilters['visit_location'] !== 'all'
                ? (string) $normalizedFilters['visit_location']
                : 'Semua lokasi',
            'Rentang Tanggal' => lapordata_format_date_label((string) $normalizedFilters['date_from'])
                . ' s/d ' . lapordata_format_date_label((string) $normalizedFilters['date_to'])
        ], $row, 'E');

        $row += 1;
        $row = lapordata_write_section_heading($summarySheet, 'Ringkasan Data', $row, 'E');
        lapordata_write_label_value_block($summarySheet, [
            'Total Request' => (string) ($summary['total_requests'] ?? 0),
            'Total Item' => (string) ($summary['total_items'] ?? 0),
            'Pending' => (string) ($summary['pending'] ?? 0),
            'Processing' => (string) ($summary['processing'] ?? 0),
            'Approved' => (string) ($summary['approved'] ?? 0),
            'Rejected' => (string) ($summary['rejected'] ?? 0),
            'Partial' => (string) ($summary['partial'] ?? 0),
            'Failed' => (string) ($summary['failed'] ?? 0)
        ], $row, 'E');

        foreach (['A' => 24, 'B' => 22, 'C' => 22, 'D' => 22, 'E' => 22] as $column => $width) {
            $summarySheet->getColumnDimension($column)->setWidth($width);
        }

        $requestSheet = $spreadsheet->createSheet();
        $requestSheet->setTitle('Approval Data');
        $requestRows = [];
        $number = 1;
        foreach ($rows as $rowData) {
            $requestRows[] = [
                $number++,
                (string) ($rowData['request_code'] ?? '-'),
                (string) ($rowData['request_id'] ?? '-'),
                lapordata_format_datetime($rowData['requested_at'] ?? ''),
                (string) ($rowData['member_id'] ?? '-'),
                (string) ($rowData['member_name'] ?? '-'),
                (string) ($rowData['member_email'] ?? '-'),
                (string) ($rowData['member_type_name'] ?? '-'),
                (string) ($rowData['visit_location'] ?? '-'),
                lapordata_action_label((string) ($rowData['action_type'] ?? 'loan')),
                lapordata_status_label((string) ($rowData['status'] ?? 'pending')),
                (string) ((int) ($rowData['item_total'] ?? 0)),
                (string) ((int) ($rowData['item_approved'] ?? 0)),
                (string) ((int) ($rowData['item_rejected'] ?? 0)),
                (string) ((int) ($rowData['item_failed'] ?? 0)),
                (string) ($rowData['item_list'] ?? '-'),
                (string) ($rowData['request_note'] ?? '-'),
                (string) ($rowData['admin_note'] ?? '-'),
                (string) ($rowData['admin_username'] ?? '-'),
                lapordata_format_datetime($rowData['decided_at'] ?? ''),
                lapordata_format_datetime($rowData['processed_at'] ?? '')
            ];
        }

        if (count($requestRows) < 1) {
            $requestRows[] = [1, '-', '-', '-', '-', 'Tidak ada data sesuai filter', '-', '-', '-', '-', '-', '0', '0', '0', '0', '-', '-', '-', '-', '-', '-'];
        }

        lapordata_write_table_sheet(
            $requestSheet,
            'Data Approval Peminjaman',
            'Request approval sesuai filter aktif',
            [
                'No',
                'Kode Request',
                'Request ID',
                'Tanggal Request',
                'Member ID',
                'Nama Member',
                'Email',
                'Tipe Member',
                'Lokasi',
                'Aksi',
                'Status',
                'Total Item',
                'Item Approve',
                'Item Reject',
                'Item Failed',
                'Daftar Item',
                'Catatan Request',
                'Catatan Admin',
                'Diproses Oleh',
                'Diputuskan',
                'Diproses'
            ],
            $requestRows,
            [
                'A' => 6, 'B' => 18, 'C' => 12, 'D' => 22, 'E' => 16, 'F' => 24, 'G' => 24,
                'H' => 18, 'I' => 18, 'J' => 14, 'K' => 14, 'L' => 11, 'M' => 12, 'N' => 12,
                'O' => 12, 'P' => 34, 'Q' => 30, 'R' => 30, 'S' => 18, 'T' => 22, 'U' => 22
            ],
            ['F', 'G', 'P', 'Q', 'R']
        );

        $itemSheet = $spreadsheet->createSheet();
        $itemSheet->setTitle('Detail Item');
        $flatRows = [];
        $number = 1;
        foreach ($itemRows as $itemRow) {
            $flatRows[] = [
                $number++,
                (string) ($itemRow['request_code'] ?? '-'),
                (string) ($itemRow['request_id'] ?? '-'),
                lapordata_format_datetime($itemRow['requested_at'] ?? ''),
                (string) ($itemRow['member_id'] ?? '-'),
                (string) ($itemRow['member_name'] ?? '-'),
                lapordata_action_label((string) ($itemRow['action_type'] ?? 'loan')),
                lapordata_status_label((string) ($itemRow['request_status'] ?? 'pending')),
                (string) ($itemRow['item_code'] ?? '-'),
                (string) ($itemRow['title'] ?? '-'),
                (string) ($itemRow['item_location'] ?? '-'),
                lapordata_status_label((string) ($itemRow['item_status'] ?? 'pending')),
                (string) ($itemRow['loan_id'] ?? '0'),
                (string) ($itemRow['currently_on_loan'] ?? '0'),
                lapordata_format_datetime($itemRow['loan_loan_date'] ?? ''),
                lapordata_format_datetime($itemRow['loan_due_date'] ?? ''),
                lapordata_format_datetime($itemRow['loan_return_date'] ?? ''),
                (string) ($itemRow['process_message'] ?? '-')
            ];
        }

        if (count($flatRows) < 1) {
            $flatRows[] = [1, '-', '-', '-', '-', 'Tidak ada detail item sesuai filter', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'];
        }

        lapordata_write_table_sheet(
            $itemSheet,
            'Detail Item Approval',
            'Item request per approval',
            [
                'No',
                'Kode Request',
                'Request ID',
                'Tanggal Request',
                'Member ID',
                'Nama Member',
                'Aksi',
                'Status Request',
                'Item Code',
                'Judul',
                'Lokasi Item',
                'Status Item',
                'Loan ID',
                'On Loan Saat Ini',
                'Tanggal Pinjam',
                'Jatuh Tempo',
                'Tanggal Kembali',
                'Pesan Proses'
            ],
            $flatRows,
            [
                'A' => 6, 'B' => 18, 'C' => 12, 'D' => 22, 'E' => 16, 'F' => 24, 'G' => 14,
                'H' => 16, 'I' => 16, 'J' => 30, 'K' => 18, 'L' => 14, 'M' => 12, 'N' => 14,
                'O' => 20, 'P' => 20, 'Q' => 20, 'R' => 28
            ],
            ['F', 'J', 'R']
        );

        $filename = 'lapordata-approval-' . date('Ymd-His') . '.xlsx';
        lapordata_send_spreadsheet($spreadsheet, $filename);
    }
}

if (!function_exists('lapordata_export_item_location_excel')) {
    function lapordata_export_item_location_excel(mysqli $dbs, array $sysconf, array $filters): void
    {
        $dataset = lapordata_fetch_item_location_dataset($dbs, $filters);
        $rows = $dataset['rows'];
        $summary = $dataset['summary'];
        $locationSummaries = $dataset['location_summaries'];
        $normalizedFilters = $dataset['filters'];
        $options = $dataset['options'];

        $spreadsheet = lapordata_prepare_spreadsheet('Laporan Buku per Lokasi');
        $summarySheet = $spreadsheet->getActiveSheet();
        $summarySheet->setTitle('Ringkasan');
        lapordata_render_title_block(
            $summarySheet,
            'Laporan Buku per Lokasi',
            'Export dibuat pada ' . date('d-m-Y H:i:s'),
            'E'
        );

        $locationLabel = 'Semua lokasi';
        if (($normalizedFilters['location_id'] ?? 'all') !== 'all') {
            $locationLabel = $options['locations'][$normalizedFilters['location_id']] ?? 'Tanpa lokasi';
        }

        $collTypeLabel = 'Semua tipe koleksi';
        if (($normalizedFilters['coll_type_id'] ?? 'all') !== 'all') {
            $collTypeLabel = $options['coll_types'][$normalizedFilters['coll_type_id']] ?? '-';
        }

        $itemStatusLabel = 'Semua status item';
        if (($normalizedFilters['item_status_id'] ?? 'all') !== 'all') {
            $itemStatusLabel = $options['item_statuses'][$normalizedFilters['item_status_id']] ?? '-';
        }

        $sourceLabel = 'Semua sumber';
        if (($normalizedFilters['source'] ?? 'all') !== 'all') {
            $sourceLabel = $options['sources'][$normalizedFilters['source']] ?? lapordata_item_source_label($normalizedFilters['source']);
        }

        $row = 4;
        $row = lapordata_write_section_heading($summarySheet, 'Filter Laporan', $row, 'E');
        $row = lapordata_write_label_value_block($summarySheet, [
            'Lokasi Buku' => $locationLabel,
            'Tipe Koleksi' => $collTypeLabel,
            'Status Item' => $itemStatusLabel,
            'Sumber Pengadaan' => $sourceLabel,
            'Tanggal Terima' => !empty($normalizedFilters['all_dates'])
                ? 'Semua tanggal'
                : lapordata_format_date_label((string) $normalizedFilters['date_from']) . ' s/d ' . lapordata_format_date_label((string) $normalizedFilters['date_to'])
        ], $row, 'E');

        $row += 1;
        $row = lapordata_write_section_heading($summarySheet, 'Ringkasan Data', $row, 'E');
        lapordata_write_label_value_block($summarySheet, [
            'Total Eksemplar' => (string) ($summary['total_items'] ?? 0),
            'Total Judul' => (string) ($summary['total_titles'] ?? 0),
            'Total Lokasi' => (string) ($summary['total_locations'] ?? 0),
            'Sumber Beli' => (string) ($summary['buy_total'] ?? 0),
            'Sumber Hadiah/Hibah' => (string) ($summary['grant_total'] ?? 0),
            'Tanpa Lokasi' => (string) ($summary['no_location_total'] ?? 0)
        ], $row, 'E');

        foreach (['A' => 24, 'B' => 24, 'C' => 22, 'D' => 22, 'E' => 22] as $column => $width) {
            $summarySheet->getColumnDimension($column)->setWidth($width);
        }

        $recapSheet = $spreadsheet->createSheet();
        $recapSheet->setTitle('Rekap Lokasi');
        $recapRows = [];
        $number = 1;
        foreach ($locationSummaries as $locationSummary) {
            $recapRows[] = [
                $number++,
                (string) ($locationSummary['location_name'] ?? 'Tanpa lokasi'),
                (string) ((int) ($locationSummary['item_total'] ?? 0)),
                (string) ((int) ($locationSummary['title_total'] ?? 0)),
                (string) ((int) ($locationSummary['buy_total'] ?? 0)),
                (string) ((int) ($locationSummary['grant_total'] ?? 0)),
                lapordata_format_datetime((string) ($locationSummary['last_update'] ?? ''))
            ];
        }

        if (count($recapRows) < 1) {
            $recapRows[] = [1, 'Tidak ada data sesuai filter', '0', '0', '0', '0', '-'];
        }

        lapordata_write_table_sheet(
            $recapSheet,
            'Rekap Buku per Lokasi',
            'Ringkasan jumlah item dan judul untuk setiap lokasi',
            ['No', 'Lokasi', 'Total Item', 'Total Judul', 'Beli', 'Hadiah/Hibah', 'Update Terakhir'],
            $recapRows,
            ['A' => 6, 'B' => 26, 'C' => 14, 'D' => 14, 'E' => 12, 'F' => 16, 'G' => 22],
            ['B']
        );

        $dataSheet = $spreadsheet->createSheet();
        $dataSheet->setTitle('Data Item');
        $dataRows = [];
        $number = 1;
        foreach ($rows as $rowData) {
            $dataRows[] = [
                $number++,
                (string) ($rowData['location_name'] ?? 'Tanpa lokasi'),
                (string) ($rowData['item_code'] ?? '-'),
                (string) ($rowData['title'] ?? '-'),
                (string) ($rowData['biblio_id'] ?? '-'),
                (string) ($rowData['call_number'] ?? '-'),
                (string) ($rowData['inventory_code'] ?? '-'),
                (string) ($rowData['coll_type_name'] ?? '-'),
                (string) ($rowData['item_status_name'] ?? '-'),
                lapordata_item_source_label((string) ($rowData['source_value'] ?? '')),
                !empty($rowData['received_date']) ? lapordata_format_date_label((string) $rowData['received_date']) : '-',
                (string) ($rowData['supplier_name'] ?? '-'),
                (string) ($rowData['order_no'] ?? '-'),
                (string) ($rowData['site'] ?? '-'),
                (string) ($rowData['price'] ?? '0'),
                (string) ($rowData['price_currency'] ?? '-'),
                lapordata_format_datetime((string) ($rowData['input_date'] ?? '')),
                lapordata_format_datetime((string) ($rowData['last_update'] ?? ''))
            ];
        }

        if (count($dataRows) < 1) {
            $dataRows[] = [1, 'Tidak ada data sesuai filter', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '0', '-', '-', '-'];
        }

        lapordata_write_table_sheet(
            $dataSheet,
            'Data Buku per Lokasi',
            'Daftar item hasil filter aktif',
            [
                'No',
                'Lokasi',
                'Item Code',
                'Judul',
                'Biblio ID',
                'Call Number',
                'Inventory Code',
                'Tipe Koleksi',
                'Status Item',
                'Sumber',
                'Tanggal Terima',
                'Supplier',
                'No Order',
                'Site',
                'Harga',
                'Mata Uang',
                'Input Date',
                'Last Update'
            ],
            $dataRows,
            [
                'A' => 6, 'B' => 28, 'C' => 18, 'D' => 42, 'E' => 12, 'F' => 18, 'G' => 20,
                'H' => 20, 'I' => 18, 'J' => 16, 'K' => 18, 'L' => 24, 'M' => 18, 'N' => 16,
                'O' => 14, 'P' => 14, 'Q' => 24, 'R' => 24
            ],
            ['B', 'D', 'L']
        );

        $filename = 'lapordata-item-lokasi-' . date('Ymd-His') . '.xlsx';
        lapordata_send_spreadsheet($spreadsheet, $filename);
    }
}
