<?php

defined('INDEX_AUTH') or die('Direct access not allowed!');

require_once __DIR__ . '/shared.php';

lapordata_require_admin_session();

$canRead = utility::havePrivilege('circulation', 'r');
if (!$canRead) {
    die('<div class="errorBox">' . __('You don\'t have enough privileges to access this area!') . '</div>');
}

$legacyPage = lapordata_approval_base_file();
if (!is_file($legacyPage)) {
    die('<div class="errorBox">Halaman Approval Peminjaman tidak ditemukan.</div>');
}

if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    require $legacyPage;
    return;
}

$baseAction = AWB . 'plugin_container.php';
$pluginMenuId = lapordata_current_plugin_menu_id('circulation', __FILE__);
$filters = lapordata_collect_approval_filters();
$locationOptions = lapordata_get_approval_location_options($dbs, $sysconf);
if (($filters['visit_location'] ?? 'all') !== 'all' && !in_array($filters['visit_location'], $locationOptions, true)) {
    $locationOptions[] = $filters['visit_location'];
}

$currentAction = trim((string) ($_GET['lapordata_action'] ?? ''));
if ($currentAction === 'export_approval') {
    lapordata_export_approval_excel($dbs, $sysconf, $filters);
}
?>
<style>
  .lapordata-panel {
    margin-bottom: 18px;
    border: 1px solid #cbd5e1;
    border-radius: 14px;
    background: linear-gradient(135deg, #f8fafc, #ecfeff);
    box-shadow: 0 10px 24px rgba(15, 23, 42, 0.08);
  }
  .lapordata-panel-head {
    padding: 18px 20px 10px;
  }
  .lapordata-panel-head h3 {
    margin: 0 0 6px;
    color: #0f172a;
    font-size: 22px;
  }
  .lapordata-panel-head p {
    margin: 0;
    color: #475569;
  }
  .lapordata-export-toolbar {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
    justify-content: space-between;
    gap: 14px;
  }
  .lapordata-export-summary {
    flex: 1 1 320px;
    min-width: 280px;
  }
  .lapordata-dropdown {
    position: relative;
  }
  .lapordata-dropdown-menu {
    position: absolute;
    right: 0;
    top: calc(100% + 10px);
    display: none;
    width: min(760px, calc(100vw - 60px));
    padding: 16px;
    border: 1px solid #cbd5e1;
    border-radius: 14px;
    background: #ffffff;
    box-shadow: 0 18px 38px rgba(15, 23, 42, 0.14);
    z-index: 50;
  }
  .lapordata-dropdown.is-open .lapordata-dropdown-menu {
    display: block;
  }
  .lapordata-panel .lapordata-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 12px;
  }
  .lapordata-panel label {
    display: block;
    margin-bottom: 6px;
    font-weight: 700;
    color: #0f172a;
  }
  .lapordata-panel .lapordata-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 14px;
  }
  .lapordata-panel .lapordata-note {
    margin-top: 12px;
    padding: 10px 12px;
    border-radius: 10px;
    background: rgba(13, 148, 136, 0.08);
    color: #0f172a;
    font-size: 13px;
  }
  @media (max-width: 767px) {
    .lapordata-dropdown {
      width: 100%;
    }
    .lapordata-dropdown > .btn {
      width: 100%;
    }
    .lapordata-dropdown-menu {
      position: static;
      width: 100%;
      margin-top: 10px;
    }
  }
</style>

<div class="lapordata-panel">
  <div class="lapordata-panel-head">
    <div class="lapordata-export-toolbar">
      <div class="lapordata-export-summary">
        <h3>Export Excel Approval Peminjaman</h3>
        <p>Filter export approval sekarang tampil lewat dropdown saat tombol export diklik, jadi submenu `circulation` tetap rapi dan halaman approval lama tetap muncul di bawah.</p>
      </div>
      <div class="lapordata-dropdown" id="lapordataApprovalDropdown">
        <button type="button" class="btn btn-success" onclick="toggleLapordataApprovalDropdown(event)">Export Excel Approval</button>
        <div class="lapordata-dropdown-menu">
          <form method="get" action="<?php echo htmlspecialchars($baseAction); ?>">
            <input type="hidden" name="mod" value="circulation">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($pluginMenuId); ?>">
            <div class="lapordata-grid">
              <div>
                <label for="lapordataApprovalStatus">Status</label>
                <select id="lapordataApprovalStatus" name="status" class="form-control">
                  <?php foreach (['all' => 'Semua status', 'pending' => 'Pending', 'processing' => 'Processing', 'approved' => 'Approved', 'rejected' => 'Rejected', 'partial' => 'Partial', 'failed' => 'Failed'] as $value => $label) { ?>
                    <option value="<?php echo htmlspecialchars($value); ?>"<?php echo $filters['status'] === $value ? ' selected' : ''; ?>><?php echo htmlspecialchars($label); ?></option>
                  <?php } ?>
                </select>
              </div>
              <div>
                <label for="lapordataApprovalAction">Jenis Aksi</label>
                <select id="lapordataApprovalAction" name="action_type" class="form-control">
                  <?php foreach (['all' => 'Semua aksi', 'loan' => 'Pinjam', 'return' => 'Kembali', 'extend' => 'Perpanjang', 'renew' => 'Renew', 'renewal' => 'Renewal'] as $value => $label) { ?>
                    <option value="<?php echo htmlspecialchars($value); ?>"<?php echo $filters['action_type'] === $value ? ' selected' : ''; ?>><?php echo htmlspecialchars($label); ?></option>
                  <?php } ?>
                </select>
              </div>
              <div>
                <label for="lapordataApprovalLocation">Lokasi Kunjungan</label>
                <select id="lapordataApprovalLocation" name="visit_location" class="form-control">
                  <option value="all">Semua lokasi</option>
                  <?php foreach ($locationOptions as $locationOption) { ?>
                    <option value="<?php echo htmlspecialchars((string) $locationOption); ?>"<?php echo $filters['visit_location'] === $locationOption ? ' selected' : ''; ?>><?php echo htmlspecialchars((string) $locationOption); ?></option>
                  <?php } ?>
                </select>
              </div>
              <div>
                <label for="lapordataApprovalDateFrom">Tanggal Dari</label>
                <input id="lapordataApprovalDateFrom" type="date" name="date_from" class="form-control" value="<?php echo htmlspecialchars((string) $filters['date_from']); ?>">
              </div>
              <div>
                <label for="lapordataApprovalDateTo">Tanggal Sampai</label>
                <input id="lapordataApprovalDateTo" type="date" name="date_to" class="form-control" value="<?php echo htmlspecialchars((string) $filters['date_to']); ?>">
              </div>
            </div>
            <div class="lapordata-actions">
              <button type="submit" class="btn btn-primary">Terapkan Filter ke Halaman</button>
              <button type="submit" name="lapordata_action" value="export_approval" class="btn btn-success">Download Excel</button>
            </div>
            <div class="lapordata-note">
              File Excel berisi sheet <strong>Ringkasan</strong>, <strong>Approval Data</strong>, dan <strong>Detail Item</strong> agar rekap request dan item tidak saling bertabrakan saat dibuka di Excel.
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  function toggleLapordataApprovalDropdown(event) {
    if (event) event.stopPropagation();
    var dropdown = document.getElementById('lapordataApprovalDropdown');
    if (!dropdown) return;
    dropdown.classList.toggle('is-open');
  }

  document.addEventListener('click', function (event) {
    var dropdown = document.getElementById('lapordataApprovalDropdown');
    if (!dropdown) return;
    if (!dropdown.contains(event.target)) {
      dropdown.classList.remove('is-open');
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      var dropdown = document.getElementById('lapordataApprovalDropdown');
      if (dropdown) {
        dropdown.classList.remove('is-open');
      }
    }
  });
</script>

<?php require $legacyPage; ?>
