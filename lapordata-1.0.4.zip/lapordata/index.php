<?php
defined('INDEX_AUTH') or die('Direct access not allowed!');
