<?php
/**
 * Plugin Name: Lapor Data
 * Plugin URI: https://slims.web.id
 * Description: Export Excel rapi untuk Kelola Visitor Lengkap dan Approval Peminjaman tanpa mengubah plugin asal.
 * Version: 1.0.4
 * Author: Irsyad
 * Author URI:
 */

use SLiMS\Plugins;

if (!class_exists(Plugins::class)) {
    return;
}

if (defined('LAPORDATA_PLUGIN_BOOTSTRAPPED')) {
    return;
}
define('LAPORDATA_PLUGIN_BOOTSTRAPPED', true);

require_once __DIR__ . '/shared.php';

$plugin = Plugins::getInstance();

$reportingGroup = function_exists('__') ? __('REPORTING FORM') : 'REPORTING FORM';
$applyLapordataMenus = function () use ($plugin, $reportingGroup) {
    Plugins::group($reportingGroup, function () use ($plugin) {
        $plugin->registerMenu(
            'reporting',
            'Kelola Visitor Lengkap',
            __DIR__ . '/visitor_export.php',
            'Kelola visitor lengkap dengan panel export Excel terstruktur'
        );
    });

    // Use an internal label so other plugins do not strip this wrapper
    // before we can re-prefer it after admin session start.
    $plugin->registerMenu(
        'circulation',
        lapordata_internal_approval_menu_label(),
        __DIR__ . '/approval_export.php',
        'Approval peminjaman dengan panel export Excel terstruktur'
    );

    $plugin->registerMenu(
        'bibliography',
        lapordata_biblio_item_export_menu_label(),
        __DIR__ . '/item_location_export.php',
        'Export item per lokasi dengan Excel terstruktur'
    );

    lapordata_prefer_module_menu(
        $plugin,
        'reporting',
        __DIR__ . '/visitor_export.php',
        ['Kelola Visitor Lengkap'],
        [SB . 'plugins/MagangKp/kelola_visitor_lengkap.php'],
        'Kelola Visitor Lengkap',
        'Kelola visitor lengkap dengan panel export Excel terstruktur'
    );

    lapordata_prefer_module_menu(
        $plugin,
        'circulation',
        __DIR__ . '/approval_export.php',
        lapordata_approval_menu_aliases(),
        [
            SB . 'plugins/MagangKp/updateterbaru/approval.php',
            SB . 'plugins/MagangKp/peminjaman/approval.php'
        ],
        lapordata_approval_menu_label(),
        'Approval peminjaman dengan panel export Excel terstruktur'
    );

    lapordata_prefer_module_menu(
        $plugin,
        'bibliography',
        __DIR__ . '/item_location_export.php',
        lapordata_biblio_item_export_menu_aliases(),
        [SB . 'admin/modules/bibliography/item_export.php'],
        lapordata_biblio_item_export_menu_label(),
        'Export item per lokasi dengan Excel terstruktur'
    );
};

$applyLapordataMenus();
$plugin->register(Plugins::ADMIN_SESSION_AFTER_START, $applyLapordataMenus);

$plugin->register(Plugins::CONTENT_BEFORE_LOAD, function ($opac) {
    lapordata_boot_visitor_member_lookup($opac);
});
