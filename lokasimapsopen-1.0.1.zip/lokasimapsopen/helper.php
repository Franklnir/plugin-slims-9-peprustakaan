<?php

if (!function_exists('lokasimapsNormalizeCoordinate')) {
    function lokasimapsNormalizeCoordinate($value)
    {
        return str_replace(',', '.', trim((string) $value));
    }
}

if (!function_exists('lokasimapsNormalizeLabel')) {
    function lokasimapsNormalizeLabel($value, $fallback = '')
    {
        $label = trim((string) $value);
        if ($label === '') {
            $label = (string) $fallback;
        }
        return strip_tags($label);
    }
}

if (!function_exists('lokasimapsDefaultLocations')) {
    function lokasimapsDefaultLocations($sysconf)
    {
        $lat = isset($sysconf['location']['lat']) && is_numeric($sysconf['location']['lat'])
            ? (float) $sysconf['location']['lat']
            : 0.0;

        $lng = isset($sysconf['location']['long']) && is_numeric($sysconf['location']['long'])
            ? (float) $sysconf['location']['long']
            : 0.0;

        $libraryName = lokasimapsNormalizeLabel($sysconf['library_name'] ?? '', __('Library Location'));

        return [[
            'label' => $libraryName !== '' ? $libraryName : __('Library Location'),
            'lat' => $lat,
            'long' => $lng,
        ]];
    }
}

if (!function_exists('lokasimapsExtractValidLocations')) {
    function lokasimapsExtractValidLocations($rawLocations)
    {
        $locations = [];

        if (!is_array($rawLocations)) {
            return $locations;
        }

        foreach ($rawLocations as $index => $row) {
            if (!is_array($row)) {
                continue;
            }

            $lat = lokasimapsNormalizeCoordinate($row['lat'] ?? '');
            $lng = lokasimapsNormalizeCoordinate($row['long'] ?? '');

            if ($lat === '' || $lng === '' || !is_numeric($lat) || !is_numeric($lng)) {
                continue;
            }

            $lat = (float) $lat;
            $lng = (float) $lng;

            if ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
                continue;
            }

            $locations[] = [
                'label' => lokasimapsNormalizeLabel($row['label'] ?? '', __('Location') . ' ' . ((int) $index + 1)),
                'lat' => $lat,
                'long' => $lng,
            ];
        }

        return $locations;
    }
}

if (!function_exists('lokasimapsGetLocations')) {
    function lokasimapsGetLocations($dbs, $sysconf)
    {
        $locations = [];

        if ($dbs instanceof mysqli) {
            $settingName = $dbs->escape_string('lokasimaps_locations');
            $query = $dbs->query("SELECT setting_value FROM setting WHERE setting_name = '{$settingName}' LIMIT 1");
            if ($query && $query->num_rows > 0) {
                $row = $query->fetch_assoc();
                $stored = @unserialize($row['setting_value']);
                $locations = lokasimapsExtractValidLocations($stored);
            }
        }

        if (count($locations) < 1) {
            $locations = lokasimapsDefaultLocations($sysconf);
        }

        return [
            'locations' => $locations,
            'primary' => $locations[0],
        ];
    }
}

if (!function_exists('lokasimapsBuildFromPost')) {
    function lokasimapsBuildFromPost($labels, $lats, $lngs, &$errors)
    {
        $errors = [];
        $locations = [];

        $labels = is_array($labels) ? $labels : [];
        $lats = is_array($lats) ? $lats : [];
        $lngs = is_array($lngs) ? $lngs : [];

        $max = max(count($labels), count($lats), count($lngs));

        for ($i = 0; $i < $max; $i++) {
            $rawLabel = $labels[$i] ?? '';
            $rawLat = lokasimapsNormalizeCoordinate($lats[$i] ?? '');
            $rawLng = lokasimapsNormalizeCoordinate($lngs[$i] ?? '');

            if (trim((string) $rawLabel) === '' && $rawLat === '' && $rawLng === '') {
                continue;
            }

            if ($rawLat === '' || $rawLng === '') {
                $errors[] = __('Latitude and longitude are required at row') . ' ' . ($i + 1) . '.';
                continue;
            }

            if (!is_numeric($rawLat) || !is_numeric($rawLng)) {
                $errors[] = __('Latitude and longitude must be numeric at row') . ' ' . ($i + 1) . '.';
                continue;
            }

            $lat = (float) $rawLat;
            $lng = (float) $rawLng;

            if ($lat < -90 || $lat > 90) {
                $errors[] = __('Latitude range is -90 to 90 at row') . ' ' . ($i + 1) . '.';
                continue;
            }

            if ($lng < -180 || $lng > 180) {
                $errors[] = __('Longitude range is -180 to 180 at row') . ' ' . ($i + 1) . '.';
                continue;
            }

            $locations[] = [
                'label' => lokasimapsNormalizeLabel($rawLabel, __('Location') . ' ' . ($i + 1)),
                'lat' => $lat,
                'long' => $lng,
            ];
        }

        if (count($locations) < 1 && count($errors) < 1) {
            $errors[] = __('Please add at least one location.');
            return [];
        }

        return $locations;
    }
}

if (!function_exists('lokasimapsUpsertSetting')) {
    function lokasimapsUpsertSetting($dbs, $name, $value)
    {
        if (!($dbs instanceof mysqli)) {
            return false;
        }

        $nameEsc = $dbs->escape_string((string) $name);
        $valueEsc = $dbs->escape_string(serialize($value));
        $sql = "INSERT INTO setting (setting_name, setting_value) VALUES ('{$nameEsc}', '{$valueEsc}') "
            . "ON DUPLICATE KEY UPDATE setting_value = '{$valueEsc}'";

        return (bool) $dbs->query($sql);
    }
}

if (!function_exists('lokasimapsSaveLocations')) {
    function lokasimapsSaveLocations($dbs, $locations, &$error = '')
    {
        if (!($dbs instanceof mysqli)) {
            $error = 'Database connection is not available.';
            return false;
        }

        if (!is_array($locations) || count($locations) < 1) {
            $error = 'Locations data is empty.';
            return false;
        }

        $primary = $locations[0];

        if (!lokasimapsUpsertSetting($dbs, 'lokasimaps_locations', $locations)) {
            $error = $dbs->error;
            return false;
        }

        $compat = [
            'lat' => (float) $primary['lat'],
            'long' => (float) $primary['long'],
        ];

        if (!lokasimapsUpsertSetting($dbs, 'location', $compat)) {
            $error = $dbs->error;
            return false;
        }

        return true;
    }
}
