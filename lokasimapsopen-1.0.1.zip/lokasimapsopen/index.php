<?php

defined('INDEX_AUTH') or die('Direct access not allowed!');

require LIB . 'ip_based_access.inc.php';
do_checkIP('smc');
do_checkIP('smc-system');

require SB . 'admin/default/session.inc.php';
require SB . 'admin/default/session_check.inc.php';
require_once __DIR__ . '/helper.php';

$canRead = utility::havePrivilege('system', 'r');
$canWrite = utility::havePrivilege('system', 'w');

if (!$canRead) {
    die('<div class="errorBox">' . __('You are not authorized to view this section') . '</div>');
}

$errors = [];
$success = '';
$bundle = lokasimapsGetLocations($dbs, $sysconf);
$locations = $bundle['locations'];

if (isset($_POST['saveLocations'])) {
    if (!$canWrite) {
        $errors[] = __('You are not authorized to change settings.');
    } else {
        $newLocations = lokasimapsBuildFromPost(
            $_POST['location_label'] ?? [],
            $_POST['location_lat'] ?? [],
            $_POST['location_long'] ?? [],
            $errors
        );

        if (count($errors) < 1) {
            $saveError = '';
            if (lokasimapsSaveLocations($dbs, $newLocations, $saveError)) {
                utility::loadSettings($dbs);
                $bundle = lokasimapsGetLocations($dbs, $sysconf);
                $locations = $bundle['locations'];
                $success = __('Location data has been saved.');

                utility::writeLogs(
                    $dbs,
                    'staff',
                    $_SESSION['uid'],
                    'system',
                    $_SESSION['realname'] . ' update multi library locations via LokasiMaps plugin',
                    'LokasiMaps',
                    'Update'
                );
            } else {
                $errors[] = __('Failed to save location data.') . ' DEBUG : ' . $saveError;
                $locations = $newLocations;
            }
        } else {
            $locations = $newLocations;
        }
    }
}

if (count($locations) < 1) {
    $locations = lokasimapsDefaultLocations($sysconf);
}

$queryString = trim((string) ($_SERVER['QUERY_STRING'] ?? ''));
$formAction = htmlspecialchars($_SERVER['PHP_SELF'] . ($queryString ? '?' . $queryString : ''), ENT_QUOTES, 'UTF-8');
$opacMapUrl = htmlspecialchars(SWB . 'index.php?p=peta', ENT_QUOTES, 'UTF-8');
$locationsJson = json_encode($locations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>

<div class="menuBox">
    <div class="menuBoxInner systemIcon">
        <div class="per_title">
            <h2><?php echo __('Lokasi Maps'); ?></h2>
        </div>
        <div class="infoBox">
            <?php echo __('Add multiple library locations. Drag red markers on map for precise latitude/longitude, then save.'); ?>
        </div>
    </div>
</div>

<?php if (!empty($success)) { ?>
<div class="alert alert-success" role="alert"><?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?></div>
<?php } ?>

<?php if (count($errors) > 0) { ?>
<div class="alert alert-danger" role="alert">
    <ul style="margin-bottom: 0; padding-left: 18px;">
        <?php foreach ($errors as $error) { ?>
        <li><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></li>
        <?php } ?>
    </ul>
</div>
<?php } ?>

<div class="card mb-3" id="lokasimapsSearchCard" style="display: none;">
    <div class="card-header"><strong>Pencarian Lokasi</strong></div>
    <div class="card-body">
        <div class="d-flex flex-wrap" style="gap: 8px;">
            <input type="text" class="form-control" id="lokasimapsSearchInput" placeholder="Ketik alamat/tempat atau koordinat lat,long" style="max-width: 420px;">
            <button type="button" class="btn btn-default" id="lokasimapsSearchButton">Cari</button>
        </div>
        <small class="text-muted d-block mt-2">Pencarian akan memindahkan peta otomatis. Pilih baris lokasi yang ingin diubah.</small>
        <small class="text-muted d-block">Tips: tombol Cari pada tabel akan memprioritaskan Latitude/Longitude manual jika kolomnya terisi.</small>
        <div id="lokasimapsSearchStatus" class="mt-2 text-muted"></div>
        <div id="lokasimapsSearchResults" class="mt-2"></div>
    </div>
</div>

<form method="post" action="<?php echo $formAction; ?>" id="lokasimapsForm">
    <div class="card mb-3">
        <div class="card-header d-flex justify-content-between align-items-center">
            <strong><?php echo __('Location List'); ?></strong>
            <button type="button" class="btn btn-default btn-sm" id="lokasimapsAddRow"><?php echo __('Add Location'); ?></button>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped mb-0" id="lokasimapsTable">
                    <thead>
                        <tr>
                            <th><?php echo __('Location Name'); ?></th>
                            <th style="width: 200px;"><?php echo __('Latitude'); ?></th>
                            <th style="width: 200px;"><?php echo __('Longitude'); ?></th>
                            <th style="width: 160px;"><?php echo __('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="lokasimapsRows">
                        <?php foreach ($locations as $location) { ?>
                        <tr>
                            <td>
                                <input type="text" class="form-control" name="location_label[]" value="<?php echo htmlspecialchars((string) $location['label'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="<?php echo __('Location Name'); ?>">
                            </td>
                            <td>
                                <input type="text" class="form-control" name="location_lat[]" value="<?php echo htmlspecialchars((string) $location['lat'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="-7.977000" autocomplete="off">
                            </td>
                            <td>
                                <input type="text" class="form-control" name="location_long[]" value="<?php echo htmlspecialchars((string) $location['long'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="112.634025" autocomplete="off">
                            </td>
                            <td class="text-center lokasimaps-action-cell">
                                <button type="button" class="btn btn-default btn-sm lokasimaps-search-row" title="<?php echo __('Search Location'); ?>">Cari</button>
                                <button type="button" class="btn btn-danger btn-sm lokasimaps-remove-row" title="<?php echo __('Remove'); ?>">&times;</button>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer d-flex flex-wrap" style="gap: 8px;">
            <button type="button" class="btn btn-default" id="lokasimapsRefreshPreview"><?php echo __('Refresh Map Preview'); ?></button>
            <?php if ($canWrite) { ?>
            <button type="submit" name="saveLocations" class="btn btn-primary"><?php echo __('Save Settings'); ?></button>
            <?php } ?>
            <a href="<?php echo $opacMapUrl; ?>" class="btn btn-success" target="_blank" rel="noopener noreferrer"><?php echo __('Open OPAC Map'); ?></a>
        </div>
        <div class="card-footer">
            <small class="text-muted">Klik tombol Cari pada baris lokasi: jika Latitude/Longitude terisi maka dipakai sebagai koordinat manual, jika kosong maka cari dari Location Name.</small>
        </div>
    </div>
</form>

<div class="card">
    <div class="card-header"><strong><?php echo __('Map Preview'); ?></strong></div>
    <div class="card-body" style="padding: 0;">
        <div id="lokasimapsPreview" style="width: 100%; min-height: 420px;"></div>
    </div>
    <div class="card-footer">
        <small class="text-muted">Tips: bisa isi koordinat lewat 3 cara: geser marker merah, cari lokasi, atau ketik manual (marker ikut berpindah). Klik peta juga bisa set koordinat baris aktif.</small>
    </div>
</div>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="anonymous">
<style>
#lokasimapsRows tr {
    cursor: pointer;
}

#lokasimapsRows tr.lokasimaps-active-row {
    background: #fff8dc;
}

#lokasimapsSearchResults button {
    display: block;
    width: 100%;
    text-align: left;
    margin-top: 6px;
}

#lokasimapsRows .lokasimaps-action-cell {
    white-space: nowrap;
}

#lokasimapsRows .lokasimaps-search-row {
    margin-right: 6px;
}
</style>
<script>
(function () {
    var tableBody = document.getElementById('lokasimapsRows');
    var addBtn = document.getElementById('lokasimapsAddRow');
    var refreshBtn = document.getElementById('lokasimapsRefreshPreview');
    var previewElement = document.getElementById('lokasimapsPreview');
    var searchCard = document.getElementById('lokasimapsSearchCard');
    var searchInput = document.getElementById('lokasimapsSearchInput');
    var searchButton = document.getElementById('lokasimapsSearchButton');
    var searchStatus = document.getElementById('lokasimapsSearchStatus');
    var searchResults = document.getElementById('lokasimapsSearchResults');
    var initialLocations = <?php echo $locationsJson ?: '[]'; ?>;

    var mapInstance = null;
    var markerList = [];
    var tileLayer = null;
    var dragIcon = null;
    var activeRow = null;

    function normalizeCoordinate(value) {
        return (value || '').trim().replace(',', '.');
    }

    function createRow(location) {
        var row = document.createElement('tr');
        var label = location && location.label ? location.label : '';
        var lat = location && (typeof location.lat !== 'undefined') ? String(location.lat) : '';
        var lng = location && (typeof location.long !== 'undefined') ? String(location.long) : '';

        row.innerHTML = '' +
            '<td><input type="text" class="form-control" name="location_label[]" value="' + escapeHtml(label) + '" placeholder="<?php echo addslashes(__('Location Name')); ?>"></td>' +
            '<td><input type="text" class="form-control" name="location_lat[]" value="' + escapeHtml(lat) + '" placeholder="-7.977000" autocomplete="off"></td>' +
            '<td><input type="text" class="form-control" name="location_long[]" value="' + escapeHtml(lng) + '" placeholder="112.634025" autocomplete="off"></td>' +
            '<td class="text-center lokasimaps-action-cell"><button type="button" class="btn btn-default btn-sm lokasimaps-search-row" title="<?php echo addslashes(__('Search Location')); ?>">Cari</button><button type="button" class="btn btn-danger btn-sm lokasimaps-remove-row" title="<?php echo addslashes(__('Remove')); ?>">&times;</button></td>';

        return row;
    }

    function setActiveRow(row) {
        if (!row) {
            return;
        }

        activeRow = row;
        var rows = tableBody.querySelectorAll('tr');
        for (var i = 0; i < rows.length; i++) {
            rows[i].classList.remove('lokasimaps-active-row');
        }
        row.classList.add('lokasimaps-active-row');
    }

    function openSearchForRow(row, focusSearchInput) {
        if (!row) {
            return;
        }

        setActiveRow(row);

        if (searchCard) {
            searchCard.style.display = '';
        }

        if (searchInput && focusSearchInput) {
            var labelInput = row.querySelector('input[name="location_label[]"]');
            if (labelInput && labelInput.value.trim() !== '') {
                searchInput.value = labelInput.value.trim();
            }
            searchInput.focus();
            searchInput.select();
        }
    }

    function searchByRow(row) {
        if (!row) {
            return;
        }

        openSearchForRow(row, true);

        var latInput = row.querySelector('input[name="location_lat[]"]');
        var lngInput = row.querySelector('input[name="location_long[]"]');
        var latRaw = latInput ? normalizeCoordinate(latInput.value) : '';
        var lngRaw = lngInput ? normalizeCoordinate(lngInput.value) : '';

        // Prioritas: jika koordinat manual sudah diisi, pakai langsung tanpa pencarian nama lokasi.
        if (latRaw !== '' || lngRaw !== '') {
            var lat = Number(latRaw);
            var lng = Number(lngRaw);
            if (isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
                setSearchStatus('Format koordinat manual tidak valid. Gunakan Latitude (-90 s/d 90) dan Longitude (-180 s/d 180).', true);
                clearSearchResults();
                return;
            }

            setRowCoordinate(row, lat, lng);
            renderPreview(false);
            if (mapInstance) {
                mapInstance.setView([lat, lng], 16);
            }
            setSearchStatus('Koordinat manual dipasang ke baris aktif. Jika kurang presisi, geser marker merah.', false);
            clearSearchResults();
            return;
        }

        var labelInput = row.querySelector('input[name="location_label[]"]');
        var query = (labelInput && labelInput.value ? labelInput.value : '').trim();

        if (!query) {
            setSearchStatus('Isi Location Name dulu, lalu klik Cari lagi.', true);
            clearSearchResults();
            return;
        }

        if (searchInput) {
            searchInput.value = query;
        }

        runSearch(query);
    }

    function getActiveRow() {
        if (activeRow && activeRow.isConnected) {
            return activeRow;
        }

        var first = tableBody.querySelector('tr');
        if (first) {
            setActiveRow(first);
            return first;
        }

        var fallbackCenter = getCurrentMapCenter();
        var row = createRow({lat: fallbackCenter.lat, long: fallbackCenter.lng});
        tableBody.appendChild(row);
        setActiveRow(row);
        return row;
    }

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function getDragIcon() {
        if (dragIcon) {
            return dragIcon;
        }

        var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26 38">' +
            '<path d="M13 0C6.4 0 1 5.4 1 12c0 8.6 9.4 18.6 11.2 20.5a1.2 1.2 0 0 0 1.6 0C15.6 30.6 25 20.6 25 12 25 5.4 19.6 0 13 0z" fill="#d93025"/>' +
            '<circle cx="13" cy="12" r="4.2" fill="#fff"/></svg>';

        dragIcon = L.icon({
            iconUrl: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg),
            iconSize: [26, 38],
            iconAnchor: [13, 36],
            popupAnchor: [0, -28]
        });

        return dragIcon;
    }

    function clearSearchResults() {
        if (searchResults) {
            searchResults.innerHTML = '';
        }
    }

    function setSearchStatus(message, isError) {
        if (!searchStatus) {
            return;
        }

        searchStatus.textContent = message || '';
        searchStatus.style.color = isError ? '#b91c1c' : '#374151';
    }

    function collectRowData() {
        var rows = tableBody.querySelectorAll('tr');
        var data = [];

        for (var i = 0; i < rows.length; i++) {
            var row = rows[i];
            var labelInput = row.querySelector('input[name="location_label[]"]');
            var latInput = row.querySelector('input[name="location_lat[]"]');
            var lngInput = row.querySelector('input[name="location_long[]"]');
            if (!labelInput || !latInput || !lngInput) {
                continue;
            }

            var latRaw = normalizeCoordinate(latInput.value);
            var lngRaw = normalizeCoordinate(lngInput.value);
            var lat = Number(latRaw);
            var lng = Number(lngRaw);
            var valid = latRaw !== '' && lngRaw !== '' && !isNaN(lat) && !isNaN(lng);
            var label = (labelInput.value || '').trim() || ('<?php echo addslashes(__('Location')); ?> ' + (i + 1));

            data.push({
                row: row,
                rowIndex: i,
                labelInput: labelInput,
                latInput: latInput,
                lngInput: lngInput,
                label: label,
                lat: lat,
                lng: lng,
                valid: valid
            });
        }

        return data;
    }

    function getCurrentMapCenter() {
        if (mapInstance) {
            var c = mapInstance.getCenter();
            return {
                lat: c.lat.toFixed(6),
                lng: c.lng.toFixed(6)
            };
        }

        var first = Array.isArray(initialLocations) && initialLocations.length > 0 ? initialLocations[0] : null;
        if (first && !isNaN(Number(first.lat)) && !isNaN(Number(first.long))) {
            return {
                lat: Number(first.lat).toFixed(6),
                lng: Number(first.long).toFixed(6)
            };
        }

        return {
            lat: '0.000000',
            lng: '0.000000'
        };
    }

    function clearMarkers() {
        if (!mapInstance) return;
        for (var i = 0; i < markerList.length; i++) {
            mapInstance.removeLayer(markerList[i]);
        }
        markerList = [];
    }

    function setRowCoordinate(row, lat, lng) {
        if (!row) {
            return;
        }

        var latInput = row.querySelector('input[name="location_lat[]"]');
        var lngInput = row.querySelector('input[name="location_long[]"]');
        if (!latInput || !lngInput) {
            return;
        }

        latInput.value = Number(lat).toFixed(6);
        lngInput.value = Number(lng).toFixed(6);
    }

    function centerToActiveRow(zoomLevel) {
        if (!mapInstance) {
            return;
        }

        var row = getActiveRow();
        var latInput = row.querySelector('input[name="location_lat[]"]');
        var lngInput = row.querySelector('input[name="location_long[]"]');
        if (!latInput || !lngInput) {
            return;
        }

        var lat = Number(normalizeCoordinate(latInput.value));
        var lng = Number(normalizeCoordinate(lngInput.value));
        if (isNaN(lat) || isNaN(lng)) {
            return;
        }

        mapInstance.setView([lat, lng], zoomLevel || 16);
    }

    function ensureMap(center) {
        if (typeof L === 'undefined') {
            return false;
        }

        if (!mapInstance) {
            mapInstance = L.map(previewElement, {
                zoomControl: true
            });

            tileLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; OpenStreetMap contributors'
            });
            tileLayer.addTo(mapInstance);

            // Klik peta untuk set koordinat row aktif.
            mapInstance.on('click', function (event) {
                var row = getActiveRow();
                if (!row) {
                    return;
                }

                setRowCoordinate(row, event.latlng.lat, event.latlng.lng);
                renderPreview(false);
                centerToActiveRow(mapInstance.getZoom());
            });
        }

        mapInstance.setView([Number(center.lat), Number(center.long)], 14);
        mapInstance.invalidateSize();
        return true;
    }

    function renderPreview(fitBounds) {
        if (typeof L === 'undefined') {
            return;
        }

        var rowsData = collectRowData();
        var locations = rowsData.filter(function (item) { return item.valid; });
        if (locations.length < 1) {
            clearMarkers();
            return;
        }

        if (!ensureMap({lat: locations[0].lat, long: locations[0].lng})) {
            return;
        }

        clearMarkers();
        var activeMarker = null;

        var bounds = [];
        locations.forEach(function (item) {
            var label = item.label;
            var marker = L.marker([item.lat, item.lng], {
                title: label,
                draggable: true,
                icon: getDragIcon()
            }).addTo(mapInstance);
            marker.bindPopup('<strong>' + escapeHtml(label) + '</strong>');
            marker.on('click', function () {
                setActiveRow(item.row);
            });
            marker.on('dragstart', function () {
                setActiveRow(item.row);
            });
            marker.on('dragend', function (event) {
                var point = event.target.getLatLng();
                setRowCoordinate(item.row, point.lat, point.lng);
                setActiveRow(item.row);
                centerToActiveRow(mapInstance.getZoom());
            });

            markerList.push(marker);
            bounds.push([item.lat, item.lng]);

            if (item.row === activeRow) {
                activeMarker = marker;
            }
        });

        if (fitBounds !== false && bounds.length > 1) {
            mapInstance.fitBounds(bounds, {padding: [20, 20]});
        } else if (fitBounds !== false && bounds.length === 1) {
            mapInstance.setView(bounds[0], 14);
        }

        if (activeMarker) {
            activeMarker.openPopup();
        }
    }

    function renderSearchResultButtons(results) {
        if (!searchResults) {
            return;
        }

        clearSearchResults();
        results.forEach(function (result) {
            var button = document.createElement('button');
            button.type = 'button';
            button.className = 'btn btn-default btn-sm';
            button.textContent = result.display_name || 'Hasil';
            button.addEventListener('click', function () {
                applySearchResult(result, false);
            });
            searchResults.appendChild(button);
        });
    }

    function normalizeQueryText(query) {
        return String(query || '')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function buildSearchCandidates(query) {
        var candidates = [];

        function pushUnique(value) {
            var cleaned = normalizeQueryText(value);
            if (!cleaned) {
                return;
            }
            if (candidates.indexOf(cleaned) === -1) {
                candidates.push(cleaned);
            }
        }

        var original = normalizeQueryText(query);
        pushUnique(original);
        pushUnique(original.replace(/[,.;]+/g, ' '));

        var strippedAddress = original
            .replace(/\b(no|nomor|rt|rw|blok|gang|gg|km)\b\.?\s*[\w/-]*/gi, ' ')
            .replace(/\b\d+[a-zA-Z/-]*\b/g, ' ')
            .replace(/[^\w\s-]/g, ' ');
        pushUnique(strippedAddress);

        var byComma = String(query || '').split(',');
        if (byComma.length > 1) {
            for (var i = byComma.length - 1; i >= 1; i--) {
                pushUnique(byComma.slice(0, i).join(' '));
            }
        }

        return candidates;
    }

    function searchNominatim(query) {
        return fetch('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&q=' + encodeURIComponent(query), {
            headers: {
                'Accept': 'application/json'
            }
        }).then(function (response) {
            if (!response.ok) {
                throw new Error('Search request failed');
            }
            return response.json();
        });
    }

    function applySearchResult(result, fromAutoPick, customMessage) {
        var row = getActiveRow();
        var latInput = row.querySelector('input[name="location_lat[]"]');
        var lngInput = row.querySelector('input[name="location_long[]"]');
        var labelInput = row.querySelector('input[name="location_label[]"]');
        if (!latInput || !lngInput || !labelInput) {
            return;
        }

        var lat = Number(result.lat);
        var lng = Number(result.lon || result.long);
        if (isNaN(lat) || isNaN(lng)) {
            return;
        }

        latInput.value = lat.toFixed(6);
        lngInput.value = lng.toFixed(6);

        if (!labelInput.value.trim()) {
            var labelSource = (result.display_name || searchInput.value || '').split(',')[0];
            labelInput.value = labelSource.trim();
        }

        renderPreview(false);

        if (mapInstance) {
            mapInstance.setView([lat, lng], 16);
        }

        setSearchStatus(
            customMessage || (
                fromAutoPick
                    ? 'Lokasi ditemukan dan dipasang otomatis. Jika kurang presisi, geser marker merah.'
                    : 'Lokasi dipasang ke baris aktif. Jika kurang presisi, geser marker merah.'
            ),
            false
        );
    }

    function runSearch(forcedQuery) {
        var query = (typeof forcedQuery === 'string' ? forcedQuery : (searchInput && searchInput.value ? searchInput.value : '')).trim();
        if (query === '') {
            setSearchStatus('Silakan ketik kata kunci lokasi terlebih dahulu.', true);
            clearSearchResults();
            return;
        }

        if (searchInput && searchInput.value !== query) {
            searchInput.value = query;
        }

        setSearchStatus('Sedang mencari lokasi...', false);
        clearSearchResults();

        var candidates = buildSearchCandidates(query);

        function tryCandidate(index) {
            if (index >= candidates.length) {
                setSearchStatus('Lokasi tidak ditemukan. Coba kata kunci yang lebih umum (nama tempat/kawasan).', true);
                return;
            }

            var candidate = candidates[index];
            searchNominatim(candidate)
                .then(function (results) {
                    if (!Array.isArray(results) || results.length < 1) {
                        tryCandidate(index + 1);
                        return;
                    }

                    var statusMessage = (index === 0)
                        ? 'Lokasi ditemukan. Jika kurang presisi, geser marker merah.'
                        : ('Pencarian awal tidak ketemu, sistem memakai pencarian cadangan: \"' + candidate + '\".');

                    applySearchResult(results[0], true, statusMessage);
                    renderSearchResultButtons(results);
                })
                .catch(function () {
                    if (index + 1 < candidates.length) {
                        tryCandidate(index + 1);
                        return;
                    }
                    setSearchStatus('Gagal mencari lokasi. Cek koneksi internet lalu coba lagi.', true);
                });
        }

        tryCandidate(0);
    }

    function initPreview() {
        if (tableBody.children.length < 1 && Array.isArray(initialLocations)) {
            initialLocations.forEach(function (location) {
                tableBody.appendChild(createRow(location));
            });
        }

        if (tableBody.children.length < 1) {
            tableBody.appendChild(createRow({}));
        }
        setActiveRow(tableBody.querySelector('tr'));

        if (typeof L !== 'undefined') {
            renderPreview();
        }
    }

    addBtn.addEventListener('click', function () {
        var center = getCurrentMapCenter();
        var row = createRow({lat: center.lat, long: center.lng});
        tableBody.appendChild(row);
        setActiveRow(row);
        renderPreview(false);
    });

    tableBody.addEventListener('click', function (event) {
        var target = event.target;
        if (target.classList.contains('lokasimaps-search-row')) {
            var searchRow = target.closest('tr');
            if (searchRow) {
                searchByRow(searchRow);
            }
            return;
        }

        if (target.classList.contains('lokasimaps-remove-row')) {
            if (tableBody.querySelectorAll('tr').length <= 1) {
                return;
            }

            var deletedRow = target.closest('tr');
            if (deletedRow) {
                deletedRow.remove();
                if (activeRow === deletedRow) {
                    activeRow = null;
                    setActiveRow(tableBody.querySelector('tr'));
                }
                renderPreview();
            }
            return;
        }

        var currentRow = target.closest('tr');
        if (currentRow) {
            setActiveRow(currentRow);
        }
    });

    tableBody.addEventListener('focusin', function (event) {
        var target = event.target;
        if (!target || (
            target.name !== 'location_lat[]' &&
            target.name !== 'location_long[]' &&
            target.name !== 'location_label[]'
        )) {
            return;
        }

        var row = target.closest('tr');
        if (row) {
            setActiveRow(row);
        }
    });

    tableBody.addEventListener('input', function (event) {
        var target = event.target;
        if (!target) return;

        if (target.name === 'location_lat[]' || target.name === 'location_long[]' || target.name === 'location_label[]') {
            var row = target.closest('tr');
            if (row) {
                setActiveRow(row);
            }
            renderPreview(false);
            if (target.name === 'location_lat[]' || target.name === 'location_long[]') {
                centerToActiveRow(16);
            }
        }
    });

    if (searchButton) {
        searchButton.addEventListener('click', runSearch);
    }

    if (searchInput) {
        searchInput.addEventListener('keydown', function (event) {
            if (event.key === 'Enter') {
                event.preventDefault();
                runSearch();
            }
        });
    }

    refreshBtn.addEventListener('click', function () {
        renderPreview();
    });

    window.lokasimapsInitPreview = function () {
        initPreview();
        renderPreview();
    };

    if (window.L) {
        window.lokasimapsInitPreview();
    }
})();
</script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" defer onload="window.lokasimapsInitPreview && window.lokasimapsInitPreview();" crossorigin="anonymous"></script>
