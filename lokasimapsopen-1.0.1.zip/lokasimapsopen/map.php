<?php

if (!defined('INDEX_AUTH')) {
    die('can not access this file directly');
}

require_once __DIR__ . '/helper.php';

if (!isset($locations) || !is_array($locations) || count($locations) < 1) {
    $bundle = lokasimapsGetLocations($dbs ?? null, $sysconf ?? []);
    $locations = $bundle['locations'];
}

$page_title = __('Library Location') . ' | ' . ($sysconf['library_name'] ?? 'SLiMS');

$jsLocations = [];
foreach ($locations as $index => $location) {
    $lat = (float) ($location['lat'] ?? 0);
    $lng = (float) ($location['long'] ?? 0);
    if ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
        continue;
    }

    $jsLocations[] = [
        'index' => $index,
        'label' => (string) ($location['label'] ?? __('Location') . ' ' . ($index + 1)),
        'lat' => $lat,
        'long' => $lng,
    ];
}

if (count($jsLocations) < 1) {
    $jsLocations[] = [
        'index' => 0,
        'label' => (string) __('Library Location'),
        'lat' => 0,
        'long' => 0,
    ];
}

$locationsJson = json_encode($jsLocations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

header('Content-Type: text/html; charset=utf-8');
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://unpkg.com; style-src 'self' 'unsafe-inline' https://unpkg.com; img-src 'self' data: https://*.tile.openstreetmap.org https://unpkg.com; font-src 'self' data: https://unpkg.com;");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($page_title, ENT_QUOTES, 'UTF-8'); ?></title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="anonymous">
<style>
html, body {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
}

#map_canvas {
    width: 100%;
    height: 100%;
}

.map-toolbar {
    position: absolute;
    z-index: 950;
    top: 10px;
    left: 56px;
    width: 360px;
    max-width: calc(100% - 66px);
    background: rgba(255, 255, 255, 0.92);
    border-radius: 8px;
    border: 1px solid rgba(0, 0, 0, 0.1);
    box-shadow: 0 4px 18px rgba(0, 0, 0, 0.16);
    padding: 8px 10px;
}

.map-toolbar label {
    display: block;
    margin-bottom: 4px;
    font-size: 12px;
    font-weight: 700;
    color: #1f2937;
}

.map-toolbar select {
    width: 100%;
    height: 34px;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    padding: 0 10px;
    font-size: 14px;
    color: #111827;
    background: #fff;
}
</style>
</head>
<body>
<div class="map-toolbar">
    <label for="lokasimapsLocationPicker"><?php echo __('Choose Location'); ?></label>
    <select id="lokasimapsLocationPicker"></select>
</div>
<div id="map_canvas"></div>

<script>
(function () {
    var locations = <?php echo $locationsJson ?: '[]'; ?>;
    var map = null;
    var markers = [];
    var picker = null;

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function focusMarker(index) {
        if (!map || !markers[index]) {
            return;
        }

        var marker = markers[index];
        var point = marker.getLatLng();
        map.flyTo(point, 16, {duration: 0.5});
        marker.openPopup();
    }

    function initMap() {
        if (typeof L === 'undefined') {
            return;
        }

        picker = document.getElementById('lokasimapsLocationPicker');
        map = L.map('map_canvas').setView([0, 0], 2);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        var bounds = [];
        markers = [];

        locations.forEach(function (location, index) {
            var lat = Number(location.lat);
            var lng = Number(location.long);
            if (isNaN(lat) || isNaN(lng)) {
                return;
            }

            var label = location.label || ('Location ' + (index + 1));
            var marker = L.marker([lat, lng], {title: label}).addTo(map);
            marker.bindPopup('<strong>' + escapeHtml(label) + '</strong><br>' + lat.toFixed(6) + ', ' + lng.toFixed(6));
            markers[index] = marker;
            bounds.push([lat, lng]);

            var option = document.createElement('option');
            option.value = String(index);
            option.textContent = label;
            picker.appendChild(option);
        });

        if (bounds.length > 1) {
            map.fitBounds(bounds, {padding: [24, 24]});
        } else if (bounds.length === 1) {
            map.setView(bounds[0], 14);
        }

        picker.addEventListener('change', function () {
            focusMarker(Number(this.value));
        });

        if (picker.options.length > 0) {
            picker.selectedIndex = 0;
            focusMarker(Number(picker.value));
        }
    }

    window.lokasimapsInitMap = initMap;
})();
</script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" defer onload="window.lokasimapsInitMap && window.lokasimapsInitMap();" crossorigin="anonymous"></script>
</body>
</html>
<?php
exit;
