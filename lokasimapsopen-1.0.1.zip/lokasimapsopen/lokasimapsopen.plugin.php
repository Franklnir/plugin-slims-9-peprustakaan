<?php
/**
 * Plugin Name: LokasiMapsOpen
 * Plugin URI: https://github.com/Franklnir/plugin_slimsperpusda_fitur_lokasi.git
 * Description: Kelola banyak lokasi perpustakaan dari admin dan tampilkan semua marker pada halaman peta OPAC.
 * Version: 1.0.1
 * Author: Sena dan Irsyad
 * Author URI: https://github.com/Franklnir/plugin_slimsperpusda_fitur_lokasi.git
 */

use SLiMS\Plugins;

require_once __DIR__ . '/helper.php';

$plugin = Plugins::getInstance();

$plugin->registerMenu(
    'system',
    function_exists('__') ? __('Lokasi Maps') : 'Lokasi Maps',
    __DIR__ . '/index.php',
    function_exists('__') ? __('Manage multi library locations and map markers') : 'Manage multi library locations and map markers'
);

$plugin->register(Plugins::CONTENT_BEFORE_LOAD, function ($opac) {
    $path = strtolower(trim((string) ($_GET['p'] ?? '')));
    if ($path === 'peta') {
        global $dbs, $sysconf;

        $bundle = lokasimapsGetLocations($dbs, $sysconf);
        $locations = $bundle['locations'];
        $primary = $bundle['primary'];

        include __DIR__ . '/map.php';
        exit;
    }

    $template = $opac->template ?? [];
    $theme = strtolower((string) ($template['theme'] ?? ''));
    if ($theme !== 'default') {
        return;
    }

    $locationLabel = 'Lokasi Perpustakaan';
    $locationLabelJs = json_encode($locationLabel, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $js = $opac->js ?? '';
    $js .= <<<HTML
<script>
document.addEventListener('DOMContentLoaded', function () {
  var currentPage = new URLSearchParams(window.location.search).get('p') || '';
  var locationLabel = {$locationLabelJs};
  var locationHref = 'index.php?p=peta';

  function hasLocationMenu(menu) {
    if (!menu) return false;
    return Boolean(
      menu.querySelector('a[data-lokasimaps-menu="1"]') ||
      menu.querySelector('a[href*="p=peta"]')
    );
  }

  function createLocationItem(isNavbar) {
    var item = document.createElement('li');
    var anchor = document.createElement('a');
    anchor.href = locationHref;
    anchor.textContent = locationLabel;
    anchor.setAttribute('data-lokasimaps-menu', '1');

    if (isNavbar) {
      item.className = 'nav-item' + (currentPage === 'peta' ? ' active' : '');
      anchor.className = 'nav-link';
    }

    item.appendChild(anchor);
    return item;
  }

  function insertAfter(targetLi, newLi) {
    if (!targetLi || !targetLi.parentNode || !newLi) return false;
    if (targetLi.nextSibling) {
      targetLi.parentNode.insertBefore(newLi, targetLi.nextSibling);
    } else {
      targetLi.parentNode.appendChild(newLi);
    }
    return true;
  }

  function insertLocationMenu(menu, isNavbar, allowFallback) {
    if (!menu) return false;
    if (hasLocationMenu(menu)) return true;

    var infoAnchor = menu.querySelector('a[href*="p=libinfo"]');
    var infoLi = infoAnchor ? infoAnchor.closest('li') : null;
    if (infoLi) {
      return insertAfter(infoLi, createLocationItem(isNavbar));
    }

    if (!allowFallback) return false;

    var visitorAnchor = menu.querySelector('a[href*="p=visitor"]');
    var visitorLi = visitorAnchor ? visitorAnchor.closest('li') : null;
    if (visitorLi) {
      return insertAfter(visitorLi, createLocationItem(isNavbar));
    }

    var homeSelector = isNavbar
      ? 'li a.nav-link[href="index.php"], li a.nav-link[href="./index.php"], li a[href="index.php"], li a[href="./index.php"]'
      : 'li a[href="index.php"], li a[href="./index.php"]';
    var homeAnchor = menu.querySelector(homeSelector);
    var homeLi = homeAnchor ? homeAnchor.closest('li') : null;
    if (homeLi) {
      return insertAfter(homeLi, createLocationItem(isNavbar));
    }

    menu.appendChild(createLocationItem(isNavbar));
    return true;
  }

  var menuTargets = [
    {node: document.querySelector('#navbarSupportedContent .navbar-nav'), isNavbar: true},
    {node: document.querySelector('.s-menu-content ul'), isNavbar: false}
  ];

  var attempts = 0;
  var maxAttempts = 20;
  var timer = window.setInterval(function () {
    attempts += 1;
    var allowFallback = attempts >= maxAttempts;
    var existingTargets = 0;
    var insertedTargets = 0;

    menuTargets.forEach(function (target) {
      if (!target.node) return;
      existingTargets += 1;
      if (insertLocationMenu(target.node, target.isNavbar, allowFallback)) {
        insertedTargets += 1;
      }
    });

    if ((existingTargets > 0 && insertedTargets >= existingTargets) || allowFallback) {
      window.clearInterval(timer);
    }
  }, 120);
});
</script>
HTML;
    $opac->js = $js;
});
