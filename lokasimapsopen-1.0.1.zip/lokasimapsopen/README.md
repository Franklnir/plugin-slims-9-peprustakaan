# LokasiMapsOpen (by Sena dan Irsyad)

Plugin SLiMS untuk:

- Input banyak lokasi perpustakaan dari admin.
- Menampilkan semua marker pada halaman OPAC `index.php?p=peta`.
- Memilih lokasi dari dropdown pada halaman `Lokasi Perpustakaan`.
- Menggunakan OpenStreetMap (tanpa API key Google Maps).

## Instalasi

1. Salin folder `lokasimapsopen` ke direktori `plugins/` pada server SLiMS.
2. Login admin.
3. Buka **System -> Plugins**.
4. Aktifkan plugin **LokasiMapsOpen**.

## Penggunaan

1. Buka **System -> Lokasi Maps**.
2. Klik/focus kolom **Latitude** atau **Longitude** pada baris yang ingin diubah (panel pencarian muncul otomatis).
3. Gunakan **Search Location** untuk mencari alamat/tempat, peta akan menuju otomatis.
4. Jika kurang presisi, geser marker merah di peta preview atau klik titik peta untuk mengisi koordinat baris aktif.
5. Klik **Save Settings**.
5. Cek hasil di OPAC: `index.php?p=peta`.

## Catatan Teknis

- Data multi lokasi disimpan di setting: `lokasimaps_locations`.
- Untuk kompatibilitas dengan core SLiMS, lokasi pertama juga disimpan ke setting `location`.
- Peta menggunakan Leaflet + OpenStreetMap tile.
- Plugin ini tidak memerlukan perubahan file core.
