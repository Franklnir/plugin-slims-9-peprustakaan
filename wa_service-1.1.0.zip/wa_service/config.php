<?php
/**
 * Dynamic Configuration for WA Bot SLiMS
 * Pulling data from SLiMS Database & Settings
 */

// Pastikan skrip ini berjalan dalam konteks SLiMS atau memiliki akses ke sistem
if (!defined('INDEX_AUTH')) {
    define('INDEX_AUTH', 1);
    // Jika dipanggil langsung (seperti oleh webhook), kita butuh akses database
    require_once __DIR__ . '/../../sysconfig.inc.php';
}

global $dbs;
$db = $slims = $dbs; 

// Ambil Pengaturan dari Database SLiMS
$get_api = $dbs->query("SELECT setting_value FROM setting WHERE setting_name = 'wa_bot_apikey'");
$APIKEY = ($get_api && $get_api->num_rows > 0) ? $get_api->fetch_row()[0] : 'SLIMS_BOT_RAHASIA_123';

$get_admin = $dbs->query("SELECT setting_value FROM setting WHERE setting_name = 'wa_bot_admin_number'");
$nomoradmin = ($get_admin && $get_admin->num_rows > 0) ? $get_admin->fetch_row()[0] : '6280000000000';

$web = \SLiMS\Url::getBaseUrl();
date_default_timezone_set('Asia/Jakarta');
?>
