<?php
/**
 * Halaman Informasi Perpustakaan (Horizontal Tabs)
 * Ditampilkan di OPAC SLiMS
 */

defined('INDEX_AUTH') or die('Direct access not allowed!');

// Ubah judul web browser agar tidak menggunakan slug "libinfo"
$page_title = 'Informasi Perpustakaan';

// Ambil konfigurasi perpustakaan
$libraries = \WaService\Config::libraries();

if (!is_array($libraries) || empty($libraries)) {
    $libraries = [];
}
?>

<style>
.info-perpus-wrapper {
    width: 100%;
    margin: 20px 0;
    font-family: inherit;
}

/* Container utama mengikuti gaya SLiMS */
.ht-container {
    background: transparent;
    border: none;
    display: flex;
    flex-direction: column;
}

/* Tab Navigation Style - Lebih menyatu dengan template Classic/Akasia */
.ht-navigation {
    display: flex;
    border-bottom: 2px solid #eee;
    margin-bottom: 20px;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

.ht-navigation::-webkit-scrollbar {
    height: 4px;
}

.ht-tab {
    padding: 12px 25px;
    border: none;
    background: transparent;
    font-size: 1rem;
    font-weight: 600;
    color: #777;
    cursor: pointer;
    transition: all 0.3s ease;
    border-bottom: 3px solid transparent;
    white-space: nowrap;
}

.ht-tab:hover {
    color: #333;
    background: rgba(0,0,0,0.02);
}

.ht-tab.active {
    color: #212529;
    border-bottom-color: #212529;
}

/* Content Area */
.ht-content-area {
    padding: 0;
    width: 100%;
    overflow-x: hidden;
    
}

.ht-pane {
    display: none;
    animation: fadeIn 0.4s ease;
}

.ht-pane.active {
    display: block;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(5px); }
    to { opacity: 1; transform: translateY(0); }
}

.ht-pane h3 {
    font-size: 1.8rem;
    font-weight: 700;
    color: #212529;
    margin-bottom: 20px;
}

/* Card Style untuk Struktur */
.ht-section {
    background: #fff;
    padding: 25px;
    border-radius: 8px;
    border: 1px none #e9ecef;
    box-shadow: 0 2px 10px rgba(0,0,0,0.02);
    margin-bottom: 30px;
}

.ht-section h4 {
    font-size: 0.9rem;
    font-weight: 700;
    color: #6c757d;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin-bottom: 20px;
    border-bottom: 1px solid #eee;
    padding-bottom: 10px;
}

/* Mencegah Bagan Over Layar */
.ws-sidebar-info img, 
.ht-section img {
    max-width: 100% !important;
    width: 100%;
    height: auto !important;
    display: block;
    border-radius: 6px;
    object-fit: contain;
}

/* Responsif */
@media screen and (min-width: 992px) {
    /* Menerapkan lebar 50% pada kolom konten utama di layar besar */
    .col-lg-8.col-sm-9.col-xs-12.animated.fadeInUp.delay2 {
        flex: 0 0 50% !important;
        max-width: 50% !important;
    }
    
    /* Memperlebar sidebar kiri (Informasi) menjadi 50% agar seimbang */
    .col-lg-4.col-sm-3.col-xs-12.animated.fadeInUp.delay4 {
        flex: 0 0 50% !important;
        max-width: 50% !important;
    }
}

@media screen and (max-width: 991px) {
    /* Tablet & Mobile: Kembali ke lebar penuh agar tidak sempit */
    .col-lg-8.col-sm-9.col-xs-12.animated.fadeInUp.delay2 {
        flex: 0 0 100% !important;
        max-width: 100% !important;
        width: 100% !important;
        margin-bottom: 20px;
    }

    /* Sidebar di bawah pada layar kecil */
    .col-lg-4.col-sm-3.col-xs-12 {
        flex: 0 0 100% !important;
        max-width: 100% !important;
    }
}

@media screen and (max-width: 768px) {
    .ht-tab {
        padding: 10px 15px;
        font-size: 0.9rem;
    }

    .ht-pane h3 {
        font-size: 1.5rem;
    }

    .ht-section {
        padding: 15px;
    }
}
</style>

<div class="info-perpus-wrapper">
    <div class="row no-gutters">
        <!-- Kolom Kiri: Informasi Dinamis (Bagan, Berita, Jam Operasional) -->
        <div id="ws-internal-sidebar-col" class="col-lg-7 col-md-12 mb-5">
            <div id="ws-dynamic-sidebar" class="ws-sidebar-info pr-lg-5">
                <p class="text-muted italic">Memuat informasi...</p>
            </div>
        </div>

        <!-- Kolom Kanan: Navigasi Tab & Struktur Organisasi -->
        <div id="ws-internal-content-col" class="col-lg-5 col-md-12">
            <div class="ht-container">
                <div class="ht-navigation">
                    <?php 
                    $first = true;
                    foreach ($libraries as $idx => $lib): 
                        $name = htmlspecialchars($lib['name'] ?? '');
                        if (empty($name)) continue; 
                        $activeClass = $first ? 'active' : '';
                    ?>
                        <button class="ht-tab <?php echo $activeClass; ?>" onclick="openTab(event, 'tab-<?php echo $idx; ?>'); if(typeof updateWsSidebar === 'function') updateWsSidebar(<?php echo $idx; ?>);">
                            <?php echo $name; ?>
                        </button>
                    <?php 
                        $first = false;
                    endforeach; 
                    ?>
                </div>

                <div class="ht-content-area">
                    <?php 
                    $first = true;
                    foreach ($libraries as $idx => $lib): 
                        $name = htmlspecialchars($lib['name'] ?? '');
                        if (empty($name)) continue; 
                        
                        $id_tab = 'tab-' . $idx;
                        $structure = $lib['structure'] ?? [];
                        $activeClass = $first ? 'active' : '';
                    ?>
                        <div id="<?php echo $id_tab; ?>" class="ht-pane <?php echo $activeClass; ?>">
                            <div class="ht-section" style="box-shadow: none; border: none; padding: 0;">
                                <h4 style="margin-top: 0; margin-bottom: 25px; font-weight: 800; color: #111; letter-spacing: 1px; border-bottom: 2px solid #eee; padding-bottom: 10px;">STRUKTUR ORGANISASI</h4>
                                <?php if (!empty($structure)): ?>
                                    <ul style="list-style: none; padding: 0;">
                                    <?php foreach ($structure as $jabatan => $nama): ?>
                                        <li style="margin-bottom: 15px; border-bottom: 1px dashed #eee; padding-bottom: 10px;">
                                            <div style="font-weight: 800; font-size: 0.7rem; color: #999; text-transform: uppercase; margin-bottom: 3px;"><?php echo htmlspecialchars($jabatan); ?></div>
                                            <div style="color: #111; font-weight: 600; font-size: 1.05rem;"><?php echo is_array($nama) ? htmlspecialchars(implode(', ', $nama)) : htmlspecialchars($nama); ?></div>
                                        </li>
                                    <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <p class="text-muted small italic">Data belum tersedia.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php 
                        $first = false;
                    endforeach; 
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function openTab(evt, tabId) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("ht-pane");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].classList.remove("active");
    }
    tablinks = document.getElementsByClassName("ht-tab");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].classList.remove("active");
    }
    document.getElementById(tabId).classList.add("active");
    evt.currentTarget.classList.add("active");
}
</script>