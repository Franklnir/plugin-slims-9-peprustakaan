# WA Service & Custom Footer for SLiMS

Plugin SLIMS yang mengintegrasikan layanan Popup WhatsApp (Widget) dangan customisasi Footer OPAC serta menggabugkan Laynan Bot WahtsApp (plugin Mas Budi Kusuma https://sites.google.com/view/masbudikusuma/product/wa-bot-slims-library)

## Fitur Utama
- **WhatsApp Floating Widget**: Tombol WhatsApp yang selalu muncul di footer OPAC untuk mempermudah Ke Bot.
- **Custom Footer OPAC**: Mengganti footer standar SLiMS dengan desain modern yang mencakup Text dinamis dan ikon Media Sosial.
- **Hybrid Library Info Page**: Halaman informatif (`?p=libinfo`) yang menampilkan foto bagan visual, jam operasional, dan berita per unit perpustakaan.
    - **Smart Compatibility**: Bekerja otomatis di tema default SLiMS (layout internal) maupun tema kustom yang memiliki sidebar (logika teleport).
- **Admin Panel Control**: Pengaturan nomor WA, pesan default, media sosial, dan data unit perpustakaan langsung dari dahsboard Admin SLiMS tanpa perlu edit kode.
- **Bot Gateway Ready**: Menyediakan endpoint webhook (`wa-pool.php`) yang kompatibel dengan aplikasi AutoResponder WhatsApp.

## Struktur Plugin
```
wa_service/
├── assets/           # CSS & Assets Gambar Bagan (Uploaded)
|   ├─ images         # Berisi Foto
|   ├─ index.php
|   └─ style.css      # File gaya halaman 
├── slims
|   ├─ cekmember.php
|   ├─ index.php
|   └─ function.php
├── src/              # Logika Inti (Config & UI Injection)
|   ├─ Config.php
|   ├─ index.php
|   └─ ui.php  
├── plugin.php        # Entry Point Plugin
├── admin_settings.php # Halaman Pengaturan Admin
├── info_perpus.php   # Halaman Informasi OPAC
├── wa-pool.php       # Endpoint Webhook Bot
└── config.json       # Penyimpanan Data Konfigurasi
```

## Cara Instalasi
1. Ekstrak folder `wa_service` ke direktori `/plugins/` di instalasi SLiMS Anda.
2. Masuk ke halaman **Admin SLiMS** > **Sistem** > **Daftar Plugin**.
3. Aktifkan plugin **WA Service & Custom Footer**.
4. Pergi ke menu baru **WA Service & Footer** di sidebar Admin untuk melakukan konfigurasi nomor WA dan data unit.

## Catatan Teknis
- Plugin ini menggunakan **Vanilla JavaScript** (tidak memerlukan library eksternal tambahan).
- Kompatibel dengan SLiMS 9 Bulian dan versi terbaru.
- Disarankan menggunakan aplikasi **AutoResponder WhatsApp** (Android) untuk memanfaatkan fitur Bot Gateway.

## Kontributor
- Faisal Fajar

---
*Developed with love for the SLiMS Community.*
