<?php
//BOT WHATSAPP FOR SLIMS
//Create by : MASBUDIKUSUMA
//Email : masbudikusuma@gmail.com
//Website : https://sites.google.com/view/masbudikusuma/product/wa-bot-slims-library
//
include 'config.php';
$data = file_get_contents("php://input");
$data = utf8_encode($data);
$data = json_decode($data, true);

// IDENTIFIKASI APLIKASI AUTOREPLY atau AUTORESPONDER
if (isset($data['senderMessage']))
{
    //App Auto Reply
    $app = "Autoreply";
    $isipesan = $data['senderMessage'];
    $paket = $data['receiveMessageAppId'];

    $sender = $data['senderName'];
    $sender = preg_replace("/[^0-9]/", "", $sender);

    $pesanin = $data['messageDateTime'];
    $dateapp = date("Y-m-d H:i:s", substr("$pesanin", 0, 10));
    $tanggal = date("Y-m-d H:i:s");
    $debugfile = "
  Waktu Asli : $pesanin
  Waktu masuk : $dateapp
  Waktu server : $tanggal
  Pengirim : " . $isipesan . "
  isi pesan : " . $isipesan . "
  app : " . $app;
}
// END IDENTIFIKASI APLIKASI AUTOREPLY


// IDENTIFIKASI APLIKASI AUTORESPONDER
if (isset($data['appPackageName']))
{
    //AutoResponder
    $app = "Autoresponder";
    $sender = $data['query']['sender'];
    $sender = preg_replace("/[^0-9]/", "", $sender);

    $isipesan = $data['query']['message'];
    $rule = $data['query']['ruleId'];
    $tanggal = date("Y-m-d H:i:s");
    $dateapp = "2000-01-01 01:01:01";

    $debugfile = "
  Waktu Asli :
  Waktu masuk :
  Waktu server : $tanggal
  Pengirim : " . $sender . "
  isi pesan : " . $isipesan . "
  app : " . $app;
}
// END IDENTIFIKASI APLIKASI AUTOREPLY

$POSTKEY = $_SERVER['HTTP_APIKEY'];
if ($APIKEY == $POSTKEY){
$count= 1;}
else {
  $jawab = "API KEY SALAH, Silahkan hubungi administrator Anda";
  $count = 0;}


if ($count == 1)
{
    if (isset($isipesan))
    { 
        // 1. Sanitasi input menggunakan escape_string dari SLiMS DB
        $safe_sender = $db->escape_string($sender);
        $safe_message = $db->escape_string($isipesan);
        $safe_app = $db->escape_string($app);
        $safe_dateapp = $db->escape_string($dateapp);

        // 2. Insert message to database
        $query1 = "INSERT INTO wa_message_in (sender, message_in, app, dateapp) VALUES
        ('" . $safe_sender . "', '" . $safe_message . "','" . $safe_app . "','" . $safe_dateapp . "')";
        
        $execution = $db->query($query1);
        $idmasuk = $db->insert_id ?? 0;
    }
    else
    {
        $isipesan = "Message Empty!";
        $idmasuk = 0;
    }
    
    // Analysys message
    include 'rule-poll.php';

    // Insert hasil Jawaban kedalam database (pastikan $jawab sudah aman)
    $safe_jawab = $db->escape_string($jawab ?? '');
    $query_update = "UPDATE wa_message_in SET message_out='" . $safe_jawab . "' WHERE id=" . (int)$idmasuk;
    $db->query($query_update);
}

$replies = [];
if (isset($jawab) && $jawab !== "") {
    $replies[] = ["message" => $jawab];
} else {
    $replies[] = ["message" => "jawab empty message"];
}

if (isset($jawab1) && $jawab1 !== "") $replies[] = ["message" => $jawab1];
if (isset($jawab2) && $jawab2 !== "") $replies[] = ["message" => $jawab2];
if (isset($jawab3) && $jawab3 !== "") $replies[] = ["message" => $jawab3];
if (isset($jawab4) && $jawab4 !== "") $replies[] = ["message" => $jawab4];

// RESPONSE
if (isset($app))
{
    header('Content-Type: application/json');
    if ($app == 'Autoresponder') {
        echo json_encode(["replies" => $replies]);
    } else if ($app == 'Autoreply') {
        echo json_encode(["data" => $replies]);
    }
}
// END RESPONSE

?>
