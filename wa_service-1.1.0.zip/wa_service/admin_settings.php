<?php
/**
 * Advanced Admin Panel Settings - WA Service & Custom Footer
 * Optimized Input Types (Minimalist)
 */

defined('INDEX_AUTH') or die('Direct access not allowed!');

if (!defined('OBB_MODULE')) {
    define('OBB_MODULE', 'system');
}

$configFile = __DIR__ . '/config.json';
$config = file_exists($configFile) ? json_decode(file_get_contents($configFile), true) : [];
$message = '';

// Logic Penambahan Admin Bot (wa_admin)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_bot_admin'])) {
    global $dbs;
    $adm_name = $dbs->escape_string($_POST['bot_admin_name'] ?? '');
    $adm_phone = $dbs->escape_string($_POST['bot_admin_phone'] ?? '');
    
    if (!empty($adm_name) && !empty($adm_phone)) {
        $adm_phone = preg_replace("/[^0-9]/", "", $adm_phone);
        if ($dbs->query("INSERT INTO wa_admin (name, phone_number) VALUES ('$adm_name', '$adm_phone')")) {
            $referer = $_SERVER['HTTP_REFERER'] ?? AWB . 'index.php';
            echo "<script>
                    alert('Admin baru berhasil didaftarkan!');
                    window.location.href = '" . htmlspecialchars($referer) . "';
                  </script>";
            exit;
        }
    }
}

// Logic Penghapusan Admin Bot
if (isset($_GET['delete_admin'])) {
    global $dbs;
    $adm_id = (int)$_GET['delete_admin'];
    $dbs->query("DELETE FROM wa_admin WHERE userid = $adm_id");
    $message = '<div class="alert alert-warning shadow-sm">Admin berhasil dihapus.</div>';
}

// Logic pemrosesan konfigurasi utama
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_config']) && $_POST['save_config'] == '1') {
    $social_media = [];
    if (isset($_POST['social_media']) && is_array($_POST['social_media'])) {
        foreach ($_POST['social_media'] as $sm) {
            if (trim($sm['name'] ?? '') !== '') {
                $social_media[] = [
                    'name' => trim($sm['name'] ?? ''),
                    'url'  => trim($sm['url'] ?? ''),
                    'icon' => trim($sm['icon'] ?? '')
                ];
            }
        }
    }

    $libraries = [];
    if (isset($_POST['libraries']) && is_array($_POST['libraries'])) {
        foreach ($_POST['libraries'] as $lib) {
            $parsedStructure = [];
            
            if (isset($lib['structure']) && is_array($lib['structure'])) {
                foreach ($lib['structure'] as $s) {
                    $role = trim($s['role'] ?? '');
                    $members_raw = trim($s['members'] ?? '');
                    if ($role !== '') {
                        $members_array = array_filter(array_map('trim', explode(',', $members_raw)));
                        if (count($members_array) === 1) {
                            $parsedStructure[$role] = array_values($members_array)[0];
                        } elseif (count($members_array) > 1) {
                            $parsedStructure[$role] = array_values($members_array);
                        }
                    }
                }
            }

            $libraries[] = [
                'name'      => trim($lib['name'] ?? ''),
                'image_url' => trim($lib['image_url'] ?? ''),
                'structure' => $parsedStructure,
                'hours'     => trim($lib['hours'] ?? ''),
                'news'      => trim($lib['news'] ?? '')
            ];
        }
    }

    // Penanganan Unggahan Gambar Bagan
    if (isset($_FILES['libraries']) && is_array($_FILES['libraries']['name'])) {
        foreach ($_FILES['libraries']['name'] as $libIdx => $libFile) {
            if (!empty($libFile['image_file'])) {
                $tmpName = $_FILES['libraries']['tmp_name'][$libIdx]['image_file'];
                $fileName = time() . '_' . basename($libFile['image_file']);
                $targetPath = __DIR__ . '/assets/images/' . $fileName;
                
                // Buat direktori jika belum ada
                if (!is_dir(__DIR__ . '/assets/images')) {
                    mkdir(__DIR__ . '/assets/images', 0777, true);
                }

                if (move_uploaded_file($tmpName, $targetPath)) {
                    // Simpan URL yang bisa diakses web
                    $libraries[$libIdx]['image_url'] = SWB . 'plugins/wa_service/assets/images/' . $fileName;
                }
            }
        }
    }

    $configData = [
        'wa_number'         => trim($_POST['wa_number'] ?? ''),
        'wa_message'        => trim($_POST['wa_message'] ?? ''),
        'wa_welcome_text'   => trim($_POST['wa_welcome_text'] ?? ''),
        'wa_bot_apikey'     => trim($_POST['wa_bot_apikey'] ?? ''),
        'wa_bot_admin_number' => trim($_POST['wa_number'] ?? ''),
        'footer_copyright'  => trim($_POST['footer_copyright'] ?? $config['footer_copyright'] ?? ''),
        'social_media'      => $social_media,
        'libraries'         => $libraries
    ];
    
    $jsonContent = json_encode($configData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
    if (file_put_contents($configFile, $jsonContent) !== false) {
        if (class_exists('\WaService\Config')) {
            \WaService\Config::save($configData);
        }

        // Sinkronisasi ke Tabel Setting SLiMS (Penting agar config.php/wa-pool.php terupdate)
        global $dbs;
        $dbs->query("UPDATE setting SET setting_value = '".$dbs->escape_string($configData['wa_bot_apikey'])."' WHERE setting_name = 'wa_bot_apikey'");
        $dbs->query("UPDATE setting SET setting_value = '".$dbs->escape_string($configData['wa_bot_admin_number'])."' WHERE setting_name = 'wa_bot_admin_number'");
        $message = '<div class="alert alert-success shadow-sm">Konfigurasi berhasil diperbarui.</div>';
        
        // Redirect (rideract) kembali ke halaman admin SLiMS yang semestinya (menghindari halaman blank HTML tanpa CSS)
        $referer = $_SERVER['HTTP_REFERER'] ?? AWB . 'index.php';
        echo "<script>
                alert('Konfigurasi Bot & Footer berhasil disimpan!');
                window.location.href = '" . htmlspecialchars($referer) . "';
              </script>";
        exit;
    } else {
         $message = '<div class="alert alert-danger shadow-sm">Gagal menulis file config.json. Periksa izin folder.</div>';
    }
}


// Muat ulang config setelah perubahan (opsional, sudah di-load di atas)
$config = file_exists($configFile) ? json_decode(file_get_contents($configFile), true) : [];

$default_sm = [
    ['name' => 'Facebook', 'url' => $config['footer_fb'] ?? '', 'icon' => 'fa-facebook'],
    ['name' => 'Instagram', 'url' => $config['footer_ig'] ?? '', 'icon' => 'fa-instagram'],
    ['name' => 'Twitter', 'url' => $config['footer_tw'] ?? '', 'icon' => 'fa-twitter'],
    ['name' => 'YouTube', 'url' => $config['footer_yt'] ?? '', 'icon' => 'fa-youtube'],
];
$saved_sm = isset($config['social_media']) && is_array($config['social_media']) ? $config['social_media'] : $default_sm;

$bot_api_key = $config['wa_bot_apikey'] ?? \WaService\Config::get('wa_bot_apikey') ?? 'SLIMS_BOT_RAHASIA_123';
$bot_admin_number = $config['wa_bot_admin_number'] ?? \WaService\Config::get('wa_bot_admin_number') ?? '6280000000000';

$site_url = \SLiMS\Url::getBaseUrl();
$webhook_url = rtrim($site_url, '/') . '/plugins/wa_service/wa-pool.php';
?>

<style>
    .custom-admin-card { background: #fff; border-radius: 4px; border: 1px solid #e0e0e0; margin-bottom: 2rem; }
    .card-header { background-color: #fafafa; border-bottom: 1px solid #e0e0e0; padding: 12px 20px; border-radius: 4px 4px 0 0; font-weight: 700; color: #333; text-transform: uppercase; font-size: 0.85rem; letter-spacing: 1px; }
    .card-body { padding: 25px; }
    .lib-box { background: #fff; border: 1px solid #eee; border-radius: 4px; padding: 20px; transition: all 0.2s ease-in-out; height: 100%; }
    .lib-box:hover { border-color: #999; }
    .form-group { margin-bottom: 15px; }
    .form-group label { font-weight: 600; color: #444; margin-bottom: 6px; display: block; font-size: 0.85rem; }
    .form-control { border-radius: 2px; border: 1px solid #ccc; font-size: 0.9rem; }
    .form-control:focus { border-color: #333; box-shadow: none; outline: none; }
    .section-title { border-bottom: 2px solid #111; display: inline-block; padding-bottom: 4px; margin: 20px 0 20px 15px; font-size: 1.1rem; font-weight: 800; }
    .btn-save { background: #111; color: #fff; border: none; padding: 12px 40px; border-radius: 2px; font-weight: 600; text-transform: uppercase; font-size: 0.85rem; letter-spacing: 1px; transition: 0.2s; cursor: pointer; }
    .btn-save:hover { background: #444; }
</style>

<div class="menuHeading">Pengaturan WA & Footer</div>

<div class="container-fluid" style="padding: 10px 20px;">
    <?php echo $message; ?>

    <form id="waSettingsForm" method="post" action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'] ?? ''); ?>" enctype="multipart/form-data">
        
        <div class="infoBlock" style="margin-bottom: 20px;">
            <strong>Webhook URL Bot:</strong> <a href="<?php echo htmlspecialchars($webhook_url); ?>" target="_blank"><?php echo htmlspecialchars($webhook_url); ?></a><br>
            <em style="color:#555;">Salin URL di atas ke aplikasi AutoResponder Anda.</em>
        </div>

        <div class="custom-admin-card">
            <div class="card-header">WhatsApp Service</div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Nomor WA (Widget & Admin Bot)</label>
                            <input type="text" name="wa_number" class="form-control" value="<?php echo htmlspecialchars($config['wa_number'] ?? ''); ?>" placeholder="628xxx">
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Teks Judul Popup</label>
                            <input type="text" name="wa_welcome_text" class="form-control" value="<?php echo htmlspecialchars($config['wa_welcome_text'] ?? ''); ?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Pesan Default (Popup)</label>
                            <input type="text" name="wa_message" class="form-control" value="<?php echo htmlspecialchars($config['wa_message'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>API KEY Bot (AutoResponder)</label>
                            <input type="text" name="wa_bot_apikey" class="form-control" value="<?php echo htmlspecialchars($bot_api_key); ?>" required>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="custom-admin-card">
            <div class="card-header">Daftar Admin Bot (Hak Akses Menu Admin WA)</div>
            <div class="card-body">
                <table class="table table-striped table-bordered" style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                    <thead style="background: #f1f1f1;">
                        <tr>
                            <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Nama Admin</th>
                            <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Nomor WhatsApp</th>
                            <th style="padding: 10px; border: 1px solid #ddd; width: 100px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        global $dbs;
                        $res_adm = $dbs->query("SELECT * FROM wa_admin ORDER BY userid DESC");
                        if ($res_adm && $res_adm->num_rows > 0):
                            while($adm = $res_adm->fetch_assoc()):
                        ?>
                        <tr>
                            <td style="padding: 8px; border: 1px solid #ddd;"><?php echo htmlspecialchars($adm['name']); ?></td>
                            <td style="padding: 8px; border: 1px solid #ddd;"><?php echo htmlspecialchars($adm['phone_number']); ?></td>
                            <td style="padding: 8px; border: 1px solid #ddd;" class="text-center">
                                <a href="<?php echo htmlspecialchars(preg_replace('/&delete_admin=\d+/', '', $_SERVER['REQUEST_URI'])); ?>&delete_admin=<?php echo $adm['userid']; ?>" 
                                   class="btn btn-danger btn-sm" 
                                   style="background: #dc3545; color: white; padding: 4px 10px; text-decoration: none; font-size: 0.8rem; border-radius: 3px; display: inline-block;"
                                   onclick="return confirm('Hapus admin ini?')">Hapus</a>
                            </td>
                        </tr>
                        <?php endwhile; else: ?>
                        <tr><td colspan="3" style="padding: 20px; border: 1px solid #ddd;" class="text-center">Belum ada admin terdaftar. Gunakan form di bawah untuk menambah.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                
                <div style="background: #f9f9f9; padding: 15px; border-radius: 4px; border: 1px solid #eee;">
                    <h5 style="margin-top: 0; font-size: 0.9rem; font-weight: 700; margin-bottom: 15px;">Daftarkan Admin Baru</h5>
                    <div style="display: flex; gap: 15px; align-items: flex-end;">
                        <div style="flex: 2;">
                            <label style="font-size: 0.75rem; font-weight: 700;">Nama Staf/Admin</label>
                            <input type="text" name="bot_admin_name" class="form-control" placeholder="Contoh: Budi Sirkulasi">
                        </div>
                        <div style="flex: 2;">
                            <label style="font-size: 0.75rem; font-weight: 700;">Nomor WA (Awali 62)</label>
                            <input type="text" name="bot_admin_phone" class="form-control" placeholder="Contoh: 62812345678">
                        </div>
                        <div style="flex: 1;">
                            <button type="submit" name="add_bot_admin" value="1" class="p-2 btn-primary" style="border-radius: 5px; width: 100%; font-weight: 700; text-transform: uppercase; font-size: 0.75rem; cursor: pointer; border: none; color: #fff;" onclick="document.getElementsByName('save_config')[0].value='0';">+ Tambah</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bagian Footer & Social Media dihapus dari Admin UI (Hanya diubah melalui config.json) -->

        <div class="custom-admin-card">
            <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
                <span>Detail Unit Perpustakaan</span>
                <div>
                    <button type="button" class="btn btn-success btn-sm" onclick="addNewUnit()">+ Tambah Unit Baru</button>
                </div>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label>Pilih Unit untuk Diedit</label>
                    <div style="display: flex; gap: 10px;">
                        <select id="unitSelector" class="form-control" style="flex: 1;" onchange="switchUnit(this.value)">
                            <?php 
                            $libsCount = is_array($config['libraries'] ?? null) ? count($config['libraries']) : 0;
                            if ($libsCount === 0) {
                                // Default minimal 1 unit
                                $config['libraries'] = [['name' => 'Unit Utama', 'image_url' => '', 'structure' => [], 'hours' => '', 'news' => '']];
                                $libsCount = 1;
                            }
                            for ($i = 0; $i < $libsCount; $i++): 
                                $libName = $config['libraries'][$i]['name'] ?: "Unit " . ($i + 1);
                            ?>
                                <option value="<?php echo $i; ?>"><?php echo htmlspecialchars($libName); ?></option>
                            <?php endfor; ?>
                        </select>
                        <button type="button" class="btn btn-danger btn-sm" onclick="deleteCurrentUnit()">Hapus Unit Ini</button>
                    </div>
                </div>

                <div id="unitFormsContainer">
                    <?php for ($i = 0; $i < $libsCount; $i++): 
                        $lib = $config['libraries'][$i] ?? ['name' => '', 'image_url' => '', 'structure' => [], 'hours' => '', 'news' => ''];
                    ?>
                        <div class="unit-form-wrapper" id="unit-form-<?php echo $i; ?>" style="<?php echo ($i === 0) ? '' : 'display:none;'; ?> border: 1px solid #eee; padding: 20px; border-radius: 4px;">
                            <div class="form-group">
                                <label>Nama Unit Perpustakaan</label>
                                <input type="text" name="libraries[<?php echo $i; ?>][name]" class="form-control lib-name-input" value="<?php echo htmlspecialchars($lib['name'] ?? ''); ?>" placeholder="Contoh: Unit Layanan Cikarang" oninput="updateDropdownText(<?php echo $i; ?>, this.value)">
                            </div>

                            <div class="form-group">
                                <label>Foto Bagan Visual (Opsional)</label>
                                <?php if (!empty($lib['image_url'])): ?>
                                    <div class="mb-2">
                                        <img src="<?php echo htmlspecialchars($lib['image_url']); ?>" style="max-width: 150px; border: 1px solid #ddd; padding: 2px; margin-bottom: 10px; display: block;">
                                        <input type="hidden" name="libraries[<?php echo $i; ?>][image_url]" value="<?php echo htmlspecialchars($lib['image_url']); ?>">
                                    </div>
                                <?php endif; ?>
                                <input type="file" name="libraries[<?php echo $i; ?>][image_file]" class="form-control" accept="image/*">
                            </div>

                            <div class="form-group structure-builder" id="structure-builder-<?php echo $i; ?>">
                                <label>Struktur Jabatan (Daftar Nama)</label>
                                <div class="structure-list" style="margin-bottom: 10px;">
                                    <?php 
                                    $s_idx = 0;
                                    if (is_array($lib['structure'] ?? null)): 
                                        foreach ($lib['structure'] as $jabatan => $nama_array): 
                                            $nama_str = is_array($nama_array) ? implode(', ', $nama_array) : $nama_array;
                                    ?>
                                        <div class="structure-row" style="display: flex; gap: 10px; margin-bottom: 5px;">
                                            <input type="text" name="libraries[<?php echo $i; ?>][structure][<?php echo $s_idx; ?>][role]" class="form-control form-control-sm" value="<?php echo htmlspecialchars($jabatan); ?>" placeholder="E.g. Kepala Unit">
                                            <input type="text" name="libraries[<?php echo $i; ?>][structure][<?php echo $s_idx; ?>][members]" class="form-control form-control-sm" value="<?php echo htmlspecialchars($nama_str); ?>" placeholder="Nama (Pisahkan dengan koma)">
                                            <button type="button" class="btn btn-danger btn-sm" onclick="this.parentElement.remove()">x</button>
                                        </div>
                                    <?php 
                                        $s_idx++;
                                        endforeach; 
                                    endif; 
                                    ?>
                                </div>
                                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="addStructureRow(<?php echo $i; ?>)">+ Tambah Baris Struktur</button>
                            </div>

                            <div class="form-group">
                                <label>Jam Operasional</label>
                                <textarea name="libraries[<?php echo $i; ?>][hours]" class="form-control" rows="2" placeholder="Contoh: Senin - Jumat: 08:00 - 16:00"><?php echo htmlspecialchars($lib['hours'] ?? ''); ?></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label>Informasi Tambahan / Berita Singkat</label>
                                <textarea name="libraries[<?php echo $i; ?>][news]" class="form-control" rows="3" placeholder="Info terkini unit..."><?php echo htmlspecialchars($lib['news'] ?? ''); ?></textarea>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>

        <div style="text-align: center; margin: 40px 0;">
            <input type="hidden" name="save_config" value="1">
            <button type="submit" class="btn-save btn-lg">Simpan Perubahan</button>
        </div>
    </form>
</div>

<script>
function switchUnit(index) {
    document.querySelectorAll('.unit-form-wrapper').forEach(el => el.style.display = 'none');
    var target = document.getElementById('unit-form-' + index);
    if (target) target.style.display = 'block';
}

function updateDropdownText(index, value) {
    var select = document.getElementById('unitSelector');
    if (select.options[index]) {
        select.options[index].text = value || "Unit " + (parseInt(index) + 1);
    }
}

function addNewUnit() {
    var container = document.getElementById('unitFormsContainer');
    var select = document.getElementById('unitSelector');
    var newIdx = container.querySelectorAll('.unit-form-wrapper').length;
    
    // Create new option in selector
    var opt = document.createElement('option');
    opt.value = newIdx;
    opt.text = "Unit Baru " + (newIdx + 1);
    select.add(opt);
    
    // Create new form template based on index 0 but empty
    var template = `
        <div class="unit-form-wrapper" id="unit-form-${newIdx}" style="border: 1px solid #eee; padding: 20px; border-radius: 4px;">
            <div class="form-group">
                <label>Nama Unit Perpustakaan</label>
                <input type="text" name="libraries[${newIdx}][name]" class="form-control lib-name-input" value="" placeholder="Masukkan nama unit..." oninput="updateDropdownText(${newIdx}, this.value)">
            </div>
            <div class="form-group">
                <label>Foto Bagan Visual (Opsional)</label>
                <input type="file" name="libraries[${newIdx}][image_file]" class="form-control" accept="image/*">
            </div>
            <div class="form-group structure-builder" id="structure-builder-${newIdx}">
                <label>Struktur Jabatan</label>
                <div class="structure-list" style="margin-bottom: 10px;"></div>
                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="addStructureRow(${newIdx})">+ Tambah Baris Struktur</button>
            </div>
            <div class="form-group">
                <label>Jam Operasional</label>
                <textarea name="libraries[${newIdx}][hours]" class="form-control" rows="2"></textarea>
            </div>
            <div class="form-group">
                <label>Informasi Tambahan / Berita Singkat</label>
                <textarea name="libraries[${newIdx}][news]" class="form-control" rows="3"></textarea>
            </div>
        </div>
    `;
    
    container.insertAdjacentHTML('beforeend', template);
    select.value = newIdx;
    switchUnit(newIdx);
}

function deleteCurrentUnit() {
    var select = document.getElementById('unitSelector');
    var index = select.value;
    var wrappers = document.querySelectorAll('.unit-form-wrapper');
    
    if (wrappers.length <= 1) {
        alert("Minimal harus ada 1 unit.");
        return;
    }
    
    if (confirm("Hapus unit ini? Data yang belum disimpan akan hilang.")) {
        var el = document.getElementById('unit-form-' + index);
        el.remove();
        select.remove(select.selectedIndex);
        
        // Reselect first unit
        switchUnit(0);
        select.value = 0;
        
        // RE-INDEXING (PENTING AGAR PHP MENERIMA ARRAY BERURUTAN)
        reindexUnits();
    }
}

function reindexUnits() {
    var wrappers = document.querySelectorAll('.unit-form-wrapper');
    var select = document.getElementById('unitSelector');
    select.innerHTML = '';
    
    wrappers.forEach((wrapper, newIdx) => {
        wrapper.id = 'unit-form-' + newIdx;
        
        // Update all input names
        wrapper.querySelectorAll('[name^="libraries["]').forEach(input => {
            input.name = input.name.replace(/libraries\[\d+\]/, 'libraries[' + newIdx + ']');
        });
        
        // Update specific ID & oncclicks
        var builder = wrapper.querySelector('.structure-builder');
        if (builder) builder.id = 'structure-builder-' + newIdx;
        
        var nameInput = wrapper.querySelector('.lib-name-input');
        if (nameInput) {
            nameInput.setAttribute('oninput', `updateDropdownText(${newIdx}, this.value)`);
            var optName = nameInput.value || "Unit " + (newIdx + 1);
            var opt = document.createElement('option');
            opt.value = newIdx;
            opt.text = optName;
            select.add(opt);
        }
        
        var addBtn = wrapper.querySelector('button[onclick^="addStructureRow"]');
        if (addBtn) addBtn.setAttribute('onclick', `addStructureRow(${newIdx})`);
    });
}

function addStructureRow(libIndex) {
    var list = document.querySelector('#structure-builder-' + libIndex + ' .structure-list');
    var sIdx = list.querySelectorAll('.structure-row').length;
    var rowHtml = `<div class="structure-row" style="display: flex; gap: 10px; margin-bottom: 5px;">
        <input type="text" name="libraries[${libIndex}][structure][${sIdx}][role]" class="form-control form-control-sm" placeholder="Jabatan">
        <input type="text" name="libraries[${libIndex}][structure][${sIdx}][members]" class="form-control form-control-sm" placeholder="Nama Anggota">
        <button type="button" class="btn btn-danger btn-sm" onclick="this.parentElement.remove()">x</button>
    </div>`;
    list.insertAdjacentHTML('beforeend', rowHtml);
}
</script>