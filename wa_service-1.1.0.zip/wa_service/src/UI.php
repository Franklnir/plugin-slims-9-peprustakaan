<?php
namespace WaService;

class UI
{
    public static function inject($opac = null)
    {
        $waUrl = 'https://wa.me/' . Config::wa_number() . '?text=' . urlencode(Config::wa_message());
        
        $socialMediaHtml = "";
        $socialMedia = Config::social_media();
        if (is_array($socialMedia)) {
            foreach ($socialMedia as $sm) {
                if (!empty($sm['url']) && !empty($sm['name'])) {
                    $icon = !empty($sm['icon']) ? '<i class="fa ' . htmlspecialchars($sm['icon']) . '"></i> ' : '';
                    $socialMediaHtml .= '<li><a href="' . htmlspecialchars($sm['url']) . '" target="_blank">' . $icon . htmlspecialchars($sm['name']) . '</a></li>';
                }
            }
        }

        // Persiapkan Data & JS untuk halaman libinfo (Hybrid Layout Logic)
        if ($opac && isset($_GET['p']) && $_GET['p'] === 'libinfo') {
            // Pasang 'Target Teleport' di area informasi tema
            $opac->info = '<div id="ws-theme-sidebar-target"></div>'; 
            
            $libs = Config::libraries();
            $libsJson = json_encode($libs, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
            
            // Injeksi Global Data & Logic
            $jsData = '<style>
                /* Sembunyikan kontainer kolom info bawaan SLiMS (jika ada) */
                .col-lg-4.animated.fadeInUp.delay4 > h2,
                .col-lg-4.animated.fadeInUp.delay4 > hr,
                .col-lg-4.animated.fadeInUp.delay4 > br {
                   display: none !important;
                }
            </style>
            <script>
            var wsLibData = ' . $libsJson . ';
            function updateWsSidebar(idx) {
                var lib = wsLibData[idx];
                var container = document.getElementById("ws-dynamic-sidebar");
                if (!lib || !container) return;

                var html = `<h4 class="text-dark" style="font-size: 2.2rem; font-weight: 800; margin-bottom: 25px;">${lib.name}</h4>`;
                
                if (lib.image_url) {
                    html += `<div class="mb-4">
                        <a href="${lib.image_url}" target="_blank" title="Klik untuk memperbesar" style="cursor: zoom-in; display: block;">
                            <img src="${lib.image_url}" class="img-fluid rounded shadow-sm" alt="Bagan Visual" style="width: 100%; height: auto; image-rendering: -webkit-optimize-contrast; border: 1px solid #eee; background: #fff;">
                        </a>
                    </div>`;
                }
                
                if (lib.news) {
                    html += `<div class="mb-4 mt-2 lib-news" style="font-size: 1.1rem; line-height: 1.7; color: #444;">${lib.news.replace(/\n/g, "<br>")}</div>`;
                }

                if (lib.hours) {
                    html += `<div class="lib-hours-box" style="border-top: 1px solid #eee; padding-top: 15px;">
                        <h6 class="text-uppercase small font-weight-bold text-secondary mb-2">Jam Operasional Unit</h6>
                        <div class="text-dark" style="font-size: 1rem;">${lib.hours.replace(/\n/g, "<br>")}</div>
                    </div>`;
                }
                
                container.innerHTML = html;
            }

            window.addEventListener("DOMContentLoaded", function() {
                var themeTarget = document.getElementById("ws-theme-sidebar-target");
                var internalSidebar = document.getElementById("ws-internal-sidebar-col");
                var internalContent = document.getElementById("ws-internal-content-col");
                var mainContent = document.querySelector(".col-lg-8.animated.fadeInUp.delay2");

                if (themeTarget) {
                    // KONDISI A: Tema punya area sidebar (Information Available)
                    var source = document.getElementById("ws-dynamic-sidebar");
                    if (source) {
                        themeTarget.appendChild(source);
                        
                        // Sembunyikan kolom internal sidebar info
                        if (internalSidebar) internalSidebar.style.display = "none";
                        
                        // MAKSIMALKAN KOLOM KANAN (Navigasi/Struktur) MENJADI 100%
                        if (internalContent) {
                            internalContent.style.flex = "0 0 100%";
                            internalContent.style.maxWidth = "100%";
                            internalContent.style.width = "100%";
                        }

                        // Berikan 100% lebar ke area konten utama SLiMS
                        if (mainContent) {
                            mainContent.style.flex = "0 0 100%";
                            mainContent.style.maxWidth = "100%";
                        }
                    }
                }
                
                setTimeout(function() { if(typeof updateWsSidebar === "function") updateWsSidebar(0); }, 300);
            });
            </script>';
            
            $opac->js = ($opac->js ?? '') . "\n" . $jsData;
        }

        // CSS untuk merombak UI Footer dan tombol WA
        $css = '<link rel="stylesheet" type="text/css" href="' . SWB . 'plugins/wa_service/assets/style.css?v=' . time() . '">';
        
        // JavaScript Injeksi (Vanilla JS)
        $js = '<script>
        (function() {
            function initWaFooter() {
                var customFooterHtml = `
                <div class="s-footer-content container">
                    <div class="row">
                        <div class="col-lg-6 col-sm-3 col-xs-12">
                            <div class="s-footer-tagline" style="line-height: 20px;">
                                ' . Config::footer_copyright() . '
                            </div>
                        </div>
                        <nav class="col-lg-6 col-sm-9 col-xs-12">
                            <ul class="s-footer-menu">
                                ' . $socialMediaHtml . '
                            </ul>
                        </nav>
                    </div>
                </div>`;
                
                var mainFooter = document.querySelector(".s-footer") || document.querySelector("footer");
                if (mainFooter) {
                    mainFooter.innerHTML = customFooterHtml;
                }

                if (!document.getElementById("ws-wa-widget")) {
                    var welcomeText = "' . htmlspecialchars(Config::wa_welcome_text() ?: 'Ada yang bisa kami bantu?') . '";
                    var waWidgetHtml = `
                    <div id="ws-wa-widget">
                        <a href="' . htmlspecialchars($waUrl) . '" target="_blank" class="ws-wa-btn" title="${welcomeText}">
                            <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="100" height="100" viewBox="0 0 48 48">
                                <path fill="#fff" d="M4.868,43.303l2.694-9.835C5.9,30.59,5.026,27.324,5.027,23.979C5.032,13.514,13.548,5,24.014,5c5.079,0.002,9.845,1.979,13.43,5.566c3.584,3.588,5.558,8.356,5.556,13.428c-0.004,10.465-8.522,18.98-18.986,18.98c-0.001,0,0,0,0,0h-0.008c-3.177-0.001-6.3-0.798-9.073-2.311L4.868,43.303z"></path>
                                <path fill="#fff" d="M4.868,43.803c-0.132,0-0.26-0.052-0.355-0.148c-0.125-0.127-0.174-0.312-0.127-0.483l2.639-9.636c-1.636-2.906-2.499-6.206-2.497-9.556C4.532,13.238,13.273,4.5,24.014,4.5c5.21,0.002,10.105,2.031,13.784,5.713c3.679,3.683,5.704,8.577,5.702,13.781c-0.004,10.741-8.746,19.48-19.486,19.48c-3.189-0.001-6.344-0.788-9.144-2.277l-9.875,2.589C4.953,43.798,4.911,43.803,4.868,43.803z"></path>
                                <path fill="#cfd8dc" d="M24.014,5c5.079,0.002,9.845,1.979,13.43,5.566c3.584,3.588,5.558,8.356,5.556,13.428c-0.004,10.465-8.522,18.98-18.986,18.98h-0.008c-3.177-0.001-6.3-0.798-9.073-2.311L4.868,43.303l2.694-9.835C5.9,30.59,5.026,27.324,5.027,23.979C5.032,13.514,13.548,5,24.014,5 M24.014,42.974C24.014,42.974,24.014,42.974,24.014,42.974C24.014,42.974,24.014,42.974,24.014,42.974 M24.014,42.974C24.014,42.974,24.014,42.974,24.014,42.974C24.014,42.974,24.014,42.974,24.014,42.974 M24.014,4C24.014,4,24.014,4,24.014,4C12.998,4,4.032,12.962,4.027,23.979c-0.001,3.367,0.849,6.685,2.461,9.622l-2.585,9.439c-0.094,0.345,0.002,0.713,0.254,0.967c0.19,0.192,0.447,0.297,0.711,0.297c0.085,0,0.17-0.011,0.254-0.033l9.687-2.54c2.828,1.468,5.998,2.243,9.197,2.244c11.024,0,19.99-8.963,19.995-19.98c0.002-5.339-2.075-10.359-5.848-14.135C34.378,6.083,29.357,4.002,24.014,4L24.014,4z"></path>
                                <path fill="#40c351" d="M35.176,12.832c-2.98-2.982-6.941-4.625-11.157-4.626c-8.704,0-15.783,7.076-15.787,15.774c-0.001,2.981,0.833,5.883,2.413,8.396l0.376,0.597l-1.595,5.821l5.973-1.566l0.577,0.342c2.422,1.438,5.2,2.198,8.032,2.199h0.006c8.698,0,15.777-7.077,15.78-15.776C39.795,19.778,38.156,15.814,35.176,12.832z"></path>
                                <path fill="#fff" fill-rule="evenodd" d="M19.268,16.045c-0.355-0.79-0.729-0.806-1.068-0.82c-0.277-0.012-0.593-0.011-0.909-0.011c-0.316,0-0.83,0.119-1.265,0.594c-0.435,0.475-1.661,1.622-1.661,3.956c0,2.334,1.7,4.59,1.937,4.906c0.237,0.316,3.282,5.259,8.104,7.161c4.007,1.58,4.823,1.266,5.693,1.187c0.87-0.079,2.807-1.147,3.202-2.255c0.395-1.108,0.395-2.057,0.277-2.255c-0.119-0.198-0.435-0.316-0.909-0.554s-2.807-1.385-3.242-1.543c-0.435-0.158-0.751-0.237-1.068,0.238c-0.316,0.474-1.225,1.543-1.502,1.859c-0.277,0.317-0.554,0.357-1.028,0.119c-0.474-0.238-2.002-0.738-3.815-2.354c-1.41-1.257-2.362-2.81-2.639-3.285c-0.277-0.474-0.03-0.731,0.208-0.968c0.213-0.213,0.474-0.554,0.712-0.831c0.237-0.277,0.316-0.475,0.474-0.791c0.158-0.317,0.079-0.594-0.04-0.831C20.612,19.329,19.69,16.983,19.268,16.045z" clip-rule="evenodd"></path>
                            </svg>  
                        </a>
                    </div>`;
                    document.body.insertAdjacentHTML("beforeend", waWidgetHtml);
                }
            }

            if (document.readyState === "loading") {
                document.addEventListener("DOMContentLoaded", initWaFooter);
            } else {
                initWaFooter();
            }
        })();
        </script>';
        
        if ($opac) {
            $opac->js = ($opac->js ?? '') . "\n" . $css . "\n" . $js;
        } else {
            echo $css . "\n" . $js;
        }
    }
}
