<?php
namespace WaService;

class Config
{
    private static $configFile = __DIR__ . '/../config.json';
    private static $configData = null;

    private static function loadConfig()
    {
        if (self::$configData === null) {
            if (file_exists(self::$configFile)) {
                $json = file_get_contents(self::$configFile);
                self::$configData = json_decode($json, true);
            }
            // Fallback Nilai Default 
            if (!is_array(self::$configData)) {
                self::$configData = [
                    'wa_number' => '628123456789',
                    'wa_message' => 'Halo, saya butuh bantuan mengenai perpustakaan.',
                    'footer_copyright' => '© 2026 Layanan Perpustakaan. Hak Cipta Dilindungi Undang-Undang.',
                    'social_media' => [
                        ['name' => 'Facebook', 'url' => '#', 'icon' => 'fa-facebook'],
                        ['name' => 'Twitter', 'url' => '#', 'icon' => 'fa-twitter'],
                        ['name' => 'Instagram', 'url' => 'https://instagram.com', 'icon' => 'fa-instagram'],
                        ['name' => 'YouTube', 'url' => 'https://youtube.com', 'icon' => 'fa-youtube']
                    ],
                    'libraries' => [
                        [
                            'name' => 'Perpustakaan Pusat', 
                            'image_url' => '',
                            'structure' => [['role' => 'Kepala Perpustakaan', 'members' => 'Dr. Andi'], ['role' => 'Staf Pengolahan', 'members' => 'Budi, Citra']], 
                            'hours' => "Senin - Jumat: 08:00 - 16:00\nSabtu: 09:00 - 13:00", 
                            'news' => "Selamat datang di perpustakaan pusat. Berita terbaru: Koleksi buku baru telah tiba!"
                        ],
                        [
                            'name' => 'Perpustakaan Fakultas A', 
                            'image_url' => '',
                            'structure' => [['role' => 'Kepala Perpustakaan', 'members' => 'Prof. Dina'], ['role' => 'Staf Sirkulasi', 'members' => 'Eka, Fajar']], 
                            'hours' => "Senin - Jumat: 08:00 - 15:00", 
                            'news' => "Ruang baca di lantai 2 sedang direnovasi."
                        ],
                        [
                            'name' => 'Perpustakaan Fakultas B', 
                            'image_url' => '',
                            'structure' => [['role' => 'Kepala Perpustakaan', 'members' => 'Dr. Gilang'], ['role' => 'Staf Referensi', 'members' => 'Hana']], 
                            'hours' => "Senin - Jumat: 09:00 - 16:00", 
                            'news' => "Layanan peminjaman tutup lebih awal hari Jumat ini."
                        ],
                        [
                            'name' => 'Perpustakaan Cabang', 
                            'image_url' => '',
                            'structure' => [['role' => 'Koordinator Wilayah', 'members' => 'Bapak Indra'], ['role' => 'Staf Pelayanan', 'members' => 'Joko']], 
                            'hours' => "Senin - Sabtu: 08:00 - 14:00", 
                            'news' => "Silakan kunjungi pameran literasi mini di lobi."
                        ]
                    ]
                ];
            }
        }
    }

    public static function get($key)
    {
        self::loadConfig();
        return isset(self::$configData[$key]) ? self::$configData[$key] : '';
    }

    public static function set($key, $value)
    {
        self::loadConfig();
        self::$configData[$key] = $value;
    }

    public static function save(array $data = [])
    {
        self::loadConfig();
        self::$configData = array_replace_recursive(self::$configData, $data);
        $json = json_encode(self::$configData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        file_put_contents(self::$configFile, $json);
    }

    // Fungsi wrapper statis agar kompatibel dengan pemanggilan \WaService\Config::$property sebelumnya
    public static function wa_number() { return self::get('wa_number'); }
    public static function wa_message() { return self::get('wa_message'); }
    public static function wa_welcome_text() { return self::get('wa_welcome_text'); }
    public static function footer_copyright() { return self::get('footer_copyright'); }
    public static function social_media() { return self::get('social_media'); }
    public static function libraries() { return self::get('libraries'); }
    public static function wa_bot_apikey() { return self::get('wa_bot_apikey'); }
    public static function wa_bot_admin_number() { return self::get('wa_bot_admin_number'); }
}
