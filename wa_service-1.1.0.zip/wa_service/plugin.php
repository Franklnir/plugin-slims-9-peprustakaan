<?php
/**
 * Plugin Name: WA Service & Custom Footer
 * Plugin URI: https://github.com/Isal0192/silsperpus
 * Description: Plugin untuk mengganti footer OPAC SLiMS menjadi kustom dan menambahkan tombol layanan WhatsApp popupup, chat bot statis.
 * Version: 1.1.0
 * Author: faisal fajar, sena dwi, irsyad 
 * Author URI: https://github.com/Isal0192
 */

use SLiMS\Plugins;

// Memuat semua file yang dibutuhkan secara langsung untuk menghindari error
require_once __DIR__ . '/src/Config.php';
require_once __DIR__ . '/src/UI.php';

// Memuat fungsi spesifik SLiMS dan Bot jika diperlukan (core files tidak diotak-atik)
// require_once __DIR__ . '/config.php'; 

$plugin = Plugins::getInstance();

$plugin->registerHook(Plugins::CONTENT_BEFORE_LOAD, function($opac) {
    if (strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false) {
        return;
    }
    // Panggil kelas dari file yang sudah diperbaiki
    \WaService\UI::inject($opac);
});

// Hook instalasi database untuk Bot WhatsApp & Config
$plugin->registerHook(Plugins::CONTENT_BEFORE_LOAD, function() {
    global $dbs;

    // 1. Inisialisasi Pengaturan Dasar SLiMS (jika belum ada)
    $settings = [
        'wa_bot_apikey' => 'SLIMS_BOT_RAHASIA_123',
        'wa_bot_admin_number' => '6280000000000'
    ];
    foreach ($settings as $name => $val) {
        $safe_name = $dbs->escape_string($name);
        $check = $dbs->query("SELECT setting_value FROM setting WHERE setting_name = '$safe_name'");
        if (!$check || $check->num_rows == 0) {
            $safe_val = $dbs->escape_string($val);
            $dbs->query("INSERT INTO setting (setting_name, setting_value) VALUES ('$safe_name', '$safe_val')");
        }
    }

    // 2. Tabel wa_data_answer (Sesi Bot)
    $dbs->query("CREATE TABLE IF NOT EXISTS `wa_data_answer` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `sender` varchar(50) NOT NULL,
      `p_last` varchar(50) DEFAULT NULL,
      `p_baru` varchar(50) DEFAULT NULL,
      `id_member` varchar(50) DEFAULT NULL,
      `nama` varchar(100) DEFAULT NULL,
      `prodi` varchar(100) DEFAULT NULL,
      `tanggal_lahir` varchar(50) DEFAULT NULL,
      `alamat` text DEFAULT NULL,
      `login_status` varchar(20) DEFAULT NULL,
      `begin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `ket` varchar(255) DEFAULT NULL,
      PRIMARY KEY (`id`),
      KEY `sender_idx` (`sender`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // 3. Tabel wa_message_in (History Pesan)
    $dbs->query("CREATE TABLE IF NOT EXISTS `wa_message_in` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `sender` varchar(50) NOT NULL,
      `message_in` text NOT NULL,
      `message_out` text DEFAULT NULL,
      `app` varchar(30) DEFAULT NULL,
      `dateapp` datetime DEFAULT NULL,
      `dateserver` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // 4. Tabel wa_faq (Data Pertanyaan Populer)
    $dbs->query("CREATE TABLE IF NOT EXISTS `wa_faq` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `question` text NOT NULL,
      `answer` text NOT NULL,
      `used` enum('yes','no') DEFAULT 'yes',
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Masukkan data FAQ contoh jika kosong
    $check_faq = $dbs->query("SELECT id FROM wa_faq LIMIT 1");
    if ($check_faq && $check_faq->num_rows == 0) {
        $dbs->query("INSERT INTO wa_faq (question, answer) VALUES 
        ('Jam Layanan', 'Perpustakaan buka Senin-Jumat pukul 08:00 - 16:00 WIB.'),
        ('Syarat Anggota', 'Membawa KTM yang masih aktif dan melakukan registrasi di bagian sirkulasi.')");
    }

    // 5. Tabel wa_admin (Daftar Admin Bot)
    $dbs->query("CREATE TABLE IF NOT EXISTS `wa_admin` (
      `userid` int(11) NOT NULL AUTO_INCREMENT,
      `name` varchar(100) DEFAULT NULL,
      `phone_number` varchar(50) NOT NULL,
      PRIMARY KEY (`userid`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
});


// Hook untuk meregistrasikan menu pengaturan di halaman Admin SLiMS
$plugin->registerMenu('system', 'WA Service & Footer', __DIR__ . '/admin_settings.php');

// Hook untuk meregistrasikan halaman baru di OPAC (Frontend) SLiMS (Menimpa halaman bawaan libinfo)
$plugin->registerMenu('opac', 'libinfo', __DIR__ . '/info_perpus.php');
