<?php
define('INDEX_AUTH', 1);
require_once __DIR__ . '/../../sysconfig.inc.php';
global $dbs;

// Kosongkan riwayat sesi hari ini agar sistem cek ulang database member
$today = date('Y-m-d');
$dbs->query("DELETE FROM wa_data_answer WHERE STR_TO_DATE(begin, '%Y-%m-%d') = '$today'");

echo "SESI HARI INI BERHASIL DIBERSIHKAN.\nSilakan Chat Bot 'menu' Sekarang!";
?>
