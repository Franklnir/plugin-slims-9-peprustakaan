<?php
//BOT WHATSAPP FOR SLIMS
//CEK A ADMIN/MEMBER/GENERAL AKSES and Welcome Message

$safe_sender = $db->escape_string($sender);

// 1. CEK ADMIN
$query = "SELECT * FROM wa_admin WHERE phone_number LIKE '%$safe_sender' LIMIT 1";
$hasil = $db->query($query);

if($hasil && $hasil->num_rows > 0 ){ 
    while($x = $hasil->fetch_assoc()){
        $nama = $x['name'];
        $member = "admin";
        $member_id = "admin";

        $jawab = "*Assalamu'alaikum Warohmatullahi Wabarokatuh...*\n\n" .
                 "Selamat Datang *$nama*\n" .
                 "di sistem Layanan Perpustakaan.\n\n" .
                 "Nomor Anda Terdaftar sebagai *ADMIN Perpustakaan*\n\n" .
                 "untuk melihat menu yang tersedia, silahkan ketik *menu*";

        $safe_nama = $db->escape_string($nama);
        $update = "INSERT INTO wa_data_answer (sender, p_last, nama, id_member)
                   VALUES ('$safe_sender', 'welcome', '$safe_nama', 'admin')";
        $db->query($update);
    }
} else {
    // 2. FIND MEMBER SLIMS
    $query_member = "SELECT * FROM member WHERE member_phone LIKE '%$safe_sender' LIMIT 1";
    $hasil_member = $slims->query($query_member);

    if($hasil_member && $hasil_member->num_rows > 0 ){
        while($x = $hasil_member->fetch_assoc()){
            $nama = $x['member_name'];
            $mid = $x['member_id'];
            $member = "member";
            $member_id = $mid;

            $jawab = "_*Assalamu'alaikum Warohmatullahi Wabarokatuh...*_\n\n" .
                     "Selamat Datang *$nama*\n" .
                     "di sistem Layanan Perpustakaan.\n\n" .
                     "Nomor Anda Terdaftar sebagai *MEMBER PERPUSTAKAAN*\n\n" .
                     "Untuk melihat menu yang tersedia, silahkan ketik *menu*";

            $safe_nama = $db->escape_string($nama);
            $safe_mid = $db->escape_string($mid);
            $update = "INSERT INTO wa_data_answer (sender, p_last, nama, id_member)
                       VALUES ('$safe_sender', 'welcome', '$safe_nama', '$safe_mid')";
            $db->query($update);
        }
    } else { 
        // 3. NOT FOUND
        $member = "non-member";
        $update = "INSERT INTO wa_data_answer (sender, p_last)
                   VALUES ('$safe_sender', 'welcome')";
        $db->query($update);

        $jawab = "_*Assalamu'alaikum Warohmatullahi Wabarokatuh...*_\n" .
                 "Selamat Datang di sistem Layanan Perpustakaan.\n\n" .
                 "Untuk melihat menu yang tersedia, silahkan ketik *menu*\n\n" .
                 "Info: Anda bisa menggunakan lebih banyak menu jika terdaftar sebagai anggota.";
    }
}
?>
