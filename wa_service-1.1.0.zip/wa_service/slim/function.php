<?php
//BOT WHATSAPP FOR SLIMS
//Create by : MASBUDIKUSUMA
//Email : masbudikusuma@gmail.com
//Website : https://sites.google.com/view/masbudikusuma/product/wa-bot-slims-library
//
function menu(&$jawab,&$jawab1,$member){ //MENU Function For Member, NonMember and Admin
  if ($member == "member"){
  $jawab = "
 *======== MENU MEMBER ========*
(1) untuk melihat biodata di sistem SLIM
(2) Peminjaman
(3) Denda Peminjaman
(4) History Peminjaman

*======== MENU UMUM ========*
(a) Melakukan Pencarian berdasarkan Judul Buku
(b) Melakukan Pencarian berdasarkan Pengarang
(c) Melakukan Pencarian berdasarkan Topik
(d) submenu
(e) submenu
";

$jawab1 = "_Ketik *Angka / huruf* di dalam kurung untuk menjalankan perintah_
_Ketik *FAQ* untuk melihat pertanyaan yang sering diajukan_";
} else if ($member == "non-member"){
  $jawab = "*Menu yang bisa Anda gunakan*
(a) Melakukan Pencarian berdasarkan Judul Buku
(b) Melakukan Pencarian berdasarkan Pengarang
(c) Melakukan Pencarian berdasarkan Topik
(d) submenu
(e) submenu
";

$jawab1 = "_Ketik *Angka / huruf* di dalam kurung untuk menjalankan perintah_
_Ketik *FAQ* untuk melihat pertanyaan yang sering diajukan_";
} else if ($member == "admin"){
  $jawab = "
  *=========== MENU ADMIN ==============*
10. Biodata member
20. Peminjaman member
30. Denda Peminjaman member
40. History Peminjaman member
50. Summary peminjaman

*=========== MENU MEMBER ==============*
1. untuk melihat biodata di sistem SLIM
2. Peminjaman
3. Denda Peminjaman
4. History Peminjaman

*=========== MENU UMUM ==============*
(a) Melakukan Pencarian berdasarkan Judul Buku
(b) Melakukan Pencarian berdasarkan Pengarang
(c) Melakukan Pencarian berdasarkan Topik
(d) submenu
(e) submenu
";

$jawab1 = "_Ketik *Angka / huruf* di dalam kurung untuk menjalankan perintah_
_Ketik *FAQ* untuk melihat pertanyaan yang sering diajukan_";
}
}

function faq_menu($sender,$db,&$jawab,&$jawab1,$member_id){
$query = "SELECT * from wa_faq where used='yes' order by id asc";
$hasil = $db->query($query);
if($hasil && $hasil->num_rows > 0 ){
$jawab = "*=========F A Q========*\n*Frequently Asked Questions:*";
while($x = $hasil->fetch_assoc()){
$jawab = $jawab."\n". $x['id'].". ".$x['question'];
}
}
$jawab1 = "_Ketik *Angka / huruf* di dalam kurung untuk menjalankan perintah_\n_ketik *menu* untuk ke menu awal_";
}

// SUB MENU FAQ ANSWER
function faq_answer($no,$db,&$jawab,&$jawab1,$member_id){
    $safe_no = (int)$no;
    $query = "SELECT * from wa_faq where id = '$safe_no' and used='yes' order by id asc ";
    $hasil = $db->query($query);
    if($hasil && $hasil->num_rows > 0 ){
        $jawab = "*=========F A Q========*\n*Frequently Asked Questions:*\n";
        while($x = $hasil->fetch_assoc()){
$question = $x['question'];
$answer = $x['answer'];
$jawab = $jawab."
*QUESTION :*
$question

*ANSWER :*
$answer
";
}
}else {$jawab = "_maaf tidak tersedia pilihan $no ._";}
$jawab1 = "_ketik *menu* untuk ke menu awal_";
}


function caridenda($sender,$slims,&$jawab,&$jawab1,$member_id){
  $safe_mid = $slims->escape_string($member_id);
  $query = "SELECT a.loan_id, a.item_code, a.loan_date, a.due_date, b.biblio_id, b.title FROM loan AS a
  LEFT JOIN loan_history AS b ON a.loan_id = b.loan_id
  WHERE a.member_id = '$safe_mid' AND a.is_return = '0'";
  $hasil = $slims->query($query);
  $totaldenda=0;  $jmlbuku =0;
    if($hasil && $hasil->num_rows > 0 ){
      $jawab = "*Denda Keterlambatan buku dengan Member ID $member_id* :\n*====================================*";
    while($x = $hasil->fetch_assoc()){
      $id_pinjam = $x['loan_id'];$item_code = $x['item_code'];
      $tgl_pinjam = $x['loan_date'];$batas_pinjam = $x['due_date'];
      $title = $x['title'];
      
      $query_fine = "SELECT a.due_date AS tgl_denda, CURDATE() AS tgl_skg,
      datediff(current_date(), due_date)  AS jumlah_hari,
      a.loan_rules_id,  a.item_code, a.member_id,
      c.fine_each_day as denda
      FROM loan AS a
      LEFT join member AS b ON a.member_id = b.member_id
      LEFT JOIN mst_loan_rules AS c ON c.member_type_id = b.member_type_id
      WHERE loan_id='".(int)$id_pinjam."';";
      $hasil1 = $slims->query($query_fine);

      if($hasil1 && $hasil1->num_rows > 0 ){
      while($y = $hasil1->fetch_assoc()){
        $jmlbuku++;
        $date1 = $y['tgl_denda'];
        $date2 = $y['tgl_skg'];
        $jumlah_hari = $y['jumlah_hari'];
        $denda = $y['denda'];
        
        $haridenda = 0;
        if ($date2 > $date1){
            $pecahTgl1 = explode("-", $date1);
            $thn1 = $pecahTgl1[0]; $bln1 = $pecahTgl1[1]; $tgl1 = $pecahTgl1[2];
            $i = 0; $sum = 0;
            do {
               $tanggal = date("Y-m-d", mktime(0, 0, 0, (int)$bln1, (int)$tgl1+$i, (int)$thn1));
               $w = date("w", mktime(0, 0, 0, (int)$bln1, (int)$tgl1+$i, (int)$thn1));
               if ($w == 0 || $w == 6) $sum++;
               $i++;
            } while ($tanggal != $date2);
            $haridenda = ($jumlah_hari - $sum - 1 );
        }
        
        $jmldenda = ($haridenda > 0) ? $haridenda * $denda : 0;
        $totaldenda += $jmldenda;
        $jawab .= "\nid Pinjam = $id_pinjam\nid Buku = $item_code\nJudul Buku = $title\nTanggal Pinjam = $tgl_pinjam\nBatas Pinjam = $batas_pinjam\nTerlambat = $haridenda Hari\nDenda = $jmldenda\n----------------------------";
      }
    }
  }
$jawab .= "\n*====================================*\n*JUMLAH BUKU DIPINJAM = $jmlbuku*\n*TOTAL DENDA = $totaldenda*";
  }else {
  $jawab = "Maaf, Member ID $member_id tidak memiliki peminjaman buku Aktif";
  }
  $jawab1 = "_Silahkan ketik kembali *ID PEMINJAM* yang diinginkan atau_\n_ketik *MENU* untuk kembali ke menu awal_";
}

// MEMBER MENU --> CARI DENDA
function denda($sender,$slims,&$jawab,$member_id){
  $safe_mid = $slims->escape_string($member_id);
  $query = "SELECT a.loan_id, a.item_code, a.loan_date, a.due_date, b.biblio_id, b.title FROM loan AS a
  LEFT JOIN loan_history AS b ON a.loan_id = b.loan_id
  WHERE a.member_id = '$safe_mid' AND a.is_return = '0'";
  $hasil = $slims->query($query);
  $totaldenda=0;
  $jmlbuku =0;
    if($hasil && $hasil->num_rows > 0 ){
      $jawab = "*Denda Keterlambatan*\n*====================================*";
    while($x = $hasil->fetch_assoc()){
      $id_pinjam = $x['loan_id'];$item_code = $x['item_code'];
      $tgl_pinjam = $x['loan_date'];$batas_pinjam = $x['due_date'];
      $title = $x['title'];
      
  $query_fine = "SELECT a.due_date AS tgl_denda, CURDATE() AS tgl_skg,
  datediff(current_date(), due_date)  AS jumlah_hari,  a.loan_rules_id,
  a.item_code, a.member_id,  c.fine_each_day as denda
  FROM loan AS a
  LEFT join member AS b ON a.member_id = b.member_id
  LEFT JOIN mst_loan_rules AS c ON c.member_type_id = b.member_type_id
  WHERE loan_id='".(int)$id_pinjam."';";
  $hasil1 = $slims->query($query_fine);
  
  if($hasil1 && $hasil1->num_rows > 0 ){
  while($y = $hasil1->fetch_assoc()){
    $jmlbuku++;
    $date1 = $y['tgl_denda'];
    $date2 = $y['tgl_skg'];
    $jumlah_hari = $y['jumlah_hari'];
    $denda = $y['denda'];

    $haridenda = 0;
    if ($date2 > $date1){
        $pecahTgl1 = explode("-", $date1);
        $thn1 = (int)$pecahTgl1[0]; $bln1 = (int)$pecahTgl1[1]; $tgl1 = (int)$pecahTgl1[2];
        $i = 0; $sum = 0;
        do {
           $tanggal = date("Y-m-d", mktime(0, 0, 0, $bln1, $tgl1+$i, $thn1));
           $w = date("w", mktime(0, 0, 0, $bln1, $tgl1+$i, $thn1));
           if ($w == 0 || $w == 6) $sum++;
           $i++;
        } while ($tanggal != $date2);
        $haridenda = ($jumlah_hari - $sum - 1 );
    }
    
    $jmldenda = ($haridenda > 0) ? $haridenda * $denda : 0;
    $totaldenda += $jmldenda;
    $jawab .= "\nid Pinjam = $id_pinjam\nid Buku = $item_code\nJudul Buku = $title\nTanggal Pinjam = $tgl_pinjam\nBatas Pinjam = $batas_pinjam\nTerlambat = $haridenda Hari\n*Denda = $jmldenda*\n----------------------------";
  }  }   }
$jawab .= "\n*====================================*\n*JUMLAH BUKU DIPINJAM = $jmlbuku*\n*TOTAL DENDA = $totaldenda*";
  }else {
  $jawab = "Maaf, Anda tidak memiliki peminjaman buku Aktif";
  }
}

// MEMBER MENU --> CEK PEMINJAMAN BUKU AKTIF
function cekpinjam($sender,$slims,&$jawab,$member_id){
  $safe_mid = $slims->escape_string($member_id);
  $query = "SELECT a.loan_id, a.item_code, a.loan_date, a.due_date, b.biblio_id, b.title FROM loan AS a
LEFT JOIN loan_history AS b ON a.loan_id = b.loan_id
WHERE a.member_id = '$safe_mid' AND a.is_return = '0'";
  $hasil = $slims->query($query);
    if($hasil && $hasil->num_rows > 0 ){
      $jawab = "*Buku yang anda pinjam saat ini* :\n*====================================*";
    while($x = $hasil->fetch_assoc()){
      $id_pinjam = $x['loan_id'];$item_code = $x['item_code'];
      $tgl_pinjam = $x['loan_date'];$batas_pinjam = $x['due_date'];
      $title = $x['title'];
      $jawab .= "\nid Pinjam = $id_pinjam\nid Buku = $item_code\nJudul Buku = $title\nTanggal Pinjam = $tgl_pinjam\nBatas Pinjam = $batas_pinjam\n----------------------------";
    }
  }else {
  $jawab = "Maaf, Anda tidak memiliki peminjaman buku Aktif";
}
}

// ADMIN MENU --> Cek Summary Pinjam
function sumpinjam($sender,$slims,&$jawab,$member_id){
$query = "SELECT count(DISTINCT a.member_id) AS peminjam,
COUNT(a.item_code) AS Buku FROM loan AS a WHERE a.is_return = 0;";
$hasil = $slims->query($query);
    $num = $hasil->num_rows ?? 0;
    if($hasil && $num > 0 ){
        while($x = $hasil->fetch_assoc()){
$aktifpinjam = $x['peminjam'];$aktifbuku = $x['Buku'];
}
}else {}
$query = "SELECT count(DISTINCT a.member_id) AS peminjam,
COUNT(a.item_code) AS Buku FROM loan AS a WHERE a.is_return = 1  ;";
$hasil = $slims->query($query);
    $num = $hasil->num_rows ?? 0;
    if($hasil && $num > 0 ){
        while($x = $hasil->fetch_assoc()){
$pasifpinjam = $x['peminjam'];$pasifbuku = $x['Buku'];
}
}else {}
$query = "SELECT count(DISTINCT a.member_id) AS peminjam,
COUNT(a.item_code) AS Buku FROM loan AS a ;  ";
$hasil = $slims->query($query);
    $num = $hasil->num_rows ?? 0;
    if($hasil && $num > 0 ){
        while($x = $hasil->fetch_assoc()){
$totalpinjam = $x['peminjam'];$totalbuku = $x['Buku'];
}
}else {}

$jawab = "*Summary Peminjaman Perpustakaan UIN Walisongo*
*====================================*;
*Peminjaman Aktif*
Jumlah Peminjam  : *$aktifpinjam member*
Buku yang dipinjam : *$aktifbuku Buku*

*Peminjaman Kembali*
Jumlah Peminjam  : *$pasifpinjam member*
Buku yang dipinjam : *$pasifbuku Buku*

*Peminjaman Total*
Jumlah Peminjam  : *$totalpinjam member*
Buku yang dipinjam : *$totalbuku Buku*
";
}//end Function cek pinjam

// MEMBER MENU --> History Pinjam
function historypinjam($sender,$slims,&$jawab,$member_id){
  $safe_mid = $slims->escape_string($member_id);
  $query = "SELECT a.loan_id, a.item_code, a.loan_date, a.due_date, b.biblio_id, b.title FROM loan AS a
  LEFT JOIN loan_history AS b ON a.loan_id = b.loan_id
  WHERE a.member_id = '$safe_mid'";
  $hasil = $slims->query($query);
    if($hasil && $hasil->num_rows > 0 ){
      $jawab = "*Sejarah Peminjaman Buku Anda* :\n*====================================*";
    while($x = $hasil->fetch_assoc()){
      $item_code = $x['item_code'];
      $tgl_pinjam = $x['loan_date'];
      $title = $x['title'];
      $jawab .= "\nid Buku = $item_code\nJudul Buku = $title\nTanggal Pinjam = $tgl_pinjam\n----------------------------";
    }
  }else {
  $jawab = "Maaf, Anda tidak memiliki sejarah peminjaman.";
  }
}

function chp($sender,$slims,&$jawab,&$jawab1,$key1){
  $safe_key = $slims->escape_string($key1);
  $query = "SELECT a.loan_id, a.item_code, a.loan_date, a.due_date, b.biblio_id, b.title FROM loan AS a
  LEFT JOIN loan_history AS b ON a.loan_id = b.loan_id
  WHERE a.member_id = '$safe_key'";
  $hasil = $slims->query($query);
    if($hasil && $hasil->num_rows > 0 ){
      $jawab = "*Sejarah Buku yang pernah dipinjam oleh Member ID $key1* :\n*====================================*;";
    while($x = $hasil->fetch_assoc()){
      $item_code = $x['item_code'];
      $tgl_pinjam = $x['loan_date'];
      $title = $x['title'];
      $jawab .= "\nid Buku = $item_code\nJudul Buku = $title\nTanggal Pinjam = $tgl_pinjam\n----------------------------";
    }
  }else {
  $jawab = "Maaf, Member ID *$key1* tidak memiliki sejarah peminjaman.";
  }
  $jawab1 = "_Silahkan ketik kembali *ID PEMINJAM* yang diinginkan atau_\n_ketik *MENU* untuk kembali ke menu awal_";
}
//end Function historypinjam


// Member MENU --> Cek Biodata Pustakawan
function biodata($sender,$slims,&$jawab,$member_id){
$safe_mid = $slims->escape_string($member_id);
$query = "SELECT * FROM member WHERE member_id = '$safe_mid' LIMIT 1";
$hasil = $slims->query($query);
 if($hasil && $x = $hasil->fetch_assoc()){
   $nama = $x['member_name'];
   $prodi = $x['inst_name'];
   $tanggal_lahir = $x['birth_date'];
   $alamat = $x['member_address'];
   $jawab = "\nMember ID : $member_id\nNama : $nama\nProdi : $prodi\nTanggal Lahir : $tanggal_lahir\nAlamat : $alamat";
} else {
  $jawab = "Maaf, data Member ID *$member_id* tidak ditemukan.";
}
}

function cbp($sender,$slims,$key1,&$jawab,&$jawab1){
$safe_key = $slims->escape_string($key1);
$query = "SELECT * FROM member WHERE member_id = '$safe_key' LIMIT 1";
$hasil = $slims->query($query);
 if($hasil && $x = $hasil->fetch_assoc()){
   $nama = $x['member_name'];
   $prodi = $x['inst_name'];
   $tanggal_lahir = $x['birth_date'];
   $alamat = $x['member_address'];
   $jawab = "\nMember ID : $key1\nNama : $nama\nProdi : $prodi\nTanggal Lahir : $tanggal_lahir\nAlamat : $alamat";
} else {
    $jawab = "Tidak ada Pustakawan dengan member ID *$key1*";
}
$jawab1 = "_Silahkan ketik kembali *ID PEMINJAM* yang diinginkan atau_\n_ketik *MENU* untuk kembali ke menu awal_";
}

function csp($sender,$slims,$key1,&$jawab,&$jawab1){
$safe_key = $slims->escape_string($key1);
$query = "SELECT a.loan_id, a.item_code, a.member_id, a.loan_date, a.due_date, a.is_return, b.title FROM loan AS a
LEFT JOIN loan_history AS b ON a.loan_id = b.loan_id
WHERE a.member_id = '$safe_key' AND a.is_return = 0";
$hasil = $slims->query($query);

  if($hasil && $hasil->num_rows > 0 ){
    $jawab = "Status Peminjaman BUKU Member ID *$key1*\n*====================================*";
    while($x = $hasil->fetch_assoc()){
          $jawab .= "\nJudul : ". $x['title']."\nItem Code : ". $x['item_code']."\nTanggal Pinjam : ".$x['loan_date']."\nTanggal Jatuh Tempo : ".$x['due_date']."\n----------------------------------";
    }
} else {
    $jawab = "Tidak ada peminjaman aktif untuk ID $key1";
}
$jawab1 = "_Silahkan ketik kembali *ID PEMINJAM* yang diinginkan atau_\n_ketik *MENU* untuk kembali ke menu awal_";
}

function cb($sender,$slims,$key1,$key2,$key3,$key4,$nomoradmin,&$jawab,&$jawab1,&$jawab2){
$safe_k1 = $slims->escape_string($key1 ?? '');
$safe_k2 = $slims->escape_string($key2 ?? '');

$query = "SELECT a.biblio_id, a.title, c.author_name FROM biblio AS a
          LEFT JOIN biblio_author AS b ON a.biblio_id = b.biblio_id
          LEFT JOIN mst_author AS c ON b.author_id = c.author_id
          WHERE a.title LIKE '%$safe_k1%$safe_k2%' OR a.title LIKE '%$safe_k2%$safe_k1%'
          LIMIT 10";
$hasil = $slims->query($query);
$jumlah = $hasil->num_rows ?? 0;

$key = trim("$key1 $key2 $key3 $key4");
$jawab = "*Hasil Pencarian Judul:* $key\n*====================================*\n";

if($hasil && $jumlah > 0 ){
    $jawab .= "Ditemukan $jumlah buku.\n*=========== DAFTAR BUKU ==============*";
    while($x = $hasil->fetch_assoc()){
         $judul = preg_replace("/[^a-zA-Z0-9 , .]/", "", $x['title']);
         $idbuku = $x['biblio_id'];
         $jawab1 .= "\nJudul : $judul\nKarya : ".$x['author_name']."\nDetail: ketik ==> cd $idbuku\n*----------------------------------------------------------*";
    }
} else {
    $jawab .= "Buku tidak ditemukan.";
}
$jawab2 = "_Ketik judul buku lain atau *MENU* untuk kembali._";
}



// UMUM --> PENCARIAN BUKU by subject / Topic
function cs($sender,$slims,$key1,$key2,$key3,$key4,$key5,$nomoradmin,&$jawab,&$jawab1,&$jawab2){
    $safe_k1 = $slims->escape_string($key1);
    $safe_k2 = $slims->escape_string($key2);
    $query = "SELECT a.title, a.author, a.biblio_id, a.topic FROM search_biblio AS a
              LEFT JOIN biblio AS b ON a.biblio_id = b.biblio_id
              WHERE topic LIKE '%$safe_k1%$safe_k2%' or topic LIKE '%$safe_k2%$safe_k1%'
              LIMIT 10";
    $hasil = $slims->query($query);
$jumlah = mysqli_num_rows($hasil);
$key = $key1. " ". $key2 . " " . $key3;
$jawab = "*Hasil Pencarian dengan Topik =* $key1 $key2 ";
 if(mysqli_num_rows($hasil) > 0 ){
   if($jumlah > 300 ){
     $jawab = $jawab."
terdapat *lebih dari 300 buku* ditemukan";
} else {
  $jawab = $jawab."
terdapat $jumlah buku ditemukan
";
}
$jawab1 = "*=========== DAFTAR BUKU ==============*";
   while($x = mysqli_fetch_array($hasil)){
         $judul = $x['title'];
         $author = $x['author'];
         $topic = $x['topic'];
         $judul = preg_replace("/[^a-z A-Z0-9 , .]/", "", $judul);
         $author = preg_replace("/[^a-z A-Z0-9 , .]/", "", $author);
         $jawab1 = $jawab1."
Judul : ". $judul."
Karya : ". $author."
Topik : ". $topic."
Detail : https://wa.me/$nomoradmin?text=cd%20".$x['biblio_id']."
*-----------------------------------------------------------------*";
 }
} else {
  $jawab1 = $jawab1. "
  buku dengan topik $key1 $key2 tidak ditemukan dalam pencarian";
}
$jawab2 = "_Silahkan kembali ketik *Judul Topik* yang diinginkan atau_
_ketik *MENU* untuk kembali ke awal_";
}

// Umum --> CP = Cari Pengarang, PENCARIAN Pengarang
function cp($sender,$slims,$key1,$key2,$key3,$key4,$nomoradmin,&$jawab,&$jawab1,&$jawab2){
$query = "SELECT * FROM search_biblio AS a
          LEFT JOIN biblio AS b ON a.biblio_id = b.biblio_id
          WHERE a.author like '%$key2%$key1%' or a.author like '%$key1%$key2%' limit 300";

          if (isset($key1)){$key = $key1;}
          if (isset($key2)){$key = $key." ".$key2;}
          if (isset($key3)){$key = $key." ".$key3;}
          if (isset($key4)){$key = $key." ".$key4;}


$hasil = $slims->query($query);
$jumlah = mysqli_num_rows($hasil);
if($jumlah > 299) {$jawab = "*Hasil Pencarian Nama Pengarang =* $key
terdapat *Lebih dari $jumlah buku* ditemukan
===================================";}
else if($jumlah > 0 ){$jawab = "*Hasil Pencarian Nama Pengarang =* $key
terdapat *$jumlah buku* ditemukan
===================================";}

$jawab1 = "*=========== DAFTAR BUKU ==============*";
  if($hasil && $hasil->num_rows > 0 ){
    while($x = $hasil->fetch_assoc()){
          $judul = $x['title'];
          $judul = preg_replace("/[^a-z A-Z0-9 , .]/", "", $judul);
          $jawab1 = $jawab1."
Judul : ". $judul."
karya : ". $x['author']."
detail : https://wa.me/$nomoradmin?text=cd%20".$x['biblio_id']."
*===================================*";
}
}else {
  $jawab1 = $jawab1."hasil pencarian Buku dengan Pengarang
  ketik *menu* untuk menampilkan menu";
}

$jawab2 = "_Silahkan kembali ketik *Nama Pengarang* yang diinginkan atau_
_ketik *MENU* untuk kembali ke awal_";}

// GENERAL MENU --> CD = CEK DETAIL PENCARIAN DETAIL BUKU
function cd($sender,$slims,$key1,$key2,$web,&$jawab){
    $safe_id = $slims->escape_string($key2);
    $query = "SELECT a.biblio_id, a.title, e.topic, a.isbn_issn, a.classification, a.notes,
              a.publish_year, a.call_number, c.author_name, d.publisher_name
              FROM biblio AS a
              LEFT JOIN biblio_author AS b ON a.biblio_id = b.biblio_id
              LEFT JOIN mst_author AS c ON b.author_id = c.author_id
              LEFT JOIN mst_publisher AS d ON a.publisher_id = d.publisher_id
              LEFT JOIN search_biblio AS e ON a.biblio_id = e.biblio_id
              WHERE a.biblio_id = '$safe_id' LIMIT 1";
    $hasil = $slims->query($query);
    if($hasil && $hasil->num_rows > 0 ){
        while($x = $hasil->fetch_assoc()){
$judul = $x['title'];
$judul = preg_replace("/[^a-z A-Z0-9 , .]/", "", $judul);
$jawab = $jawab."
*==========DETAIL==========*
  Judul : ". $judul."
  Pengarang : ". $x['author_name']."
  Penerbit : ". $x['publisher_name']."
  Tahun Terbit : ". $x['publish_year']."
  Subyek : ". $x['topic']."
  Nomor Panggil : ". $x['call_number']."
  Deskripsi Fisik : ". $x['collation']."
  isbn issn : ". $x['isbn_issn']."
  Website : $web/index.php?p=show_detail&id=$key2
*=========Ketersediaan========*";

                  $item = "SELECT * FROM item g WHERE g.biblio_id = '$key2'";
                  $hasilitem = $slims->query($item);
                  if($hasilitem && $hasilitem->num_rows > 0 ){
                    while($y = $hasilitem->fetch_assoc()){
                      $itemcode = $y['item_code'];

                                  $status = "
                                  SELECT z.item_code, z.item_status_id, z.biblio_id, y.due_date, x.*  FROM item z
LEFT JOIN loan y ON y.item_code = z.item_code
LEFT JOIN mst_item_status x ON z.item_status_id = x.item_status_id
WHERE z.item_code = '$itemcode' and y.is_return = 0";

                                  $hasilstatus = $slims->query($status);
                                  if($hasilstatus && $hasilstatus->num_rows > 0 ){
                                    while($z = $hasilstatus->fetch_assoc()){
                                      $jatuhtempo = $z['due_date'];
$jawab = $jawab."
 |Item Code : $itemcode | Dipinjam (Jatuh Tempo $jatuhtempo) ";
}}else {
if ($y['item_status_id'] == "NL"){
$jawab = $jawab."
 |Item Code : $itemcode | *Tersedia dan tidak untuk dipinjamkan*";
} else {
$jawab = $jawab."
 |Item Code : $itemcode | *Tersedia*";
}}

} }else {
  $jawab = "Detail buku dengan ID $key2 tidak ditemukan.
  silahkan ketik *menu* untuk menampilkan Menu tersedia ";
} $jawab = $jawab."
"; //Jeda Detail Buku
}}}


?>
