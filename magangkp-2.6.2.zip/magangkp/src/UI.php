<?php
/**
 * @Author: Faisal Fajar, Irsyad, Sena
 * @Date: 2026-02-27
 */

namespace MagangKp;

use SLiMS\Plugins;

/**
 * Class UI
 * 
 * Helper untuk memanipulasi antarmuka (UI) OPAC dan pendaftaran menu plugin.
 */
class UI
{
    /**
     * Mendaftarkan menu Visitor pada modul OPAC.
     * 
     * @param string $pluginDir Path ke direktori plugin.
     * @return void
     */
    public static function registerVisitorMenu($pluginDir)
    {
        $plugin = Plugins::getInstance();
        $plugin->registerMenu('opac', 'Visitor', $pluginDir . '/visitor.php');
    }

    /**
     * Mendaftarkan menu admin untuk monitoring/kelola visitor plugin.
     *
     * @param string $pluginDir
     * @return void
     */
    public static function registerAdminVisitorMenu($pluginDir)
    {
        $plugin = Plugins::getInstance();

        // Place under existing native reporting header to avoid "PLUGINS" group label.
        $groupName = function_exists('__') ? __('REPORTING FORM') : 'REPORTING FORM';
        Plugins::group($groupName, function () use ($plugin, $pluginDir) {
            $plugin->registerMenu(
                'reporting',
                'Kelola Visitor Lengkap',
                $pluginDir . '/kelola_visitor_lengkap.php',
                'Monitoring dan kelola visitor sinkron dari OPAC'
            );
            $plugin->registerMenu(
                'reporting',
                'Non Member List',
                $pluginDir . '/non_member_list.php',
                'Daftar kunjungan Non Member dan Rombongan'
            );
            $plugin->registerMenu(
                'reporting',
                'Jadwal Visitor per Lokasi',
                $pluginDir . '/jadwal_visitor_lokasi.php',
                'Atur jam buka/tutup visitor per lokasi dan hari libur'
            );
        });
    }

    /**
     * Menyembunyikan menu "About SLiMS" dan mengelola navigasi samping OPAC.
     * 
     * @param object $opac Instance dari SLiMS\Opac.
     * @return void
     */
    public static function tweakOpacInterface($opac)
    {
        // 1. Injeksi CSS untuk menyembunyikan link slimsinfo (About SLiMS)
        $metadata = $opac->metadata ?? '';
        $metadata .= <<<HTML
<style>
  a[href*="p=slimsinfo"] {
    display: none !important;
  }
</style>
HTML;
        $opac->metadata = $metadata;

        // 2. Injeksi JavaScript untuk menyisipkan menu Visitor via plugin
        $labelVisitor = function_exists('__') ? __('Visitor') : 'Visitor';
        $labelVisitorJs = json_encode($labelVisitor, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        
        $js = $opac->js ?? '';
        $js .= <<<HTML
<script>
document.addEventListener('DOMContentLoaded', function () {
  var currentPage = new URLSearchParams(window.location.search).get('p') || '';
  var visitorLabel = {$labelVisitorJs};

  function removeSlimsInfoMenu(menu) {
    if (!menu) return;
    menu.querySelectorAll('a[href*="p=slimsinfo"]').forEach(function (anchor) {
      var li = anchor.closest('li');
      if (li) li.remove();
    });
  }

  function insertVisitorMenu(menu, isNavbar) {
    if (!menu) return;

    removeSlimsInfoMenu(menu);
    if (menu.querySelector('a[href*="p=visitor"]')) return;

    var visitorLi = document.createElement('li');
    var visitorA = document.createElement('a');
    visitorA.href = 'index.php?p=visitor';
    visitorA.textContent = visitorLabel;

    if (isNavbar) {
      visitorLi.className = 'nav-item' + (currentPage === 'visitor' ? ' active' : '');
      visitorA.className = 'nav-link';
    }

    visitorLi.appendChild(visitorA);

    var homeSelector = isNavbar
      ? 'li a.nav-link[href="index.php"], li a.nav-link[href="./index.php"], li a[href="index.php"], li a[href="./index.php"]'
      : 'li a[href="index.php"], li a[href="./index.php"]';
    var homeAnchor = menu.querySelector(homeSelector);
    var homeLi = homeAnchor ? homeAnchor.closest('li') : null;

    if (homeLi && homeLi.parentNode) {
      homeLi.parentNode.insertBefore(visitorLi, homeLi.nextSibling);
      return;
    }

    if (menu.firstChild) {
      menu.insertBefore(visitorLi, menu.firstChild);
      return;
    }

    menu.appendChild(visitorLi);
  }

  insertVisitorMenu(document.querySelector('.s-menu-content ul'), false);
  insertVisitorMenu(document.querySelector('#navbarSupportedContent .navbar-nav'), true);
});
</script>
HTML;
        $opac->js = $js;

        // 3. Blokir akses langsung ke halaman About SLiMS melalui URL
        $path = strtolower(trim((string) ($_GET['p'] ?? '')));
        if ($path === 'slimsinfo') {
            header('Location: index.php', true, 302);
            exit;
        }
    }
}
