<?php
/**
 * @Author: Faisal Fajar, Irsyad, Sena
 * @Date: 2026-02-27
 */

namespace MagangKp;

use SLiMS\DB;
use SLiMS\Json;

/**
 * Class VisitorLogic
 * 
 * Menangani logika pemrosesan data pengunjung, terutama fitur Rombongan (Multi-insert).
 */
class VisitorLogic
{
    private const NON_MEMBER_JOBS = [
        'Pegawai Negeri', 'Pegawai Swasta', 'Wiraswasta', 'Mahasiswa',
        'Peneliti', 'Dosen', 'Guru', 'Lainnya',
        'TNI/POLRI', 'Pensiunan', 'Pelajar'
    ];

    private const EDUCATION_LEVELS = ['TK', 'SD', 'SMP', 'SMA', 'D1', 'D2', 'D3', 'S1', 'S2', 'S3'];

    private const GENDERS = ['1', '0'];

    private const PURPOSE_OPTIONS = [
        'Membaca di tempat', 'Belajar', 'Riset',
        'Internet', 'Kunjungan instansi', 'Lainnya'
    ];

    private const GROUP_JOB_FIELDS = [
        'groupJobPns' => 'PNS',
        'groupJobPegawaiSwasta' => 'Pegawai Swasta',
        'groupJobPeneliti' => 'Peneliti',
        'groupJobGuru' => 'Guru',
        'groupJobDosen' => 'Dosen',
        'groupJobPensiunan' => 'Pensiunan',
        'groupJobTniPolri' => 'TNI/POLRI',
        'groupJobWiraswasta' => 'Wiraswasta',
        'groupJobPelajar' => 'Pelajar',
        'groupJobMahasiswa' => 'Mahasiswa',
        'groupJobLainnya' => 'Lainnya'
    ];

    private const GROUP_EDUCATION_FIELDS = [
        'groupEduTk' => 'TK',
        'groupEduSd' => 'SD',
        'groupEduSmp' => 'SMP (sederajat)',
        'groupEduSma' => 'SMA (sederajat)',
        'groupEduD1' => 'Diploma (D1)',
        'groupEduD2' => 'Diploma (D2)',
        'groupEduD3' => 'Diploma (D3)',
        'groupEduS1' => 'Sarjana (S1)',
        'groupEduS2' => 'Magister (S2)',
        'groupEduS3' => 'Doktor (S3)'
    ];

    private const VISIT_SCHEDULE_SETTING = 'magangkp_visit_schedule';

    private const DAY_KEYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

    private const DAY_LABELS = [
        'monday' => 'Senin',
        'tuesday' => 'Selasa',
        'wednesday' => 'Rabu',
        'thursday' => 'Kamis',
        'friday' => 'Jumat',
        'saturday' => 'Sabtu',
        'sunday' => 'Minggu'
    ];

    /**
     * Process submission and return structured response data.
     * This method does not print output or terminate execution.
     *
     * @param object $visitorSInstance Instance dari SLiMS\Visitor.
     * @return array|null
     */
    public static function handleSubmissionWithResult($visitorSInstance): ?array
    {
        if (!isset($_POST['counter'])) return null;

        if (trim($_POST['memberID'] ?? '') == '') {
            return ['message' => __('Member ID can\'t be empty'), 'image' => 'person.png', 'status' => false];
        }

        $visitorType = $_POST['visitorType'] ?? 'member';
        $allowedType = ['member', 'non_member', 'rombongan', 'kritik_saran'];
        if (!in_array($visitorType, $allowedType, true)) {
            $visitorType = 'member';
        }

        $memberName = self::sanitizeText($_POST['memberID'] ?? '', 120) ?? '';
        $institution = trim($_POST['institution'] ?? '');
        $maleCount = max(0, (int)($_POST['maleCount'] ?? 0));
        $femaleCount = max(0, (int)($_POST['femaleCount'] ?? 0));
        $groupTotal = $maleCount + $femaleCount;
        $visitLocation = self::sanitizeText($_POST['visitLocation'] ?? '', 120);

        $nonMemberData = [
            'job' => self::normalizeChoice($_POST['visitorJob'] ?? '', self::NON_MEMBER_JOBS),
            'education' => self::normalizeChoice($_POST['visitorEducation'] ?? '', self::EDUCATION_LEVELS),
            'gender' => self::normalizeGender($_POST['visitorGender'] ?? ''),
            'address' => self::sanitizeText($_POST['visitorAddress'] ?? '', 500),
            'purpose' => self::normalizeChoice($_POST['visitorPurpose'] ?? '', self::PURPOSE_OPTIONS)
        ];

        $groupData = [
            'leader_phone' => self::sanitizePhone($_POST['groupLeaderPhone'] ?? '', 40),
            'institution_address' => self::sanitizeText($_POST['groupInstitutionAddress'] ?? '', 700),
            'institution_phone' => self::sanitizePhone($_POST['groupInstitutionPhone'] ?? '', 40),
            'institution_email' => self::sanitizeEmail($_POST['groupInstitutionEmail'] ?? '', 120),
            'purpose' => self::normalizeChoice($_POST['groupPurpose'] ?? '', self::PURPOSE_OPTIONS),
            'male_count' => $maleCount,
            'female_count' => $femaleCount,
            'person_count' => $groupTotal,
            'job_stats' => self::sanitizeCounterMap(self::GROUP_JOB_FIELDS),
            'education_stats' => self::sanitizeCounterMap(self::GROUP_EDUCATION_FIELDS)
        ];

        if ($visitorType === 'kritik_saran') {
            $visitorType = 'non_member';
            if ($nonMemberData['purpose'] === null) {
                $nonMemberData['purpose'] = 'Lainnya';
            }
            if ($nonMemberData['gender'] === null) {
                $nonMemberData['gender'] = '0';
            }
        }

        if (($visitorType === 'non_member' || $visitorType === 'rombongan') && $institution === '') {
            return [
                'message' => __('Sorry, Please fill institution field if you are not library member'),
                'image' => 'person.png',
                'status' => false
            ];
        }
        if (($visitorType === 'non_member' || $visitorType === 'rombongan') && !self::isVisitorNameLettersOnly($memberName)) {
            return [
                'message' => 'Nama pengunjung/ketua rombongan hanya boleh huruf dan spasi',
                'image' => 'person.png',
                'status' => false
            ];
        }
        if (($visitorType === 'non_member' || $visitorType === 'rombongan') && !self::isInstitutionLettersOnly($institution)) {
            return [
                'message' => 'Institution hanya boleh huruf dan spasi',
                'image' => 'person.png',
                'status' => false
            ];
        }
        if ($visitLocation === null) {
            return [
                'message' => 'Pilih lokasi kunjungan terlebih dahulu',
                'image' => 'person.png',
                'status' => false
            ];
        }

        $visitWindow = self::getVisitWindowStatus($visitLocation);
        if (!$visitWindow['allowed']) {
            return [
                'message' => $visitWindow['reason'] ?: 'Layanan visitor sedang tutup untuk lokasi ini',
                'image' => 'person.png',
                'status' => false
            ];
        }

        if ($visitorType !== 'rombongan' && $nonMemberData['purpose'] === null) {
            return [
                'message' => 'Pilih tujuan kunjungan terlebih dahulu',
                'image' => 'person.png',
                'status' => false
            ];
        }
        if ($visitorType === 'non_member' && $nonMemberData['gender'] === null) {
            return [
                'message' => 'Pilih jenis kelamin terlebih dahulu',
                'image' => 'person.png',
                'status' => false
            ];
        }

        if ($visitorType === 'rombongan') {
            if ($groupTotal < 1) {
                return [
                    'message' => 'Jumlah rombongan minimal 1 orang',
                    'image' => 'person.png',
                    'status' => false
                ];
            }

            if ($groupData['leader_phone'] === null) {
                return [
                    'message' => 'Nomor telepon ketua rombongan wajib diisi',
                    'image' => 'person.png',
                    'status' => false
                ];
            }

            if ($groupData['institution_address'] === null) {
                return [
                    'message' => 'Alamat instansi lembaga wajib diisi',
                    'image' => 'person.png',
                    'status' => false
                ];
            }

            if (($groupData['institution_email'] ?? '') === '__INVALID_EMAIL__') {
                return [
                    'message' => 'Format email instansi tidak valid',
                    'image' => 'person.png',
                    'status' => false
                ];
            }

            $jobStatsTotal = array_sum($groupData['job_stats']);
            if ($jobStatsTotal !== $groupTotal) {
                return [
                    'message' => 'Total rincian pekerjaan rombongan harus sama dengan jumlah personil',
                    'image' => 'person.png',
                    'status' => false
                ];
            }

            $educationStatsTotal = array_sum($groupData['education_stats']);
            if ($educationStatsTotal > $groupTotal) {
                return [
                    'message' => 'Total rincian pendidikan tidak boleh melebihi jumlah rombongan',
                    'image' => 'person.png',
                    'status' => false
                ];
            }

            return self::processRombongan($memberName, $institution, $maleCount, $femaleCount, $groupData, $visitLocation);
        }

        return self::processStandard($visitorSInstance, $memberName, $visitorType, $nonMemberData, $visitLocation);
    }

    /**
     * Memproses data pengunjung berdasarkan tipe yang dipilih.
     * 
     * @param object $visitorSInstance Instance dari SLiMS\Visitor.
     * @return void
     */
    public static function handleSubmission($visitorSInstance)
    {
        $result = self::handleSubmissionWithResult($visitorSInstance);
        if ($result === null) return;
        die(Json::stringify($result)->withHeader());
    }

    /**
     * Mengolah pendaftaran tipe Rombongan dengan strategi Row Multiplication.
     * 
     * @param string $leaderNama Nama ketua rombongan.
     * @param string $inst Institusi asal.
     * @param int $maleCount Jumlah laki-laki dalam rombongan.
     * @param int $femaleCount Jumlah perempuan dalam rombongan.
     * @param array $groupData Data detail rombongan.
     * @return array
     */
    private static function processRombongan($leaderNama, $inst, $maleCount, $femaleCount, array $groupData = [], ?string $visitLocation = null)
    {
        $db = DB::getInstance();
        $roomCode = $_GET['room'] ?? null;
        $maleCount = max(0, (int)$maleCount);
        $femaleCount = max(0, (int)$femaleCount);
        $total = $maleCount + $femaleCount;

        if ($total < 1) {
            return ['message' => 'Jumlah rombongan minimal 1 orang', 'image' => 'photo.png', 'status' => false];
        }

        $columnSupport = [
            'visitor_type' => self::hasColumn($db, 'visitor_count', 'visitor_type'),
            'visit_location' => self::hasColumn($db, 'visitor_count', 'visit_location'),
            'group_leader_phone' => self::hasColumn($db, 'visitor_count', 'group_leader_phone'),
            'institution_address' => self::hasColumn($db, 'visitor_count', 'institution_address'),
            'institution_phone' => self::hasColumn($db, 'visitor_count', 'institution_phone'),
            'institution_email' => self::hasColumn($db, 'visitor_count', 'institution_email'),
            'group_purpose' => self::hasColumn($db, 'visitor_count', 'group_purpose'),
            'group_gender_male' => self::hasColumn($db, 'visitor_count', 'group_gender_male'),
            'group_gender_female' => self::hasColumn($db, 'visitor_count', 'group_gender_female'),
            'group_person_count' => self::hasColumn($db, 'visitor_count', 'group_person_count'),
            'group_job_stats' => self::hasColumn($db, 'visitor_count', 'group_job_stats'),
            'group_education_stats' => self::hasColumn($db, 'visitor_count', 'group_education_stats')
        ];

        $groupPayload = [
            'visit_location' => $visitLocation,
            'group_leader_phone' => $groupData['leader_phone'] ?? null,
            'institution_address' => $groupData['institution_address'] ?? null,
            'institution_phone' => $groupData['institution_phone'] ?? null,
            'institution_email' => ($groupData['institution_email'] ?? null) === '__INVALID_EMAIL__'
                ? null
                : ($groupData['institution_email'] ?? null),
            'group_purpose' => $groupData['purpose'] ?? null,
            'group_gender_male' => $maleCount,
            'group_gender_female' => $femaleCount,
            'group_person_count' => $total,
            'group_job_stats' => self::encodeCounterMap($groupData['job_stats'] ?? []),
            'group_education_stats' => self::encodeCounterMap($groupData['education_stats'] ?? [])
        ];

        $insertColumns = ['member_id', 'member_name', 'institution', 'group_count', 'room_code'];
        $basePayload = [null, null, $inst, 1, $roomCode];

        if ($columnSupport['visitor_type']) {
            $insertColumns[] = 'visitor_type';
            $basePayload[] = 'rombongan';
        }

        foreach ($groupPayload as $column => $value) {
            if ($columnSupport[$column]) {
                $insertColumns[] = $column;
                $basePayload[] = $value;
            }
        }

        $insertColumns[] = 'checkin_date';
        $placeholders = implode(',', array_fill(0, count($insertColumns), '?'));
        $insertQuery = 'INSERT INTO visitor_count (' . implode(', ', $insertColumns) . ') VALUES (' . $placeholders . ')';
        $insertStatement = $db->prepare($insertQuery);

        if (!$insertStatement) {
            return ['message' => 'Gagal menyiapkan data rombongan!', 'image' => 'photo.png', 'status' => false];
        }
        
        $successCount = 0;
        $isLeaderAssigned = false;
        $executeInsert = function (string $nameToSave) use (&$successCount, &$isLeaderAssigned, $insertStatement, $basePayload) {
            $payload = $basePayload;
            $payload[1] = $nameToSave;
            $payload[] = date('Y-m-d H:i:s');
            $res = $insertStatement->execute($payload);
            if ($res) {
                $successCount++;
                $isLeaderAssigned = true;
            }
        };

        for ($i = 0; $i < $maleCount; $i++) {
            $nameToSave = (!$isLeaderAssigned)
                ? $leaderNama . " (Ketua Rombongan - Laki-laki)"
                : "Anggota Rombongan Laki-laki ($leaderNama)";
            $executeInsert($nameToSave);
        }

        for ($i = 0; $i < $femaleCount; $i++) {
            $nameToSave = (!$isLeaderAssigned)
                ? $leaderNama . " (Ketua Rombongan - Perempuan)"
                : "Anggota Rombongan Perempuan ($leaderNama)";
            $executeInsert($nameToSave);
        }
        
        if ($successCount > 0) {
            $message = $leaderNama . " (Ketua Rombongan), terima kasih telah mengisi buku tamu (L: {$maleCount}, P: {$femaleCount}, Total: {$total} orang)";
            return ['message' => $message, 'image' => 'photo.png', 'status' => true];
        } else {
            return ['message' => 'Gagal menyimpan data rombongan!', 'image' => 'photo.png', 'status' => false];
        }
    }

    /**
     * Mengolah pendaftaran pengunjung standar (Anggota/Non-Anggota) menggunakan library SLiMS.
     * 
     * @param object $vInstance Instance SLiMS\Visitor.
     * @param string $mID ID Anggota atau Nama Non-Anggota.
     * @return array
     */
    private static function processStandard($vInstance, $mID, string $visitorType = 'member', array $nonMemberData = [], ?string $visitLocation = null)
    {
        $vInstance->record($mID);
        $image = 'photo.png';

        if ($vInstance->getResult() === true) {
            list($memberId, $memberNameResult, $institutionResult, $image) = $vInstance->getData();
            $message = $memberNameResult . __(', thank you for inserting your data to our visitor log');
            if ($vInstance->isMemberExpire()) $message = '<div class="error visitor-error">'.__('Your membership already EXPIRED, please renew/extend your membership immediately').'</div>';
            if ($vInstance->isAlreadyCheckIn()) $message = __('Welcome back').' '.$memberNameResult.'.';

            // Persist additional metadata on fresh check-in row.
            if (!$vInstance->isAlreadyCheckIn()) {
                self::persistVisitorMetadata($mID, $vInstance->isMember(), $visitorType, $nonMemberData, $visitLocation);
            }
        } else if ($vInstance->isInstitutionEmpty()) {
            $message = __('Sorry, Please fill institution field if you are not library member');
        } else {
            $message = 'Gagal menyimpan data ke basis data!';
        }
        
        return ['message' => $message, 'image' => $image, 'status' => $vInstance->getResult()];
    }

    /**
     * Validasi institution hanya huruf dan spasi.
     *
     * @param string $institution
     * @return bool
     */
    private static function isInstitutionLettersOnly(string $institution): bool
    {
        return self::isLettersAndSpacesOnly($institution);
    }

    /**
     * Validasi nama pengunjung/ketua rombongan hanya huruf dan spasi.
     *
     * @param string $visitorName
     * @return bool
     */
    private static function isVisitorNameLettersOnly(string $visitorName): bool
    {
        return self::isLettersAndSpacesOnly($visitorName);
    }

    /**
     * Helper validasi: hanya huruf (unicode) dan spasi.
     *
     * @param string $value
     * @return bool
     */
    private static function isLettersAndSpacesOnly(string $value): bool
    {
        $value = trim($value);
        if ($value === '') {
            return false;
        }
        return (bool) preg_match('/^[\p{L}\s]+$/u', $value);
    }

    /**
     * Cek apakah kolom tersedia pada tabel.
     *
     * @param object $db
     * @param string $table
     * @param string $column
     * @return bool
     */
    private static function hasColumn($db, string $table, string $column): bool
    {
        try {
            $result = $db->query("SHOW COLUMNS FROM {$table} LIKE '{$column}'");
            return $result && $result->rowCount() > 0;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Persist visitor_type and non-member detail fields into latest inserted row.
     *
     * @param string $visitorIdentifier
     * @param bool $isMember
     * @param string $visitorType
     * @param array $nonMemberData
     * @return void
     */
    private static function persistVisitorMetadata(string $visitorIdentifier, bool $isMember, string $visitorType, array $nonMemberData, ?string $visitLocation = null): void
    {
        $db = DB::getInstance();

        $hasVisitorType = self::hasColumn($db, 'visitor_count', 'visitor_type');
        $hasJob = self::hasColumn($db, 'visitor_count', 'visitor_job');
        $hasEducation = self::hasColumn($db, 'visitor_count', 'visitor_education');
        $hasGender = self::hasColumn($db, 'visitor_count', 'visitor_gender');
        $hasAddress = self::hasColumn($db, 'visitor_count', 'visitor_address');
        $hasPurpose = self::hasColumn($db, 'visitor_count', 'visitor_purpose');
        $hasVisitLocation = self::hasColumn($db, 'visitor_count', 'visit_location');

        $updateFields = [];
        $updateValues = [];

        if ($hasVisitorType) {
            $updateFields[] = 'visitor_type = ?';
            $updateValues[] = $visitorType;
        }

        if ($hasVisitLocation) {
            $updateFields[] = 'visit_location = ?';
            $updateValues[] = $visitLocation;
        }

        if ($visitorType === 'non_member') {
            if ($hasJob) {
                $updateFields[] = 'visitor_job = ?';
                $updateValues[] = $nonMemberData['job'] ?? null;
            }
            if ($hasEducation) {
                $updateFields[] = 'visitor_education = ?';
                $updateValues[] = $nonMemberData['education'] ?? null;
            }
            if ($hasGender) {
                $updateFields[] = 'visitor_gender = ?';
                $updateValues[] = $nonMemberData['gender'] ?? null;
            }
            if ($hasAddress) {
                $updateFields[] = 'visitor_address = ?';
                $updateValues[] = $nonMemberData['address'] ?? null;
            }
        }

        if ($hasPurpose && $visitorType !== 'rombongan') {
            $updateFields[] = 'visitor_purpose = ?';
            $updateValues[] = $nonMemberData['purpose'] ?? null;
        }

        if (empty($updateFields)) {
            return;
        }

        $visitorId = (int)$db->lastInsertId();
        if ($visitorId < 1) {
            $criteria = $isMember ? 'member_id' : 'member_name';
            $findStmt = $db->prepare("SELECT visitor_id FROM visitor_count WHERE {$criteria} = ? ORDER BY visitor_id DESC LIMIT 1");
            if (!$findStmt || !$findStmt->execute([$visitorIdentifier])) {
                return;
            }
            $row = $findStmt->fetch(\PDO::FETCH_ASSOC);
            $visitorId = (int)($row['visitor_id'] ?? 0);
            if ($visitorId < 1) {
                return;
            }
        }

        $sql = 'UPDATE visitor_count SET ' . implode(', ', $updateFields) . ' WHERE visitor_id = ?';
        $stmt = $db->prepare($sql);
        if (!$stmt) {
            return;
        }

        $updateValues[] = $visitorId;
        $stmt->execute($updateValues);
    }

    /**
     * Evaluate whether visitor check-in is currently allowed for selected location.
     *
     * @param string|null $location
     * @param int|null $timestamp
     * @return array
     */
    public static function getVisitWindowStatus(?string $location, ?int $timestamp = null): array
    {
        $time = $timestamp ?? time();
        $selectedLocation = trim((string)$location);
        $date = date('Y-m-d', $time);
        $dayKey = strtolower(date('l', $time));
        $dayLabel = self::DAY_LABELS[$dayKey] ?? ucfirst($dayKey);
        $clock = date('H:i', $time);

        $status = [
            'allowed' => true,
            'location' => $selectedLocation,
            'date' => $date,
            'day_key' => $dayKey,
            'day_label' => $dayLabel,
            'time' => $clock,
            'open_time' => null,
            'close_time' => null,
            'reason' => ''
        ];

        $config = self::loadVisitScheduleConfig();
        $hasSchedule = !empty($config['schedules']);
        $hasHoliday = !empty($config['holidays']);

        if (!$hasSchedule && !$hasHoliday) {
            return $status;
        }

        if ($selectedLocation === '') {
            $status['allowed'] = false;
            $status['reason'] = 'Pilih lokasi kunjungan terlebih dahulu';
            return $status;
        }

        foreach ($config['holidays'] as $holidayRow) {
            $holidayStart = (string)($holidayRow['start_date'] ?? ($holidayRow['date'] ?? ''));
            $holidayEnd = (string)($holidayRow['end_date'] ?? ($holidayRow['date'] ?? ''));
            $holidayLocation = (string)($holidayRow['location'] ?? 'all');

            if (!self::isValidDate($holidayStart) || !self::isValidDate($holidayEnd)) {
                continue;
            }

            if ($holidayEnd < $holidayStart) {
                $temp = $holidayStart;
                $holidayStart = $holidayEnd;
                $holidayEnd = $temp;
            }

            $isDateInside = ($date >= $holidayStart && $date <= $holidayEnd);
            if (
                $isDateInside &&
                ($holidayLocation === 'all' || $holidayLocation === $selectedLocation)
            ) {
                $holidayName = trim((string)($holidayRow['name'] ?? ''));
                $rangeLabel = $holidayStart === $holidayEnd
                    ? $holidayStart
                    : ($holidayStart . ' s/d ' . $holidayEnd);

                $status['allowed'] = false;
                $status['reason'] = $holidayName !== ''
                    ? "Hari libur {$rangeLabel}: {$holidayName}"
                    : "Hari libur {$rangeLabel} untuk {$selectedLocation}";
                return $status;
            }
        }

        $locationSchedule = $config['schedules'][$selectedLocation] ?? null;
        if (!is_array($locationSchedule)) {
            // No configured schedule for this location means always open (except holiday).
            return $status;
        }

        $todaySchedule = $locationSchedule[$dayKey] ?? null;
        if (!is_array($todaySchedule)) {
            return $status;
        }

        $isOpen = !empty($todaySchedule['open']);
        $openTime = self::normalizeTimeValue((string)($todaySchedule['open_time'] ?? ''), '08:00');
        $closeTime = self::normalizeTimeValue((string)($todaySchedule['close_time'] ?? ''), '16:00');
        $status['open_time'] = $openTime;
        $status['close_time'] = $closeTime;

        if (!$isOpen) {
            $status['allowed'] = false;
            $status['reason'] = "Layanan tutup pada hari {$dayLabel}";
            return $status;
        }

        if (!self::isWithinTimeWindow($clock, $openTime, $closeTime)) {
            $status['allowed'] = false;
            $status['reason'] = "Jam layanan {$dayLabel}: {$openTime} - {$closeTime}";
            return $status;
        }

        $status['reason'] = "Layanan buka {$dayLabel}: {$openTime} - {$closeTime}";
        return $status;
    }

    /**
     * Read and normalize visit schedule config from setting table.
     *
     * @return array
     */
    private static function loadVisitScheduleConfig(): array
    {
        $db = DB::getInstance();
        $rawValue = '';

        try {
            $stmt = $db->prepare('SELECT setting_value FROM setting WHERE setting_name = ? LIMIT 1');
            if ($stmt && $stmt->execute([self::VISIT_SCHEDULE_SETTING])) {
                $row = $stmt->fetch(\PDO::FETCH_ASSOC);
                $rawValue = (string)($row['setting_value'] ?? '');
            }
        } catch (\Exception $e) {
            $rawValue = '';
        }

        if ($rawValue === '') {
            return ['schedules' => [], 'holidays' => []];
        }

        $decoded = @unserialize($rawValue);
        if (!is_array($decoded)) {
            $decoded = json_decode($rawValue, true);
        }

        if (!is_array($decoded)) {
            return ['schedules' => [], 'holidays' => []];
        }

        return self::normalizeVisitScheduleConfig($decoded);
    }

    /**
     * Normalize configured visit schedules/holidays structure.
     *
     * @param array $config
     * @return array
     */
    private static function normalizeVisitScheduleConfig(array $config): array
    {
        $normalizedSchedules = [];
        $rawSchedules = is_array($config['schedules'] ?? null) ? $config['schedules'] : [];

        foreach ($rawSchedules as $location => $locationSchedule) {
            $locationName = trim(strip_tags((string)$location));
            if ($locationName === '' || !is_array($locationSchedule)) {
                continue;
            }

            $normalizedDayMap = [];
            foreach (self::DAY_KEYS as $dayKey) {
                $dayConfig = is_array($locationSchedule[$dayKey] ?? null) ? $locationSchedule[$dayKey] : [];
                $openValue = $dayConfig['open'] ?? 0;
                $isOpen = ($openValue === 1 || $openValue === '1' || $openValue === true || $openValue === 'true' || $openValue === 'on');
                $openTime = self::normalizeTimeValue((string)($dayConfig['open_time'] ?? ''), '08:00');
                $closeTime = self::normalizeTimeValue((string)($dayConfig['close_time'] ?? ''), '16:00');

                $normalizedDayMap[$dayKey] = [
                    'open' => $isOpen ? 1 : 0,
                    'open_time' => $openTime,
                    'close_time' => $closeTime
                ];
            }

            $normalizedSchedules[$locationName] = $normalizedDayMap;
        }

        $normalizedHolidays = [];
        $seenHoliday = [];
        $rawHolidays = is_array($config['holidays'] ?? null) ? $config['holidays'] : [];

        foreach ($rawHolidays as $holidayRow) {
            if (!is_array($holidayRow)) {
                continue;
            }

            $startDate = trim((string)($holidayRow['start_date'] ?? ($holidayRow['date'] ?? '')));
            $endDate = trim((string)($holidayRow['end_date'] ?? ($holidayRow['date'] ?? '')));
            if (!self::isValidDate($startDate)) {
                continue;
            }
            if (!self::isValidDate($endDate)) {
                $endDate = $startDate;
            }
            if ($endDate < $startDate) {
                $temp = $startDate;
                $startDate = $endDate;
                $endDate = $temp;
            }

            $name = trim(strip_tags((string)($holidayRow['name'] ?? '')));
            $location = trim(strip_tags((string)($holidayRow['location'] ?? 'all')));
            if ($location === '') {
                $location = 'all';
            }

            $dedupeKey = $startDate . '|' . $endDate . '|' . $location . '|' . $name;
            if (isset($seenHoliday[$dedupeKey])) {
                continue;
            }
            $seenHoliday[$dedupeKey] = true;

            $normalizedHolidays[] = [
                'start_date' => $startDate,
                'end_date' => $endDate,
                'name' => $name,
                'location' => $location
            ];
        }

        return [
            'schedules' => $normalizedSchedules,
            'holidays' => $normalizedHolidays
        ];
    }

    /**
     * Normalize HH:MM value.
     *
     * @param string $value
     * @param string $fallback
     * @return string
     */
    private static function normalizeTimeValue(string $value, string $fallback): string
    {
        $value = trim($value);
        if (!preg_match('/^\d{2}:\d{2}$/', $value)) {
            return $fallback;
        }

        $hour = (int)substr($value, 0, 2);
        $minute = (int)substr($value, 3, 2);
        if ($hour < 0 || $hour > 23 || $minute < 0 || $minute > 59) {
            return $fallback;
        }

        return sprintf('%02d:%02d', $hour, $minute);
    }

    /**
     * Validate date with YYYY-MM-DD format.
     *
     * @param string $value
     * @return bool
     */
    private static function isValidDate(string $value): bool
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return false;
        }
        $dateObj = \DateTime::createFromFormat('Y-m-d', $value);
        return $dateObj && $dateObj->format('Y-m-d') === $value;
    }

    /**
     * Check if current time is inside opening window.
     * Supports overnight windows when close_time < open_time.
     *
     * @param string $currentTime
     * @param string $openTime
     * @param string $closeTime
     * @return bool
     */
    private static function isWithinTimeWindow(string $currentTime, string $openTime, string $closeTime): bool
    {
        if ($openTime === $closeTime) {
            return false;
        }

        $currentMinutes = ((int)substr($currentTime, 0, 2) * 60) + (int)substr($currentTime, 3, 2);
        $openMinutes = ((int)substr($openTime, 0, 2) * 60) + (int)substr($openTime, 3, 2);
        $closeMinutes = ((int)substr($closeTime, 0, 2) * 60) + (int)substr($closeTime, 3, 2);

        if ($closeMinutes > $openMinutes) {
            return $currentMinutes >= $openMinutes && $currentMinutes <= $closeMinutes;
        }

        return $currentMinutes >= $openMinutes || $currentMinutes <= $closeMinutes;
    }

    /**
     * Normalize text to max length and collapse spaces.
     *
     * @param string $text
     * @param int $maxLength
     * @return string|null
     */
    private static function sanitizeText(string $text, int $maxLength = 255): ?string
    {
        $text = strip_tags($text);
        $text = preg_replace('/\s+/u', ' ', trim($text));
        if ($text === '') {
            return null;
        }
        $length = function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
        if ($length > $maxLength) {
            $text = function_exists('mb_substr')
                ? mb_substr($text, 0, $maxLength, 'UTF-8')
                : substr($text, 0, $maxLength);
        }
        return $text;
    }

    /**
     * Normalize allowed option value.
     *
     * @param string $value
     * @param array $allowedOptions
     * @return string|null
     */
    private static function normalizeChoice(string $value, array $allowedOptions): ?string
    {
        $value = self::sanitizeText($value, 100);
        if ($value === null) {
            return null;
        }
        return in_array($value, $allowedOptions, true) ? $value : null;
    }

    /**
     * Normalize gender value to member-compatible format: 1=Male, 0=Female.
     * Keep backward compatibility for old textual values.
     *
     * @param string $value
     * @return string|null
     */
    private static function normalizeGender(string $value): ?string
    {
        $value = self::sanitizeText($value, 30);
        if ($value === null) {
            return null;
        }

        if (in_array($value, self::GENDERS, true)) {
            return $value;
        }

        $normalized = strtolower(str_replace('-', ' ', $value));
        $normalized = preg_replace('/\s+/u', ' ', trim($normalized));

        if (in_array($normalized, ['male', 'laki laki', 'laki', 'pria', 'm', '1'], true)) {
            return '1';
        }
        if (in_array($normalized, ['female', 'perempuan', 'wanita', 'f', '0'], true)) {
            return '0';
        }

        return null;
    }

    /**
     * Normalize phone number text.
     *
     * @param string $value
     * @param int $maxLength
     * @return string|null
     */
    private static function sanitizePhone(string $value, int $maxLength = 40): ?string
    {
        $value = preg_replace('/[^0-9+\-\s()]/', '', trim($value));
        if ($value === '') {
            return null;
        }
        if (strlen($value) > $maxLength) {
            $value = substr($value, 0, $maxLength);
        }
        return $value;
    }

    /**
     * Normalize email value. Returns "__INVALID_EMAIL__" when malformed.
     *
     * @param string $value
     * @param int $maxLength
     * @return string|null
     */
    private static function sanitizeEmail(string $value, int $maxLength = 120): ?string
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }
        if (strlen($value) > $maxLength) {
            $value = substr($value, 0, $maxLength);
        }
        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            return '__INVALID_EMAIL__';
        }
        return $value;
    }

    /**
     * Normalize numeric counter map from POST by key->label mapping.
     *
     * @param array $fieldMap
     * @return array
     */
    private static function sanitizeCounterMap(array $fieldMap): array
    {
        $result = [];
        foreach ($fieldMap as $fieldName => $label) {
            $count = (int)($_POST[$fieldName] ?? 0);
            if ($count > 0) {
                $result[$label] = $count;
            }
        }
        return $result;
    }

    /**
     * Encode counter map into JSON string.
     *
     * @param array $data
     * @return string|null
     */
    private static function encodeCounterMap(array $data): ?string
    {
        if (empty($data)) {
            return null;
        }

        $encoded = json_encode($data, JSON_UNESCAPED_UNICODE);
        return $encoded === false ? null : $encoded;
    }
}
