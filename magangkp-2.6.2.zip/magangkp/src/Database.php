<?php
/**
 * @Author: Faisal Fajar, Irsyad, Sena
 * @Date: 2026-02-27
 */

namespace MagangKp;

use SLiMS\DB;

/**
 * Class Database
 * 
 * Helper untuk menangani operasi basis data terkait plugin Magang KP.
 */
class Database
{
    /**
     * Menjalankan migrasi database yang diperlukan oleh plugin.
     * 
     * Saat ini bertugas mengecek kolom tambahan pada tabel 'visitor_count'
     * (room_code, visit_location, group_count, visitor_type, visitor_job, visitor_education,
     * visitor_gender, visitor_address, visitor_purpose, dan metadata rombongan)
     * lalu menambahkannya jika belum ada.
     * 
     * @return void
     */
    public static function migrate()
    {
        $db = DB::getInstance();
        try {
            // Ensure room_code exists for SLiMS native visitor insert query.
            $roomCodeColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'room_code'");
            $roomCodeExists = $roomCodeColumn && $roomCodeColumn->rowCount() > 0;

            if (!$roomCodeExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN room_code VARCHAR(20) NULL AFTER institution");
                $roomCodeExists = true;
            }

            // Ensure visit_location exists for selected location dropdown persistence.
            $visitLocationColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'visit_location'");
            $visitLocationExists = $visitLocationColumn && $visitLocationColumn->rowCount() > 0;

            if (!$visitLocationExists) {
                $afterColumn = $roomCodeExists ? 'room_code' : 'institution';
                $db->query("ALTER TABLE visitor_count ADD COLUMN visit_location VARCHAR(120) NULL AFTER {$afterColumn}");
                $visitLocationExists = true;
            }

            // Ensure group_count exists for plugin monitoring/reporting.
            $groupCountColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'group_count'");
            $groupCountExists = $groupCountColumn && $groupCountColumn->rowCount() > 0;

            if (!$groupCountExists) {
                $afterColumn = $visitLocationExists
                    ? 'visit_location'
                    : ($roomCodeExists ? 'room_code' : 'institution');
                $db->query("ALTER TABLE visitor_count ADD COLUMN group_count INT DEFAULT 1 AFTER {$afterColumn}");
                $groupCountExists = true;
            }

            // Ensure visitor_type exists for accurate monitoring split (member/non-member/rombongan).
            $visitorTypeColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'visitor_type'");
            $visitorTypeExists = $visitorTypeColumn && $visitorTypeColumn->rowCount() > 0;

            if (!$visitorTypeExists) {
                $afterColumn = $groupCountExists ? 'group_count' : ($roomCodeExists ? 'room_code' : 'institution');
                $db->query("ALTER TABLE visitor_count ADD COLUMN visitor_type VARCHAR(20) NULL AFTER {$afterColumn}");
            }

            // Ensure non-member detail columns exist.
            $jobColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'visitor_job'");
            $jobExists = $jobColumn && $jobColumn->rowCount() > 0;
            if (!$jobExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN visitor_job VARCHAR(100) NULL AFTER visitor_type");
            }

            $educationColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'visitor_education'");
            $educationExists = $educationColumn && $educationColumn->rowCount() > 0;
            if (!$educationExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN visitor_education VARCHAR(20) NULL AFTER visitor_job");
            }

            $genderColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'visitor_gender'");
            $genderExists = $genderColumn && $genderColumn->rowCount() > 0;
            if (!$genderExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN visitor_gender VARCHAR(20) NULL AFTER visitor_education");
            }

            $addressColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'visitor_address'");
            $addressExists = $addressColumn && $addressColumn->rowCount() > 0;
            if (!$addressExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN visitor_address TEXT NULL AFTER visitor_gender");
            }

            $purposeColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'visitor_purpose'");
            $purposeExists = $purposeColumn && $purposeColumn->rowCount() > 0;
            if (!$purposeExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN visitor_purpose VARCHAR(100) NULL AFTER visitor_address");
            }

            // Ensure rombongan detail columns exist.
            $groupLeaderPhoneColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'group_leader_phone'");
            $groupLeaderPhoneExists = $groupLeaderPhoneColumn && $groupLeaderPhoneColumn->rowCount() > 0;
            if (!$groupLeaderPhoneExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN group_leader_phone VARCHAR(40) NULL AFTER visitor_purpose");
            }

            $institutionAddressColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'institution_address'");
            $institutionAddressExists = $institutionAddressColumn && $institutionAddressColumn->rowCount() > 0;
            if (!$institutionAddressExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN institution_address TEXT NULL AFTER group_leader_phone");
            }

            $institutionPhoneColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'institution_phone'");
            $institutionPhoneExists = $institutionPhoneColumn && $institutionPhoneColumn->rowCount() > 0;
            if (!$institutionPhoneExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN institution_phone VARCHAR(40) NULL AFTER institution_address");
            }

            $institutionEmailColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'institution_email'");
            $institutionEmailExists = $institutionEmailColumn && $institutionEmailColumn->rowCount() > 0;
            if (!$institutionEmailExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN institution_email VARCHAR(120) NULL AFTER institution_phone");
            }

            $groupPurposeColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'group_purpose'");
            $groupPurposeExists = $groupPurposeColumn && $groupPurposeColumn->rowCount() > 0;
            if (!$groupPurposeExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN group_purpose VARCHAR(120) NULL AFTER institution_email");
            }

            $groupGenderMaleColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'group_gender_male'");
            $groupGenderMaleExists = $groupGenderMaleColumn && $groupGenderMaleColumn->rowCount() > 0;
            if (!$groupGenderMaleExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN group_gender_male INT DEFAULT NULL AFTER group_purpose");
            }

            $groupGenderFemaleColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'group_gender_female'");
            $groupGenderFemaleExists = $groupGenderFemaleColumn && $groupGenderFemaleColumn->rowCount() > 0;
            if (!$groupGenderFemaleExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN group_gender_female INT DEFAULT NULL AFTER group_gender_male");
            }

            $groupPersonCountColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'group_person_count'");
            $groupPersonCountExists = $groupPersonCountColumn && $groupPersonCountColumn->rowCount() > 0;
            if (!$groupPersonCountExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN group_person_count INT DEFAULT NULL AFTER group_gender_female");
            }

            $groupJobStatsColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'group_job_stats'");
            $groupJobStatsExists = $groupJobStatsColumn && $groupJobStatsColumn->rowCount() > 0;
            if (!$groupJobStatsExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN group_job_stats TEXT NULL AFTER group_person_count");
            }

            $groupEducationStatsColumn = $db->query("SHOW COLUMNS FROM visitor_count LIKE 'group_education_stats'");
            $groupEducationStatsExists = $groupEducationStatsColumn && $groupEducationStatsColumn->rowCount() > 0;
            if (!$groupEducationStatsExists) {
                $db->query("ALTER TABLE visitor_count ADD COLUMN group_education_stats TEXT NULL AFTER group_job_stats");
            }
        } catch (\Exception $e) {
            // Mengabaikan error jika tabel belum ada atau terjadi masalah koneksi saat inisialisasi
        }
    }
}
