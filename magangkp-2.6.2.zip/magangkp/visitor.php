<?php
/**
 * Magang KP Visitor Handler
 * Keep native visitor UI and add monitoring widget.
 */

use SLiMS\Visitor;
use SLiMS\Json;
use MagangKp\VisitorLogic;

if (!defined('INDEX_AUTH')) {
    die('Direct access not allowed!');
}

// Visitor feedback API (migrated dari updateterbaru agar URL tetap p=visitor)
$isVisitorFeedbackApi = isset($_REQUEST['visitor_feedback_api']) && (string) ($_REQUEST['visitor_feedback_api'] ?? '') === '1';
if ($isVisitorFeedbackApi) {
    require_once __DIR__ . '/updateterbaru/lib.php';

    if ($dbs instanceof mysqli) {
        updatefiturnewEnsureSchema($dbs);
    }

    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-cache, no-store, must-revalidate');

    $response = static function (array $payload): void {
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    };

    $action = strtolower(trim((string) ($_REQUEST['action'] ?? 'list')));
    $isPost = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST';

    if ($action === 'context') {
        $memberInput = trim((string) ($_REQUEST['member_input'] ?? ''));
        $institution = trim((string) ($_REQUEST['institution'] ?? ''));
        $roomCode = trim((string) ($_REQUEST['room_code'] ?? ''));
        $looksLikeMemberId = updatefiturnewLooksLikeMemberId($memberInput);
        $context = updatefiturnewFindLatestVisitorContext($dbs, $memberInput, $institution, $roomCode);

        if (!is_array($context)) {
            $memberLookup = $looksLikeMemberId
                ? updatefiturnewGetMemberFresh($dbs, $memberInput)
                : updatefiturnewGetMemberFreshByName($dbs, $memberInput);
            if ($memberLookup) {
                $context = [
                    'member_id' => (string) ($memberLookup['member_id'] ?? ''),
                    'member_name' => (string) ($memberLookup['member_name'] ?? $memberInput),
                    'institution' => (string) ($memberLookup['inst_name'] ?? ''),
                    'member_type_name' => (string) ($memberLookup['member_type_name'] ?? ''),
                    'visitor_kind' => 'anggota',
                    'room_code' => $roomCode,
                    'visit_location' => updatefiturnewResolveVisitorLocationLabel($dbs, $roomCode, ''),
                    'checkin_at' => updatefiturnewNow()
                ];
            } else {
                $context = [
                    'member_id' => $looksLikeMemberId ? '' : updatefiturnewFeedbackVisitorNameMarker(),
                    'member_name' => $memberInput !== '' ? $memberInput : 'Visitor',
                    'institution' => $institution,
                    'member_type_name' => '',
                    'visitor_kind' => updatefiturnewClassifyVisitorKind('', $memberInput, $institution),
                    'room_code' => $roomCode,
                    'visit_location' => updatefiturnewResolveVisitorLocationLabel($dbs, $roomCode, ''),
                    'checkin_at' => updatefiturnewNow()
                ];
            }
        }

        if (!$looksLikeMemberId && trim((string) ($context['member_id'] ?? '')) === '') {
            $context['member_id'] = updatefiturnewFeedbackVisitorNameMarker();
        }

        $response([
            'ok' => true,
            'context' => $context
        ]);
    }

    if ($action === 'submit') {
        if (!$isPost) {
            $response([
                'ok' => false,
                'message' => 'Metode submit harus POST.'
            ]);
        }

        $error = '';
        $created = updatefiturnewCreateVisitorFeedback($dbs, [
            'member_id' => (string) ($_POST['member_id'] ?? ''),
            'member_name' => (string) ($_POST['member_name'] ?? ''),
            'institution' => (string) ($_POST['institution'] ?? ''),
            'member_type_name' => (string) ($_POST['member_type_name'] ?? ''),
            'room_code' => (string) ($_POST['room_code'] ?? ''),
            'visit_location' => (string) ($_POST['visit_location'] ?? ''),
            'checkin_at' => (string) ($_POST['checkin_at'] ?? ''),
            'feedback_type' => (string) ($_POST['feedback_type'] ?? 'saran'),
            'feedback_text' => (string) ($_POST['feedback_text'] ?? ''),
            'created_ip' => (string) ip()
        ], $error);

        if (!$created) {
            $response([
                'ok' => false,
                'message' => $error !== '' ? $error : 'Gagal menyimpan kritik/saran.'
            ]);
        }

        $response([
            'ok' => true,
            'message' => 'Kritik/saran berhasil disimpan.',
            'feedback' => $created
        ]);
    }

    if ($action === 'list') {
        $limit = isset($_REQUEST['limit']) ? (int) $_REQUEST['limit'] : 60;
        $rows = updatefiturnewGetRecentVisitorFeedback($dbs, $limit);
        $response([
            'ok' => true,
            'rows' => $rows
        ]);
    }

    $response([
        'ok' => false,
        'message' => 'Aksi API tidak dikenali.'
    ]);
}

// Native SLiMS visitor flow.
$visitor = new Visitor($sysconf['allowed_counter_ip'], $sysconf['time_visitor_limitation'], $this);
$visitor->accessCheck();

if ($sysconf['enable_counter_by_ip'] && !$visitor->isAccessAllow()) {
    header('location: index.php');
    exit;
}

if (!function_exists('magangKpVisitorMonitoringToday')) {
    /**
     * Get visitor summary for today.
     */
    function magangKpVisitorMonitoringToday(mysqli $dbs): array
    {
        $todayStart = date('Y-m-d 00:00:00');
        $tomorrowStart = date('Y-m-d 00:00:00', strtotime('+1 day'));
        $hasGroupCount = false;
        $hasVisitorType = false;
        $hasVisitorPurpose = false;
        $hasGroupPurpose = false;

        if ($columnCheck = $dbs->query("SHOW COLUMNS FROM visitor_count LIKE 'group_count'")) {
            $hasGroupCount = $columnCheck->num_rows > 0;
            $columnCheck->free_result();
        }
        if ($columnCheck = $dbs->query("SHOW COLUMNS FROM visitor_count LIKE 'visitor_type'")) {
            $hasVisitorType = $columnCheck->num_rows > 0;
            $columnCheck->free_result();
        }
        if ($columnCheck = $dbs->query("SHOW COLUMNS FROM visitor_count LIKE 'visitor_purpose'")) {
            $hasVisitorPurpose = $columnCheck->num_rows > 0;
            $columnCheck->free_result();
        }
        if ($columnCheck = $dbs->query("SHOW COLUMNS FROM visitor_count LIKE 'group_purpose'")) {
            $hasGroupPurpose = $columnCheck->num_rows > 0;
            $columnCheck->free_result();
        }

        $counterWeightExpression = $hasGroupCount
            ? "CASE WHEN group_count IS NULL OR group_count < 1 THEN 1 ELSE group_count END"
            : "1";

        $totalExpression = $hasGroupCount
            ? "COALESCE(SUM({$counterWeightExpression}), 0)"
            : "COUNT(visitor_id)";

        $rombonganCondition = $hasVisitorType
            ? "(COALESCE(visitor_type, '') = 'rombongan' OR (COALESCE(visitor_type, '') = '' AND COALESCE(member_name, '') LIKE '%Rombongan%'))"
            : "(COALESCE(member_name, '') LIKE '%Rombongan%')";

        $monitoring = [
            'total' => 0,
            'member' => 0,
            'non_member' => 0,
            'rombongan' => 0,
            'last_checkin' => null,
            'recent_visitors' => []
        ];

        $summaryQuery = "
            SELECT
                {$totalExpression} AS total,
                SUM(CASE WHEN member_id IS NOT NULL AND member_id <> '' THEN {$counterWeightExpression} ELSE 0 END) AS member,
                SUM(CASE WHEN {$rombonganCondition} THEN {$counterWeightExpression} ELSE 0 END) AS rombongan,
                SUM(CASE WHEN (member_id IS NULL OR member_id = '') AND NOT {$rombonganCondition} THEN {$counterWeightExpression} ELSE 0 END) AS non_member,
                MAX(checkin_date) AS last_checkin
            FROM visitor_count
            WHERE checkin_date >= ? AND checkin_date < ?
        ";

        if ($statement = $dbs->prepare($summaryQuery)) {
            $statement->bind_param('ss', $todayStart, $tomorrowStart);
            $statement->execute();
            if ($result = $statement->get_result()) {
                if ($row = $result->fetch_assoc()) {
                    $monitoring['total'] = (int)($row['total'] ?? 0);
                    $monitoring['member'] = (int)($row['member'] ?? 0);
                    $monitoring['non_member'] = (int)($row['non_member'] ?? 0);
                    $monitoring['rombongan'] = (int)($row['rombongan'] ?? 0);
                    $monitoring['last_checkin'] = $row['last_checkin'] ?: null;
                }
            }
            $statement->close();
        }

        $purposeExpression = "'Belum diisi'";
        if ($hasVisitorPurpose && $hasGroupPurpose) {
            $purposeExpression = $hasVisitorType
                ? "CASE
                    WHEN COALESCE(visitor_type, '') = 'rombongan'
                        THEN COALESCE(NULLIF(TRIM(group_purpose), ''), NULLIF(TRIM(visitor_purpose), ''), 'Belum diisi')
                    ELSE COALESCE(NULLIF(TRIM(visitor_purpose), ''), 'Belum diisi')
                  END"
                : "CASE
                    WHEN {$rombonganCondition}
                        THEN COALESCE(NULLIF(TRIM(group_purpose), ''), NULLIF(TRIM(visitor_purpose), ''), 'Belum diisi')
                    ELSE COALESCE(NULLIF(TRIM(visitor_purpose), ''), 'Belum diisi')
                  END";
        } elseif ($hasVisitorPurpose) {
            $purposeExpression = "COALESCE(NULLIF(TRIM(visitor_purpose), ''), 'Belum diisi')";
        } elseif ($hasGroupPurpose) {
            $purposeExpression = "COALESCE(NULLIF(TRIM(group_purpose), ''), 'Belum diisi')";
        }

        $recentQuery = "
            SELECT
                COALESCE(NULLIF(TRIM(member_name), ''), NULLIF(TRIM(member_id), ''), 'Tanpa Nama') AS visitor_name,
                DATE_FORMAT(checkin_date, '%H:%i') AS visit_time,
                {$purposeExpression} AS visit_purpose
            FROM visitor_count
            WHERE checkin_date >= ? AND checkin_date < ?
            ORDER BY checkin_date DESC, visitor_id DESC
            LIMIT 12
        ";

        if ($recentStatement = $dbs->prepare($recentQuery)) {
            $recentStatement->bind_param('ss', $todayStart, $tomorrowStart);
            $recentStatement->execute();
            if ($recentResult = $recentStatement->get_result()) {
                while ($recentRow = $recentResult->fetch_assoc()) {
                    $monitoring['recent_visitors'][] = [
                        'name' => (string)($recentRow['visitor_name'] ?? ''),
                        'time' => (string)($recentRow['visit_time'] ?? ''),
                        'purpose' => (string)($recentRow['visit_purpose'] ?? 'Belum diisi')
                    ];
                }
            }
            $recentStatement->close();
        }

        return $monitoring;
    }
}

if (!function_exists('magangKpVisitorLocationOptions')) {
    /**
     * Read location labels from LokasiMaps setting for visitor dropdown.
     */
    function magangKpVisitorLocationOptions(mysqli $dbs, array $sysconf): array
    {
        $labels = [];

        if ($query = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='lokasimaps_locations' LIMIT 1")) {
            if ($row = $query->fetch_assoc()) {
                $stored = @unserialize($row['setting_value']);
                if (is_array($stored)) {
                    foreach ($stored as $locationRow) {
                        if (!is_array($locationRow)) {
                            continue;
                        }
                        $label = trim(strip_tags((string)($locationRow['label'] ?? '')));
                        if ($label === '') {
                            continue;
                        }
                        $labels[$label] = $label;
                    }
                }
            }
            $query->free_result();
        }

        if (count($labels) < 1) {
            $fallback = trim(strip_tags((string)($sysconf['library_name'] ?? 'Lokasi Utama')));
            if ($fallback !== '') {
                $labels[$fallback] = $fallback;
            }
        }

        return array_values($labels);
    }
}

if (isset($_GET['monitor']) && $_GET['monitor'] === 'today') {
    die(Json::stringify([
        'status' => true,
        'monitoring' => magangKpVisitorMonitoringToday($dbs)
    ])->withHeader());
}

if (isset($_GET['schedule']) && $_GET['schedule'] === 'status') {
    $visitLocation = trim((string)($_GET['visit_location'] ?? ''));
    die(Json::stringify([
        'status' => true,
        'window' => VisitorLogic::getVisitWindowStatus($visitLocation)
    ])->withHeader());
}

if (isset($_POST['counter'])) {
    // Keep plugin-provided feature logic (member/non-member/rombongan) from VisitorLogic.
    $result = VisitorLogic::handleSubmissionWithResult($visitor) ?? [
        'message' => __('Error while inserting counter data to database.'),
        'image' => 'person.png',
        'status' => false
    ];

    $result['monitoring'] = magangKpVisitorMonitoringToday($dbs);
    die(Json::stringify($result)->withHeader());
}

$monitoring = magangKpVisitorMonitoringToday($dbs);
$visitorLocationOptions = magangKpVisitorLocationOptions($dbs, $sysconf);
$initialVisitWindowStatus = VisitorLogic::getVisitWindowStatus(null);
$roomQuery = trim(isset($_GET['room']) ? '&room=' . simbio_security::xssFree($_GET['room']) : '');

ob_start();
require SB . $sysconf['template']['dir'] . '/' . $sysconf['template']['theme'] . '/visitor_template.php';
?>
<style>
  .s-visitor {
    --magangkp-surface: #ffffff;
    --magangkp-surface-soft: transparent;
    --magangkp-border: #b8c2d0;
    --magangkp-text: #111827;
    --magangkp-text-muted: #1f2937;
    --magangkp-caption-bg: transparent;
    --magangkp-caption-text: #ffffff;
    --magangkp-shadow: 0 8px 20px rgba(15, 23, 42, 0.14);
    --magangkp-control-radius: 999px;
    --magangkp-control-height: 52px;
    --magangkp-control-padding-x: 18px;
  }
  #login-page .s-footer,
  #login-page footer.s-footer,
  #login-page .s-footer-content {
    display: none !important;
  }
  #login-page .s-main {
    padding-bottom: 0 !important;
  }
  .s-visitor .magangkp-field {
    margin-bottom: 12px;
  }
  .s-visitor #memberID,
  .s-visitor #institution,
  .s-visitor #counter,
  .s-visitor .magangkp-field .form-control {
    font-size: 16px !important;
    font-weight: 500;
    line-height: 1.35;
  }
  .s-visitor #visitorCounterForm input.form-control,
  .s-visitor #visitorCounterForm select.form-control,
  .s-visitor #visitorCounterForm textarea.form-control {
    border-radius: var(--magangkp-control-radius) !important;
    min-height: var(--magangkp-control-height);
    height: var(--magangkp-control-height);
    padding: 0 var(--magangkp-control-padding-x);
  }
  .s-visitor #visitorCounterForm textarea.form-control {
    border-radius: 18px !important;
    min-height: 110px;
    height: auto;
    padding: 12px 14px;
  }
  .s-visitor .magangkp-field .form-control {
    background: var(--magangkp-surface);
    border: 1px solid var(--magangkp-border);
    color: var(--magangkp-text);
    box-shadow: var(--magangkp-shadow);
    border-radius: var(--magangkp-control-radius) !important;
    min-height: var(--magangkp-control-height);
    height: var(--magangkp-control-height);
    padding: 0 var(--magangkp-control-padding-x);
  }
  .s-visitor .magangkp-field select.form-control {
    padding-right: 38px;
  }
  .s-visitor #counter {
    border-radius: var(--magangkp-control-radius) !important;
    min-height: var(--magangkp-control-height);
    height: var(--magangkp-control-height);
    padding: 0 var(--magangkp-control-padding-x);
    box-shadow: var(--magangkp-shadow);
  }
  .s-visitor .magangkp-field textarea.form-control,
  .s-visitor .magangkp-field .magangkp-textarea.form-control {
    border-radius: 18px !important;
    min-height: 110px;
    height: auto;
    padding: 12px 14px;
  }
  .s-visitor .magangkp-field .form-control:focus {
    background: #ffffff;
    border-color: rgba(59, 130, 246, 0.68);
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
    color: var(--magangkp-text);
  }
  .s-visitor .magangkp-field .form-control::placeholder {
    color: var(--magangkp-text-muted);
    opacity: 0.9;
    font-weight: 500;
  }
  .s-visitor .magangkp-input-caption {
    display: inline-block;
    margin: 0 0 7px;
    padding: 4px 10px;
    border-radius: 999px;
    background: var(--magangkp-caption-bg);
    color: var(--magangkp-caption-text);
    font-size: 14px;
    font-weight: 700;
    letter-spacing: 0.3px;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.28);
  }
  .s-visitor .magangkp-group-fields .magangkp-input-caption,
  .s-visitor .magangkp-nonmember-fields .magangkp-input-caption,
  .s-visitor .magangkp-standard-purpose-field .magangkp-input-caption {
    background: transparent;
  }
  .s-visitor .magangkp-choice-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 9px 14px;
    margin-bottom: 8px;
    padding: 10px 12px;
    border-radius: 10px;
    border: 1px solid var(--magangkp-border);
    background: transparent;
  }
  .s-visitor .magangkp-choice-item {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    margin: 0;
    color: var(--magangkp-text);
    font-size: 15px;
    font-weight: 600;
    line-height: 1.25;
  }
  .s-visitor .magangkp-choice-item input[type=radio] {
    margin: 0;
    width: 16px;
    height: 16px;
  }
  .s-visitor .magangkp-group-section {
    margin-bottom: 10px;
  }
  .s-visitor .magangkp-counter-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
    gap: 8px 12px;
    padding: 10px 12px;
    border-radius: 10px;
    border: 1px solid var(--magangkp-border);
    background: transparent;
  }
  .s-visitor .magangkp-counter-item {
    display: flex;
    align-items: center;
    gap: 9px;
    color: var(--magangkp-text);
    font-size: 15px;
    font-weight: 600;
  }
  .s-visitor .magangkp-counter-item input[type=number] {
    width: 72px;
    height: 40px;
    padding: 5px 8px;
    font-size: 16px;
    font-weight: 600;
    border: 1px solid var(--magangkp-border);
    border-radius: 12px;
    background: var(--magangkp-surface);
    color: var(--magangkp-text);
  }
  .s-visitor .magangkp-group-required::after {
    content: ' *';
    color: #dc2626;
    font-weight: 800;
  }
  .s-visitor .magangkp-group-person-count input {
    text-align: center;
    font-weight: 600;
  }
  .s-visitor .magangkp-textarea {
    min-height: 100px;
    resize: vertical;
  }
  .s-visitor .magangkp-submit-field {
    margin-top: 10px;
  }
  .s-visitor#visitor-counter {
    min-height: 100vh !important;
    height: auto !important;
    align-items: stretch !important;
  }
  .s-visitor#visitor-counter > .bg-white {
    min-height: 100vh;
    height: auto !important;
    padding-bottom: 28px;
  }
  .s-visitor#visitor-counter #visitorCounterForm .form-control,
  .s-visitor#visitor-counter #visitorCounterForm input[type=text],
  .s-visitor#visitor-counter #visitorCounterForm input[type=email],
  .s-visitor#visitor-counter #visitorCounterForm input[type=number],
  .s-visitor#visitor-counter #visitorCounterForm select,
  .s-visitor#visitor-counter #visitorCounterForm textarea {
    color: #111827 !important;
    -webkit-text-fill-color: #111827;
  }
  .s-visitor#visitor-counter #visitorCounterForm input[type=text]::placeholder,
  .s-visitor#visitor-counter #visitorCounterForm input[type=email]::placeholder,
  .s-visitor#visitor-counter #visitorCounterForm input[type=number]::placeholder,
  .s-visitor#visitor-counter #visitorCounterForm textarea::placeholder {
    color: #334155 !important;
    opacity: 1;
  }
  .s-visitor#visitor-counter .magangkp-input-caption {
    color: #0f172a !important;
    text-shadow: none !important;
  }
  .s-visitor .s-visitor-monitor {
    margin-top: 16px;
    border: 1px solid rgba(255, 255, 255, 0.34);
    border-radius: 12px;
    padding: 14px;
    background: rgba(15, 23, 42, 0.38);
    color: #111827;
    box-shadow: 0 10px 24px rgba(2, 6, 23, 0.26);
    direction: ltr;
    text-align: left;
  }
  .s-visitor .s-visitor-monitor-title {
    font-size: 15px;
    font-weight: 800;
    margin-bottom: 10px;
    text-align: center;
  }
  .s-visitor .s-visitor-monitor-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 9px;
  }
  .s-visitor .s-visitor-monitor-item {
    min-width: 0;
    border: 1px solid rgba(255, 255, 255, 0.26);
    border-radius: 8px;
    padding: 10px;
    text-align: center;
    background: rgba(255, 255, 255, 0.14);
  }
  .s-visitor .s-visitor-monitor-label {
    display: block;
    font-size: 12px;
    font-weight: 700;
    opacity: 0.95;
    color: #111827;
  }
  .s-visitor .s-visitor-monitor-value {
    display: block;
    font-size: 28px;
    font-weight: 800;
    line-height: 1.1;
    color: #111827;
  }
  .s-visitor .s-visitor-monitor-foot {
    margin-top: 10px;
    font-size: 14px;
    font-weight: 600;
    color: #111827;
  }
  .s-visitor .s-visitor-monitor-list {
    margin-top: 12px;
  }
  .s-visitor .s-visitor-monitor-list-title {
    font-size: 14px;
    font-weight: 800;
    margin-bottom: 8px;
  }
  .s-visitor .s-visitor-monitor-list-items {
    list-style: none;
    margin: 0;
    padding: 0;
    max-height: 260px;
    overflow-y: auto;
  }
  .s-visitor .s-visitor-monitor-list-item {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 10px;
    padding: 9px;
    border: 1px solid rgba(255, 255, 255, 0.22);
    border-radius: 8px;
    margin-bottom: 7px;
    background: rgba(255, 255, 255, 0.12);
    align-items: start;
  }
  .s-visitor .s-visitor-monitor-list-main {
    min-width: 0;
    text-align: left;
  }
  .s-visitor .s-visitor-monitor-list-name {
    display: block;
    color: #111827;
    font-size: 14px;
    font-weight: 800;
    word-break: break-word;
  }
  .s-visitor .s-visitor-monitor-list-purpose {
    display: block;
    color: #1f2937;
    font-size: 13px;
    font-weight: 600;
    opacity: 1;
    word-break: break-word;
  }
  .s-visitor .s-visitor-monitor-list-time {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 56px;
    padding: 3px 8px;
    border-radius: 999px;
    border: 1px solid rgba(15, 23, 42, 0.16);
    background: rgba(255, 255, 255, 0.42);
    color: #111827;
    font-size: 13px;
    font-weight: 700;
    white-space: nowrap;
    opacity: 1;
    line-height: 1.2;
  }
  .s-visitor .s-visitor-monitor-empty {
    padding: 10px;
    border: 1px dashed rgba(255, 255, 255, 0.34);
    border-radius: 8px;
    text-align: center;
    color: #111827;
    font-size: 13px;
    font-weight: 600;
    opacity: 1;
  }
  .s-visitor .magangkp-visit-window {
    margin-bottom: 12px;
    padding: 10px 12px;
    border-radius: 10px;
    border: 1px solid rgba(255, 255, 255, 0.25);
    background: rgba(15, 23, 42, 0.35);
    color: #f8fafc;
    font-size: 14px;
    font-weight: 600;
  }
  .s-visitor .magangkp-visit-window.is-open {
    border-color: rgba(34, 197, 94, 0.7);
    background: rgba(240, 253, 244, 0.78);
    color: #15803d !important;
    font-weight: 700;
    text-shadow: none;
  }
  .s-visitor .magangkp-visit-window.is-closed {
    border-color: rgba(248, 113, 113, 0.7);
    background: rgba(254, 242, 242, 0.82);
    color: #dc2626 !important;
    font-weight: 700;
    text-shadow: none;
  }
  .s-visitor .magangkp-visit-alert {
    display: none;
    margin-bottom: 12px;
    padding: 11px 13px;
    border-radius: 10px;
    border: 1px solid #ef4444;
    background: rgba(127, 29, 29, 0.78);
    color: #fee2e2;
    font-size: 14px;
    font-weight: 700;
    letter-spacing: 0.1px;
  }
  .s-visitor .magangkp-visit-alert strong {
    font-weight: 800;
  }
  @media (max-width: 767px) {
    .s-visitor #memberID,
    .s-visitor #institution,
    .s-visitor #counter,
    .s-visitor .magangkp-field .form-control {
      font-size: 15px !important;
    }
    .s-visitor .magangkp-choice-item,
    .s-visitor .magangkp-counter-item {
      font-size: 13px;
    }
    .s-visitor .s-visitor-monitor-value {
      font-size: 24px;
    }
    .s-visitor .s-visitor-monitor-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    .s-visitor .s-visitor-monitor-list-item {
      grid-template-columns: 1fr;
      gap: 7px;
    }
    .s-visitor .s-visitor-monitor-list-time {
      justify-self: flex-start;
    }
  }
  .magangkp-success-toast {
    position: fixed;
    top: 24px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 9999;
    min-width: 280px;
    max-width: calc(100vw - 40px);
    padding: 10px 16px;
    border-radius: 999px;
    color: #fff;
    background: rgba(40, 167, 69, 0.95);
    box-shadow: 0 8px 18px rgba(0, 0, 0, 0.2);
    text-align: center;
    font-weight: 600;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.25s ease;
  }
  .magangkp-success-toast.is-error {
    background: rgba(220, 53, 69, 0.95);
  }
  .magangkp-success-toast.is-show {
    opacity: 1;
  }
</style>
<script>
$(document).ready(function() {
  var successText = '<?php echo __('Welcome to our library.') ?>';
  var errorText = '<?php echo __('Error while inserting counter data to database.') ?>';
  var institutionRequiredText = '<?php echo __('Sorry, Please fill institution field if you are not library member') ?>';
  var visitorNameAlphaOnlyText = 'Nama pengunjung/ketua rombongan hanya boleh huruf dan spasi';
  var institutionAlphaOnlyText = 'Institution hanya boleh huruf dan spasi';
  var locationRequiredText = 'Pilih lokasi kunjungan terlebih dahulu';
  var purposeRequiredText = 'Pilih tujuan kunjungan terlebih dahulu';
  var genderRequiredText = 'Pilih jenis kelamin terlebih dahulu';
  var groupTotalRequiredText = 'Jumlah rombongan minimal 1 orang';
  var groupPhoneRequiredText = 'Nomor telepon ketua rombongan wajib diisi';
  var groupAddressRequiredText = 'Alamat instansi lembaga wajib diisi';
  var groupEmailInvalidText = 'Format email instansi tidak valid';
  var groupJobTotalInvalidText = 'Total rincian pekerjaan rombongan harus sama dengan jumlah personil';
  var groupEducationTotalInvalidText = 'Total rincian pendidikan tidak boleh melebihi jumlah rombongan';
  var defaultMemberHint = <?php echo json_encode(__('Member ID / Visitor Name')); ?>;
  var nonMemberNameHint = 'Nama Pengunjung';
  var institutionHint = <?php echo json_encode(__('Institution')); ?>;
  var groupInstitutionHint = 'Nama Instansi Lembaga';
  var groupLeaderHint = 'Nama Ketua Rombongan';
  var groupLeaderPhoneHint = 'Nomor Telepon Ketua Rombongan';
  var groupInstitutionAddressHint = 'Alamat Instansi Lembaga';
  var groupInstitutionPhoneHint = 'Nomor Telepon Instansi Lembaga';
  var groupInstitutionEmailHint = 'Alamat Email Instansi Lembaga';
  var maleGenderText = <?php echo json_encode(__('Male')); ?>;
  var femaleGenderText = <?php echo json_encode(__('Female')); ?>;
  var maleCountHint = 'Jumlah Laki-laki';
  var femaleCountHint = 'Jumlah Perempuan';
  var defaultCounterInfoText = <?php echo json_encode(__('Please insert your library member ID otherwise your full name instead')); ?>;
  var monitorUrl = 'index.php?p=visitor<?php echo $roomQuery; ?>&monitor=today';
  var scheduleStatusUrl = 'index.php?p=visitor<?php echo $roomQuery; ?>&schedule=status';
  var postUrl = 'index.php?p=visitor<?php echo $roomQuery; ?>';
  var feedbackApiBaseUrl = 'index.php?p=visitor&visitor_feedback_api=1';
  var initialMonitoring = <?php echo json_encode($monitoring); ?>;
  var initialVisitWindowStatus = <?php echo json_encode($initialVisitWindowStatus, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
  var visitorLocationOptions = <?php echo json_encode($visitorLocationOptions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '[]'; ?>;
  var defaultAddButtonText = <?php echo json_encode(__('Add')); ?>;
  var feedbackSendButtonText = 'Kirim Kritik/Saran';
  var feedbackTypeRequiredText = 'Pilih jenis masukan: Kritik atau Saran';
  var feedbackTextRequiredText = 'Isi kritik/saran tidak boleh kosong';
  var feedbackSuccessText = 'Kritik/saran berhasil dikirim';
  var successToastMessage = 'Selamat, data pengunjung berhasil ditambahkan';
  var errorToastMessage = 'Data belum tersimpan, cek form lalu coba lagi';
  var visitClosedText = 'Layanan visitor sedang tutup untuk lokasi ini';
  var visitNeedLocationText = 'Pilih lokasi kunjungan untuk cek jam layanan';
  var visitCheckText = 'Memeriksa jam layanan lokasi...';
  var visitWarningPrefix = 'Peringatan';
  var visitWarningDefault = 'Layanan visitor sedang tutup atau libur.';
  var successToastTimer = null;
  var visitWindowAllowed = true;
  var visitWindowReason = '';
  var visitWindowTimer = null;
  var visitWindowRequestSeq = 0;

  function formatNumber(num) {
    return new Intl.NumberFormat('id-ID').format(parseInt(num || 0, 10));
  }

  function getVisitorShell() {
    var shell = $('.s-visitor').first();
    if (shell.length) return shell;

    shell = $('#visitor-counter').first();
    if (shell.length) {
      shell.addClass('s-visitor');
    }
    return shell;
  }

  function ensureFieldColumn(fieldNode, className) {
    if (!fieldNode || fieldNode.length < 1) return $();

    var colNode = fieldNode.closest('.col-lg-12, .col-lg-6, .col-md-12, .col-md-6, .col-sm-12, .col-sm-6, .col-xs-12');
    if (colNode.length) return colNode.first();

    var groupNode = fieldNode.closest('.form-group');
    if (groupNode.length < 1) {
      if (!fieldNode.is('input,textarea,select,button')) return $();
      fieldNode.wrap('<div class="form-group"></div>');
      groupNode = fieldNode.closest('.form-group');
    }

    groupNode.wrap('<div class="' + className + '"></div>');
    return groupNode.parent();
  }

  function normalizeVisitorFormForTheme() {
    var shell = getVisitorShell();
    var formNode = $('#visitorCounterForm').first();

    if (formNode.length < 1 && shell.length) {
      formNode = shell.find('form').first();
    }
    if (formNode.length < 1) return formNode;

    if (formNode.closest('#visitor-counter').length) {
      var vueRoot = document.getElementById('visitor-counter');
      if (vueRoot && vueRoot.__vue__ && typeof vueRoot.__vue__.$destroy === 'function') {
        try {
          vueRoot.__vue__.$destroy();
        } catch (err) {}
      }

      formNode.each(function() {
        this.removeAttribute('@submit.prevent');
        this.removeAttribute('v-on:submit.prevent');
      });

      formNode.find('input,textarea,select,button').each(function() {
        this.removeAttribute('v-model');
        this.removeAttribute('ref');
      });

      var clonedForm = formNode.clone(false);
      formNode.replaceWith(clonedForm);
      formNode = clonedForm;
    }

    formNode.attr('id', 'visitorCounterForm');
    formNode.attr('name', 'visitorCounterForm');
    formNode.attr('method', 'post');
    formNode.attr('action', postUrl);

    var memberInput = formNode.find('#memberID, input[name=memberID]').first();
    if (memberInput.length < 1) {
      memberInput = formNode.find('input[type=text], input[type=search]').first();
    }
    if (memberInput.length) {
      memberInput.attr({'id': 'memberID', 'name': 'memberID'});
      memberInput.addClass('form-control input-lg');
    }

    var institutionInput = formNode.find('#institution, input[name=institution]').first();
    if (institutionInput.length < 1) {
      institutionInput = formNode.find('input[type=text], input[type=search]').not(memberInput).first();
    }
    if (institutionInput.length) {
      institutionInput.attr({'id': 'institution', 'name': 'institution'});
      institutionInput.addClass('form-control input-lg');
    }

    var submitControl = formNode.find('#counter').first();
    if (submitControl.length < 1) {
      submitControl = formNode.find('input[type=submit], button[type=submit], button:not([type])').first();
    }
    if (submitControl.length < 1) {
      submitControl = $('<input type="submit" value="<?php echo __('Add'); ?>" />');
      formNode.append(submitControl);
    }

    submitControl.attr('id', 'counter').attr('name', 'counter').addClass('form-control input-lg');
    if (!submitControl.is('input')) {
      submitControl.attr('type', 'submit');
    }

    if (formNode.find('.row').length < 1) {
      var rowNode = $('<div class="row"></div>');
      var memberCol = ensureFieldColumn(memberInput, 'col-lg-6 col-sm-6 col-xs-12');
      var institutionCol = ensureFieldColumn(institutionInput, 'col-lg-6 col-sm-6 col-xs-12');
      var submitCol = ensureFieldColumn(submitControl, 'col-lg-12 col-sm-12 col-xs-12');

      if (memberCol.length) rowNode.append(memberCol);
      if (institutionCol.length && (!memberCol.length || institutionCol[0] !== memberCol[0])) {
        rowNode.append(institutionCol);
      }
      if (submitCol.length
        && (!memberCol.length || submitCol[0] !== memberCol[0])
        && (!institutionCol.length || submitCol[0] !== institutionCol[0])) {
        rowNode.append(submitCol);
      }

      if (rowNode.children().length) {
        formNode.empty().append(rowNode);
      }
    }

    return formNode;
  }

  function ensureCounterInfoBox() {
    var infoNode = $('#counterInfo').first();
    if (infoNode.length) return infoNode;

    infoNode = $('<div id="counterInfo" class="info"></div>').text(defaultCounterInfoText);
    var formNode = $('#visitorCounterForm').first();
    if (formNode.length) {
      formNode.before(infoNode);
    } else {
      var shell = getVisitorShell();
      if (shell.length) shell.prepend(infoNode);
    }
    return $('#counterInfo').first();
  }

  function ensureVisitWindowNode() {
    var statusNode = $('#magangkpVisitWindow').first();
    if (statusNode.length) return statusNode;

    statusNode = $('<div id="magangkpVisitWindow" class="magangkp-visit-window"></div>').text(visitNeedLocationText);
    var locationField = visitorCounterForm.find('.magangkp-location-field').first();
    if (locationField.length) {
      locationField.after(statusNode);
    } else {
      var formNode = $('#visitorCounterForm').first();
      if (formNode.length) {
        formNode.prepend(statusNode);
      }
    }
    return $('#magangkpVisitWindow').first();
  }

  function ensureVisitAlertNode() {
    var alertNode = $('#magangkpVisitAlert').first();
    if (alertNode.length) return alertNode;

    alertNode = $('<div id="magangkpVisitAlert" class="magangkp-visit-alert"></div>');
    var statusNode = ensureVisitWindowNode();
    if (statusNode.length) {
      statusNode.before(alertNode);
    } else {
      var formNode = $('#visitorCounterForm').first();
      if (formNode.length) {
        formNode.prepend(alertNode);
      }
    }
    return $('#magangkpVisitAlert').first();
  }

  function setVisitWindowState(allowed, message, mode) {
    visitWindowAllowed = !!allowed;
    visitWindowReason = $.trim(String(message || ''));

    if (!visitWindowAllowed && visitWindowReason === '') {
      visitWindowReason = visitClosedText;
    }

    var submitButton = visitorCounterForm.find('#counter').first();
    if (submitButton.length) {
      submitButton.prop('disabled', !visitWindowAllowed);
    }

    var statusNode = ensureVisitWindowNode();
    if (statusNode.length) {
      statusNode.removeClass('is-open is-closed');
      if (mode === 'checking') {
        statusNode.text(visitCheckText);
      } else if (mode === 'idle') {
        statusNode.text(visitWindowReason || visitNeedLocationText);
      } else if (visitWindowAllowed) {
        statusNode.addClass('is-open');
        statusNode.text(visitWindowReason || 'Layanan visitor sedang buka');
      } else {
        statusNode.addClass('is-closed');
        var warningText = visitWindowReason || visitWarningDefault;
        statusNode.text(visitWarningPrefix + ': ' + warningText);
      }
    }

    var alertNode = $('#magangkpVisitAlert').first();
    if (alertNode.length) {
      alertNode.hide().empty();
    }
  }

  function applyVisitWindowStatus(windowData) {
    if (!windowData || typeof windowData !== 'object') {
      setVisitWindowState(true, '', 'open');
      return;
    }

    var allowed = !!windowData.allowed;
    var reason = $.trim(String(windowData.reason || ''));
    if (reason === '' && allowed && windowData.open_time && windowData.close_time) {
      reason = 'Layanan buka ' + (windowData.day_label || '') + ': ' + windowData.open_time + ' - ' + windowData.close_time;
    }

    setVisitWindowState(allowed, reason, allowed ? 'open' : 'closed');
  }

  function refreshVisitWindowStatus(silent) {
    var selectedLocation = $.trim($('#visitLocation').val() || '');
    if (selectedLocation === '') {
      setVisitWindowState(false, visitNeedLocationText, 'idle');
      return;
    }

    if (!silent) {
      setVisitWindowState(false, visitCheckText, 'checking');
    }

    visitWindowRequestSeq += 1;
    var requestId = visitWindowRequestSeq;

    $.ajax({
      url: scheduleStatusUrl + '&visit_location=' + encodeURIComponent(selectedLocation) + '&_=' + new Date().getTime(),
      type: 'GET',
      cache: false,
      success: function(respond) {
        if (requestId !== visitWindowRequestSeq) return;
        if (respond && respond.window) {
          applyVisitWindowStatus(respond.window);
          return;
        }
        setVisitWindowState(true, '', 'open');
      },
      error: function() {
        if (requestId !== visitWindowRequestSeq) return;
        setVisitWindowState(true, '', 'open');
      }
    });
  }

  function ensureMonitoringWidget() {
    if ($('#vmTotal').length > 0) return;

    var panelHtml = ''
      + '<div class="s-visitor-monitor" id="magangKpMonitor">'
      + '  <div class="s-visitor-monitor-title"><?php echo __('Information') . ' - ' . __('Today Visitor Monitoring'); ?></div>'
      + '  <div class="s-visitor-monitor-grid">'
      + '    <div class="s-visitor-monitor-item"><span class="s-visitor-monitor-label"><?php echo __('Total'); ?></span><span class="s-visitor-monitor-value" id="vmTotal">0</span></div>'
      + '    <div class="s-visitor-monitor-item"><span class="s-visitor-monitor-label"><?php echo __('Member'); ?></span><span class="s-visitor-monitor-value" id="vmMember">0</span></div>'
      + '    <div class="s-visitor-monitor-item"><span class="s-visitor-monitor-label"><?php echo __('Non Member'); ?></span><span class="s-visitor-monitor-value" id="vmNonMember">0</span></div>'
      + '    <div class="s-visitor-monitor-item"><span class="s-visitor-monitor-label">Rombongan</span><span class="s-visitor-monitor-value" id="vmRombongan">0</span></div>'
      + '  </div>'
      + '  <div class="s-visitor-monitor-foot"><?php echo __('Last Check In'); ?>: <span id="vmLastCheckin">-</span></div>'
      + '  <div class="s-visitor-monitor-list">'
      + '    <div class="s-visitor-monitor-list-title">Daftar Kunjungan Hari Ini</div>'
      + '    <ul class="s-visitor-monitor-list-items" id="vmRecentList">'
      + '      <li class="s-visitor-monitor-empty">Belum ada kunjungan hari ini</li>'
      + '    </ul>'
      + '  </div>'
      + '</div>';

    var formContainer = $('#visitorCounterForm').first();
    if (formContainer.length) {
      formContainer.after(panelHtml);
      return;
    }

    var fallbackContainer = getVisitorShell();
    if (fallbackContainer.length) {
      fallbackContainer.append(panelHtml);
    }
  }

  function updateMonitoring(monitoring) {
    if (!monitoring || $('#vmTotal').length < 1) return;
    $('#vmTotal').text(formatNumber(monitoring.total));
    $('#vmMember').text(formatNumber(monitoring.member));
    $('#vmNonMember').text(formatNumber(monitoring.non_member));
    $('#vmRombongan').text(formatNumber(monitoring.rombongan));
    $('#vmLastCheckin').text(monitoring.last_checkin ? monitoring.last_checkin : '-');
    renderRecentVisitors(monitoring.recent_visitors);
  }

  function renderRecentVisitors(visitors) {
    var listNode = $('#vmRecentList');
    if (listNode.length < 1) return;

    if (!Array.isArray(visitors) || visitors.length < 1) {
      listNode.html('<li class="s-visitor-monitor-empty">Belum ada kunjungan hari ini</li>');
      return;
    }

    var html = '';
    visitors.forEach(function(item) {
      var name = $('<div/>').text((item && item.name) ? item.name : 'Tanpa Nama').html();
      var time = $('<div/>').text((item && item.time) ? item.time : '-').html();
      var purpose = $('<div/>').text((item && item.purpose) ? item.purpose : 'Belum diisi').html();
      html += ''
        + '<li class="s-visitor-monitor-list-item">'
        + '  <div class="s-visitor-monitor-list-main">'
        + '    <span class="s-visitor-monitor-list-name">' + name + '</span>'
        + '    <span class="s-visitor-monitor-list-purpose">Tujuan: ' + purpose + '</span>'
        + '  </div>'
        + '  <span class="s-visitor-monitor-list-time">' + time + '</span>'
        + '</li>';
    });

    listNode.html(html);
  }

  function fetchMonitoring() {
    $.ajax({
      url: monitorUrl + '&_=' + new Date().getTime(),
      type: 'GET',
      cache: false,
      success: function(respond) {
        if (respond && respond.monitoring) updateMonitoring(respond.monitoring);
      }
    });
  }

  function ensureSuccessToast() {
    if ($('#magangkpSuccessToast').length > 0) return;
    $('body').append('<div id="magangkpSuccessToast" class="magangkp-success-toast"><span class="magangkp-success-toast-text"></span></div>');
  }

  function showActionToast(message, type) {
    ensureSuccessToast();
    var toast = $('#magangkpSuccessToast');
    toast.removeClass('is-error');
    if (type === 'error') {
      toast.addClass('is-error');
    }
    toast.find('.magangkp-success-toast-text').text(message || successToastMessage);
    if (successToastTimer) clearTimeout(successToastTimer);
    toast.addClass('is-show');
    successToastTimer = setTimeout(function() {
      toast.removeClass('is-show');
    }, type === 'error' ? 2800 : 2200);
  }

  function showFormError(message, focusSelector) {
    $('#counterInfo').html(message);
    showActionToast(message || errorToastMessage, 'error');
    if (focusSelector) {
      $(focusSelector).focus();
    }
    return false;
  }

  var visitorCounterForm = normalizeVisitorFormForTheme();
  ensureCounterInfoBox();
  ensureVisitWindowNode();
  ensureMonitoringWidget();
  ensureSuccessToast();
  applyVisitWindowStatus(initialVisitWindowStatus);
  updateMonitoring(initialMonitoring);
  fetchMonitoring();
  setInterval(fetchMonitoring, 30000);

  if (visitorCounterForm.length < 1) return;

  function parseCounterValue(rawValue) {
    var parsed = parseInt(rawValue || '0', 10);
    return (isNaN(parsed) || parsed < 0) ? 0 : parsed;
  }

  function sanitizeLettersOnly(value) {
    var cleaned = value || '';
    try {
      cleaned = cleaned.replace(/[^\p{L}\s]/gu, '');
    } catch (err) {
      cleaned = cleaned.replace(/[^A-Za-z\s]/g, '');
    }
    return cleaned;
  }

  function isLettersOnly(value) {
    var trimmed = $.trim(value || '');
    if (!trimmed) return false;
    try {
      return /^[\p{L}\s]+$/u.test(trimmed);
    } catch (err) {
      return /^[A-Za-z\s]+$/.test(trimmed);
    }
  }

  function buildVisitorLocationOptionsHtml() {
    var html = '<option value="">Pilih Lokasi Kunjungan</option>';
    if (!Array.isArray(visitorLocationOptions)) return html;

    visitorLocationOptions.forEach(function(optionLabel) {
      var label = $.trim(String(optionLabel || ''));
      if (!label) return;
      var escaped = $('<div/>').text(label).html();
      html += '<option value="' + escaped + '">' + escaped + '</option>';
    });

    return html;
  }

  function sumCounterInputs(selector) {
    var total = 0;
    visitorCounterForm.find(selector).each(function() {
      total += parseCounterValue($(this).val());
    });
    return total;
  }

  function updateGroupPersonCount() {
    var male = parseCounterValue($('#maleCount').val());
    var female = parseCounterValue($('#femaleCount').val());
    var total = male + female;
    $('#groupPersonCount').val(total > 0 ? total : '');
    return total;
  }

  function isEmailValid(value) {
    if (!value) return true;
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function resetGroupFields() {
    $('#groupLeaderPhone').val('');
    $('#groupInstitutionPhone').val('');
    $('#groupInstitutionEmail').val('');
    $('#groupInstitutionAddress').val('');
    $('#groupPurpose').val('');
    $('#maleCount').val('');
    $('#femaleCount').val('');
    $('#groupPersonCount').val('');
    visitorCounterForm.find('input[name^=groupJob], input[name^=groupEdu]').val('');
  }

  function resetFeedbackFields() {
    visitorCounterForm.find('input[name=feedbackType][value=saran]').prop('checked', true);
    visitorCounterForm.find('input[name=feedbackType][value=kritik]').prop('checked', false);
    $('#feedbackText').val('');
  }

  function submitVisitorFeedback(memberInput, visitLocation, feedbackType, feedbackText) {
    var deferred = $.Deferred();
    var contextUrl = feedbackApiBaseUrl + '&action=context';
    var submitUrl = feedbackApiBaseUrl + '&action=submit';

    var submitPayload = function(contextData) {
      var context = (contextData && typeof contextData === 'object') ? contextData : {};
      var payload = {
        member_id: $.trim(String(context.member_id || '')),
        member_name: $.trim(String(context.member_name || '')) || memberInput,
        institution: $.trim(String(context.institution || '')),
        member_type_name: $.trim(String(context.member_type_name || '')),
        room_code: $.trim(String(context.room_code || '')),
        visit_location: visitLocation,
        checkin_at: $.trim(String(context.checkin_at || '')),
        feedback_type: feedbackType,
        feedback_text: feedbackText
      };

      if (payload.member_id === '' && /^[A-Za-z0-9._-]{3,20}$/.test(memberInput)) {
        payload.member_id = memberInput;
      }
      if (payload.member_name === '') {
        payload.member_name = memberInput;
      }

      $.ajax({
        url: submitUrl,
        type: 'POST',
        dataType: 'json',
        cache: false,
        data: payload
      }).done(function(saveResponse) {
        deferred.resolve(saveResponse);
      }).fail(function(xhr) {
        deferred.reject(xhr);
      });
    };

    $.ajax({
      url: contextUrl,
      type: 'POST',
      dataType: 'json',
      cache: false,
      data: {
        member_input: memberInput,
        institution: '',
        room_code: ''
      }
    }).done(function(contextResponse) {
      var context = (contextResponse && contextResponse.context) ? contextResponse.context : {};
      submitPayload(context);
    }).fail(function() {
      submitPayload({});
    });

    return deferred.promise();
  }

  function ensureSubmitButtonAtBottom() {
    var submitControl = visitorCounterForm.find('#counter').first();
    if (submitControl.length < 1) return;

    var formRow = visitorCounterForm.find('.row').first();
    if (!formRow.length) return;

    var submitCol = submitControl.closest('.col-lg-12, .col-lg-6, .col-md-12, .col-md-6, .col-sm-12, .col-sm-6, .col-xs-12');
    if (submitCol.length < 1) {
      var submitGroup = submitControl.closest('.form-group');
      if (submitGroup.length < 1) {
        submitControl.wrap('<div class="form-group"></div>');
        submitGroup = submitControl.closest('.form-group');
      }
      submitGroup.wrap('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 magangkp-submit-field"></div>');
      submitCol = submitGroup.parent();
    }

    submitCol
      .removeClass('col-lg-6 col-md-6 col-sm-6 col-xs-6')
      .addClass('col-lg-12 col-md-12 col-sm-12 col-xs-12 magangkp-submit-field');
    formRow.append(submitCol);
  }

  function ensureVisitorTypeControls() {
    if ($('#visitorType').length > 0) return;

    var formRow = visitorCounterForm.find('.row').first();
    if (!formRow.length) return;

    var typeFieldHtml = ''
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-type-field">'
      + '  <div class="form-group">'
      + '    <select id="visitorType" name="visitorType" class="form-control input-lg" title="Tipe Pengunjung">'
      + '      <option value="member">Anggota</option>'
      + '      <option value="non_member">Non Anggota</option>'
      + '      <option value="rombongan">Rombongan</option>'
      + '      <option value="kritik_saran">Kritik dan Saran</option>'
      + '    </select>'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-location-field">'
      + '  <div class="magangkp-input-caption">Lokasi Kunjungan</div>'
      + '  <div class="form-group">'
      + '    <select id="visitLocation" name="visitLocation" class="form-control input-lg" required>'
      +        buildVisitorLocationOptionsHtml()
      + '    </select>'
      + '  </div>'
      + '</div>';

    var nonMemberFieldHtml = ''
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-nonmember-fields" style="display:none;">'
      + '  <div class="magangkp-input-caption">Pekerjaan</div>'
      + '  <div class="magangkp-choice-grid">'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorJob" value="Pegawai Negeri"> Pegawai Negeri</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorJob" value="Pegawai Swasta"> Pegawai Swasta</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorJob" value="Wiraswasta"> Wiraswasta</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorJob" value="Mahasiswa"> Mahasiswa</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorJob" value="Peneliti"> Peneliti</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorJob" value="Dosen"> Dosen</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorJob" value="Guru"> Guru</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorJob" value="TNI/POLRI"> TNI/POLRI</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorJob" value="Pensiunan"> Pensiunan</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorJob" value="Pelajar"> Pelajar</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorJob" value="Lainnya"> Lainnya</label>'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-nonmember-fields" style="display:none;">'
      + '  <div class="magangkp-input-caption">Pendidikan Terakhir</div>'
      + '  <div class="magangkp-choice-grid">'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorEducation" value="TK"> TK</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorEducation" value="SD"> SD</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorEducation" value="SMP"> SMP</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorEducation" value="SMA"> SMA</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorEducation" value="D1"> D1</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorEducation" value="D2"> D2</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorEducation" value="D3"> D3</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorEducation" value="S1"> S1</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorEducation" value="S2"> S2</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorEducation" value="S3"> S3</label>'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-nonmember-fields" style="display:none;">'
      + '  <div class="magangkp-input-caption">Jenis Kelamin</div>'
      + '  <div class="magangkp-choice-grid">'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorGender" value="1"> ' + maleGenderText + '</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="visitorGender" value="0"> ' + femaleGenderText + '</label>'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-nonmember-fields" style="display:none;">'
      + '  <div class="magangkp-input-caption">Alamat</div>'
      + '  <div class="form-group">'
      + '    <textarea id="visitorAddress" name="visitorAddress" class="form-control input-lg magangkp-textarea" placeholder="Alamat Pengunjung"></textarea>'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-standard-purpose-field" style="display:none;">'
      + '  <div class="magangkp-input-caption">Tujuan</div>'
      + '  <div class="form-group">'
      + '    <select id="visitorPurpose" name="visitorPurpose" class="form-control input-lg">'
      + '      <option value="">Pilih Tujuan Kunjungan</option>'
      + '      <option value="Membaca di tempat">Membaca di tempat</option>'
      + '      <option value="Belajar">Belajar</option>'
      + '      <option value="Riset">Riset</option>'
      + '      <option value="Internet">Internet</option>'
      + '      <option value="Kunjungan instansi">Kunjungan instansi</option>'
      + '      <option value="Lainnya">Lainnya</option>'
      + '    </select>'
      + '  </div>'
      + '</div>';

    var groupFieldHtml = ''
      + '<div class="col-lg-6 col-sm-6 col-xs-12 magangkp-field magangkp-group-fields" style="display:none;">'
      + '  <div class="magangkp-input-caption magangkp-group-required">Nomor Telepon Ketua Rombongan</div>'
      + '  <div class="form-group">'
      + '    <input type="text" id="groupLeaderPhone" name="groupLeaderPhone" class="form-control input-lg" placeholder="Nomor Telepon Ketua Rombongan" />'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-6 col-sm-6 col-xs-12 magangkp-field magangkp-group-fields" style="display:none;">'
      + '  <div class="magangkp-input-caption">Nomor Telepon Instansi Lembaga</div>'
      + '  <div class="form-group">'
      + '    <input type="text" id="groupInstitutionPhone" name="groupInstitutionPhone" class="form-control input-lg" placeholder="Nomor Telepon Instansi Lembaga" />'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-6 col-sm-6 col-xs-12 magangkp-field magangkp-group-fields" style="display:none;">'
      + '  <div class="magangkp-input-caption">Alamat Email Instansi Lembaga</div>'
      + '  <div class="form-group">'
      + '    <input type="email" id="groupInstitutionEmail" name="groupInstitutionEmail" class="form-control input-lg" placeholder="Alamat Email Instansi Lembaga" />'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-group-fields" style="display:none;">'
      + '  <div class="magangkp-input-caption magangkp-group-required">Alamat Instansi Lembaga</div>'
      + '  <div class="form-group">'
      + '    <textarea id="groupInstitutionAddress" name="groupInstitutionAddress" class="form-control input-lg magangkp-textarea" placeholder="Alamat Instansi Lembaga"></textarea>'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-4 col-sm-4 col-xs-12 magangkp-field magangkp-group-fields magangkp-group-gender-fields magangkp-group-gender-field" style="display:none;">'
      + '  <div class="magangkp-input-caption">Jumlah Laki-laki</div>'
      + '  <div class="form-group">'
      + '    <input type="number" min="0" step="1" value="" id="maleCount" name="maleCount" class="form-control input-lg" placeholder="Jumlah Laki-laki" />'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-4 col-sm-4 col-xs-12 magangkp-field magangkp-group-fields magangkp-group-gender-fields magangkp-group-gender-field" style="display:none;">'
      + '  <div class="magangkp-input-caption">Jumlah Perempuan</div>'
      + '  <div class="form-group">'
      + '    <input type="number" min="0" step="1" value="" id="femaleCount" name="femaleCount" class="form-control input-lg" placeholder="Jumlah Perempuan" />'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-4 col-sm-4 col-xs-12 magangkp-field magangkp-group-fields magangkp-group-gender-fields magangkp-group-person-count" style="display:none;">'
      + '  <div class="magangkp-input-caption">Jumlah Personil</div>'
      + '  <div class="form-group">'
      + '    <input type="number" min="0" id="groupPersonCount" name="groupPersonCount" class="form-control input-lg" placeholder="Jumlah Personil" readonly />'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-group-fields" style="display:none;">'
      + '  <div class="magangkp-group-section">'
      + '    <div class="magangkp-input-caption">Rincian Pekerjaan Rombongan</div>'
      + '    <div class="magangkp-counter-grid">'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupJobPns" value="" /><span>PNS</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupJobPegawaiSwasta" value="" /><span>Pegawai Swasta</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupJobPeneliti" value="" /><span>Peneliti</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupJobGuru" value="" /><span>Guru</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupJobDosen" value="" /><span>Dosen</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupJobPensiunan" value="" /><span>Pensiunan</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupJobTniPolri" value="" /><span>TNI/POLRI</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupJobWiraswasta" value="" /><span>Wiraswasta</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupJobPelajar" value="" /><span>Pelajar</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupJobMahasiswa" value="" /><span>Mahasiswa</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupJobLainnya" value="" /><span>Lainnya</span></label>'
      + '    </div>'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-group-fields" style="display:none;">'
      + '  <div class="magangkp-group-section">'
      + '    <div class="magangkp-input-caption">Rincian Pendidikan Terakhir</div>'
      + '    <div class="magangkp-counter-grid">'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupEduTk" value="" /><span>TK</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupEduSd" value="" /><span>SD</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupEduSmp" value="" /><span>SMP (sederajat)</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupEduSma" value="" /><span>SMA (sederajat)</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupEduD1" value="" /><span>Diploma (D1)</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupEduD2" value="" /><span>Diploma (D2)</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupEduD3" value="" /><span>Diploma (D3)</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupEduS1" value="" /><span>Sarjana (S1)</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupEduS2" value="" /><span>Magister (S2)</span></label>'
      + '      <label class="magangkp-counter-item"><input type="number" min="0" step="1" name="groupEduS3" value="" /><span>Doktor (S3)</span></label>'
      + '    </div>'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-group-fields" style="display:none;">'
      + '  <div class="magangkp-input-caption">Tujuan Kunjungan Rombongan</div>'
      + '  <div class="form-group">'
      + '    <select id="groupPurpose" name="groupPurpose" class="form-control input-lg">'
      + '      <option value="">Pilih Tujuan Kunjungan</option>'
      + '      <option value="Membaca di tempat">Membaca di tempat</option>'
      + '      <option value="Belajar">Belajar</option>'
      + '      <option value="Riset">Riset</option>'
      + '      <option value="Internet">Internet</option>'
      + '      <option value="Kunjungan instansi">Kunjungan instansi</option>'
      + '      <option value="Lainnya">Lainnya</option>'
      + '    </select>'
      + '  </div>'
      + '</div>';

    var feedbackFieldHtml = ''
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-feedback-fields" style="display:none;">'
      + '  <div class="magangkp-input-caption">Jenis Masukan</div>'
      + '  <div class="magangkp-choice-grid">'
      + '    <label class="magangkp-choice-item"><input type="radio" name="feedbackType" value="saran" checked> Saran</label>'
      + '    <label class="magangkp-choice-item"><input type="radio" name="feedbackType" value="kritik"> Kritik</label>'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-feedback-fields" style="display:none;">'
      + '  <div class="magangkp-input-caption">Isi Kritik/Saran</div>'
      + '  <div class="form-group">'
      + '    <textarea id="feedbackText" name="feedbackText" class="form-control input-lg magangkp-textarea" placeholder="Tulis kritik atau saran Anda..."></textarea>'
      + '  </div>'
      + '</div>'
      + '<div class="col-lg-12 col-sm-12 col-xs-12 magangkp-field magangkp-feedback-fields" style="display:none;">'
      + '  <div class="form-group" style="margin-bottom:6px;">'
      + '    <button type="button" id="feedbackCancelBtn" class="btn btn-default">Cancel</button>'
      + '  </div>'
      + '</div>';

    var firstCol = formRow.find('.col-lg-6, .col-lg-12').first();
    if (firstCol.length) {
      firstCol.before(typeFieldHtml);
    } else {
      formRow.prepend(typeFieldHtml);
    }

    var submitCol = formRow.find('input#counter').closest('.col-lg-12, .col-sm-12, .col-xs-12').first();
    if (submitCol.length) {
      submitCol.before(nonMemberFieldHtml + groupFieldHtml + feedbackFieldHtml);
    } else {
      formRow.append(nonMemberFieldHtml + groupFieldHtml + feedbackFieldHtml);
    }

    ensureSubmitButtonAtBottom();
  }

  function applyVisitorTypeState() {
    var visitorType = $('#visitorType').val() || 'member';
    var memberInput = $('#memberID');
    var institutionInput = $('#institution');
    var memberField = memberInput.closest('.col-lg-6, .col-lg-12, .col-md-6, .col-md-12, .col-sm-6, .col-sm-12, .col-xs-12');
    var institutionField = institutionInput.closest('.col-lg-6, .col-lg-12, .col-md-6, .col-md-12, .col-sm-6, .col-sm-12, .col-xs-12');
    var isNonMember = visitorType === 'non_member';
    var isGroup = visitorType === 'rombongan';
    var isFeedbackVisitor = visitorType === 'kritik_saran';
    var isStandardVisitor = !isGroup && !isFeedbackVisitor;
    var needsInstitution = isNonMember || isGroup;
    var submitButton = visitorCounterForm.find('#counter').first();

    visitorCounterForm.find('.magangkp-nonmember-fields').toggle(isNonMember);
    visitorCounterForm.find('.magangkp-standard-purpose-field').toggle(isStandardVisitor);
    visitorCounterForm.find('.magangkp-group-fields').toggle(isGroup);
    visitorCounterForm.find('.magangkp-feedback-fields').toggle(isFeedbackVisitor);
    $('#maleCount').prop('required', isGroup);
    $('#femaleCount').prop('required', isGroup);
    $('#groupLeaderPhone').prop('required', isGroup);
    $('#groupInstitutionAddress').prop('required', isGroup);
    $('#visitorPurpose').prop('required', isStandardVisitor);
    visitorCounterForm.find('input[name=visitorGender]').prop('required', isNonMember);
    visitorCounterForm.find('input[name=feedbackType]').prop('required', isFeedbackVisitor);
    $('#feedbackText').prop('required', isFeedbackVisitor);
    $('#visitLocation').prop('required', true);
    institutionInput.prop('required', needsInstitution);

    if (submitButton.length) {
      if (submitButton.is('input')) {
        submitButton.val(isFeedbackVisitor ? feedbackSendButtonText : defaultAddButtonText);
      } else {
        submitButton.text(isFeedbackVisitor ? feedbackSendButtonText : defaultAddButtonText);
      }
    }

    if (needsInstitution) {
      institutionInput.attr('pattern', '[A-Za-z\\s]+');
      institutionInput.attr('title', institutionAlphaOnlyText);
    } else {
      institutionInput.removeAttr('pattern');
      institutionInput.removeAttr('title');
    }

    if (isNonMember || isGroup) {
      memberInput.attr('pattern', '[A-Za-z\\s]+');
      memberInput.attr('title', visitorNameAlphaOnlyText);
      memberInput.val(sanitizeLettersOnly(memberInput.val()));
    } else {
      memberInput.removeAttr('pattern');
      memberInput.removeAttr('title');
    }

    if (!memberField.length) {
      memberField = memberInput.closest('.form-group');
    }
    if (!institutionField.length) {
      institutionField = institutionInput.closest('.form-group');
    }

    if (needsInstitution) {
      institutionField.show();
      memberField
        .removeClass('col-lg-12 col-md-12 col-sm-12')
        .addClass('col-lg-6 col-md-6 col-sm-6');
    } else {
      institutionField.hide();
      institutionInput.val('');
      memberField
        .removeClass('col-lg-6 col-md-6 col-sm-6')
        .addClass('col-lg-12 col-md-12 col-sm-12');
    }

    memberInput.attr('placeholder', isGroup ? groupLeaderHint : (isNonMember ? nonMemberNameHint : defaultMemberHint));
    institutionInput.attr('placeholder', isGroup ? groupInstitutionHint : institutionHint);
    $('#groupLeaderPhone').attr('placeholder', groupLeaderPhoneHint);
    $('#groupInstitutionAddress').attr('placeholder', groupInstitutionAddressHint);
    $('#groupInstitutionPhone').attr('placeholder', groupInstitutionPhoneHint);
    $('#groupInstitutionEmail').attr('placeholder', groupInstitutionEmailHint);
    $('#maleCount').attr('placeholder', maleCountHint);
    $('#femaleCount').attr('placeholder', femaleCountHint);

    if (!isNonMember) {
      visitorCounterForm.find('.magangkp-nonmember-fields input[type=radio]').prop('checked', false);
      $('#visitorAddress').val('');
    }

    if (!isGroup) {
      resetGroupFields();
    } else {
      $('#visitorPurpose').val('');
    }
    if (!isFeedbackVisitor) {
      resetFeedbackFields();
    }

    institutionInput.val(sanitizeLettersOnly(institutionInput.val()));
    updateGroupPersonCount();
    ensureSubmitButtonAtBottom();
    refreshVisitWindowStatus(true);
  }

  ensureVisitorTypeControls();
  applyVisitorTypeState();
  visitorCounterForm.on('change', '#visitorType', applyVisitorTypeState);
  visitorCounterForm.on('input', '#memberID', function() {
    var visitorType = $('#visitorType').val() || 'member';
    if (visitorType !== 'non_member' && visitorType !== 'rombongan') return;
    this.value = sanitizeLettersOnly(this.value);
  });
  visitorCounterForm.on('input', '#institution', function() {
    this.value = sanitizeLettersOnly(this.value);
  });
  visitorCounterForm.on('input', '#groupLeaderPhone, #groupInstitutionPhone', function() {
    this.value = this.value.replace(/[^0-9+\-\s()]/g, '');
  });
  visitorCounterForm.on('click', '#feedbackCancelBtn', function() {
    resetFeedbackFields();
    $('#visitorType').val('member').trigger('change');
    $('#counterInfo').html(defaultCounterInfoText);
    $('#memberID').focus();
  });
  visitorCounterForm.on('input', '#maleCount, #femaleCount', updateGroupPersonCount);
  visitorCounterForm.on('change', '#visitLocation', function() {
    refreshVisitWindowStatus(false);
  });

  refreshVisitWindowStatus(true);
  visitWindowTimer = setInterval(function() {
    refreshVisitWindowStatus(true);
  }, 45000);

  $('#memberID').focus();
  var defaultMsg = $('#counterInfo').html();
  var defaultImg = 'photo.png';

  visitorCounterForm.on('submit', function(e) {
    e.preventDefault();
    var visitorType = $('#visitorType').val() || 'member';
    var isFeedbackVisitor = visitorType === 'kritik_saran';
    var memberId = $.trim($('#memberID').val());
    var institution = $.trim($('#institution').val());
    var visitLocation = $.trim($('#visitLocation').val());
    var maleCount = parseCounterValue($('#maleCount').val());
    var femaleCount = parseCounterValue($('#femaleCount').val());
    var groupTotal = updateGroupPersonCount();
    var groupLeaderPhone = $.trim($('#groupLeaderPhone').val());
    var groupInstitutionAddress = $.trim($('#groupInstitutionAddress').val());
    var groupInstitutionEmail = $.trim($('#groupInstitutionEmail').val());
    var visitorPurpose = $.trim($('#visitorPurpose').val());
    var visitorGender = $.trim((visitorCounterForm.find('input[name=visitorGender]:checked').val() || ''));
    var feedbackType = $.trim((visitorCounterForm.find('input[name=feedbackType]:checked').val() || 'saran')).toLowerCase();
    var feedbackText = $.trim($('#feedbackText').val());
    var groupJobTotal = sumCounterInputs('input[name^=groupJob]');
    var groupEducationTotal = sumCounterInputs('input[name^=groupEdu]');

    if (!isFeedbackVisitor && !visitWindowAllowed) {
      return showFormError(visitWindowReason || visitClosedText, '#visitLocation');
    }
    if (memberId === '') {
      return showFormError(errorText, '#memberID');
    }
    if ((visitorType === 'non_member' || visitorType === 'rombongan') && !isLettersOnly(memberId)) {
      return showFormError(visitorNameAlphaOnlyText, '#memberID');
    }
    if ((visitorType === 'non_member' || visitorType === 'rombongan') && institution === '') {
      return showFormError(institutionRequiredText, '#institution');
    }
    if ((visitorType === 'non_member' || visitorType === 'rombongan') && !isLettersOnly(institution)) {
      return showFormError(institutionAlphaOnlyText, '#institution');
    }
    if (visitLocation === '') {
      return showFormError(locationRequiredText, '#visitLocation');
    }
    if (isFeedbackVisitor && feedbackType !== 'kritik' && feedbackType !== 'saran') {
      return showFormError(feedbackTypeRequiredText);
    }
    if (isFeedbackVisitor && feedbackText === '') {
      return showFormError(feedbackTextRequiredText, '#feedbackText');
    }
    if (visitorType === 'non_member' && visitorGender === '') {
      return showFormError(genderRequiredText);
    }
    if (visitorType !== 'rombongan' && !isFeedbackVisitor && visitorPurpose === '') {
      return showFormError(purposeRequiredText, '#visitorPurpose');
    }
    if (visitorType === 'rombongan' && groupTotal < 1) {
      return showFormError(groupTotalRequiredText, '#maleCount');
    }
    if (visitorType === 'rombongan' && groupLeaderPhone === '') {
      return showFormError(groupPhoneRequiredText, '#groupLeaderPhone');
    }
    if (visitorType === 'rombongan' && groupInstitutionAddress === '') {
      return showFormError(groupAddressRequiredText, '#groupInstitutionAddress');
    }
    if (visitorType === 'rombongan' && !isEmailValid(groupInstitutionEmail)) {
      return showFormError(groupEmailInvalidText, '#groupInstitutionEmail');
    }
    if (visitorType === 'rombongan' && groupJobTotal !== groupTotal) {
      return showFormError(groupJobTotalInvalidText);
    }
    if (visitorType === 'rombongan' && groupEducationTotal > groupTotal) {
      return showFormError(groupEducationTotalInvalidText);
    }

    var theForm = $(this);
    if (isFeedbackVisitor) {
      theForm.disableForm();
      $('#counterInfo').html('Mengirim kritik/saran...');

      submitVisitorFeedback(memberId, visitLocation, feedbackType, feedbackText)
        .done(function(respond) {
          var isSuccess = !!(respond && respond.ok);
          var responseMessage = respond && respond.message
            ? String(respond.message)
            : (isSuccess ? feedbackSuccessText : errorText);
          $('#counterInfo').html(responseMessage);
          showActionToast(responseMessage, isSuccess ? 'success' : 'error');

          if (isSuccess) {
            $('#text_voice').val(successText + responseMessage);
            $('#speak').trigger('click');
            visitorCounterForm.find('input[type=text], input[type=email], input[type=number]').val('');
            visitorCounterForm.find('textarea').val('');
            visitorCounterForm.find('input[type=radio][name^=visitor]').prop('checked', false);
            resetGroupFields();
            resetFeedbackFields();
            $('#visitLocation').val('');
            $('#visitorPurpose').val('');
            $('#groupPurpose').val('');
            $('#visitorType').val('member').trigger('change');
            $('#visitorCounterPhoto').attr('src', './images/persons/' + defaultImg);
          } else {
            $('#memberID').focus();
          }
        })
        .fail(function() {
          $('#text_voice').val(errorText);
          $('#counterInfo').html(errorText);
          showActionToast(errorToastMessage, 'error');
          $('#memberID').focus();
        })
        .always(function() {
          visitorCounterForm.enableForm();
          applyVisitorTypeState();
          refreshVisitWindowStatus(true);
          $('#memberID').focus();
        });
      return;
    }

    var formData = theForm.serialize();
    formData += '&counter=true';

    theForm.disableForm();
    $('#counterInfo').html('Please Wait ...');

    $.ajax({
      url: postUrl,
      type: 'POST',
      data: formData,
      dataType: 'json',
      cache: false,
      success: function(respond) {
        var responseMessage = respond && respond.message ? respond.message : errorText;
        var isSuccess = !!(respond && respond.status);
        $('#counterInfo').html(responseMessage);
        showActionToast(isSuccess ? successToastMessage : responseMessage, isSuccess ? 'success' : 'error');
        if (respond && respond.monitoring) {
          updateMonitoring(respond.monitoring);
        }
        $('#text_voice').val(successText + responseMessage);
        $('#speak').trigger('click');
        $('#visitorCounterPhoto').attr('src', './images/persons/' + ((respond && respond.image) ? respond.image : defaultImg));

        if (isSuccess) {
          fetchMonitoring();
          setTimeout(fetchMonitoring, 600);
          setTimeout(function() {
            $('#counterInfo').html(defaultMsg);
            visitorCounterForm.enableForm().find('input[type=text], input[type=email], input[type=number]').val('');
            visitorCounterForm.find('textarea').val('');
            visitorCounterForm.find('input[type=radio][name^=visitor]').prop('checked', false);
            $('#visitLocation').val('');
            $('#visitorPurpose').val('');
            $('#groupPurpose').val('');
            $('#maleCount').val('');
            $('#femaleCount').val('');
            $('#groupPersonCount').val('');
            visitorCounterForm.find('input[name^=groupJob], input[name^=groupEdu]').val('');
            $('#visitorType').val('member').trigger('change');
            refreshVisitWindowStatus(true);
            $('#memberID').focus();
            setTimeout(function() {
              $('#visitorCounterPhoto').attr('src', './images/persons/' + defaultImg);
            }, 8000);
          }, 1000);
        } else {
          $('#memberID').focus();
        }
      },
      complete: function() {
        visitorCounterForm.enableForm();
        refreshVisitWindowStatus(true);
        var memberImage = $('#memberImage');
        if (memberImage.length) {
          $('#visitorCounterPhoto').attr('src', memberImage.data('img'));
        }
        $('#memberID').focus();
      },
      error: function() {
        $('#text_voice').val(errorText);
        visitorCounterForm.enableForm();
        $('#counterInfo').html(errorText);
        showActionToast(errorToastMessage, 'error');
        $('#memberID').focus();
      }
    });
  });
});

$('#speak').on('click', function () {
  var message = new SpeechSynthesisUtterance($('#text_voice').val());
  message.volume = 1;
  message.rate = 1;
  message.pitch = 1;
  message.lang = '<?php echo str_replace('_', '-', $sysconf['default_lang']); ?>';
  message.voice = null;
  speechSynthesis.cancel();
  speechSynthesis.speak(message);
});
</script>
<?php
$main_content = ob_get_clean();
$page_title = __('Visitor Counter') . ' | ' . $sysconf['library_name'];
require $main_template_path;
exit();
