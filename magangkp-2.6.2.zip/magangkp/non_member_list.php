<?php
/**
 * Non Member & Rombongan Visitor List
 * Reporting page for plugin MagangKp.
 */

defined('INDEX_AUTH') or die('Direct access not allowed!');

if (!function_exists('do_checkIP')) {
    require LIB . 'ip_based_access.inc.php';
}
do_checkIP('smc');
do_checkIP('smc-reporting');

if (session_status() !== PHP_SESSION_ACTIVE) {
    require SB . 'admin/default/session.inc.php';
}
if (!defined('MAGANGKP_ADMIN_SESSION_CHECKED')) {
    require SB . 'admin/default/session_check.inc.php';
    define('MAGANGKP_ADMIN_SESSION_CHECKED', 1);
}

$canRead = utility::havePrivilege('reporting', 'r');
if (!$canRead) {
    die('<div class="errorBox">' . __('You don\'t have enough privileges to access this area!') . '</div>');
}

if (!function_exists('magangKpNmHasColumn')) {
    function magangKpNmHasColumn(mysqli $dbs, string $column, string $table = 'visitor_count'): bool
    {
        $tableEsc = $dbs->escape_string($table);
        if ($result = $dbs->query("SHOW COLUMNS FROM {$tableEsc} LIKE '" . $dbs->escape_string($column) . "'")) {
            $exists = $result->num_rows > 0;
            $result->free_result();
            return $exists;
        }
        return false;
    }
}

if (!function_exists('magangKpNmSafeDate')) {
    function magangKpNmSafeDate(string $value, string $fallback): string
    {
        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) ? $value : $fallback;
    }
}

if (!function_exists('magangKpNmLocationOptions')) {
    function magangKpNmLocationOptions(mysqli $dbs, bool $hasVisitLocation): array
    {
        $options = [];

        if ($settingQuery = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='lokasimaps_locations' LIMIT 1")) {
            if ($settingRow = $settingQuery->fetch_assoc()) {
                $stored = @unserialize($settingRow['setting_value']);
                if (is_array($stored)) {
                    foreach ($stored as $locationRow) {
                        if (!is_array($locationRow)) {
                            continue;
                        }
                        $label = trim(strip_tags((string)($locationRow['label'] ?? '')));
                        if ($label === '') {
                            continue;
                        }
                        $options[$label] = $label;
                    }
                }
            }
            $settingQuery->free_result();
        }

        if ($hasVisitLocation) {
            $sql = "SELECT DISTINCT TRIM(visit_location) AS visit_location FROM visitor_count "
                . "WHERE visit_location IS NOT NULL AND TRIM(visit_location) <> '' ORDER BY visit_location ASC";
            if ($locationQuery = $dbs->query($sql)) {
                while ($row = $locationQuery->fetch_assoc()) {
                    $label = trim((string)($row['visit_location'] ?? ''));
                    if ($label === '') {
                        continue;
                    }
                    $options[$label] = $label;
                }
                $locationQuery->free_result();
            }
        }

        return array_values($options);
    }
}

if (!function_exists('magangKpNmExtractLeaderName')) {
    function magangKpNmExtractLeaderName(string $rawName): string
    {
        $rawName = trim($rawName);
        if ($rawName === '') {
            return 'Tanpa Nama';
        }

        if (preg_match('/^(.*?)\s*\(Ketua Rombongan.*\)$/ui', $rawName, $matches)) {
            $leader = trim((string)($matches[1] ?? ''));
            if ($leader !== '') {
                return $leader;
            }
        }

        if (preg_match('/\(([^()]*)\)\s*$/u', $rawName, $matches)) {
            $leader = trim((string)($matches[1] ?? ''));
            if ($leader !== '') {
                return $leader;
            }
        }

        return $rawName;
    }
}

if (!function_exists('magangKpNmFormatStats')) {
    function magangKpNmFormatStats(string $raw): string
    {
        $raw = trim($raw);
        if ($raw === '') {
            return '-';
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            $decoded = @unserialize($raw);
        }
        if (!is_array($decoded)) {
            return $raw;
        }

        $parts = [];
        foreach ($decoded as $label => $count) {
            $label = trim(strip_tags((string)$label));
            $count = (int)$count;
            if ($label === '' || $count < 1) {
                continue;
            }
            $parts[] = $label . ': ' . $count;
        }

        return empty($parts) ? '-' : implode(', ', $parts);
    }
}

$pluginId = utility::filterData('id', 'get', false, true, true);
$basePageUrl = AWB . 'plugin_container.php';
$today = date('Y-m-d');

$dateFrom = magangKpNmSafeDate((string)(utility::filterData('date_from', 'get', false, true, true) ?: $today), $today);
$dateUntil = magangKpNmSafeDate((string)(utility::filterData('date_until', 'get', false, true, true) ?: $today), $today);
if (strtotime($dateUntil) < strtotime($dateFrom)) {
    $temp = $dateFrom;
    $dateFrom = $dateUntil;
    $dateUntil = $temp;
}

$showAllDates = (string)(utility::filterData('all_dates', 'get', false, true, true) ?? '') === '1';
$keyword = trim((string)(utility::filterData('keyword', 'get', true, true, true) ?? ''));
$visitLocationFilter = trim((string)(utility::filterData('visit_location', 'get', true, true, true) ?? 'all'));
if ($visitLocationFilter === '') {
    $visitLocationFilter = 'all';
}

$perPage = (int)(utility::filterData('per_page', 'get', false, true, true) ?: 20);
if ($perPage < 20) {
    $perPage = 20;
}
if ($perPage > 200) {
    $perPage = 200;
}

$pageNonMember = (int)(utility::filterData('page_non_member', 'get', false, true, true) ?: 1);
if ($pageNonMember < 1) {
    $pageNonMember = 1;
}
$pageRombongan = (int)(utility::filterData('page_rombongan', 'get', false, true, true) ?: 1);
if ($pageRombongan < 1) {
    $pageRombongan = 1;
}

$hasVisitorType = magangKpNmHasColumn($dbs, 'visitor_type');
$hasVisitLocation = magangKpNmHasColumn($dbs, 'visit_location');
$hasVisitorJob = magangKpNmHasColumn($dbs, 'visitor_job');
$hasVisitorEducation = magangKpNmHasColumn($dbs, 'visitor_education');
$hasVisitorGender = magangKpNmHasColumn($dbs, 'visitor_gender');
$hasVisitorAddress = magangKpNmHasColumn($dbs, 'visitor_address');
$hasVisitorPurpose = magangKpNmHasColumn($dbs, 'visitor_purpose');
$hasGroupPurpose = magangKpNmHasColumn($dbs, 'group_purpose');
$hasGroupLeaderPhone = magangKpNmHasColumn($dbs, 'group_leader_phone');
$hasInstitutionPhone = magangKpNmHasColumn($dbs, 'institution_phone');
$hasInstitutionEmail = magangKpNmHasColumn($dbs, 'institution_email');
$hasGroupMale = magangKpNmHasColumn($dbs, 'group_gender_male');
$hasGroupFemale = magangKpNmHasColumn($dbs, 'group_gender_female');
$hasGroupPersonCount = magangKpNmHasColumn($dbs, 'group_person_count');
$hasGroupJobStats = magangKpNmHasColumn($dbs, 'group_job_stats');
$hasGroupEducationStats = magangKpNmHasColumn($dbs, 'group_education_stats');

$visitLocationOptions = magangKpNmLocationOptions($dbs, $hasVisitLocation);
if (count($visitLocationOptions) < 1) {
    $fallbackLocation = trim(strip_tags((string)($sysconf['library_name'] ?? 'Lokasi Utama')));
    if ($fallbackLocation !== '') {
        $visitLocationOptions[] = $fallbackLocation;
    }
}

if ($visitLocationFilter !== 'all' && !in_array($visitLocationFilter, $visitLocationOptions, true)) {
    $visitLocationFilter = 'all';
}

$resolvedTypeExpr = $hasVisitorType
    ? "CASE
        WHEN COALESCE(vc.visitor_type, '') <> '' THEN vc.visitor_type
        WHEN COALESCE(vc.member_id, '') <> '' THEN 'member'
        WHEN COALESCE(vc.member_name, '') LIKE '%Rombongan%' THEN 'rombongan'
        ELSE 'non_member'
      END"
    : "CASE
        WHEN COALESCE(vc.member_id, '') <> '' THEN 'member'
        WHEN COALESCE(vc.member_name, '') LIKE '%Rombongan%' THEN 'rombongan'
        ELSE 'non_member'
      END";

$visitLocationExpr = $hasVisitLocation
    ? "COALESCE(NULLIF(TRIM(vc.visit_location), ''), '-')"
    : "'-'";

$nonMemberJobExpr = $hasVisitorJob
    ? "COALESCE(NULLIF(TRIM(vc.visitor_job), ''), '-')"
    : "'-'";
$nonMemberEducationExpr = $hasVisitorEducation
    ? "COALESCE(NULLIF(TRIM(vc.visitor_education), ''), '-')"
    : "'-'";
$nonMemberAddressExpr = $hasVisitorAddress
    ? "COALESCE(NULLIF(TRIM(vc.visitor_address), ''), '-')"
    : "'-'";
$nonMemberPurposeExpr = "'Belum diisi'";
if ($hasVisitorPurpose && $hasGroupPurpose) {
    $nonMemberPurposeExpr = "COALESCE(NULLIF(TRIM(vc.visitor_purpose), ''), NULLIF(TRIM(vc.group_purpose), ''), 'Belum diisi')";
} elseif ($hasVisitorPurpose) {
    $nonMemberPurposeExpr = "COALESCE(NULLIF(TRIM(vc.visitor_purpose), ''), 'Belum diisi')";
} elseif ($hasGroupPurpose) {
    $nonMemberPurposeExpr = "COALESCE(NULLIF(TRIM(vc.group_purpose), ''), 'Belum diisi')";
}

$nonMemberGenderExpr = "'-'";
if ($hasVisitorGender) {
    $nonMemberGenderExpr = "CASE
        WHEN LOWER(REPLACE(TRIM(COALESCE(vc.visitor_gender, '')), '-', ' ')) IN ('1', 'laki laki', 'laki', 'pria', 'male', 'l', 'm') THEN 'Male'
        WHEN LOWER(REPLACE(TRIM(COALESCE(vc.visitor_gender, '')), '-', ' ')) IN ('0', 'perempuan', 'wanita', 'female', 'p', 'f') THEN 'Female'
        ELSE '-'
      END";
}

$groupLeaderPhoneExpr = $hasGroupLeaderPhone
    ? "COALESCE(NULLIF(TRIM(vc.group_leader_phone), ''), '-')"
    : "'-'";
$institutionPhoneExpr = $hasInstitutionPhone
    ? "COALESCE(NULLIF(TRIM(vc.institution_phone), ''), '-')"
    : "'-'";
$institutionEmailExpr = $hasInstitutionEmail
    ? "COALESCE(NULLIF(TRIM(vc.institution_email), ''), '-')"
    : "'-'";
$groupMaleExpr = $hasGroupMale ? "COALESCE(vc.group_gender_male, 0)" : "0";
$groupFemaleExpr = $hasGroupFemale ? "COALESCE(vc.group_gender_female, 0)" : "0";
$groupPersonExpr = $hasGroupPersonCount
    ? "CASE WHEN vc.group_person_count IS NULL OR vc.group_person_count < 1 THEN ({$groupMaleExpr} + {$groupFemaleExpr}) ELSE vc.group_person_count END"
    : "({$groupMaleExpr} + {$groupFemaleExpr})";
$groupJobStatsExpr = $hasGroupJobStats ? "COALESCE(vc.group_job_stats, '')" : "''";
$groupEducationStatsExpr = $hasGroupEducationStats ? "COALESCE(vc.group_education_stats, '')" : "''";

$groupPurposeExpr = "'Belum diisi'";
if ($hasGroupPurpose && $hasVisitorPurpose) {
    $groupPurposeExpr = "COALESCE(NULLIF(TRIM(vc.group_purpose), ''), NULLIF(TRIM(vc.visitor_purpose), ''), 'Belum diisi')";
} elseif ($hasGroupPurpose) {
    $groupPurposeExpr = "COALESCE(NULLIF(TRIM(vc.group_purpose), ''), 'Belum diisi')";
} elseif ($hasVisitorPurpose) {
    $groupPurposeExpr = "COALESCE(NULLIF(TRIM(vc.visitor_purpose), ''), 'Belum diisi')";
}

$baseWhere = [];
if (!$showAllDates) {
    $baseWhere[] = "vc.checkin_date >= '" . $dbs->escape_string($dateFrom . ' 00:00:00') . "'";
    $baseWhere[] = "vc.checkin_date <= '" . $dbs->escape_string($dateUntil . ' 23:59:59') . "'";
}
if ($hasVisitLocation && $visitLocationFilter !== 'all') {
    $baseWhere[] = "TRIM(COALESCE(vc.visit_location, '')) = '" . $dbs->escape_string($visitLocationFilter) . "'";
}

$keywordEscaped = $dbs->escape_string($keyword);

$nonMemberWhere = $baseWhere;
$nonMemberWhere[] = "{$resolvedTypeExpr} = 'non_member'";
if ($keyword !== '') {
    $keywordFields = [
        "vc.member_id LIKE '%{$keywordEscaped}%'",
        "vc.member_name LIKE '%{$keywordEscaped}%'",
        "vc.institution LIKE '%{$keywordEscaped}%'"
    ];
    if ($hasVisitLocation) {
        $keywordFields[] = "vc.visit_location LIKE '%{$keywordEscaped}%'";
    }
    if ($hasVisitorJob) {
        $keywordFields[] = "vc.visitor_job LIKE '%{$keywordEscaped}%'";
    }
    if ($hasVisitorEducation) {
        $keywordFields[] = "vc.visitor_education LIKE '%{$keywordEscaped}%'";
    }
    if ($hasVisitorAddress) {
        $keywordFields[] = "vc.visitor_address LIKE '%{$keywordEscaped}%'";
    }
    if ($hasVisitorPurpose) {
        $keywordFields[] = "vc.visitor_purpose LIKE '%{$keywordEscaped}%'";
    }
    $nonMemberWhere[] = '(' . implode(' OR ', $keywordFields) . ')';
}
$nonMemberWhereSql = implode(' AND ', $nonMemberWhere);
if ($nonMemberWhereSql === '') {
    $nonMemberWhereSql = '1=1';
}

$rombonganWhere = $baseWhere;
$rombonganWhere[] = "{$resolvedTypeExpr} = 'rombongan'";
// Reduce duplicates from one rombongan check-in by keeping only rows labeled as leader.
$rombonganWhere[] = "(COALESCE(vc.member_name, '') LIKE '%Ketua Rombongan%' OR COALESCE(vc.member_name, '') NOT LIKE 'Anggota Rombongan %')";
if ($keyword !== '') {
    $keywordFields = [
        "vc.member_name LIKE '%{$keywordEscaped}%'",
        "vc.institution LIKE '%{$keywordEscaped}%'"
    ];
    if ($hasVisitLocation) {
        $keywordFields[] = "vc.visit_location LIKE '%{$keywordEscaped}%'";
    }
    if ($hasGroupLeaderPhone) {
        $keywordFields[] = "vc.group_leader_phone LIKE '%{$keywordEscaped}%'";
    }
    if ($hasInstitutionPhone) {
        $keywordFields[] = "vc.institution_phone LIKE '%{$keywordEscaped}%'";
    }
    if ($hasInstitutionEmail) {
        $keywordFields[] = "vc.institution_email LIKE '%{$keywordEscaped}%'";
    }
    if ($hasGroupPurpose) {
        $keywordFields[] = "vc.group_purpose LIKE '%{$keywordEscaped}%'";
    }
    if ($hasVisitorPurpose) {
        $keywordFields[] = "vc.visitor_purpose LIKE '%{$keywordEscaped}%'";
    }
    if ($hasGroupJobStats) {
        $keywordFields[] = "vc.group_job_stats LIKE '%{$keywordEscaped}%'";
    }
    if ($hasGroupEducationStats) {
        $keywordFields[] = "vc.group_education_stats LIKE '%{$keywordEscaped}%'";
    }
    $rombonganWhere[] = '(' . implode(' OR ', $keywordFields) . ')';
}
$rombonganWhereSql = implode(' AND ', $rombonganWhere);
if ($rombonganWhereSql === '') {
    $rombonganWhereSql = '1=1';
}

$totalNonMemberRows = 0;
if ($countResult = $dbs->query("SELECT COUNT(vc.visitor_id) AS row_total FROM visitor_count vc WHERE {$nonMemberWhereSql}")) {
    if ($countRow = $countResult->fetch_assoc()) {
        $totalNonMemberRows = max(0, (int)($countRow['row_total'] ?? 0));
    }
    $countResult->free_result();
}

$totalRombonganRows = 0;
if ($countResult = $dbs->query("SELECT COUNT(vc.visitor_id) AS row_total FROM visitor_count vc WHERE {$rombonganWhereSql}")) {
    if ($countRow = $countResult->fetch_assoc()) {
        $totalRombonganRows = max(0, (int)($countRow['row_total'] ?? 0));
    }
    $countResult->free_result();
}

$totalNonMemberPages = max(1, (int)ceil(($totalNonMemberRows > 0 ? $totalNonMemberRows : 1) / $perPage));
if ($pageNonMember > $totalNonMemberPages) {
    $pageNonMember = $totalNonMemberPages;
}
$nonMemberOffset = ($pageNonMember - 1) * $perPage;

$totalRombonganPages = max(1, (int)ceil(($totalRombonganRows > 0 ? $totalRombonganRows : 1) / $perPage));
if ($pageRombongan > $totalRombonganPages) {
    $pageRombongan = $totalRombonganPages;
}
$rombonganOffset = ($pageRombongan - 1) * $perPage;

$baseQuery = [
    'mod' => 'reporting',
    'id' => $pluginId,
    'date_from' => $dateFrom,
    'date_until' => $dateUntil,
    'all_dates' => $showAllDates ? 1 : null,
    'keyword' => $keyword,
    'visit_location' => $visitLocationFilter,
    'per_page' => $perPage,
    'page_non_member' => $pageNonMember,
    'page_rombongan' => $pageRombongan
];

$buildUrl = function (array $overrides = []) use ($basePageUrl, $baseQuery): string {
    $query = array_merge($baseQuery, $overrides);
    foreach ($query as $key => $value) {
        if ($value === null || $value === '') {
            unset($query[$key]);
        }
    }
    return $basePageUrl . (empty($query) ? '' : ('?' . http_build_query($query)));
};

$nonMemberRows = [];
$nonMemberSql = "
    SELECT
      vc.visitor_id,
      vc.checkin_date,
      COALESCE(NULLIF(TRIM(vc.member_name), ''), NULLIF(TRIM(vc.member_id), ''), 'Tanpa Nama') AS visitor_name,
      COALESCE(NULLIF(TRIM(vc.institution), ''), '-') AS institution,
      {$visitLocationExpr} AS visit_location,
      {$nonMemberJobExpr} AS visitor_job,
      {$nonMemberEducationExpr} AS visitor_education,
      {$nonMemberPurposeExpr} AS visitor_purpose,
      {$nonMemberGenderExpr} AS visitor_gender,
      {$nonMemberAddressExpr} AS visitor_address
    FROM visitor_count vc
    WHERE {$nonMemberWhereSql}
    ORDER BY vc.checkin_date DESC, vc.visitor_id DESC
    LIMIT {$nonMemberOffset}, {$perPage}
";
if ($listResult = $dbs->query($nonMemberSql)) {
    while ($row = $listResult->fetch_assoc()) {
        $nonMemberRows[] = $row;
    }
    $listResult->free_result();
}

$rombonganRows = [];
$rombonganSql = "
    SELECT
      vc.visitor_id,
      vc.checkin_date,
      COALESCE(NULLIF(TRIM(vc.member_name), ''), 'Tanpa Nama') AS leader_name_raw,
      COALESCE(NULLIF(TRIM(vc.institution), ''), '-') AS institution,
      {$visitLocationExpr} AS visit_location,
      {$groupLeaderPhoneExpr} AS group_leader_phone,
      {$institutionPhoneExpr} AS institution_phone,
      {$institutionEmailExpr} AS institution_email,
      {$groupMaleExpr} AS male_total,
      {$groupFemaleExpr} AS female_total,
      {$groupPersonExpr} AS person_total,
      {$groupJobStatsExpr} AS group_job_stats,
      {$groupEducationStatsExpr} AS group_education_stats,
      {$groupPurposeExpr} AS group_purpose
    FROM visitor_count vc
    WHERE {$rombonganWhereSql}
    ORDER BY vc.checkin_date DESC, vc.visitor_id DESC
    LIMIT {$rombonganOffset}, {$perPage}
";
if ($listResult = $dbs->query($rombonganSql)) {
    while ($row = $listResult->fetch_assoc()) {
        $row['leader_name'] = magangKpNmExtractLeaderName((string)($row['leader_name_raw'] ?? ''));
        $row['group_job_stats_text'] = magangKpNmFormatStats((string)($row['group_job_stats'] ?? ''));
        $row['group_education_stats_text'] = magangKpNmFormatStats((string)($row['group_education_stats'] ?? ''));
        $maleTotal = max(0, (int)($row['male_total'] ?? 0));
        $femaleTotal = max(0, (int)($row['female_total'] ?? 0));
        $personTotal = max(0, (int)($row['person_total'] ?? 0));
        if ($personTotal < 1) {
            $personTotal = $maleTotal + $femaleTotal;
        }
        $row['male_total'] = $maleTotal;
        $row['female_total'] = $femaleTotal;
        $row['person_total'] = $personTotal;
        $rombonganRows[] = $row;
    }
    $listResult->free_result();
}
?>

<style>
  .magangkp-nm-wrap {
    width: 100%;
  }
  .magangkp-nm-wrap .menuBoxInner {
    width: 100%;
    box-sizing: border-box;
    padding: 20px 22px;
  }
  .magangkp-nm-wrap .mkp-filter-row,
  .magangkp-nm-wrap .mkp-summary-row {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin: 0;
  }
  .magangkp-nm-wrap .mkp-filter-row > [class*="col-"] {
    padding: 0;
    margin: 0;
    flex: 1 1 220px;
    min-width: 220px;
    max-width: none;
  }
  .magangkp-nm-wrap .mkp-filter-row .mkp-filter-submit {
    flex: 0 0 170px;
    min-width: 170px;
  }
  .magangkp-nm-wrap .mkp-filter-row .mkp-filter-full {
    flex: 1 0 100%;
    min-width: 100%;
  }
  .magangkp-nm-wrap .mkp-summary-row > [class*="col-"] {
    padding: 0;
    margin: 0;
    flex: 1 1 210px;
    min-width: 210px;
    max-width: none;
  }
  .magangkp-nm-wrap .card-stat {
    border-radius: 12px;
    border: 1px solid #dbe6ef;
    background: #fff;
    padding: 14px;
    text-align: center;
  }
  .magangkp-nm-wrap .card-stat small {
    display: block;
    color: #5c6b7a;
    font-size: 11px;
    letter-spacing: .4px;
    text-transform: uppercase;
  }
  .magangkp-nm-wrap .card-stat strong {
    display: block;
    font-size: 28px;
    line-height: 1.1;
    color: #0f172a;
    margin-top: 4px;
  }
  .magangkp-nm-wrap .mkp-table-card {
    margin-top: 16px;
    border: 1px solid #dbe6ef;
    border-radius: 12px;
    background: #fff;
    padding: 14px;
  }
  .magangkp-nm-wrap .mkp-table-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
  }
  .magangkp-nm-wrap .mkp-table-head h5 {
    margin: 0;
  }
  .magangkp-nm-wrap .table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
  }
  .magangkp-nm-wrap .table {
    min-width: 1200px;
  }
  .magangkp-nm-wrap .table td,
  .magangkp-nm-wrap .table th {
    vertical-align: middle;
  }
  .magangkp-nm-wrap .mkp-pager {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 10px;
    gap: 10px;
  }
  .magangkp-nm-wrap .mkp-pager-info {
    color: #64748b;
    font-size: 12px;
  }
  @media (max-width: 767px) {
    .magangkp-nm-wrap .menuBoxInner {
      padding: 14px;
    }
    .magangkp-nm-wrap .mkp-filter-row > [class*="col-"],
    .magangkp-nm-wrap .mkp-summary-row > [class*="col-"] {
      flex: 1 0 100%;
      min-width: 100%;
    }
    .magangkp-nm-wrap .mkp-filter-row .mkp-filter-submit {
      flex: 1 0 100%;
      min-width: 100%;
    }
  }
</style>

<div class="menuBox magangkp-nm-wrap">
  <div class="menuBoxInner">
    <div class="per_title mb-2">
      <h2>Non Member List</h2>
    </div>
    <div class="infoBox mb-2">
      Menampilkan data kunjungan khusus <strong>Non Member</strong> dan <strong>Rombongan</strong> dari tabel visitor yang sama.
    </div>

    <form method="get" action="<?php echo $basePageUrl; ?>" class="mb-3">
      <input type="hidden" name="mod" value="reporting">
      <input type="hidden" name="id" value="<?php echo htmlspecialchars((string)$pluginId); ?>">
      <div class="form-row align-items-end mkp-filter-row">
        <div class="col-md-2">
          <label><?php echo __('Date From'); ?></label>
          <input type="date" name="date_from" class="form-control" value="<?php echo $dateFrom; ?>">
        </div>
        <div class="col-md-2">
          <label><?php echo __('Date Until'); ?></label>
          <input type="date" name="date_until" class="form-control" value="<?php echo $dateUntil; ?>">
        </div>
        <div class="col-md-3">
          <label><?php echo __('Keyword'); ?></label>
          <input type="text" name="keyword" class="form-control" value="<?php echo htmlspecialchars($keyword); ?>" placeholder="Nama / Institusi / Lokasi / Tujuan / Telepon">
        </div>
        <div class="col-md-3">
          <label>Lokasi Kunjungan</label>
          <select name="visit_location" class="form-control">
            <option value="all"<?php echo $visitLocationFilter === 'all' ? ' selected' : ''; ?>>Semua Lokasi</option>
            <?php foreach ($visitLocationOptions as $locationOption) { ?>
              <option value="<?php echo htmlspecialchars($locationOption); ?>"<?php echo $visitLocationFilter === $locationOption ? ' selected' : ''; ?>>
                <?php echo htmlspecialchars($locationOption); ?>
              </option>
            <?php } ?>
          </select>
        </div>
        <div class="col-md-1">
          <label><?php echo __('Rows'); ?></label>
          <select name="per_page" class="form-control">
            <?php foreach ([20, 50, 100, 200] as $rowOption) { ?>
              <option value="<?php echo $rowOption; ?>"<?php echo $perPage === $rowOption ? ' selected' : ''; ?>><?php echo $rowOption; ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="col-md-1 mkp-filter-submit">
          <button type="submit" class="btn btn-primary btn-block"><?php echo __('Filter'); ?></button>
        </div>
        <div class="col-md-12 mt-2 mkp-filter-full">
          <label class="mb-0">
            <input type="checkbox" name="all_dates" value="1"<?php echo $showAllDates ? ' checked' : ''; ?>>
            Tampilkan semua tanggal (abaikan Date From/Date Until)
          </label>
        </div>
      </div>
    </form>

    <div class="row mb-3 mkp-summary-row">
      <div class="col-md-4 mb-2">
        <div class="card-stat">
          <small>Total Non Member</small>
          <strong><?php echo number_format($totalNonMemberRows); ?></strong>
        </div>
      </div>
      <div class="col-md-4 mb-2">
        <div class="card-stat">
          <small>Total Rombongan</small>
          <strong><?php echo number_format($totalRombonganRows); ?></strong>
        </div>
      </div>
      <div class="col-md-4 mb-2">
        <div class="card-stat">
          <small>Total Data</small>
          <strong><?php echo number_format($totalNonMemberRows + $totalRombonganRows); ?></strong>
        </div>
      </div>
    </div>

    <div class="mkp-table-card">
      <div class="mkp-table-head">
        <h5>List Non Member</h5>
      </div>
      <div class="table-responsive">
        <table class="table table-striped table-bordered">
          <thead class="thead-light">
            <tr>
              <th style="width:70px">ID</th>
              <th style="width:160px">Check In</th>
              <th>Nama</th>
              <th>Lokasi Kunjungan</th>
              <th>Institusi</th>
              <th>Pekerjaan</th>
              <th>Pendidikan Terakhir</th>
              <th>Tujuan</th>
              <th>Jenis Kelamin</th>
              <th>Alamat</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($nonMemberRows)) { ?>
              <tr>
                <td colspan="10" class="text-center text-muted">Data non member tidak ditemukan untuk filter ini.</td>
              </tr>
            <?php } else { ?>
              <?php foreach ($nonMemberRows as $row) { ?>
                <tr>
                  <td><?php echo (int)($row['visitor_id'] ?? 0); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['checkin_date'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['visitor_name'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['visit_location'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['institution'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['visitor_job'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['visitor_education'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['visitor_purpose'] ?? 'Belum diisi')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['visitor_gender'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['visitor_address'] ?? '-')); ?></td>
                </tr>
              <?php } ?>
            <?php } ?>
          </tbody>
        </table>
      </div>
      <div class="mkp-pager">
        <div class="mkp-pager-info">
          Menampilkan <?php echo $totalNonMemberRows > 0 ? ($nonMemberOffset + 1) : 0; ?>-<?php echo min($nonMemberOffset + $perPage, $totalNonMemberRows); ?> dari <?php echo $totalNonMemberRows; ?> data
        </div>
        <nav>
          <ul class="pagination mb-0">
            <li class="page-item<?php echo $pageNonMember <= 1 ? ' disabled' : ''; ?>">
              <a class="page-link" href="<?php echo $buildUrl(['page_non_member' => max(1, $pageNonMember - 1), 'page_rombongan' => $pageRombongan]); ?>">&laquo;</a>
            </li>
            <?php
            $startPage = max(1, $pageNonMember - 2);
            $endPage = min($totalNonMemberPages, $pageNonMember + 2);
            for ($i = $startPage; $i <= $endPage; $i++) {
            ?>
              <li class="page-item<?php echo $i === $pageNonMember ? ' active' : ''; ?>">
                <a class="page-link" href="<?php echo $buildUrl(['page_non_member' => $i, 'page_rombongan' => $pageRombongan]); ?>"><?php echo $i; ?></a>
              </li>
            <?php } ?>
            <li class="page-item<?php echo $pageNonMember >= $totalNonMemberPages ? ' disabled' : ''; ?>">
              <a class="page-link" href="<?php echo $buildUrl(['page_non_member' => min($totalNonMemberPages, $pageNonMember + 1), 'page_rombongan' => $pageRombongan]); ?>">&raquo;</a>
            </li>
          </ul>
        </nav>
      </div>
    </div>

    <div class="mkp-table-card">
      <div class="mkp-table-head">
        <h5>List Rombongan</h5>
      </div>
      <div class="table-responsive">
        <table class="table table-striped table-bordered">
          <thead class="thead-light">
            <tr>
              <th style="width:70px">ID</th>
              <th style="width:160px">Check In</th>
              <th>Lokasi Kunjungan</th>
              <th>Nama Ketua Rombongan</th>
              <th>Institusi</th>
              <th>No. Telepon Institusi</th>
              <th>No. Telepon Ketua</th>
              <th>Email Instansi</th>
              <th>Jumlah Personil (L/P)</th>
              <th>Rincian Pekerjaan Rombongan</th>
              <th>Rincian Pendidikan Terakhir</th>
              <th>Tujuan Kunjungan Rombongan</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($rombonganRows)) { ?>
              <tr>
                <td colspan="12" class="text-center text-muted">Data rombongan tidak ditemukan untuk filter ini.</td>
              </tr>
            <?php } else { ?>
              <?php foreach ($rombonganRows as $row) { ?>
                <tr>
                  <td><?php echo (int)($row['visitor_id'] ?? 0); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['checkin_date'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['visit_location'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['leader_name'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['institution'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['institution_phone'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['group_leader_phone'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['institution_email'] ?? '-')); ?></td>
                  <td>
                    <?php echo (int)($row['person_total'] ?? 0); ?>
                    (<?php echo (int)($row['male_total'] ?? 0); ?>/<?php echo (int)($row['female_total'] ?? 0); ?>)
                  </td>
                  <td><?php echo htmlspecialchars((string)($row['group_job_stats_text'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['group_education_stats_text'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['group_purpose'] ?? 'Belum diisi')); ?></td>
                </tr>
              <?php } ?>
            <?php } ?>
          </tbody>
        </table>
      </div>
      <div class="mkp-pager">
        <div class="mkp-pager-info">
          Menampilkan <?php echo $totalRombonganRows > 0 ? ($rombonganOffset + 1) : 0; ?>-<?php echo min($rombonganOffset + $perPage, $totalRombonganRows); ?> dari <?php echo $totalRombonganRows; ?> data
        </div>
        <nav>
          <ul class="pagination mb-0">
            <li class="page-item<?php echo $pageRombongan <= 1 ? ' disabled' : ''; ?>">
              <a class="page-link" href="<?php echo $buildUrl(['page_rombongan' => max(1, $pageRombongan - 1), 'page_non_member' => $pageNonMember]); ?>">&laquo;</a>
            </li>
            <?php
            $startPage = max(1, $pageRombongan - 2);
            $endPage = min($totalRombonganPages, $pageRombongan + 2);
            for ($i = $startPage; $i <= $endPage; $i++) {
            ?>
              <li class="page-item<?php echo $i === $pageRombongan ? ' active' : ''; ?>">
                <a class="page-link" href="<?php echo $buildUrl(['page_rombongan' => $i, 'page_non_member' => $pageNonMember]); ?>"><?php echo $i; ?></a>
              </li>
            <?php } ?>
            <li class="page-item<?php echo $pageRombongan >= $totalRombonganPages ? ' disabled' : ''; ?>">
              <a class="page-link" href="<?php echo $buildUrl(['page_rombongan' => min($totalRombonganPages, $pageRombongan + 1), 'page_non_member' => $pageNonMember]); ?>">&raquo;</a>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
</div>
