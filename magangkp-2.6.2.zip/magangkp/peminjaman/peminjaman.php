<?php

defined('INDEX_AUTH') or die('Direct access not allowed!');

require_once __DIR__ . '/lib.php';

if ($dbs instanceof mysqli) {
  peminjamanEnsureSchema($dbs);
}

$mode = strtolower(trim((string) ($_REQUEST['mode'] ?? 'login')));
if (!in_array($mode, ['login', 'status'], true)) {
  $mode = 'login';
}

$messages = [
  'success' => [],
  'error' => [],
  'info' => []
];
$isPostRequest = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST';

$flashBagKey = 'peminjaman_flash_messages';
if (isset($_SESSION[$flashBagKey]) && is_array($_SESSION[$flashBagKey])) {
  foreach (['success', 'error', 'info'] as $messageType) {
    if (!empty($_SESSION[$flashBagKey][$messageType]) && is_array($_SESSION[$flashBagKey][$messageType])) {
      foreach ($_SESSION[$flashBagKey][$messageType] as $flashMessage) {
        $flashMessage = trim((string) $flashMessage);
        if ($flashMessage !== '') {
          $messages[$messageType][] = $flashMessage;
        }
      }
    }
  }
  unset($_SESSION[$flashBagKey]);
}

$buildPeminjamanUrl = function (array $params = []): string {
  $query = ['p' => 'peminjaman'];
  foreach ($params as $key => $value) {
    if ($value === null) {
      continue;
    }
    $value = trim((string) $value);
    if ($value === '') {
      continue;
    }
    $query[(string) $key] = $value;
  }
  return 'index.php?' . http_build_query($query);
};

$redirectVisitorUrl = 'index.php?p=visitor&destination=' . rawurlencode($buildPeminjamanUrl());
$pushFlashAndRedirect = function (string $url, array $flash = []) use ($flashBagKey): void {
  if (!isset($_SESSION[$flashBagKey]) || !is_array($_SESSION[$flashBagKey])) {
    $_SESSION[$flashBagKey] = [
      'success' => [],
      'error' => [],
      'info' => []
    ];
  }
  foreach (['success', 'error', 'info'] as $messageType) {
    if (empty($flash[$messageType]) || !is_array($flash[$messageType])) {
      continue;
    }
    foreach ($flash[$messageType] as $message) {
      $message = trim((string) $message);
      if ($message !== '') {
        $_SESSION[$flashBagKey][$messageType][] = $message;
      }
    }
  }
  header('Location: ' . $url);
  exit;
};

$locations = peminjamanGetLocationOptions($dbs, $sysconf);
$today = date('Y-m-d');
$authMember = null;
$visitWindow = [
  'allowed' => true,
  'location' => '',
  'reason' => '',
  'open_time' => null,
  'close_time' => null
];
$loanServiceOpen = true;
$dailyLimitValue = peminjamanGetDailyLoanLimit($dbs, 3);
$sameItemDailyLimitValue = peminjamanGetSameItemDailyLimit($dbs, 3);
$allowLoanWithoutVisitor = peminjamanGetAllowLoanWithoutVisitor($dbs, false);
$useVisitorScheduleForLoan = peminjamanGetUseVisitorScheduleForLoan($dbs, true);
$dailyLoanUsage = [
  'limit' => $dailyLimitValue,
  'used' => 0,
  'remaining' => $dailyLimitValue
];

$resolveVisitWindow = static function (string $location) use ($dbs, $useVisitorScheduleForLoan): array {
  if ($useVisitorScheduleForLoan) {
    return peminjamanGetVisitWindowStatus($dbs, $location);
  }
  return [
    'allowed' => true,
    'location' => $location,
    'reason' => 'Mode jadwal pengunjung untuk peminjaman dinonaktifkan oleh admin.',
    'open_time' => null,
    'close_time' => null
  ];
};

if (!isset($_SESSION['peminjaman_cart']) || !is_array($_SESSION['peminjaman_cart'])) {
  $_SESSION['peminjaman_cart'] = [];
}

$auth = $_SESSION['peminjaman_auth'] ?? null;
if (is_array($auth) && !empty($auth['member_id'])) {
  // Real-time member data refresh: prevent stale session if admin modifies member
  $freshMember = peminjamanGetMemberFresh($dbs, (string) $auth['member_id']);
  if (!$freshMember) {
    unset($_SESSION['peminjaman_auth'], $_SESSION['peminjaman_cart']);
    $auth = null;
    $_SESSION['peminjaman_cart'] = [];
    $messages['error'][] = 'Data member tidak ditemukan di database. Silakan login ulang atau hubungi admin.';
  } elseif ((int) ($freshMember['is_pending'] ?? 0) === 1) {
    unset($_SESSION['peminjaman_auth'], $_SESSION['peminjaman_cart']);
    $auth = null;
    $_SESSION['peminjaman_cart'] = [];
    $messages['error'][] = 'Akun member Anda masih dalam status pending. Silakan hubungi admin perpustakaan.';
  } elseif (isset($freshMember['expire_date']) && $freshMember['expire_date'] < date('Y-m-d')) {
    unset($_SESSION['peminjaman_auth'], $_SESSION['peminjaman_cart']);
    $auth = null;
    $_SESSION['peminjaman_cart'] = [];
    $messages['error'][] = 'Keanggotaan Anda sudah kedaluwarsa (expired: ' . htmlspecialchars($freshMember['expire_date']) . '). Silakan hubungi admin untuk perpanjangan.';
  } else {
    // Keep session minimal: do not persist personal login data.
    $visitLocationSession = peminjamanNormalizeText((string) ($auth['visit_location'] ?? ''), 120);
    if ($visitLocationSession === '' && !empty($locations[0])) {
      $visitLocationSession = (string) $locations[0];
    }
    $_SESSION['peminjaman_auth'] = [
      'member_id' => (string) $freshMember['member_id'],
      'visit_location' => $visitLocationSession,
      'login_at' => (string) ($auth['login_at'] ?? peminjamanNow())
    ];
    $auth = $_SESSION['peminjaman_auth'];
    $authMember = $freshMember;

    // Visitor check (can be disabled from admin approval settings).
    if (!$allowLoanWithoutVisitor) {
      $stillVisitedToday = peminjamanHasVisitorToday($dbs, (string) $auth['member_id']);
      if (!$stillVisitedToday) {
        unset($_SESSION['peminjaman_auth'], $_SESSION['peminjaman_cart']);
        $auth = null;
        $_SESSION['peminjaman_cart'] = [];
        $pushFlashAndRedirect($redirectVisitorUrl, [
          'error' => ['Sesi peminjaman ditutup karena data visitor hari ini belum ditemukan. Silakan isi form Visitor terlebih dahulu.']
        ]);
      }
    }

    if ($auth) {
      $visitWindow = $resolveVisitWindow((string) ($auth['visit_location'] ?? ''));
      if (empty($visitWindow['allowed'])) {
        $loanServiceOpen = false;
        $messages['info'][] = 'Layanan peminjaman sedang tutup. ' . (string) ($visitWindow['reason'] ?? 'Silakan coba kembali saat jam layanan visitor buka.');
      }
    }
  }
}

if (isset($_POST['logout_peminjaman'])) {
  unset($_SESSION['peminjaman_auth'], $_SESSION['peminjaman_cart']);
  $_SESSION['peminjaman_cart'] = [];
  $auth = null;
  $messages['success'][] = 'Logout berhasil dari fitur peminjaman.';
}

if (isset($_POST['login_peminjaman'])) {
  $mode = 'login';
  $email = trim((string) ($_POST['member_email'] ?? ''));
  $password = (string) ($_POST['member_password'] ?? '');
  $visitLocation = peminjamanNormalizeText((string) ($_POST['visit_location'] ?? ''), 120);

  if ($email === '' || $password === '' || $visitLocation === '') {
    $messages['error'][] = 'Email, kata sandi, dan lokasi wajib diisi.';
  } else {
    $visitWindowLogin = $resolveVisitWindow($visitLocation);
    if (empty($visitWindowLogin['allowed'])) {
      $messages['error'][] = 'Login tidak dapat diproses karena layanan peminjaman sedang tutup. ' . (string) ($visitWindowLogin['reason'] ?? 'Ikuti jadwal layanan visitor.');
      $loanServiceOpen = false;
      $visitWindow = $visitWindowLogin;
    } else {
      $member = peminjamanFindMemberByEmail($dbs, $email);

      if (!$member || !peminjamanVerifyPassword($dbs, (string) $member['member_id'], $password, (string) ($member['mpasswd'] ?? ''))) {
        $messages['error'][] = 'Login gagal. Silakan datang ke perpustakaan untuk daftar member baru atau hubungi admin.';
      } elseif ((int) ($member['is_pending'] ?? 0) === 1) {
        $messages['error'][] = 'Akun member Anda masih dalam status pending. Silakan hubungi admin perpustakaan.';
      } elseif (isset($member['expire_date']) && $member['expire_date'] < date('Y-m-d')) {
        $messages['error'][] = 'Keanggotaan Anda sudah kedaluwarsa (expired: ' . htmlspecialchars($member['expire_date']) . '). Silakan hubungi admin untuk perpanjangan.';
      } else {
        $memberId = (string) $member['member_id'];
        if (!$allowLoanWithoutVisitor && !peminjamanHasVisitorToday($dbs, $memberId)) {
          $pushFlashAndRedirect($redirectVisitorUrl, [
            'error' => ['Login berhasil, tetapi Anda belum isi visitor hari ini. Anda akan diarahkan ke halaman Visitor.']
          ]);
        } else {
          $_SESSION['peminjaman_auth'] = [
            'member_id' => $memberId,
            'visit_location' => $visitLocation,
            'login_at' => peminjamanNow()
          ];
          $_SESSION['peminjaman_cart'] = [];
          $auth = $_SESSION['peminjaman_auth'];
          $authMember = $member;
          $visitWindow = $visitWindowLogin;
          $loanServiceOpen = true;
          $messages['success'][] = 'Login berhasil. Anda bisa membuat request transaksi peminjaman.';
        }
      }
    }
  }
}

if ($auth && isset($_POST['update_location'])) {
  $newLocation = peminjamanNormalizeText((string) ($_POST['visit_location'] ?? ''), 120);
  if ($newLocation === '') {
    $messages['error'][] = 'Lokasi kunjungan harus dipilih.';
  } else {
    $_SESSION['peminjaman_auth']['visit_location'] = $newLocation;
    $auth = $_SESSION['peminjaman_auth'];
    $visitWindow = $resolveVisitWindow($newLocation);
    $loanServiceOpen = !empty($visitWindow['allowed']);
    if ($loanServiceOpen) {
      $messages['success'][] = 'Lokasi kunjungan berhasil diperbarui.';
    } else {
      $messages['info'][] = 'Lokasi diperbarui, namun layanan peminjaman sedang tutup. ' . (string) ($visitWindow['reason'] ?? '');
    }
  }
}

if ($auth && isset($_POST['add_item_code'])) {
  if (!$loanServiceOpen) {
    $messages['error'][] = 'Peminjaman ditutup sementara karena jadwal visitor sedang tidak aktif.';
  } else {
    $itemCode = trim((string) ($_POST['item_code'] ?? ''));
    if ($itemCode === '') {
      $messages['error'][] = 'Item code / barcode wajib diisi.';
    } else {
      $item = peminjamanFindItemByCode($dbs, $itemCode);
      if (!$item) {
        $messages['error'][] = 'Item code tidak ditemukan.';
      } elseif ((int) ($item['no_loan'] ?? 0) > 0) {
        $messages['error'][] = 'Item "' . htmlspecialchars((string) ($item['title'] ?? $itemCode)) . '" tidak diizinkan untuk dipinjam (status: ' . htmlspecialchars((string) ($item['item_status_name'] ?? 'No Loan')) . ').';
      } else {
        $normalizedCode = (string) $item['item_code'];
        $dailyLimit = peminjamanCheckSameItemDailyLimit(
          $dbs,
          (string) ($auth['member_id'] ?? ''),
          $normalizedCode,
          $sameItemDailyLimitValue
        );
        if (empty($dailyLimit['allowed'])) {
          $messages['error'][] = (string) ($dailyLimit['message'] ?? 'Batas peminjaman harian untuk item ini sudah tercapai.');
        } else {
          $usageNow = peminjamanGetDailyLoanUsage($dbs, (string) ($auth['member_id'] ?? ''), (int) ($dailyLoanUsage['limit'] ?? 3));
          $plannedCartCount = count($_SESSION['peminjaman_cart']);
          if (!isset($_SESSION['peminjaman_cart'][$normalizedCode])) {
            $plannedCartCount++;
          }
          if (((int) ($usageNow['used'] ?? 0) + $plannedCartCount) > (int) ($usageNow['limit'] ?? 3)) {
            $messages['error'][] = 'Batas pinjam harian tercapai. Maksimal ' . (int) ($usageNow['limit'] ?? 3) . ' buku per hari, sisa kuota saat ini: ' . (int) ($usageNow['remaining'] ?? 0) . '.';
          } else {
            $_SESSION['peminjaman_cart'][$normalizedCode] = [
              'item_code' => $normalizedCode,
              'title' => (string) ($item['title'] ?? '-'),
              'location' => (string) ($item['location_name'] ?? '-'),
              'on_loan' => (int) ($item['on_loan'] ?? 0)
            ];
            if ((int) ($item['on_loan'] ?? 0) > 0) {
              $messages['info'][] = 'Item masuk daftar request, tetapi saat ini statusnya masih dipinjam. Admin akan memutuskan saat approval.';
            } else {
              $messages['success'][] = 'Item berhasil ditambahkan ke daftar request pinjam.';
            }
          }
        }
      }
    }
  }
}

if ($auth && isset($_POST['remove_item_code'])) {
  $removeCode = trim((string) ($_POST['remove_code'] ?? ''));
  if ($removeCode !== '' && isset($_SESSION['peminjaman_cart'][$removeCode])) {
    unset($_SESSION['peminjaman_cart'][$removeCode]);
    $messages['success'][] = 'Item dihapus dari daftar request.';
  }
}

if ($auth && isset($_POST['clear_cart'])) {
  $_SESSION['peminjaman_cart'] = [];
  $messages['success'][] = 'Daftar request pinjam dikosongkan.';
}

if ($auth && isset($_POST['submit_loan_request'])) {
  if (!$loanServiceOpen) {
    $messages['error'][] = 'Peminjaman ditutup sementara karena jadwal visitor sedang tidak aktif.';
  } else {
    $cartItems = array_values($_SESSION['peminjaman_cart']);
    $requestItems = [];
    $unavailableItems = [];

    // Re-validate all cart items in real-time before submitting
    foreach ($cartItems as $cartItem) {
      $itemCode = trim((string) ($cartItem['item_code'] ?? ''));
      if ($itemCode === '') {
        continue;
      }
      $freshItem = peminjamanFindItemByCode($dbs, $itemCode);
      if (!$freshItem) {
        $unavailableItems[] = $itemCode . ' (tidak ditemukan)';
        continue;
      }
      if ((int) ($freshItem['no_loan'] ?? 0) > 0) {
        $unavailableItems[] = $itemCode . ' (tidak boleh dipinjam)';
        continue;
      }

      $dailyLimit = peminjamanCheckSameItemDailyLimit(
        $dbs,
        (string) ($auth['member_id'] ?? ''),
        $itemCode,
        $sameItemDailyLimitValue
      );
      if (empty($dailyLimit['allowed'])) {
        $unavailableItems[] = $itemCode . ' (batas harian tercapai)';
        $messages['error'][] = (string) ($dailyLimit['message'] ?? '');
        continue;
      }

      $requestItems[] = [
        'item_code' => $itemCode,
        'loan_id' => null
      ];
    }

    if (count($unavailableItems) > 0) {
      $messages['info'][] = 'Beberapa item tidak bisa diproses: ' . implode(', ', $unavailableItems);
    }

    if (count($requestItems) < 1) {
      $messages['error'][] = 'Tidak ada item valid untuk request pinjam.';
    } else {
      $usageNow = peminjamanGetDailyLoanUsage($dbs, (string) ($auth['member_id'] ?? ''), (int) ($dailyLoanUsage['limit'] ?? 3));
      $requestedCount = count($requestItems);
      if (((int) ($usageNow['used'] ?? 0) + $requestedCount) > (int) ($usageNow['limit'] ?? 3)) {
        $messages['error'][] = 'Permintaan melebihi batas pinjam harian. Maksimal ' . (int) ($usageNow['limit'] ?? 3) . ' buku per hari. Sisa kuota hari ini: ' . (int) ($usageNow['remaining'] ?? 0) . '.';
      } else {
      $memberContext = $authMember ?: peminjamanGetMemberFresh($dbs, (string) ($auth['member_id'] ?? ''));
      $error = '';
      $created = peminjamanCreateRequest($dbs, [
        'action_type' => 'loan',
        'member_id' => (string) ($auth['member_id'] ?? ''),
        'member_email' => (string) ($memberContext['member_email'] ?? ''),
        'member_name' => (string) ($memberContext['member_name'] ?? ''),
        'member_type_name' => (string) ($memberContext['member_type_name'] ?? '-'),
        'visit_location' => (string) ($auth['visit_location'] ?? ''),
        'request_note' => trim((string) ($_POST['request_note_loan'] ?? '')),
        'created_ip' => (string) ip()
      ], $requestItems, $error);

      if ($created) {
        $_SESSION['peminjaman_cart'] = [];
        $messages['success'][] = 'Request pinjam berhasil dikirim. Kode request: ' . $created['request_code'];
      } else {
        $messages['error'][] = 'Gagal membuat request pinjam. ' . ($error ?: 'Coba lagi.');
      }
      }
    }
  }
}

if ($auth && isset($_POST['submit_return_request'])) {
  if (!$loanServiceOpen) {
    $messages['error'][] = 'Layanan pengembalian via OPAC ditutup sementara karena jadwal visitor tidak aktif.';
  } else {
    $selectedLoans = isset($_POST['loan_ids_return']) && is_array($_POST['loan_ids_return'])
      ? array_map('intval', $_POST['loan_ids_return'])
      : [];

    $activeLoans = peminjamanGetActiveLoans($dbs, (string) $auth['member_id']);
    $loanMap = [];
    foreach ($activeLoans as $loanRow) {
      $loanMap[(int) $loanRow['loan_id']] = $loanRow;
    }

    $requestItems = [];
    foreach ($selectedLoans as $loanId) {
      if (!isset($loanMap[$loanId])) {
        continue;
      }
      // Cek apakah sudah ada pending request untuk item ini
      $checkItemCode = (string) $loanMap[$loanId]['item_code'];
      $pendingCheck = $dbs->query("SELECT r.request_id FROM peminjaman_request r
        INNER JOIN peminjaman_request_item ri ON r.request_id = ri.request_id
        WHERE r.member_id = '" . $dbs->real_escape_string((string) $auth['member_id']) . "'
        AND ri.item_code = '" . $dbs->real_escape_string($checkItemCode) . "'
        AND r.status = 'pending'
        LIMIT 1");
      if ($pendingCheck && $pendingCheck->num_rows > 0) {
        $messages['error'][] = 'Sudah ada request pending untuk item ' . htmlspecialchars($checkItemCode) . '. Tunggu admin memproses request sebelumnya.';
        $pendingCheck->free_result();
        continue;
      }
      if ($pendingCheck)
        $pendingCheck->free_result();
      $requestItems[] = [
        'item_code' => $checkItemCode,
        'loan_id' => $loanId
      ];
    }

    $memberContext = $authMember ?: peminjamanGetMemberFresh($dbs, (string) ($auth['member_id'] ?? ''));
    $error = '';
    $created = peminjamanCreateRequest($dbs, [
      'action_type' => 'return',
      'member_id' => (string) ($auth['member_id'] ?? ''),
      'member_email' => (string) ($memberContext['member_email'] ?? ''),
      'member_name' => (string) ($memberContext['member_name'] ?? ''),
      'member_type_name' => (string) ($memberContext['member_type_name'] ?? '-'),
      'visit_location' => (string) ($auth['visit_location'] ?? ''),
      'request_note' => trim((string) ($_POST['request_note_return'] ?? '')),
      'created_ip' => (string) ip()
    ], $requestItems, $error);

    if ($created) {
      // Auto-approve return request — pengembalian tidak perlu approval admin
      $autoResult = peminjamanProcessRequest(
        $dbs,
        (int) $created['request_id'],
        true, // approve
        'Pengembalian otomatis diproses.',
        [
          'uid' => 0,
          'username' => 'system (auto-return)'
        ],
        $sysconf ?? []
      );
      if (!empty($autoResult['ok']) && ($autoResult['final_status'] ?? '') === 'approved') {
        $messages['success'][] = 'Buku berhasil dikembalikan! (Kode: ' . $created['request_code'] . ')';
      } else {
        $messages['success'][] = 'Request kembali dikirim. Kode: ' . $created['request_code'] . '. ' . ($autoResult['message'] ?? '');
      }
    } else {
      $messages['error'][] = 'Gagal membuat request kembali. ' . ($error ?: 'Pilih minimal satu item pinjaman.');
    }
  }
}

if ($isPostRequest) {
  $redirectParams = [];
  $postedMode = strtolower(trim((string) ($_POST['mode'] ?? $mode)));
  if (in_array($postedMode, ['login', 'status'], true)) {
    $redirectParams['mode'] = $postedMode;
  }

  if (isset($_POST['check_status'])) {
    $redirectParams['check_status'] = '1';
    $statusMember = trim((string) ($_POST['status_member_id'] ?? ''));
    if ($statusMember !== '') {
      $redirectParams['status_member_id'] = $statusMember;
    }
    $statusFilter = trim((string) ($_POST['status_list_filter'] ?? ''));
    if ($statusFilter !== '') {
      $redirectParams['status_list_filter'] = $statusFilter;
    }
    $statusMonth = trim((string) ($_POST['status_list_month'] ?? ''));
    if ($statusMonth !== '') {
      $redirectParams['status_list_month'] = $statusMonth;
    }
  }

  if (isset($_POST['member_list_filter']) || isset($_POST['member_list_month'])) {
    $memberFilter = trim((string) ($_POST['member_list_filter'] ?? ''));
    if ($memberFilter !== '') {
      $redirectParams['member_list_filter'] = $memberFilter;
    }
    $memberMonth = trim((string) ($_POST['member_list_month'] ?? ''));
    if ($memberMonth !== '') {
      $redirectParams['member_list_month'] = $memberMonth;
    }
  }

  if (!$auth) {
    $postedLocation = trim((string) ($_POST['visit_location'] ?? ''));
    if ($postedLocation !== '') {
      $redirectParams['visit_location'] = $postedLocation;
    }
  }

  $pushFlashAndRedirect($buildPeminjamanUrl($redirectParams), $messages);
}



$auth = $_SESSION['peminjaman_auth'] ?? null;
$cart = $_SESSION['peminjaman_cart'] ?? [];
$activeLoans = [];
$memberRequests = [];
$cartLiveItemMap = [];
$pendingRequestMapByItem = [];

if ($auth && !empty($auth['member_id'])) {
  $authMember = peminjamanGetMemberFresh($dbs, (string) $auth['member_id']);
  if (!$authMember) {
    unset($_SESSION['peminjaman_auth'], $_SESSION['peminjaman_cart']);
    $auth = null;
    $cart = [];
    $messages['error'][] = 'Data member tidak ditemukan. Silakan login ulang.';
  } else {
    $sessionLocation = trim((string) ($auth['visit_location'] ?? ''));
    if ($sessionLocation === '' && !empty($locations[0])) {
      $sessionLocation = (string) $locations[0];
      $_SESSION['peminjaman_auth']['visit_location'] = $sessionLocation;
      $auth = $_SESSION['peminjaman_auth'];
    }

    $visitWindow = $resolveVisitWindow($sessionLocation);
    $loanServiceOpen = !empty($visitWindow['allowed']);
    if (!$loanServiceOpen) {
      $windowInfo = 'Layanan peminjaman sedang tutup. ' . (string) ($visitWindow['reason'] ?? '');
      if (!in_array($windowInfo, $messages['info'], true)) {
        $messages['info'][] = $windowInfo;
      }
    }

    $dailyLoanUsage = peminjamanGetDailyLoanUsage($dbs, (string) $auth['member_id'], (int) ($dailyLoanUsage['limit'] ?? 3));
    $activeLoans = peminjamanGetActiveLoans($dbs, (string) $auth['member_id']);
    $memberRequests = peminjamanGetRequestsByMemberId($dbs, (string) $auth['member_id'], 20);
  }
} else {
  $candidateLocation = trim((string) ($_REQUEST['visit_location'] ?? ''));
  if ($candidateLocation !== '') {
    $visitWindow = $resolveVisitWindow($candidateLocation);
    $loanServiceOpen = !empty($visitWindow['allowed']);
  }
}

if (count($cart) > 0) {
  $cartCodes = [];
  foreach ($cart as $cartRow) {
    $code = trim((string) ($cartRow['item_code'] ?? ''));
    if ($code !== '') {
      $cartCodes[] = $code;
    }
  }
  if (count($cartCodes) > 0) {
    $cartLiveItemMap = peminjamanGetItemsByCodes($dbs, $cartCodes);
  }
}

if ($auth && count($activeLoans) > 0) {
  $loanCodes = [];
  foreach ($activeLoans as $loanRow) {
    $code = trim((string) ($loanRow['item_code'] ?? ''));
    if ($code !== '') {
      $loanCodes[] = $code;
    }
  }
  if (count($loanCodes) > 0) {
    $pendingRequestMapByItem = peminjamanGetPendingRequestMapForMemberItems($dbs, (string) ($auth['member_id'] ?? ''), $loanCodes);
  }
}

$statusRows = [];
$statusMemberId = trim((string) ($_REQUEST['status_member_id'] ?? ''));
$isCheckingStatus = $mode === 'status' && (isset($_POST['check_status']) || isset($_GET['check_status']));
if ($isCheckingStatus) {
  if ($statusMemberId === '') {
    $messages['error'][] = 'Member ID wajib diisi untuk cek status.';
  } else {
    $statusRows = peminjamanGetRequestsByMemberId($dbs, $statusMemberId, 50);
    if (count($statusRows) < 1) {
      $messages['info'][] = 'Belum ada data request peminjaman untuk Member ID tersebut.';
    }
  }
}

$buildRelativeMeta = static function (string $datetimeValue): array {
  $requestedDate = preg_match('/^\d{4}-\d{2}-\d{2}/', $datetimeValue) ? substr($datetimeValue, 0, 10) : '';
  $relativeLabel = 'Telah Lalu';
  $relativeBadge = 'secondary';
  if ($requestedDate === date('Y-m-d')) {
    $relativeLabel = 'Hari Ini';
    $relativeBadge = 'primary';
  } elseif ($requestedDate === date('Y-m-d', strtotime('-1 day'))) {
    $relativeLabel = 'Kemarin';
    $relativeBadge = 'warning';
  }
  return [
    'label' => $relativeLabel,
    'badge' => $relativeBadge
  ];
};

$requestFilterOptions = [
  'all' => 'Semua',
  'approved' => 'Disetujui',
  'rejected' => 'Ditolak',
  'renewed' => 'Diperpanjang',
  'returned' => 'Dikembalikan',
  'today' => 'Hari Ini',
  'yesterday' => 'Kemarin',
  'past' => 'Telah Lalu'
];

$normalizeRequestFilter = static function (string $value) use ($requestFilterOptions): string {
  $value = trim(strtolower($value));
  if (!array_key_exists($value, $requestFilterOptions)) {
    return 'all';
  }
  return $value;
};

$normalizeMonthFilter = static function (string $value): string {
  $value = trim($value);
  if ($value === '' || !preg_match('/^\d{4}-\d{2}$/', $value)) {
    return '';
  }
  return $value;
};

$filterRequestRows = static function (array $rows, string $filterKey, string $monthFilter = ''): array {
  $filterKey = trim(strtolower($filterKey));
  $monthFilter = trim($monthFilter);
  if ($filterKey === '' || $filterKey === 'all') {
    if ($monthFilter === '') {
      return $rows;
    }
  }

  $today = date('Y-m-d');
  $yesterday = date('Y-m-d', strtotime('-1 day'));
  $filtered = [];

  foreach ($rows as $row) {
    $status = (string) ($row['status'] ?? '');
    $action = strtolower(trim((string) ($row['action_type'] ?? '')));
    $approvedCount = (int) ($row['item_approved'] ?? 0);
    $isApprovedLike = ($status === 'approved') || ($status === 'partial' && $approvedCount > 0);
    $isRejectedLike = in_array($status, ['rejected', 'failed'], true) || ($status === 'partial' && $approvedCount < 1);
    $isRenewAction = in_array($action, ['extend', 'renew', 'renewal'], true);
    $requestedAt = (string) ($row['requested_at'] ?? '');
    $requestedDate = preg_match('/^\d{4}-\d{2}-\d{2}/', $requestedAt) ? substr($requestedAt, 0, 10) : '';
    $requestedMonth = $requestedDate !== '' ? substr($requestedDate, 0, 7) : '';

    if ($monthFilter !== '' && $requestedMonth !== $monthFilter) {
      continue;
    }

    $match = false;
    if ($filterKey === '' || $filterKey === 'all') {
      $match = true;
    } elseif ($filterKey === 'approved') {
      $match = $action === 'loan' && $isApprovedLike;
    } elseif ($filterKey === 'rejected') {
      $match = $isRejectedLike;
    } elseif ($filterKey === 'renewed') {
      $match = $isRenewAction && $isApprovedLike;
    } elseif ($filterKey === 'returned') {
      $match = $action === 'return' && $isApprovedLike;
    } elseif ($filterKey === 'today') {
      $match = ($requestedDate === $today);
    } elseif ($filterKey === 'yesterday') {
      $match = ($requestedDate === $yesterday);
    } elseif ($filterKey === 'past') {
      $match = ($requestedDate !== '' && $requestedDate !== $today && $requestedDate !== $yesterday);
    }

    if ($match) {
      $filtered[] = $row;
    }
  }

  return $filtered;
};

$statusListFilter = $normalizeRequestFilter((string) ($_REQUEST['status_list_filter'] ?? 'all'));
$memberListFilter = $normalizeRequestFilter((string) ($_REQUEST['member_list_filter'] ?? 'all'));
$statusListMonth = $normalizeMonthFilter((string) ($_REQUEST['status_list_month'] ?? ''));
$memberListMonth = $normalizeMonthFilter((string) ($_REQUEST['member_list_month'] ?? ''));

$filteredStatusRows = $filterRequestRows($statusRows, $statusListFilter, $statusListMonth);
$filteredMemberRequests = $filterRequestRows($memberRequests, $memberListFilter, $memberListMonth);
$statusItemMap = [];
if (count($filteredStatusRows) > 0) {
  $statusRequestIds = [];
  foreach ($filteredStatusRows as $statusRow) {
    $rid = (int) ($statusRow['request_id'] ?? 0);
    if ($rid > 0) {
      $statusRequestIds[] = $rid;
    }
  }
  if (count($statusRequestIds) > 0) {
    $statusItemMap = peminjamanGetItemDetailMapForRequests($dbs, $statusRequestIds);
  }
}

$selectedLocation = trim((string) ($auth['visit_location'] ?? ($_REQUEST['visit_location'] ?? '')));
$isGuestLoginState = !$auth;
$mustPickLocationFirst = $isGuestLoginState && $selectedLocation === '';
$windowLocationLabel = $selectedLocation !== '' ? $selectedLocation : '-';
$locationServiceMap = [];
$hasAnyOpenLocation = false;
foreach ($locations as $locationOption) {
  $locationName = trim((string) $locationOption);
  if ($locationName === '') {
    continue;
  }
  $locationWindow = $resolveVisitWindow($locationName);
  $isLocationOpen = !empty($locationWindow['allowed']);
  $locationServiceMap[$locationName] = [
    'allowed' => $isLocationOpen,
    'reason' => (string) ($locationWindow['reason'] ?? '')
  ];
  if ($isLocationOpen) {
    $hasAnyOpenLocation = true;
  }
}

$allLocationsClosed = !$auth && !$hasAnyOpenLocation;
$selectedLocationMeta = $locationServiceMap[$selectedLocation] ?? null;
$loginBySelectedLocationOpen = false;
if (!$mustPickLocationFirst && is_array($selectedLocationMeta)) {
  $loginBySelectedLocationOpen = !empty($selectedLocationMeta['allowed']);
}
$loginInputEnabled = (!$mustPickLocationFirst && $loginBySelectedLocationOpen);
$loginBySelectedLocationReason = '';
if ($mustPickLocationFirst) {
  $loginBySelectedLocationReason = 'Pilih lokasi kunjungan terlebih dahulu.';
} elseif (is_array($selectedLocationMeta)) {
  $loginBySelectedLocationReason = (string) ($selectedLocationMeta['reason'] ?? '');
} else {
  $loginBySelectedLocationReason = (string) ($visitWindow['reason'] ?? '');
}
if ($allLocationsClosed) {
  $allClosedInfo = 'Semua lokasi layanan peminjaman sedang tutup. Pilih lokasi untuk cek jadwal buka.';
  if (!in_array($allClosedInfo, $messages['info'], true)) {
    $messages['info'][] = $allClosedInfo;
  }
}

$locationServiceMapJs = json_encode($locationServiceMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$loginLocationClosedText = json_encode('Login nonaktif: perpustakaan tutup untuk lokasi ini.', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$loginChooseLocationText = json_encode('Pilih lokasi kunjungan terlebih dahulu.', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$loginAllClosedText = json_encode('Mode Login dinonaktifkan karena semua lokasi sedang tutup.', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$allLocationsClosedJs = $allLocationsClosed ? 'true' : 'false';

?>
<style>
  .peminjaman-wrap {
    --pmj-surface: #ffffff;
    --pmj-surface-soft: #f8fafc;
    --pmj-border: rgba(30, 41, 59, 0.35);
    --pmj-text: #0b1220;
    --pmj-muted: #1e293b;
    --pmj-accent: #0ea5e9;
    --pmj-warning: #d97706;
    --pmj-danger: #dc2626;
    --pmj-shadow: 0 8px 18px rgba(15, 23, 42, 0.12);
    width: 100%;
    max-width: 1420px;
    margin: 0 auto;
    padding: 10px 10px 22px;
  }

  .peminjaman-card {
    background: var(--pmj-surface);
    border: 1px solid var(--pmj-border);
    border-radius: 12px;
    box-shadow: var(--pmj-shadow);
    padding: 20px;
    margin-bottom: 16px;
  }

  .peminjaman-title {
    margin: 0 0 12px;
    font-size: 1.48rem;
    font-weight: 800;
    letter-spacing: 0.01em;
    color: var(--pmj-text);
  }

  .peminjaman-subtitle {
    margin: 0 0 14px;
    color: var(--pmj-muted);
  }

  .peminjaman-table-wrap {
    overflow-x: auto;
    border: 1px solid var(--pmj-border);
    border-radius: 12px;
    background: var(--pmj-surface-soft);
  }

  .peminjaman-wrap,
  .peminjaman-card,
  .peminjaman-form-row,
  .peminjaman-table-wrap,
  .peminjaman-table {
    direction: ltr;
  }

  .s-main-page .s-main-content.s-main-content-wide {
    max-width: 1500px;
    margin-left: auto !important;
    margin-right: auto !important;
    padding-left: 16px !important;
    padding-right: 16px !important;
  }

  .s-main-page .s-main-content.s-main-content-wide>.row {
    margin-left: -8px !important;
    margin-right: -8px !important;
  }

  .s-main-page .s-main-content.s-main-content-wide>.row>[class*="col-"] {
    padding-left: 8px !important;
    padding-right: 8px !important;
  }

  .peminjaman-table {
    width: 100%;
    border-collapse: collapse;
  }

  .peminjaman-table th,
  .peminjaman-table td {
    border: 1px solid rgba(148, 163, 184, 0.5);
    padding: 10px;
    color: var(--pmj-text);
    font-size: 15px;
    font-weight: 600;
    vertical-align: top;
    text-align: left;
  }

  .peminjaman-table th {
    background: linear-gradient(180deg, #e2e8f0 0%, #cbd5e1 100%);
    font-weight: 800;
    white-space: nowrap;
  }

  .peminjaman-table tbody tr:nth-child(even) {
    background: rgba(248, 250, 252, 0.8);
  }

  .peminjaman-row-overdue td {
    background: #fef2f2 !important;
    border-color: #fecaca !important;
    color: #7f1d1d;
  }

  .peminjaman-form-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 12px;
  }

  .peminjaman-compact-row {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    align-items: center;
  }

  .peminjaman-label {
    color: var(--pmj-text);
    font-weight: 600;
    margin-bottom: 6px;
    display: block;
  }

  .peminjaman-badge {
    display: inline-block;
    padding: 5px 12px;
    border-radius: 999px;
    font-size: 13px;
    font-weight: 800;
    line-height: 1.2;
    color: #fff;
  }

  .peminjaman-badge.badge-success {
    background: #16a34a;
  }

  .peminjaman-badge.badge-danger {
    background: #dc2626;
  }

  .peminjaman-badge.badge-warning {
    background: #d97706;
  }

  .peminjaman-badge.badge-info {
    background: #0284c7;
  }

  .peminjaman-badge.badge-primary {
    background: #1d4ed8;
  }

  .peminjaman-badge.badge-secondary {
    background: #4b5563;
  }

  .peminjaman-muted {
    color: var(--pmj-muted);
    font-size: 13px;
  }

  .peminjaman-window-status {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    border-radius: 10px;
    padding: 10px 12px;
    border: 1px solid #bae6fd;
    background: #eff6ff;
    color: #0c4a6e;
    margin-bottom: 14px;
    font-size: 13px;
  }

  .peminjaman-window-status.is-closed {
    border-color: #fed7aa;
    background: #fff7ed;
    color: #9a3412;
  }

  .peminjaman-status-stack {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    align-items: center;
  }

  .peminjaman-status-note {
    font-size: 11px;
    color: var(--pmj-muted);
    margin-top: 4px;
    display: block;
  }

  .peminjaman-member-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 10px;
  }

  .peminjaman-member-grid .item {
    border: 1px solid rgba(148, 163, 184, 0.45);
    border-radius: 10px;
    padding: 10px;
    background: var(--pmj-surface-soft);
  }

  .peminjaman-member-grid .item strong {
    display: block;
    color: #334155;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: .04em;
  }

  .peminjaman-member-grid .item span {
    display: block;
    color: var(--pmj-text);
    margin-top: 4px;
    font-weight: 600;
  }

  .peminjaman-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .peminjaman-empty {
    border: 1px dashed #94a3b8;
    border-radius: 10px;
    padding: 12px;
    color: #334155;
    background: #f8fafc;
  }

  .peminjaman-quota-box {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 12px;
    border: 1px solid #fde68a;
    border-radius: 999px;
    background: #fffbeb;
    color: #92400e;
    font-weight: 700;
    font-size: 12px;
    margin-bottom: 12px;
  }

  .peminjaman-wrap .form-control,
  .peminjaman-wrap .btn {
    font-size: 14px;
  }

  .peminjaman-wrap input::placeholder {
    color: #64748b;
    opacity: 1;
  }

  @media (max-width: 640px) {
    .peminjaman-wrap {
      padding: 8px 4px 16px;
    }

    .s-main-page .s-main-content.s-main-content-wide {
      padding-left: 8px !important;
      padding-right: 8px !important;
    }

    .peminjaman-card {
      padding: 12px;
    }

    .peminjaman-table th,
    .peminjaman-table td {
      font-size: 12px;
      padding: 7px;
    }
  }
</style>

<div class="peminjaman-wrap s-main">
  <div class="peminjaman-card">
    <h2 class="peminjaman-title">Peminjaman Koleksi</h2>

    <form method="get" class="peminjaman-form-row">
      <input type="hidden" name="p" value="peminjaman">
      <div>
        <label class="peminjaman-label" for="modeSelect">Mode Layanan</label>
        <select id="modeSelect" name="mode" class="form-control" onchange="this.form.submit()">
          <option value="login" <?php echo $mode === 'login' ? ' selected' : ''; ?>>Login</option>
          <option value="status" <?php echo $mode === 'status' ? ' selected' : ''; ?>>Cek Status Peminjaman</option>
        </select>
      </div>
    </form>
  </div>

  <?php foreach (['error' => 'danger', 'success' => 'success'] as $messageType => $alertClass) { ?>
    <?php foreach ($messages[$messageType] as $message) { ?>
      <div class="alert alert-<?php echo $alertClass; ?>"><?php echo htmlspecialchars($message); ?></div>
    <?php } ?>
  <?php } ?>

  <?php if ($mode === 'login') { ?>
    <div class="peminjaman-window-status<?php echo $loanServiceOpen ? '' : ' is-closed'; ?>">
      <div><strong><?php echo $loanServiceOpen ? 'Jam Layanan Aktif' : 'Jam Layanan Tutup'; ?></strong></div>
      <div>
        Lokasi: <strong><?php echo htmlspecialchars($windowLocationLabel); ?></strong><br>
        <?php echo htmlspecialchars((string) ($visitWindow['reason'] ?? ($loanServiceOpen ? 'Layanan mengikuti jadwal visitor.' : 'Layanan peminjaman ditutup sementara.'))); ?>
      </div>
    </div>
  <?php } ?>

  <?php if ($mode === 'status') { ?>
    <div class="peminjaman-card">
      <h3 class="peminjaman-title">Cek Status Peminjaman Koleksi</h3>
      <form method="get" class="peminjaman-form-row">
        <input type="hidden" name="p" value="peminjaman">
        <input type="hidden" name="mode" value="status">
        <div>
          <label class="peminjaman-label" for="statusMemberId">Member ID</label>
          <input type="text" id="statusMemberId" name="status_member_id" class="form-control"
            value="<?php echo htmlspecialchars($statusMemberId); ?>" placeholder="Masukkan Member ID">
        </div>
        <div>
          <label class="peminjaman-label" for="statusListFilter">Filter Status</label>
          <select id="statusListFilter" name="status_list_filter" class="form-control">
            <?php foreach ($requestFilterOptions as $filterKey => $filterLabel) { ?>
              <option value="<?php echo htmlspecialchars($filterKey); ?>" <?php echo $statusListFilter === $filterKey ? ' selected' : ''; ?>>
                <?php echo htmlspecialchars($filterLabel); ?>
              </option>
            <?php } ?>
          </select>
        </div>
        <div>
          <label class="peminjaman-label" for="statusListMonth">Filter Bulan</label>
          <input type="month" id="statusListMonth" name="status_list_month" class="form-control"
            value="<?php echo htmlspecialchars($statusListMonth); ?>">
        </div>
        <div style="align-self:end;">
          <button type="submit" name="check_status" class="btn btn-primary">Cek Status</button>
        </div>
      </form>

      <?php if (count($statusRows) > 0) { ?>
        <?php if (count($filteredStatusRows) < 1) { ?>
          <div class="peminjaman-empty" style="margin-top:12px;">Data tidak ditemukan untuk filter yang dipilih.</div>
        <?php } else { ?>
        <div class="peminjaman-table-wrap" style="margin-top:12px;">
          <table class="peminjaman-table">
            <thead>
              <tr>
                <th>Kode Request</th>
                <th>Aksi</th>
                <th>Lokasi</th>
                <th>Status</th>
                <th>Waktu Request</th>
                <th>Catatan Admin</th>
              </tr>
            </thead>
              <tbody>
              <?php foreach ($filteredStatusRows as $row) {
                $requestItems = $statusItemMap[(int) ($row['request_id'] ?? 0)] ?? [];
                $relativeMeta = $buildRelativeMeta((string) ($row['requested_at'] ?? ''));
                ?>
                <tr>
                  <td><?php echo htmlspecialchars((string) $row['request_code']); ?></td>
                  <td><?php echo htmlspecialchars(peminjamanActionLabel((string) $row['action_type'])); ?></td>
                  <td><?php echo htmlspecialchars((string) ($row['visit_location'] ?: '-')); ?></td>
                  <td>
                    <div class="peminjaman-status-stack">
                      <span
                        class="peminjaman-badge badge-<?php echo htmlspecialchars(peminjamanBadgeClass((string) $row['status'])); ?>">
                        <?php echo htmlspecialchars(peminjamanStatusLabel((string) $row['status'])); ?>
                      </span>
                      <span class="peminjaman-badge badge-<?php echo htmlspecialchars((string) ($relativeMeta['badge'] ?? 'secondary')); ?>">
                        <?php echo htmlspecialchars((string) ($relativeMeta['label'] ?? 'Telah Lalu')); ?>
                      </span>
                    </div>
                  </td>
                  <td><?php echo htmlspecialchars((string) $row['requested_at']); ?></td>
                  <td><?php echo htmlspecialchars((string) ($row['admin_note'] ?: $row['process_result'] ?: '-')); ?></td>
                </tr>
                <?php if (count($requestItems) > 0) { ?>
                  <tr>
                    <td colspan="6" style="padding:4px 8px 12px;">
                      <table class="peminjaman-table" style="margin:0; font-size:13px;">
                        <thead>
                          <tr>
                            <th>Item Code</th>
                            <th>Judul</th>
                            <th>Lokasi Item</th>
                            <th>Status Item</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($requestItems as $ri) { ?>
                            <tr>
                              <td><?php echo htmlspecialchars((string) ($ri['item_code'] ?: '-')); ?></td>
                              <td><?php echo htmlspecialchars((string) $ri['title']); ?></td>
                              <td><?php echo htmlspecialchars((string) $ri['item_location']); ?></td>
                              <td>
                                <span
                                  class="peminjaman-badge badge-<?php echo htmlspecialchars(peminjamanBadgeClass((string) $ri['item_status'])); ?>">
                                  <?php echo htmlspecialchars(peminjamanStatusLabel((string) $ri['item_status'])); ?>
                                </span>
                                <?php if (trim((string) ($ri['process_message'] ?? '')) !== '') { ?>
                                  <br><small><?php echo htmlspecialchars((string) $ri['process_message']); ?></small>
                                <?php } ?>
                              </td>
                            </tr>
                          <?php } ?>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                <?php } ?>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <?php } ?>
      <?php } ?>
    </div>
  <?php } else { ?>

    <?php if (!$auth) { ?>
      <div class="peminjaman-card">
        <h3 class="peminjaman-title">Login Member</h3>
        <form method="post" class="peminjaman-form-row">
          <input type="hidden" name="mode" value="login">
          <div>
            <label class="peminjaman-label" for="visitLocation">Lokasi Kunjungan</label>
            <select id="visitLocation" name="visit_location" class="form-control" required>
              <option value="">Pilih Lokasi</option>
              <?php foreach ($locations as $location) { ?>
                <option value="<?php echo htmlspecialchars($location); ?>" <?php echo $selectedLocation === $location ? ' selected' : ''; ?>>
                  <?php echo htmlspecialchars($location); ?>
                </option>
              <?php } ?>
            </select>
          </div>
          <div>
            <label class="peminjaman-label" for="memberEmail">Email Member</label>
            <input type="email" id="memberEmail" name="member_email" class="form-control" placeholder="email@contoh.com"
              required<?php echo $loginInputEnabled ? '' : ' disabled'; ?>>
          </div>
          <div>
            <label class="peminjaman-label" for="memberPassword">Password</label>
            <input type="password" id="memberPassword" name="member_password" class="form-control" required<?php echo $loginInputEnabled ? '' : ' disabled'; ?>>
          </div>
          <div style="align-self:end;">
            <button id="loginSubmitBtn" type="submit" name="login_peminjaman" class="btn btn-primary"<?php echo $loginBySelectedLocationOpen ? '' : ' disabled'; ?>>Login</button>
          </div>
          <div style="grid-column:1 / -1;">
            <small id="loginServiceNotice" class="peminjaman-status-note"<?php echo $loginBySelectedLocationOpen ? ' style="display:none;"' : ''; ?>>
              <?php
              $loginNotice = trim($loginBySelectedLocationReason);
              if ($loginNotice === '') {
                $loginNotice = 'Perpustakaan sedang tutup untuk lokasi ini.';
              }
              echo 'Login nonaktif: ' . htmlspecialchars($loginNotice);
              ?>
            </small>
          </div>
        </form>
      </div>
    <?php } else { ?>
      <div class="peminjaman-card">
        <div class="peminjaman-compact-row" style="justify-content:space-between; margin-bottom:12px;">
          <h3 class="peminjaman-title" style="margin:0;">Dashboard Request Peminjaman</h3>
          <form method="post" style="margin:0;">
            <input type="hidden" name="mode" value="login">
            <button type="submit" name="logout_peminjaman" class="btn btn-outline-secondary">Logout</button>
          </form>
        </div>

        <div class="peminjaman-member-grid">
          <div class="item"><strong>Member
              Name</strong><span><?php echo htmlspecialchars((string) ($authMember['member_name'] ?? '-')); ?></span></div>
          <div class="item"><strong>Member
              ID</strong><span><?php echo htmlspecialchars((string) $auth['member_id']); ?></span></div>
          <div class="item"><strong>Member
              Email</strong><span><?php echo htmlspecialchars((string) ($authMember['member_email'] ?? '-')); ?></span></div>
          <div class="item"><strong>Member
              Type</strong><span><?php echo htmlspecialchars((string) ($authMember['member_type_name'] ?? '-')); ?></span></div>
          <div class="item"><strong>Register
              Date</strong><span><?php echo htmlspecialchars((string) ($authMember['register_date'] ?? '-')); ?></span></div>
          <div class="item"><strong>Expiry
              Date</strong><span><?php echo htmlspecialchars((string) ($authMember['expire_date'] ?? '-')); ?></span></div>
        </div>

        <form method="post" class="peminjaman-form-row" style="margin-top:12px;">
          <input type="hidden" name="mode" value="login">
          <div>
            <label class="peminjaman-label" for="visitLocationUpdate">Lokasi Peminjaman</label>
            <select id="visitLocationUpdate" name="visit_location" class="form-control">
              <?php foreach ($locations as $location) { ?>
                <option value="<?php echo htmlspecialchars($location); ?>" <?php echo $selectedLocation === $location ? ' selected' : ''; ?>><?php echo htmlspecialchars($location); ?></option>
              <?php } ?>
            </select>
          </div>
          <div style="align-self:end;">
            <button type="submit" name="update_location" class="btn btn-default">Simpan Lokasi</button>
          </div>
        </form>
      </div>

      <div class="peminjaman-card">
        <h3 class="peminjaman-title">Insert Item Code / Barcode</h3>
        <div class="peminjaman-quota-box">
          Kuota pinjam hari ini: <?php echo (int) ($dailyLoanUsage['used'] ?? 0); ?> / <?php echo (int) ($dailyLoanUsage['limit'] ?? $dailyLimitValue); ?>
          (sisa <?php echo (int) ($dailyLoanUsage['remaining'] ?? 0); ?>)
        </div>
        <form method="post" class="peminjaman-form-row">
          <input type="hidden" name="mode" value="login">
          <div>
            <label class="peminjaman-label" for="itemCodeInput">Item Code / Barcode</label>
            <input type="text" id="itemCodeInput" name="item_code" class="form-control" placeholder="Masukkan barcode item">
          </div>
          <div style="align-self:end;" class="peminjaman-actions">
            <button type="submit" name="add_item_code" class="btn btn-primary"<?php echo $loanServiceOpen ? '' : ' disabled'; ?>>Tambah</button>
            <button type="submit" name="clear_cart" class="btn btn-danger">Kosongkan</button>
          </div>
        </form>
        <?php if (!$loanServiceOpen) { ?>
          <small class="peminjaman-status-note">Aksi pinjam/nonaktif: <?php echo htmlspecialchars((string) ($visitWindow['reason'] ?? 'Mengikuti jadwal visitor.')); ?></small>
        <?php } ?>

        <?php if (count($cart) > 0) { ?>
          <div class="peminjaman-table-wrap" style="margin-top: 12px;">
            <table class="peminjaman-table">
              <thead>
                <tr>
                  <th>Item Code</th>
                  <th>Judul</th>
                  <th>Lokasi Item</th>
                  <th>Status Saat Ini</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($cart as $cartRow) {
                  // Use batch-loaded item snapshot to avoid N+1 queries.
                  $liveItem = $cartLiveItemMap[(string) ($cartRow['item_code'] ?? '')] ?? null;
                  $liveOnLoan = $liveItem ? (int) ($liveItem['on_loan'] ?? 0) : 0;
                  $liveLocation = $liveItem ? (string) ($liveItem['location_name'] ?? '-') : '-';
                  $liveNoLoan = $liveItem ? (int) ($liveItem['no_loan'] ?? 0) : 0;
                  ?>
                  <tr>
                    <td><?php echo htmlspecialchars((string) $cartRow['item_code']); ?></td>
                    <td><?php echo htmlspecialchars((string) $cartRow['title']); ?></td>
                    <td><?php echo htmlspecialchars($liveLocation); ?></td>
                    <td><?php
                    if ($liveNoLoan > 0) {
                      echo '<span class="peminjaman-badge badge-danger">Tidak Boleh Dipinjam</span>';
                    } elseif ($liveOnLoan > 0) {
                      echo '<span class="peminjaman-badge badge-warning">Sedang Dipinjam</span>';
                    } else {
                      echo '<span class="peminjaman-badge badge-success">Tersedia</span>';
                    }
                    ?></td>
                    <td>
                      <form method="post" style="margin:0;">
                        <input type="hidden" name="mode" value="login">
                        <input type="hidden" name="remove_code"
                          value="<?php echo htmlspecialchars((string) $cartRow['item_code']); ?>">
                        <button type="submit" name="remove_item_code" class="btn btn-sm btn-danger">Hapus</button>
                      </form>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>

          <form method="post" style="margin-top:12px;">
            <input type="hidden" name="mode" value="login">
            <button type="submit" name="submit_loan_request" class="btn btn-success"<?php echo $loanServiceOpen ? '' : ' disabled'; ?>>Selesaikan Transaksi (ESC)</button>
          </form>
        <?php } else { ?>
          <div class="peminjaman-empty" style="margin-top:12px;">Belum ada item di daftar request pinjam.</div>
        <?php } ?>
      </div>

      <div class="peminjaman-card">
        <h3 class="peminjaman-title">Request Pengembalian Buku</h3>

        <?php if (count($activeLoans) < 1) { ?>
          <div class="peminjaman-empty">Tidak ada pinjaman aktif untuk member ini.</div>
        <?php } else { ?>
          <div class="peminjaman-table-wrap">
            <table class="peminjaman-table">
              <thead>
                <tr>
                  <th>Loan ID</th>
                  <th>Item Code</th>
                  <th>Judul</th>
                  <th>Lokasi Item</th>
                  <th>Loan Date</th>
                  <th>Due Date</th>
                  <th>Status</th>
                  <th style="min-width:200px;">Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($activeLoans as $loan) {
                  $loanId = (int) $loan['loan_id'];
                  $loanMeta = peminjamanGetLoanStatusMeta($loan);
                  $recencyBadge = match ((string) ($loanMeta['recency_key'] ?? 'past')) {
                    'today' => 'primary',
                    'yesterday' => 'warning',
                    default => 'secondary'
                  };
                  ?>
                  <tr class="<?php echo htmlspecialchars((string) ($loanMeta['row_class'] ?? '')); ?>">
                    <td><?php echo $loanId; ?></td>
                    <td><?php echo htmlspecialchars((string) $loan['item_code']); ?></td>
                    <td><?php echo htmlspecialchars((string) $loan['title']); ?></td>
                    <td><?php echo htmlspecialchars((string) ($loan['item_location'] ?? '-')); ?></td>
                    <td><?php echo htmlspecialchars((string) $loan['loan_date']); ?></td>
                    <td><?php echo htmlspecialchars((string) $loan['due_date']); ?></td>
                    <td>
                      <div class="peminjaman-status-stack">
                        <span class="peminjaman-badge badge-<?php echo htmlspecialchars($recencyBadge); ?>">
                          <?php echo htmlspecialchars((string) ($loanMeta['recency_label'] ?? 'Telah Lalu')); ?>
                        </span>
                        <span
                          class="peminjaman-badge badge-<?php echo htmlspecialchars((string) ($loanMeta['state_badge'] ?? 'info')); ?>">
                          <?php echo htmlspecialchars((string) ($loanMeta['state_label'] ?? 'Aktif')); ?>
                        </span>
                      </div>
                      <?php if ((int) ($loan['renewed'] ?? 0) > 0) { ?>
                        <small class="peminjaman-status-note">Perpanjangan: <?php echo (int) $loan['renewed']; ?>x</small>
                      <?php } ?>
                    </td>
                    <td>
                      <?php
                      $loanItemCode = (string) ($loan['item_code'] ?? '');
                      $pRow = $pendingRequestMapByItem[$loanItemCode] ?? null;
                      $hasPendingReq = is_array($pRow);
                      if ($hasPendingReq) {
                        ?>
                        <span class="peminjaman-badge badge-warning" style="font-size:11px;">
                          ⏳ Menunggu Approval
                          (<?php echo htmlspecialchars(peminjamanActionLabel((string) ($pRow['action_type'] ?? ''))); ?>)
                        </span>
                      <?php } else { ?>
                        <div style="display:flex; gap:6px; flex-wrap:wrap;">
                          <form method="post" style="margin:0;">
                            <input type="hidden" name="mode" value="login">
                            <input type="hidden" name="loan_ids_return[]" value="<?php echo $loanId; ?>">
                            <button type="submit" name="submit_return_request" class="btn btn-sm btn-warning"
                              <?php echo $loanServiceOpen ? '' : ' disabled'; ?>
                              style="font-size:12px; padding:4px 12px; font-weight:600;"
                              onclick="return confirm('Request kembali item <?php echo htmlspecialchars((string) $loan['item_code']); ?>?');">
                              📦 Kembali
                            </button>
                          </form>

                        </div>
                      <?php } ?>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        <?php } ?>
      </div>

      <div class="peminjaman-card">
        <h3 class="peminjaman-title">Riwayat Status Request</h3>
        <?php if (count($memberRequests) < 1) { ?>
          <div class="peminjaman-empty">Belum ada riwayat request peminjaman.</div>
        <?php } else { ?>
          <form method="get" class="peminjaman-form-row" style="margin-bottom:12px;">
            <input type="hidden" name="p" value="peminjaman">
            <input type="hidden" name="mode" value="login">
            <div>
              <label class="peminjaman-label" for="memberListFilter">Filter Riwayat</label>
              <select id="memberListFilter" name="member_list_filter" class="form-control">
                <?php foreach ($requestFilterOptions as $filterKey => $filterLabel) { ?>
                  <option value="<?php echo htmlspecialchars($filterKey); ?>" <?php echo $memberListFilter === $filterKey ? ' selected' : ''; ?>>
                    <?php echo htmlspecialchars($filterLabel); ?>
                  </option>
                <?php } ?>
              </select>
            </div>
            <div>
              <label class="peminjaman-label" for="memberListMonth">Filter Bulan</label>
              <input type="month" id="memberListMonth" name="member_list_month" class="form-control"
                value="<?php echo htmlspecialchars($memberListMonth); ?>">
            </div>
            <div style="align-self:end;" class="peminjaman-actions">
              <button type="submit" class="btn btn-primary">Terapkan Filter</button>
              <a href="<?php echo htmlspecialchars($buildPeminjamanUrl([
                'mode' => 'login',
                'member_list_filter' => $memberListFilter,
                'member_list_month' => $memberListMonth
              ])); ?>" class="btn btn-info">Refresh</a>
            </div>
          </form>

          <?php if (count($filteredMemberRequests) < 1) { ?>
            <div class="peminjaman-empty" style="margin-bottom:12px;">Data riwayat tidak ditemukan untuk filter yang dipilih.</div>
          <?php } else { ?>
          <div class="peminjaman-table-wrap">
            <table class="peminjaman-table">
              <thead>
                <tr>
                  <th>Kode Request</th>
                  <th>Aksi</th>
                  <th>Status</th>
                  <th>Lokasi</th>
                  <th>Item</th>
                  <th>Waktu Request</th>
                  <th>Catatan</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($filteredMemberRequests as $row) {
                  $relativeMeta = $buildRelativeMeta((string) ($row['requested_at'] ?? ''));
                  ?>
                  <tr>
                    <td><?php echo htmlspecialchars((string) $row['request_code']); ?></td>
                    <td><?php echo htmlspecialchars(peminjamanActionLabel((string) $row['action_type'])); ?></td>
                    <td>
                      <div class="peminjaman-status-stack">
                        <span
                          class="peminjaman-badge badge-<?php echo htmlspecialchars(peminjamanBadgeClass((string) $row['status'])); ?>">
                          <?php echo htmlspecialchars(peminjamanStatusLabel((string) $row['status'])); ?>
                        </span>
                        <span class="peminjaman-badge badge-<?php echo htmlspecialchars((string) ($relativeMeta['badge'] ?? 'secondary')); ?>">
                          <?php echo htmlspecialchars((string) ($relativeMeta['label'] ?? 'Telah Lalu')); ?>
                        </span>
                      </div>
                    </td>
                    <td><?php echo htmlspecialchars((string) ($row['visit_location'] ?: '-')); ?></td>
                    <td><?php echo htmlspecialchars((string) ($row['item_list'] ?: '-')); ?></td>
                    <td><?php echo htmlspecialchars((string) $row['requested_at']); ?></td>
                    <td><?php echo htmlspecialchars((string) ($row['admin_note'] ?: $row['process_result'] ?: '-')); ?></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <?php } ?>
        <?php } ?>
      </div>

    <?php } ?>
  <?php } ?>
</div>
<?php if (!$auth) { ?>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      var locationMap = <?php echo $locationServiceMapJs ?: '{}'; ?>;
      var allLocationsClosed = <?php echo $allLocationsClosedJs; ?>;
      var locationClosedText = <?php echo $loginLocationClosedText; ?>;
      var chooseLocationText = <?php echo $loginChooseLocationText; ?>;
      var allClosedText = <?php echo $loginAllClosedText; ?>;

      var modeSelect = document.getElementById('modeSelect');
      var visitLocation = document.getElementById('visitLocation');
      var memberEmail = document.getElementById('memberEmail');
      var memberPassword = document.getElementById('memberPassword');
      var loginSubmitBtn = document.getElementById('loginSubmitBtn');
      var loginServiceNotice = document.getElementById('loginServiceNotice');

      function syncLoginStateByLocation() {
        if (!visitLocation || !loginSubmitBtn) {
          return;
        }
        var selected = visitLocation.value || '';
        var meta = locationMap[selected] || null;
        var isLocationChosen = selected !== '';
        var isOpen = !!(meta && meta.allowed);
        var reason = meta && meta.reason ? String(meta.reason) : '';

        if (allLocationsClosed) {
          if (memberEmail) memberEmail.disabled = true;
          if (memberPassword) memberPassword.disabled = true;
          loginSubmitBtn.disabled = true;
          if (loginServiceNotice) {
            loginServiceNotice.style.display = '';
            loginServiceNotice.textContent = allClosedText;
          }
          return;
        }

        if (!isLocationChosen) {
          if (memberEmail) memberEmail.disabled = true;
          if (memberPassword) memberPassword.disabled = true;
          loginSubmitBtn.disabled = true;
          if (loginServiceNotice) {
            loginServiceNotice.style.display = '';
            loginServiceNotice.textContent = chooseLocationText;
          }
          return;
        }

        if (memberEmail) memberEmail.disabled = !isOpen;
        if (memberPassword) memberPassword.disabled = !isOpen;
        loginSubmitBtn.disabled = !isOpen;
        if (loginServiceNotice) {
          if (isOpen) {
            loginServiceNotice.style.display = 'none';
            loginServiceNotice.textContent = '';
          } else {
            loginServiceNotice.style.display = '';
            loginServiceNotice.textContent = reason !== '' ? ('Login nonaktif: ' + reason) : locationClosedText;
          }
        }
      }

      if (visitLocation) {
        visitLocation.addEventListener('change', syncLoginStateByLocation);
        syncLoginStateByLocation();
      }
    });
  </script>
<?php } ?>
