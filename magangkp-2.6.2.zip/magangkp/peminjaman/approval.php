<?php

defined('INDEX_AUTH') or die('Direct access not allowed!');

require_once __DIR__ . '/lib.php';

require LIB . 'ip_based_access.inc.php';
do_checkIP('smc');
do_checkIP('smc-circulation');

if (session_status() !== PHP_SESSION_ACTIVE) {
  require SB . 'admin/default/session.inc.php';
}
require SB . 'admin/default/session_check.inc.php';

// Prevent hard-fail 500 on SQL runtime differences between servers.
if (function_exists('mysqli_report')) {
  @mysqli_report(MYSQLI_REPORT_OFF);
}

peminjamanEnsureSchema($dbs);

$canRead = utility::havePrivilege('circulation', 'r');
$canWrite = utility::havePrivilege('circulation', 'w');


// ============================================================
// AJAX handler: intercept ?ajax=1 requests and return JSON
// ============================================================
if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
  error_reporting(0);
  ini_set('display_errors', 0);
  while (ob_get_level() > 0)
    ob_end_clean();
  ob_start(); // Start a fresh buffer to catch any stray output
  header('Content-Type: application/json; charset=utf-8');
  header('Cache-Control: no-cache, no-store, must-revalidate');
  if (!$canRead) {
    while (ob_get_level() > 0)
      ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'message' => 'Sesi tidak valid / Tidak punya hak akses.']);
    exit;
  }


  $ajaxAction = trim((string) ($_GET['action'] ?? $_POST['action'] ?? ''));

  if ($ajaxAction === 'stream') {
    $sf = trim((string) ($_GET['status'] ?? 'all'));
    $af = trim((string) ($_GET['action_type'] ?? 'all'));
    $lf = trim((string) ($_GET['visit_location'] ?? 'all'));
    $df = trim((string) ($_GET['date_from'] ?? ''));
    $dt = trim((string) ($_GET['date_to'] ?? ''));
    $kw = trim((string) ($_GET['keyword'] ?? ''));

    $fr = peminjamanBuildAdminFilterSql($dbs, [
      'status' => $sf,
      'action_type' => $af,
      'visit_location' => $lf,
      'date_from' => $df,
      'date_to' => $dt,
      'keyword' => $kw
    ]);
    $ws = trim((string) ($fr['where_sql'] ?? ''));
    $whereSql = $ws !== '' ? (' ' . $ws) : '';

    while (ob_get_level() > 0)
      ob_end_clean();
    header('Content-Type: text/event-stream; charset=utf-8');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');
    @ini_set('zlib.output_compression', '0');
    @ini_set('output_buffering', 'off');
    @ignore_user_abort(true);
    if (function_exists('set_time_limit')) {
      @set_time_limit(0);
    }

    $buildSignature = static function () use ($dbs, $whereSql): string {
      $sql = "SELECT
                COALESCE(UNIX_TIMESTAMP(MAX(COALESCE(r.updated_at, r.processed_at, r.decided_at, r.requested_at))), 0) AS last_ts,
                COUNT(1) AS total
              FROM peminjaman_request AS r" . $whereSql;

      $query = $dbs->query($sql);
      if (!$query) {
        return 'ERR:' . md5((string) $dbs->error);
      }
      $row = $query->fetch_assoc() ?: [];
      $query->free_result();
      return sha1(json_encode($row));
    };

    echo "retry: 2500\n\n";
    @ob_flush();
    flush();

    $lastSignature = '';
    $startedAt = time();
    $maxRuntime = 25;
    $lastHeartbeat = 0;

    while (!connection_aborted() && (time() - $startedAt) < $maxRuntime) {
      $signature = $buildSignature();
      if ($signature !== $lastSignature) {
        $payload = [
          'changed' => $lastSignature !== '',
          'signature' => $signature,
          'at' => date('H:i:s')
        ];
        echo "event: sync\n";
        echo 'data: ' . json_encode($payload) . "\n\n";
        @ob_flush();
        flush();
        $lastSignature = $signature;
        $lastHeartbeat = time();
      } elseif ((time() - $lastHeartbeat) >= 10) {
        echo ": ping\n\n";
        @ob_flush();
        flush();
        $lastHeartbeat = time();
      }
      usleep(1000000);
    }
    exit;
  }

  if ($ajaxAction === 'save_settings') {
    if (!$canWrite) {
      while (ob_get_level() > 0)
        ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok' => false, 'message' => 'Tidak punya hak akses.']);
      exit;
    }

    $postedRaw = trim((string) ($_POST['daily_loan_limit'] ?? ''));
    $postedSameItemRaw = trim((string) ($_POST['same_item_daily_limit'] ?? ''));
    $postedAllowWithoutVisitor = peminjamanParseBoolSetting($_POST['allow_without_visitor'] ?? '0', false);
    $postedUseVisitorSchedule = peminjamanParseBoolSetting($_POST['use_visitor_schedule'] ?? '0', false);

    if ($postedRaw === '' || !preg_match('/^\d+$/', $postedRaw)) {
      while (ob_get_level() > 0)
        ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok' => false, 'message' => 'Batas pinjam harian wajib angka bulat 1-50.']);
      exit;
    }
    if ($postedSameItemRaw === '' || !preg_match('/^\d+$/', $postedSameItemRaw)) {
      while (ob_get_level() > 0)
        ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok' => false, 'message' => 'Batas item sama wajib angka bulat 2-50.']);
      exit;
    }

    $postedLimit = (int) $postedRaw;
    $postedSameItemLimit = (int) $postedSameItemRaw;
    if ($postedLimit < 1 || $postedLimit > 50) {
      while (ob_get_level() > 0)
        ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok' => false, 'message' => 'Batas pinjam harian harus 1-50.']);
      exit;
    }
    if ($postedSameItemLimit < 2 || $postedSameItemLimit > 50) {
      while (ob_get_level() > 0)
        ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok' => false, 'message' => 'Batas item sama harus 2-50.']);
      exit;
    }

    $savedDaily = peminjamanSetDailyLoanLimit($dbs, $postedLimit);
    $savedSameItem = peminjamanSetSameItemDailyLimit($dbs, $postedSameItemLimit);
    $savedAllowWithoutVisitor = peminjamanSetAllowLoanWithoutVisitor($dbs, $postedAllowWithoutVisitor);
    $savedUseVisitorSchedule = peminjamanSetUseVisitorScheduleForLoan($dbs, $postedUseVisitorSchedule);
    if (!$savedDaily || !$savedSameItem || !$savedAllowWithoutVisitor || !$savedUseVisitorSchedule) {
      while (ob_get_level() > 0)
        ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok' => false, 'message' => 'Gagal menyimpan pengaturan.']);
      exit;
    }

    $dailyLoanLimitNow = peminjamanGetDailyLoanLimit($dbs, $postedLimit);
    $sameItemDailyLimitNow = peminjamanGetSameItemDailyLimit($dbs, $postedSameItemLimit);
    $allowLoanWithoutVisitorNow = peminjamanGetAllowLoanWithoutVisitor($dbs, $postedAllowWithoutVisitor);
    $useVisitorScheduleForLoanNow = peminjamanGetUseVisitorScheduleForLoan($dbs, $postedUseVisitorSchedule);

    utility::writeLogs(
      $dbs,
      'staff',
      (string) ($_SESSION['uid'] ?? 0),
      'circulation',
      (string) ($_SESSION['realname'] ?? 'admin')
      . ' mengubah batas pinjam harian=' . $dailyLoanLimitNow
      . ', same_item_limit=' . $sameItemDailyLimitNow
      . ', allow_without_visitor=' . ($allowLoanWithoutVisitorNow ? '1' : '0')
      . ', use_visitor_schedule=' . ($useVisitorScheduleForLoanNow ? '1' : '0'),
      'Peminjaman Approval',
      'UPDATE'
    );

    while (ob_get_level() > 0)
      ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
      'ok' => true,
      'message' => 'Pengaturan berhasil disimpan.',
      'settings' => [
        'daily_loan_limit' => $dailyLoanLimitNow,
        'same_item_daily_limit' => $sameItemDailyLimitNow,
        'allow_without_visitor' => $allowLoanWithoutVisitorNow ? 1 : 0,
        'use_visitor_schedule' => $useVisitorScheduleForLoanNow ? 1 : 0
      ]
    ]);
    exit;
  }

  if ($ajaxAction === 'process') {
    if (!$canWrite) {
      while (ob_get_level() > 0)
        ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok' => false, 'message' => 'Tidak punya hak akses.']);
      exit;
    }
    $requestId = (int) ($_POST['request_id'] ?? 0);
    $decision = trim((string) ($_POST['decision'] ?? ''));
    $adminNote = trim((string) ($_POST['admin_note'] ?? ''));

    if ($requestId < 1 || !in_array($decision, ['approve', 'reject'], true)) {
      while (ob_get_level() > 0)
        ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok' => false, 'message' => 'Parameter tidak valid.']);
      exit;
    }
    if ($decision === 'reject' && $adminNote === '') {
      while (ob_get_level() > 0)
        ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok' => false, 'message' => 'Alasan penolakan wajib diisi.']);
      exit;
    }

    $result = peminjamanProcessRequest(
      $dbs,
      $requestId,
      $decision === 'approve',
      $adminNote,
      [
        'uid' => (int) ($_SESSION['uid'] ?? 0),
        'username' => (string) ($_SESSION['realname'] ?? 'admin')
      ],
      $sysconf
    );

    if (!empty($result['ok'])) {
      $finalStatus = (string) ($result['final_status'] ?? ($decision === 'approve' ? 'approved' : 'rejected'));
      // Auto-reject duplicates
      $pr = $dbs->query("SELECT r.member_id, ri.item_code FROM peminjaman_request r
        INNER JOIN peminjaman_request_item ri ON r.request_id = ri.request_id
        WHERE r.request_id = " . (int) $requestId);
      if ($pr) {
        while ($prRow = $pr->fetch_assoc()) {
          $dbs->query("UPDATE peminjaman_request r
            INNER JOIN peminjaman_request_item ri ON r.request_id = ri.request_id
            SET r.status='rejected', r.admin_note='Auto-ditolak: request lain sudah diproses',
                r.decided_at=NOW(), r.admin_username='" . $dbs->real_escape_string((string) ($_SESSION['realname'] ?? 'admin')) . "'
            WHERE r.member_id='" . $dbs->real_escape_string((string) $prRow['member_id']) . "'
            AND ri.item_code='" . $dbs->real_escape_string((string) $prRow['item_code']) . "'
            AND r.status='pending' AND r.request_id != " . (int) $requestId);
        }
        $pr->free_result();
      }
      utility::writeLogs(
        $dbs,
        'staff',
        (string) ($_SESSION['uid'] ?? 0),
        'circulation',
        (string) ($_SESSION['realname'] ?? 'admin') . ' memproses approval #' . $requestId . ' => ' . $finalStatus,
        'Peminjaman Approval',
        strtoupper($decision)
      );

      while (ob_get_level() > 0)
        ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok' => true, 'message' => 'Request #' . $requestId . ' berhasil diproses.', 'final_status' => $finalStatus]);
    } else {
      while (ob_get_level() > 0)
        ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok' => false, 'message' => (string) ($result['message'] ?? 'Gagal memproses.')]);
    }
    exit;
  }

  if ($ajaxAction === 'list') {
    $sf = trim((string) ($_GET['status'] ?? 'all'));
    $af = trim((string) ($_GET['action_type'] ?? 'all'));
    $pg = max(1, (int) ($_GET['page'] ?? 1));
    $pp = 50;

    $fr = peminjamanBuildAdminFilterSql($dbs, ['status' => $sf, 'action_type' => $af]);
    $ws = $fr['where_sql'] ?? '';

    $cq = $dbs->query("SELECT COUNT(DISTINCT r.request_id) AS total FROM peminjaman_request r
      INNER JOIN peminjaman_request_item ri ON r.request_id = ri.request_id $ws");
    $total = 0;
    if ($cq) {
      $cr = $cq->fetch_assoc();
      $total = (int) ($cr['total'] ?? 0);
      $cq->free_result();
    }

    $off = ($pg - 1) * $pp;
    $dq = $dbs->query("SELECT r.*, ri.request_item_id, ri.item_code, ri.loan_id, ri.item_status, ri.process_message
      FROM peminjaman_request r
      INNER JOIN peminjaman_request_item ri ON r.request_id = ri.request_id
      $ws
      ORDER BY CASE r.status WHEN 'pending' THEN 0 WHEN 'processing' THEN 1 ELSE 2 END, r.requested_at DESC
      LIMIT $pp OFFSET $off");

    $rows = [];
    if ($dq) {
      while ($r = $dq->fetch_assoc()) {
        $rows[] = $r;
      }
      $dq->free_result();
    }

    $grouped = [];
    foreach ($rows as $row) {
      $rid = (int) $row['request_id'];
      if (!isset($grouped[$rid])) {
        $grouped[$rid] = [
          'request_id' => $rid,
          'request_code' => $row['request_code'] ?? '',
          'member_id' => $row['member_id'],
          'member_name' => $row['member_name'],
          'action_type' => $row['action_type'],
          'status' => $row['status'],
          'admin_note' => $row['admin_note'] ?? '',
          'process_result' => $row['process_result'] ?? '',
          'requested_at' => $row['requested_at'],
          'decided_at' => $row['decided_at'] ?? null,
          'visit_location' => $row['visit_location'] ?? '',
          'items' => []
        ];
      }
      $itemCode = trim((string) ($row['item_code'] ?? ''));
      $itemTitle = '-';
      if ($itemCode !== '') {
        $tq = $dbs->query("SELECT b.title FROM item i INNER JOIN biblio b ON i.biblio_id=b.biblio_id WHERE i.item_code='" . $dbs->real_escape_string($itemCode) . "' LIMIT 1");
        if ($tq && $tq->num_rows > 0) {
          $tr = $tq->fetch_assoc();
          $itemTitle = $tr['title'] ?? '-';
        }
        if ($tq)
          $tq->free_result();
      }
      $grouped[$rid]['items'][] = [
        'item_code' => $itemCode,
        'item_title' => $itemTitle,
        'item_status' => $row['item_status'] ?? 'pending',
        'process_message' => $row['process_message'] ?? ''
      ];
    }

    while (ob_get_level() > 0)
      ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => true, 'total' => $total, 'requests' => array_values($grouped)]);
    exit;
  }

  while (ob_get_level() > 0)
    ob_end_clean();
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => false, 'message' => 'Action tidak dikenal.']);
  exit;
}
// ============================================================
// End AJAX handler
// ============================================================

if (!$canRead) {
  die('<div class="errorBox">' . __('You don\'t have enough privileges to access this area!') . '</div>');
}



$messages = [
  'success' => [],
  'error' => []
];

$selfPath = (string) ($_SERVER['PHP_SELF'] ?? 'plugin_container.php');
$moduleParam = trim((string) ($_GET['mod'] ?? 'circulation'));
if ($moduleParam === '') {
  $moduleParam = 'circulation';
}

$pluginMenuId = trim((string) ($_GET['id'] ?? ''));
if ($pluginMenuId === '' && class_exists('\SLiMS\\Plugins')) {
  $menuList = \SLiMS\Plugins::getInstance()->getMenus($moduleParam);
  $currentPluginPath = realpath(__FILE__);
  if (is_array($menuList)) {
    foreach ($menuList as $menuId => $menuMeta) {
      $menuPath = isset($menuMeta[3]) ? realpath((string) $menuMeta[3]) : false;
      if ($menuPath && $menuPath === $currentPluginPath) {
        $pluginMenuId = (string) $menuId;
        break;
      }
    }
  }
}

$buildQueryUrl = static function (array $params) use ($selfPath): string {
  return $selfPath . '?' . http_build_query($params);
};

$canonicalQuery = $_GET;
unset($canonicalQuery['ajax'], $canonicalQuery['action']);
$canonicalQuery['mod'] = $moduleParam;
if ($pluginMenuId !== '') {
  $canonicalQuery['id'] = $pluginMenuId;
}

$formAction = htmlspecialchars($selfPath, ENT_QUOTES, 'UTF-8');
$pageUrl = $buildQueryUrl($canonicalQuery);
$ajaxQuery = $canonicalQuery;
$ajaxQuery['ajax'] = '1';
$ajaxUrl = $buildQueryUrl($ajaxQuery);

$dailyLoanLimit = peminjamanGetDailyLoanLimit($dbs, 3);
$dailyLoanLimitInput = (string) $dailyLoanLimit;
$sameItemDailyLimit = peminjamanGetSameItemDailyLimit($dbs, 3);
$sameItemDailyLimitInput = (string) $sameItemDailyLimit;
$allowLoanWithoutVisitor = peminjamanGetAllowLoanWithoutVisitor($dbs, false);
$useVisitorScheduleForLoan = peminjamanGetUseVisitorScheduleForLoan($dbs, true);
if (isset($_POST['save_daily_loan_limit'])) {
  if (!$canWrite) {
    $messages['error'][] = 'Anda tidak punya hak untuk mengubah batas pinjam harian.';
  } else {
    $postedRaw = trim((string) ($_POST['daily_loan_limit'] ?? ''));
    $postedSameItemRaw = trim((string) ($_POST['same_item_daily_limit'] ?? ''));
    $postedAllowWithoutVisitor = peminjamanParseBoolSetting($_POST['allow_without_visitor'] ?? '0', false);
    $postedUseVisitorSchedule = peminjamanParseBoolSetting($_POST['use_visitor_schedule'] ?? '0', false);
    $dailyLoanLimitInput = $postedRaw;
    $sameItemDailyLimitInput = $postedSameItemRaw;
    $allowLoanWithoutVisitor = $postedAllowWithoutVisitor;
    $useVisitorScheduleForLoan = $postedUseVisitorSchedule;

    $hasValidationError = false;
    if ($postedRaw === '') {
      $messages['error'][] = 'Batas pinjam harian wajib diisi dengan angka bulat.';
      $hasValidationError = true;
    } elseif (!preg_match('/^\d+$/', $postedRaw)) {
      $messages['error'][] = 'Batas pinjam harian hanya boleh angka bulat (0-9).';
      $hasValidationError = true;
    }

    if ($postedSameItemRaw === '') {
      $messages['error'][] = 'Batas item sama per hari wajib diisi dengan angka bulat.';
      $hasValidationError = true;
    } elseif (!preg_match('/^\d+$/', $postedSameItemRaw)) {
      $messages['error'][] = 'Batas item sama per hari hanya boleh angka bulat (0-9).';
      $hasValidationError = true;
    }

    if (!$hasValidationError) {
      $postedLimit = (int) $postedRaw;
      $postedSameItemLimit = (int) $postedSameItemRaw;

      if ($postedLimit < 1 || $postedLimit > 50) {
        $messages['error'][] = 'Batas pinjam harian harus di antara 1 sampai 50 buku per hari.';
        $hasValidationError = true;
      }
      if ($postedSameItemLimit < 2 || $postedSameItemLimit > 50) {
        $messages['error'][] = 'Batas item sama per hari harus di antara 2 sampai 50.';
        $hasValidationError = true;
      }
    }

    if (!$hasValidationError) {
      $postedLimit = (int) $postedRaw;
      $postedSameItemLimit = (int) $postedSameItemRaw;
      $savedDaily = peminjamanSetDailyLoanLimit($dbs, $postedLimit);
      $savedSameItem = peminjamanSetSameItemDailyLimit($dbs, $postedSameItemLimit);
      $savedAllowWithoutVisitor = peminjamanSetAllowLoanWithoutVisitor($dbs, $postedAllowWithoutVisitor);
      $savedUseVisitorSchedule = peminjamanSetUseVisitorScheduleForLoan($dbs, $postedUseVisitorSchedule);

      if ($savedDaily && $savedSameItem && $savedAllowWithoutVisitor && $savedUseVisitorSchedule) {
        $dailyLoanLimit = peminjamanGetDailyLoanLimit($dbs, $postedLimit);
        $sameItemDailyLimit = peminjamanGetSameItemDailyLimit($dbs, $postedSameItemLimit);
        $allowLoanWithoutVisitor = peminjamanGetAllowLoanWithoutVisitor($dbs, $postedAllowWithoutVisitor);
        $useVisitorScheduleForLoan = peminjamanGetUseVisitorScheduleForLoan($dbs, $postedUseVisitorSchedule);
        $dailyLoanLimitInput = (string) $dailyLoanLimit;
        $sameItemDailyLimitInput = (string) $sameItemDailyLimit;
        $messages['success'][] = 'Batas approval berhasil disimpan: maksimal '
          . $dailyLoanLimit . ' buku/user/hari, dan item yang sama dibatasi sampai '
          . $sameItemDailyLimit . ' kali/hari (maksimal ' . max(1, $sameItemDailyLimit - 1) . ' kali). '
          . 'Pinjaman tanpa visitor: ' . ($allowLoanWithoutVisitor ? 'aktif' : 'nonaktif') . '. '
          . 'Gunakan jadwal visitor: ' . ($useVisitorScheduleForLoan ? 'aktif' : 'nonaktif') . '.';
        utility::writeLogs(
          $dbs,
          'staff',
          (string) ($_SESSION['uid'] ?? 0),
          'circulation',
          (string) ($_SESSION['realname'] ?? 'admin')
          . ' mengubah batas pinjam harian=' . $dailyLoanLimit
          . ', batas item sama=' . $sameItemDailyLimit . ' kali/hari'
          . ', no_visitor=' . ($allowLoanWithoutVisitor ? '1' : '0')
          . ', use_vschedule=' . ($useVisitorScheduleForLoan ? '1' : '0') . '.',
          'Peminjaman Approval',
          'UPDATE'
        );
      } else {
        $messages['error'][] = 'Gagal menyimpan batas approval. ' . trim((string) ($dbs->error ?: 'Silakan coba lagi.'));
      }
    }
  }
}

if (isset($_POST['process_request'])) {
  if (!$canWrite) {
    $messages['error'][] = 'Anda tidak punya hak untuk memproses approval.';
  } else {
    $requestId = (int) ($_POST['request_id'] ?? 0);
    $decision = trim((string) ($_POST['decision'] ?? ''));
    $adminNote = trim((string) ($_POST['admin_note'] ?? ''));

    if ($requestId < 1 || !in_array($decision, ['approve', 'reject'], true)) {
      $messages['error'][] = 'Aksi approval tidak valid.';
    } elseif ($decision === 'reject' && $adminNote === '') {
      $messages['error'][] = 'Alasan penolakan wajib diisi saat menolak request.';
    } else {
      error_log('[APPROVAL DEBUG] Processing request_id=' . $requestId . ' decision=' . $decision . ' admin_note=' . $adminNote);
      $result = peminjamanProcessRequest(
        $dbs,
        $requestId,
        $decision === 'approve',
        $adminNote,
        [
          'uid' => (int) ($_SESSION['uid'] ?? 0),
          'username' => (string) ($_SESSION['realname'] ?? 'admin')
        ],
        $sysconf
      );
      error_log('[APPROVAL DEBUG] Result: ' . json_encode($result));

      if (!empty($result['ok'])) {
        $finalStatus = (string) ($result['final_status'] ?? ($decision === 'approve' ? 'approved' : 'rejected'));
        $messages['success'][] = 'Request #' . $requestId . ' berhasil diproses. Status akhir: ' . peminjamanStatusLabel($finalStatus);

        // Auto-reject semua pending request duplikat untuk member+item yang sama
        $processedRequest = $dbs->query("SELECT r.member_id, ri.item_code
          FROM peminjaman_request r
          INNER JOIN peminjaman_request_item ri ON r.request_id = ri.request_id
          WHERE r.request_id = " . (int) $requestId);
        if ($processedRequest) {
          while ($prRow = $processedRequest->fetch_assoc()) {
            $dbs->query("UPDATE peminjaman_request r
              INNER JOIN peminjaman_request_item ri ON r.request_id = ri.request_id
              SET r.status = 'rejected',
                  r.admin_note = 'Auto-ditolak: request lain untuk item yang sama sudah diproses',
                  r.decided_at = NOW(),
                  r.admin_username = '" . $dbs->real_escape_string((string) ($_SESSION['realname'] ?? 'admin')) . "'
              WHERE r.member_id = '" . $dbs->real_escape_string((string) $prRow['member_id']) . "'
              AND ri.item_code = '" . $dbs->real_escape_string((string) $prRow['item_code']) . "'
              AND r.status = 'pending'
              AND r.request_id != " . (int) $requestId);
          }
          $processedRequest->free_result();
        }

        utility::writeLogs(
          $dbs,
          'staff',
          (string) ($_SESSION['uid'] ?? 0),
          'circulation',
          (string) ($_SESSION['realname'] ?? 'admin') . ' memproses approval request peminjaman #' . $requestId . ' => ' . $finalStatus,
          'Peminjaman Approval',
          strtoupper($decision)
        );
      } else {
        $messages['error'][] = (string) ($result['message'] ?? 'Gagal memproses approval request.');
      }
    }
  }
}

// Keep last selected filter on refresh/navigation unless user explicitly resets it.
$filterDefaults = [
  'status' => 'all',
  'action_type' => 'all',
  'visit_location' => 'all',
  'date_from' => date('Y-m-01'),
  'date_to' => date('Y-m-d'),
  'keyword' => ''
];
$filterSessionKey = 'peminjaman_approval_filter_state';
$filterStateScope = (($pluginMenuId !== '' ? $pluginMenuId : 'default') . ':' . (string) ($_SESSION['uid'] ?? '0'));
if (!isset($_SESSION[$filterSessionKey]) || !is_array($_SESSION[$filterSessionKey])) {
  $_SESSION[$filterSessionKey] = [];
}
$savedFilterState = $_SESSION[$filterSessionKey][$filterStateScope] ?? [];
if (!is_array($savedFilterState)) {
  $savedFilterState = [];
}

$resetFilter = isset($_GET['reset_filter']) && (string) $_GET['reset_filter'] === '1';
if ($resetFilter) {
  unset($_SESSION[$filterSessionKey][$filterStateScope]);
  $savedFilterState = [];
}

$filterKeys = ['status', 'action_type', 'visit_location', 'date_from', 'date_to', 'keyword'];
$hasExplicitFilter = false;
foreach ($filterKeys as $filterKey) {
  if (array_key_exists($filterKey, $_GET)) {
    $hasExplicitFilter = true;
    break;
  }
}

$incomingFilter = $filterDefaults;
if ($hasExplicitFilter) {
  foreach ($filterKeys as $filterKey) {
    $incomingFilter[$filterKey] = trim((string) ($_GET[$filterKey] ?? $filterDefaults[$filterKey]));
  }
} elseif (count($savedFilterState) > 0) {
  foreach ($filterKeys as $filterKey) {
    $incomingFilter[$filterKey] = trim((string) ($savedFilterState[$filterKey] ?? $filterDefaults[$filterKey]));
  }
}

$statusFilter = $incomingFilter['status'];
$actionFilter = $incomingFilter['action_type'];
$locationFilter = $incomingFilter['visit_location'];
$dateFrom = $incomingFilter['date_from'];
$dateTo = $incomingFilter['date_to'];
$keyword = $incomingFilter['keyword'];

$filters = peminjamanBuildAdminFilterSql($dbs, [
  'status' => $statusFilter,
  'action_type' => $actionFilter,
  'visit_location' => $locationFilter,
  'date_from' => $dateFrom,
  'date_to' => $dateTo,
  'keyword' => $keyword
]);

$_SESSION[$filterSessionKey][$filterStateScope] = [
  'status' => $filters['status'] ?: 'all',
  'action_type' => $filters['action_type'] ?: 'all',
  'visit_location' => $filters['visit_location'] ?: 'all',
  'date_from' => $filters['date_from'],
  'date_to' => $filters['date_to'],
  'keyword' => $filters['keyword']
];

$whereSql = $filters['where_sql'];

$safeQuery = static function (mysqli $dbs, string $sql) {
  try {
    return $dbs->query($sql);
  } catch (Throwable $e) {
    error_log('[PEMINJAMAN APPROVAL SQL ERROR] ' . $e->getMessage());
    return false;
  }
};

$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 25;
$offset = ($page - 1) * $perPage;

$effectiveWhereSql = trim((string) $whereSql);
$effectiveWhereSql = $effectiveWhereSql !== '' ? (' ' . $effectiveWhereSql) : '';

$totalRows = 0;
$countSql = "SELECT COUNT(1) AS total
             FROM peminjaman_request AS r" . $effectiveWhereSql;
if ($countQuery = $safeQuery($dbs, $countSql)) {
  if ($countRow = $countQuery->fetch_assoc()) {
    $totalRows = (int) ($countRow['total'] ?? 0);
  }
  $countQuery->free_result();
}

$totalPages = max(1, (int) ceil($totalRows / $perPage));
if ($page > $totalPages) {
  $page = $totalPages;
  $offset = ($page - 1) * $perPage;
}

$rows = [];
$dataSql = "SELECT r.request_id, r.request_code, r.member_id, r.member_name, r.member_email,
                   r.member_type_name, r.visit_location, r.action_type, r.status,
                   r.request_note, r.admin_note, r.process_result,
                   r.requested_at, r.decided_at, r.processed_at,
                   r.admin_username
            FROM peminjaman_request AS r" . $effectiveWhereSql . "
            ORDER BY r.requested_at DESC, r.request_id DESC
            LIMIT {$offset}, {$perPage}";

if ($dataQuery = $safeQuery($dbs, $dataSql)) {
  while ($row = $dataQuery->fetch_assoc()) {
    $rows[] = $row;
  }
  $dataQuery->free_result();
}

$itemMap = [];
if (count($rows) > 0) {
  $idList = array_map(static fn($r) => (int) $r['request_id'], $rows);
  $idListSql = implode(',', $idList);
  $itemSql = "SELECT ri.request_item_id, ri.request_id, ri.item_code, ri.loan_id, ri.item_status, ri.process_message,
                       COALESCE(b.title, '-') AS title,
                       COALESCE(loc.location_name, '-') AS item_location,
                       COALESCE(loan_by_id.is_lent, 0) AS loan_is_lent,
                       COALESCE(loan_by_id.is_return, 0) AS loan_is_return,
                       COALESCE(loan_by_id.due_date, '') AS loan_due_date,
                       COALESCE(loan_by_id.return_date, '') AS loan_return_date,
                       COALESCE(loan_by_id.renewed, 0) AS loan_renewed,
                       COALESCE(loan_by_id.loan_date, '') AS loan_loan_date
                FROM peminjaman_request_item AS ri
                LEFT JOIN item AS i ON ri.item_code = i.item_code
                LEFT JOIN biblio AS b ON i.biblio_id = b.biblio_id
                LEFT JOIN mst_location AS loc ON i.location_id = loc.location_id
                LEFT JOIN loan AS loan_by_id ON (ri.loan_id IS NOT NULL AND ri.loan_id > 0 AND loan_by_id.loan_id = ri.loan_id)
                WHERE ri.request_id IN ({$idListSql})
                ORDER BY ri.request_id ASC, ri.request_item_id ASC";
  if ($itemQuery = $safeQuery($dbs, $itemSql)) {
    while ($itemRow = $itemQuery->fetch_assoc()) {
      $rid = (int) $itemRow['request_id'];
      if (!isset($itemMap[$rid])) {
        $itemMap[$rid] = [];
      }
      $itemMap[$rid][] = $itemRow;
    }
    $itemQuery->free_result();
  }

  $itemCodeSet = [];
  foreach ($itemMap as $itemRows) {
    foreach ($itemRows as $itemRow) {
      $itemCode = trim((string) ($itemRow['item_code'] ?? ''));
      if ($itemCode !== '') {
        $itemCodeSet[$itemCode] = $itemCode;
      }
    }
  }
  $onLoanMap = count($itemCodeSet) > 0 ? peminjamanGetOnLoanCountMapByItemCodes($dbs, array_values($itemCodeSet)) : [];
  if (count($onLoanMap) > 0) {
    foreach ($itemMap as $rid => $itemRows) {
      foreach ($itemRows as $idx => $itemRow) {
        $code = trim((string) ($itemRow['item_code'] ?? ''));
        $itemMap[$rid][$idx]['currently_on_loan'] = $code !== '' ? (int) ($onLoanMap[$code] ?? 0) : 0;
      }
    }
  } else {
    foreach ($itemMap as $rid => $itemRows) {
      foreach ($itemRows as $idx => $itemRow) {
        $itemMap[$rid][$idx]['currently_on_loan'] = 0;
      }
    }
  }

  foreach ($rows as &$rowRef) {
    $rid = (int) ($rowRef['request_id'] ?? 0);
    $rowItems = $itemMap[$rid] ?? [];
    $rowRef['item_total'] = count($rowItems);
    $rowRef['item_approved'] = 0;
    $rowRef['item_failed'] = 0;
    $rowRef['item_rejected'] = 0;
    $itemList = [];
    foreach ($rowItems as $rowItem) {
      $statusKey = strtolower(trim((string) ($rowItem['item_status'] ?? '')));
      if ($statusKey === 'approved') {
        $rowRef['item_approved']++;
      } elseif ($statusKey === 'failed') {
        $rowRef['item_failed']++;
      } elseif ($statusKey === 'rejected') {
        $rowRef['item_rejected']++;
      }
      $code = trim((string) ($rowItem['item_code'] ?? ''));
      $loanId = (int) ($rowItem['loan_id'] ?? 0);
      if ($code === '') {
        $itemList[] = '#LOAN-' . max(0, $loanId);
      } elseif ($loanId > 0) {
        $itemList[] = $code . ' (#' . $loanId . ')';
      } else {
        $itemList[] = $code;
      }
    }
    $rowRef['item_list'] = implode(', ', $itemList);
  }
  unset($rowRef);

  // Collapse duplicate rows for the same loan cycle (same loan_id),
  // keep only the newest request row so status updates don't appear as new case rows.
  $buildLoanCycleKey = static function (array $requestRow, array $requestItems): string {
    $loanIds = [];
    foreach ($requestItems as $requestItem) {
      $loanId = (int) ($requestItem['loan_id'] ?? 0);
      if ($loanId > 0) {
        $loanIds[$loanId] = true;
      }
    }
    if (count($loanIds) < 1) {
      return 'request:' . (int) ($requestRow['request_id'] ?? 0);
    }
    $ids = array_keys($loanIds);
    sort($ids, SORT_NUMERIC);
    return 'loan:' . implode(',', $ids);
  };

  $cycleBuckets = [];
  $cycleOrder = [];
  foreach ($rows as $rowData) {
    $requestId = (int) ($rowData['request_id'] ?? 0);
    $cycleKey = $buildLoanCycleKey($rowData, $itemMap[$requestId] ?? []);
    $statusNorm = strtolower(trim((string) ($rowData['status'] ?? '')));

    if (!isset($cycleBuckets[$cycleKey])) {
      $cycleBuckets[$cycleKey] = [
        'fallback' => $rowData, // newest row in this cycle
        'preferred' => null
      ];
      $cycleOrder[] = $cycleKey;
    }

    // Prefer actionable status for admin (pending first, then processing).
    if ($statusNorm === 'pending') {
      $cycleBuckets[$cycleKey]['preferred'] = $rowData;
      continue;
    }
    if ($statusNorm === 'processing') {
      $currentPreferred = $cycleBuckets[$cycleKey]['preferred'];
      $currentPreferredStatus = strtolower(trim((string) ($currentPreferred['status'] ?? '')));
      if ($currentPreferred === null || $currentPreferredStatus !== 'pending') {
        $cycleBuckets[$cycleKey]['preferred'] = $rowData;
      }
    }
  }

  $collapsedRows = [];
  foreach ($cycleOrder as $cycleKey) {
    $bucket = $cycleBuckets[$cycleKey];
    $collapsedRows[] = $bucket['preferred'] ?? $bucket['fallback'];
  }

  $droppedCount = max(0, count($rows) - count($collapsedRows));
  if ($droppedCount > 0) {
    $rows = $collapsedRows;
    $totalRows = max(count($rows), $totalRows - $droppedCount);
    $totalPages = max(1, (int) ceil($totalRows / $perPage));
  }
}

$memberStatusMap = [];
if (count($rows) > 0) {
  $memberIds = [];
  foreach ($rows as $rowData) {
    $mid = trim((string) ($rowData['member_id'] ?? ''));
    if ($mid !== '') {
      $memberIds[$mid] = $mid;
    }
  }
  if (count($memberIds) > 0) {
    $memberStatusMap = peminjamanGetMemberStatusMapByIds($dbs, array_values($memberIds));
  }
}

$resolveLoanStatusMeta = static function (array $requestRow, ?array $itemRow): array {
  $item = is_array($itemRow) ? $itemRow : [];
  $action = strtolower(trim((string) ($requestRow['action_type'] ?? 'loan')));
  $reqStatus = strtolower(trim((string) ($requestRow['status'] ?? 'pending')));
  $itemStatus = strtolower(trim((string) (($item['item_status'] ?? 'pending'))));

  $isLent = (int) (($item['loan_is_lent'] ?? 0));
  $isReturn = (int) (($item['loan_is_return'] ?? 0));
  $dueDate = trim((string) (($item['loan_due_date'] ?? '')));
  $returnDate = trim((string) (($item['loan_return_date'] ?? '')));
  $renewedCount = (int) (($item['loan_renewed'] ?? 0));
  $currentlyOnLoan = (int) (($item['currently_on_loan'] ?? 0));
  $today = date('Y-m-d');

  $meta = [
    'label' => 'Tersedia',
    'badge' => 'badge-success',
    'detail' => '',
    'is_overdue' => false
  ];

  if (in_array($reqStatus, ['rejected', 'failed'], true)) {
    if (in_array($action, ['return'], true)) {
      $meta['label'] = $reqStatus === 'rejected' ? 'Kembali Ditolak' : 'Kembali Gagal';
    } elseif (in_array($action, ['extend', 'renew', 'renewal'], true)) {
      $meta['label'] = $reqStatus === 'rejected' ? 'Perpanjang Ditolak' : 'Perpanjang Gagal';
    } else {
      $meta['label'] = $reqStatus === 'rejected' ? 'Pinjam Ditolak' : 'Pinjam Gagal';
    }
    $meta['badge'] = $reqStatus === 'rejected' ? 'badge-danger' : 'badge-secondary';
    return $meta;
  }

  if (in_array($reqStatus, ['pending', 'processing'], true)) {
    if (in_array($action, ['return'], true)) {
      $meta['label'] = 'Menunggu Kembali';
    } elseif (in_array($action, ['extend', 'renew', 'renewal'], true)) {
      $meta['label'] = 'Menunggu Perpanjang';
    } else {
      $meta['label'] = 'Menunggu Pinjam';
    }
    $meta['badge'] = 'badge-warning';
    return $meta;
  }

  if ($itemStatus === 'rejected') {
    $meta['label'] = in_array($action, ['return'], true) ? 'Kembali Ditolak' : 'Ditolak';
    $meta['badge'] = 'badge-danger';
    return $meta;
  }
  if ($itemStatus === 'failed') {
    $meta['label'] = in_array($action, ['return'], true) ? 'Kembali Gagal' : 'Gagal';
    $meta['badge'] = 'badge-secondary';
    return $meta;
  }

  if (in_array($action, ['return'], true)) {
    $meta['label'] = 'Sudah Dikembalikan';
    $meta['badge'] = 'badge-secondary';
    if ($returnDate !== '' && strtotime($returnDate) !== false) {
      $meta['detail'] = date('d M Y H:i', strtotime($returnDate));
    }
    return $meta;
  }

  if ($isReturn === 1) {
    $meta['label'] = 'Sudah Dikembalikan';
    $meta['badge'] = 'badge-secondary';
    if ($returnDate !== '' && strtotime($returnDate) !== false) {
      $meta['detail'] = date('d M Y H:i', strtotime($returnDate));
    }
    return $meta;
  }

  if ($isLent === 1) {
    if ($dueDate !== '' && preg_match('/^\d{4}-\d{2}-\d{2}/', $dueDate) && substr($dueDate, 0, 10) < $today) {
      $meta['label'] = 'Terlambat';
      $meta['badge'] = 'badge-danger';
      $meta['is_overdue'] = true;
      $daysDiff = (int) floor((strtotime($today) - strtotime(substr($dueDate, 0, 10))) / 86400);
      $meta['detail'] = max(1, $daysDiff) . ' hari';
      return $meta;
    }

    if (in_array($action, ['extend', 'renew', 'renewal'], true) || $renewedCount > 0) {
      $meta['label'] = 'Diperpanjang';
      $meta['badge'] = 'badge-info';
      $meta['detail'] = $renewedCount > 0 ? 'x' . $renewedCount : '';
      return $meta;
    }

    $meta['label'] = 'Sedang Dipinjam';
    $meta['badge'] = 'badge-warning';
    if ($dueDate !== '' && strtotime($dueDate) !== false) {
      $meta['detail'] = 's/d ' . date('d M', strtotime($dueDate));
    }
    return $meta;
  }

  if ($currentlyOnLoan > 0 && in_array($action, ['loan'], true) && in_array($reqStatus, ['approved', 'partial'], true)) {
    $meta['label'] = 'Sedang Dipinjam';
    $meta['badge'] = 'badge-warning';
    return $meta;
  }

  if (in_array($action, ['extend', 'renew', 'renewal'], true)) {
    $meta['label'] = 'Perpanjang Diproses';
    $meta['badge'] = 'badge-info';
    return $meta;
  }

  $meta['label'] = in_array($reqStatus, ['approved', 'partial'], true) ? 'Sudah Dikembalikan' : 'Tersedia';
  $meta['badge'] = in_array($reqStatus, ['approved', 'partial'], true) ? 'badge-secondary' : 'badge-success';
  return $meta;
};

$summaryByStatus = [
  'pending' => 0,
  'processing' => 0,
  'approved' => 0,
  'partial' => 0,
  'rejected' => 0,
  'failed' => 0
];
$summarySql = "SELECT r.status, COUNT(1) AS total
               FROM peminjaman_request AS r" . $effectiveWhereSql . "
               GROUP BY r.status";
if ($summaryQuery = $safeQuery($dbs, $summarySql)) {
  while ($summaryRow = $summaryQuery->fetch_assoc()) {
    $status = (string) ($summaryRow['status'] ?? '');
    if (!isset($summaryByStatus[$status])) {
      continue;
    }
    $summaryByStatus[$status] = (int) ($summaryRow['total'] ?? 0);
  }
  $summaryQuery->free_result();
}

$locationOptions = peminjamanGetLocationOptions($dbs, $sysconf);
foreach (peminjamanGetDistinctVisitLocations($dbs) as $extraLocation) {
  $locationOptions[] = $extraLocation;
}
$locationOptions = array_values(array_unique($locationOptions));
sort($locationOptions);

$baseFilter = [
  'mod' => $moduleParam,
  'id' => $pluginMenuId,
  'status' => $filters['status'] ?: 'all',
  'action_type' => $filters['action_type'] ?: 'all',
  'visit_location' => $filters['visit_location'] ?: 'all',
  'date_from' => $filters['date_from'],
  'date_to' => $filters['date_to'],
  'keyword' => $filters['keyword']
];

$buildPageUrl = static function (int $targetPage) use ($baseFilter, $buildQueryUrl): string {
  $query = $baseFilter;
  $query['page'] = max(1, $targetPage);
  return $buildQueryUrl($query);
};

$resetQuery = ['mod' => $moduleParam];
if ($pluginMenuId !== '') {
  $resetQuery['id'] = $pluginMenuId;
}
$resetQuery['reset_filter'] = '1';
$resetUrl = $buildQueryUrl($resetQuery);
$refreshUrl = $buildPageUrl($page);

?>

<style>
  .peminjaman-admin-wrap {
    font-family: inherit;
    --mkp-surface: rgba(255, 255, 255, 0.94);
    --mkp-surface-soft: rgba(248, 250, 252, 0.95);
    --mkp-border: rgba(148, 163, 184, 0.45);
    --mkp-text: #0f172a;
    --mkp-muted: #64748b;
    --mkp-shadow: 0 10px 24px rgba(15, 23, 42, 0.08);
  }

  .peminjaman-admin-wrap .mkp-card {
    background: var(--mkp-surface);
    border: 1px solid var(--mkp-border);
    border-radius: 8px;
    padding: 12px;
    margin-bottom: 12px;
    box-shadow: var(--mkp-shadow);
  }

  .peminjaman-admin-wrap .mkp-summary-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .peminjaman-admin-wrap .mkp-summary-item {
    border: 1px solid var(--mkp-border);
    border-radius: 6px;
    padding: 8px 14px;
    background: var(--mkp-surface-soft);
    min-width: 100px;
    text-align: center;
  }

  .peminjaman-admin-wrap .mkp-summary-item strong {
    display: block;
    color: var(--mkp-muted);
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.3px;
  }

  .peminjaman-admin-wrap .mkp-summary-item span {
    display: block;
    margin-top: 2px;
    font-size: 20px;
    font-weight: 700;
    color: var(--mkp-text);
  }

  .peminjaman-admin-wrap .mkp-filter-row {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    align-items: flex-end;
  }

  .peminjaman-admin-wrap .mkp-setting-row {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: flex-end;
  }

  .peminjaman-admin-wrap .mkp-setting-row label {
    font-size: 11px;
    color: var(--mkp-muted);
    font-weight: 700;
    margin-bottom: 4px;
    display: block;
  }

  .peminjaman-admin-wrap .mkp-setting-help {
    margin-top: 4px;
    color: var(--mkp-muted);
    font-size: 11px;
    display: block;
  }

  .peminjaman-admin-wrap .mkp-filter-row>div {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .peminjaman-admin-wrap .mkp-filter-actions {
    display: flex;
    gap: 4px;
    align-items: flex-end;
    white-space: nowrap;
    flex-wrap: nowrap;
    flex-shrink: 0;
  }

  .peminjaman-admin-wrap .mkp-filter-row label {
    font-size: 11px;
    color: var(--mkp-muted);
    font-weight: 600;
  }

  .peminjaman-admin-wrap .mkp-filter-row select,
  .peminjaman-admin-wrap .mkp-filter-row input {
    font-size: 12px;
    padding: 4px 6px;
    height: 30px;
  }

  .peminjaman-admin-wrap .tbl-approval {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
  }

  .peminjaman-admin-wrap .tbl-approval th {
    background: linear-gradient(180deg, #334155 0%, #1e293b 100%);
    color: #fff;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    padding: 10px 12px;
    border: 1px solid #334155;
    white-space: nowrap;
    text-align: left;
  }

  .peminjaman-admin-wrap .tbl-approval td {
    padding: 9px 12px;
    border: 1px solid var(--mkp-border);
    vertical-align: middle;
    color: var(--mkp-text);
    font-weight: 500;
  }

  .peminjaman-admin-wrap .tbl-approval tbody tr:hover {
    background: #f8fafc;
  }

  .peminjaman-admin-wrap .tbl-approval tr.row-pending {
    background: #fffbeb;
  }

  .peminjaman-admin-wrap .tbl-approval tr.row-pending:hover {
    background: #fef3c7;
  }

  .peminjaman-admin-wrap .tbl-approval tr.row-onloan {
    background: #fffbeb;
    border-left: 3px solid #eab308;
  }

  .peminjaman-admin-wrap .tbl-approval tr.row-onloan td {
    background: #fffbeb !important;
  }

  .peminjaman-admin-wrap .tbl-approval tr.row-onloan:hover {
    background: #fef3c7;
  }

  .peminjaman-admin-wrap .tbl-approval tr.row-onloan:hover td {
    background: #fef3c7 !important;
  }

  .peminjaman-admin-wrap .tbl-approval tr.row-overdue {
    background: #fef2f2;
    border-left: 3px solid #ef4444;
  }

  .peminjaman-admin-wrap .tbl-approval tr.row-overdue:hover {
    background: #fee2e2;
  }

  .peminjaman-admin-wrap .tbl-approval tr.row-rejected {
    background: #f8f8f8;
    opacity: 0.7;
  }

  .peminjaman-admin-wrap .mkp-badge {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 4px;
    color: #fff;
    font-size: 11px;
    font-weight: 600;
    white-space: nowrap;
  }

  .peminjaman-admin-wrap .badge-success {
    background: #16a34a;
  }

  .peminjaman-admin-wrap .badge-warning {
    background: #d97706;
  }

  .peminjaman-admin-wrap .badge-danger {
    background: #dc2626;
  }

  .peminjaman-admin-wrap .badge-info {
    background: #2563eb;
  }

  .peminjaman-admin-wrap .badge-secondary {
    background: #64748b;
  }

  .peminjaman-admin-wrap .badge-primary {
    background: #7c3aed;
  }

  .peminjaman-admin-wrap .mkp-pagination {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 10px;
    font-size: 12px;
    color: var(--mkp-muted);
  }
</style>

<div class="menuBox peminjaman-admin-wrap">
  <div class="menuBoxInner circulationIcon">
    <div class="per_title">
      <h2>Approval Peminjaman</h2>
    </div>
    <div class="infoBox">
      Kelola persetujuan request peminjaman, pengembalian &amp; perpanjangan dari OPAC.
    </div>
  </div>

  <?php foreach ($messages['success'] as $message) { ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
  <?php } ?>
  <?php foreach ($messages['error'] as $message) { ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($message); ?></div>
  <?php } ?>

  <div class="mkp-card">
    <div style="margin-bottom:8px; font-weight:700; color:#0f172a;">Pengaturan Approval Pinjam</div>
    <form id="mkp-settings-form" method="post" action="<?php echo htmlspecialchars($pageUrl); ?>" class="mkp-setting-row">
      <input type="hidden" name="save_daily_loan_limit" value="1">
      <input type="hidden" name="mod" value="<?php echo htmlspecialchars($moduleParam); ?>">
      <?php if ($pluginMenuId !== '') { ?>
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($pluginMenuId); ?>">
      <?php } ?>
      <div>
        <label for="dailyLoanLimit">Batas Pinjam Harian per User</label>
        <input type="text" inputmode="numeric" autocomplete="off"
          id="dailyLoanLimit" name="daily_loan_limit"
          class="form-control" style="width:180px;"
          value="<?php echo htmlspecialchars($dailyLoanLimitInput); ?>" <?php echo $canWrite ? '' : ' disabled'; ?>
          oninput="this.value=this.value.replace(/[^0-9]/g,'');">
        <small class="mkp-setting-help">Wajib angka bulat 1-50. Contoh: 3 berarti user maksimal pinjam 3 buku/hari.</small>
      </div>
      <div>
        <label for="sameItemDailyLimit">Batas Item Sama per Hari</label>
        <input type="text" inputmode="numeric" autocomplete="off"
          id="sameItemDailyLimit" name="same_item_daily_limit"
          class="form-control" style="width:180px;"
          value="<?php echo htmlspecialchars($sameItemDailyLimitInput); ?>" <?php echo $canWrite ? '' : ' disabled'; ?>
          oninput="this.value=this.value.replace(/[^0-9]/g,'');">
        <small class="mkp-setting-help">Wajib angka bulat 2-50. Contoh: 3 = item yang sama tidak boleh sampai 3 kali/hari (maksimal 2 kali).</small>
        <?php if (!$canWrite) { ?>
          <small class="mkp-setting-help" style="color:#dc2626;">Akun ini tidak memiliki hak tulis modul sirkulasi.</small>
        <?php } ?>
      </div>
      <div style="min-width:320px;">
        <label for="allowWithoutVisitor" style="display:flex; align-items:center; gap:8px;">
          <input type="hidden" name="allow_without_visitor" value="0">
          <input type="checkbox" id="allowWithoutVisitor" name="allow_without_visitor" value="1"
            <?php echo $allowLoanWithoutVisitor ? ' checked' : ''; ?> <?php echo $canWrite ? '' : ' disabled'; ?>>
          Aktifkan pinjaman tanpa perlu isi form pengunjung
        </label>
        <small class="mkp-setting-help">Jika aktif, user bisa login peminjaman tanpa wajib mengisi Visitor pada hari yang sama.</small>
      </div>
      <div style="min-width:320px;">
        <label for="useVisitorSchedule" style="display:flex; align-items:center; gap:8px;">
          <input type="hidden" name="use_visitor_schedule" value="0">
          <input type="checkbox" id="useVisitorSchedule" name="use_visitor_schedule" value="1"
            <?php echo $useVisitorScheduleForLoan ? ' checked' : ''; ?> <?php echo $canWrite ? '' : ' disabled'; ?>>
          Gunakan jadwal pengunjung untuk meminjam
        </label>
        <small class="mkp-setting-help">Jika nonaktif, layanan peminjaman tidak mengikuti jam buka/tutup Visitor.</small>
      </div>
      <div>
        <button type="submit" class="btn btn-primary btn-sm"<?php echo $canWrite ? '' : ' disabled'; ?>>Simpan Batas</button>
      </div>
    </form>
  </div>

  <!-- Summary -->
  <div class="mkp-card">
    <div class="mkp-summary-grid">
      <?php foreach ($summaryByStatus as $sKey => $sCount) { ?>
        <div class="mkp-summary-item">
          <strong><?php echo htmlspecialchars(peminjamanStatusLabel($sKey)); ?></strong>
          <span><?php echo (int) $sCount; ?></span>
        </div>
      <?php } ?>
    </div>
  </div>

  <!-- Filter -->
  <div class="mkp-card">
    <form method="get" action="<?php echo $formAction; ?>"
      class="mkp-filter-row submitViaAJAX">
      <input type="hidden" name="mod" value="<?php echo htmlspecialchars($moduleParam); ?>">
      <input type="hidden" name="id" value="<?php echo htmlspecialchars($pluginMenuId); ?>">

      <div>
        <label>Status</label>
        <select name="status" class="form-control" style="width:120px;">
          <option value="all" <?php echo ($baseFilter['status'] === 'all') ? ' selected' : ''; ?>>Semua</option>
          <option value="pending" <?php echo ($baseFilter['status'] === 'pending') ? ' selected' : ''; ?>>Pending</option>
          <option value="approved" <?php echo ($baseFilter['status'] === 'approved') ? ' selected' : ''; ?>>Disetujui
          </option>
          <option value="rejected" <?php echo ($baseFilter['status'] === 'rejected') ? ' selected' : ''; ?>>Ditolak
          </option>
          <option value="failed" <?php echo ($baseFilter['status'] === 'failed') ? ' selected' : ''; ?>>Gagal</option>
        </select>
      </div>

      <div>
        <label>Aksi</label>
        <select name="action_type" class="form-control" style="width:120px;">
          <option value="all" <?php echo ($baseFilter['action_type'] === 'all') ? ' selected' : ''; ?>>Semua</option>
          <option value="loan" <?php echo ($baseFilter['action_type'] === 'loan') ? ' selected' : ''; ?>>Pinjam</option>
          <option value="return" <?php echo ($baseFilter['action_type'] === 'return') ? ' selected' : ''; ?>>Kembali
          </option>
          <option value="extend" <?php echo ($baseFilter['action_type'] === 'extend') ? ' selected' : ''; ?>>Perpanjang
          </option>
        </select>
      </div>

      <div>
        <label>Lokasi</label>
        <select name="visit_location" class="form-control" style="width:140px;">
          <option value="all">Semua</option>
          <?php foreach ($locationOptions as $opt) { ?>
            <option value="<?php echo htmlspecialchars($opt); ?>" <?php echo ($baseFilter['visit_location'] === $opt) ? ' selected' : ''; ?>>
              <?php echo htmlspecialchars($opt); ?>
            </option>
          <?php } ?>
        </select>
      </div>

      <div>
        <label>Dari</label>
        <input type="date" name="date_from" class="form-control" style="width:140px;"
          value="<?php echo htmlspecialchars($baseFilter['date_from']); ?>">
      </div>

      <div>
        <label>Sampai</label>
        <input type="date" name="date_to" class="form-control" style="width:140px;"
          value="<?php echo htmlspecialchars($baseFilter['date_to']); ?>">
      </div>

      <div>
        <label>Cari</label>
        <input type="text" name="keyword" class="form-control" style="width:180px;"
          value="<?php echo htmlspecialchars($baseFilter['keyword']); ?>" placeholder="Member, item, kode...">
      </div>

      <div class="mkp-filter-actions">
        <button type="submit" class="btn btn-primary btn-sm">Filter</button>
        <a href="<?php echo htmlspecialchars($refreshUrl); ?>"
          class="btn btn-info btn-sm">Refresh</a>
        <a href="<?php echo htmlspecialchars($resetUrl); ?>"
          class="btn btn-default btn-sm">Reset</a>
      </div>
    </form>
  </div>


  <!-- Table -->
  <div class="mkp-card mkp-table-wrapper">
    <div class="table-responsive">
      <table class="tbl-approval">
        <thead>
          <tr>
            <th style="width:40px;">No</th>
            <th>ID Anggota</th>
            <th>Member</th>
            <th style="width:80px;">Tipe</th>
            <th>Kode Item</th>
            <th>Judul</th>
            <th>Lokasi</th>
            <th style="width:130px;">Tanggal</th>
            <th style="width:90px;">Status</th>
            <th style="width:80px;">Aksi</th>
            <th style="width:130px;">Status Pinjaman</th>
            <th style="min-width:180px;">Aksi Admin</th>
          </tr>
        </thead>
        <tbody>
          <?php if (count($rows) < 1) { ?>
            <tr>
              <td colspan="12" style="text-align:center; color:#94a3b8; padding:20px;">Belum ada data request.</td>
            </tr>
          <?php } ?>

          <?php foreach ($rows as $row) {
            $requestId = (int) $row['request_id'];
            $status = strtolower(trim((string) ($row['status'] ?? '')));
            if ($status === '') {
              $status = 'pending';
            }
            $badgeClass = peminjamanBadgeClass($status);
            $requestItems = $itemMap[$requestId] ?? [];
            $isPending = ($status === 'pending');
            $isRejected = ($status === 'rejected');

            // Build item info (first item for main row, expand if multiple)
            $firstItem = $requestItems[0] ?? null;
            $itemCode = $firstItem ? htmlspecialchars((string) ($firstItem['item_code'] ?: '-')) : '-';
            $itemTitle = $firstItem ? htmlspecialchars((string) ($firstItem['title'] ?? '-')) : '-';
            $itemLocation = $firstItem ? htmlspecialchars((string) ($firstItem['item_location'] ?? '-')) : '-';
            $firstLoanMeta = $resolveLoanStatusMeta($row, $firstItem);

            $rowClass = '';
            if (!empty($firstLoanMeta['is_overdue'])) {
              $rowClass = 'row-overdue';
            } elseif (($firstLoanMeta['label'] ?? '') === 'Sedang Dipinjam') {
              $rowClass = 'row-onloan';
            } elseif ($isPending) {
              $rowClass = 'row-pending';
            } elseif ($isRejected) {
              $rowClass = 'row-rejected';
            }

            // action badge color
            $actionBadge = match ((string) $row['action_type']) {
              'loan' => 'badge-warning',
              'return' => 'badge-success',
              'extend', 'renew', 'renewal' => 'badge-info',

              default => 'badge-secondary'
            };

            // Member warning (batch-loaded map, avoids N+1 queries)
            $liveMember = $memberStatusMap[(string) ($row['member_id'] ?? '')] ?? null;
            $memberFlag = '';
            if (!$liveMember) {
              $memberFlag = ' <span class="mkp-badge badge-danger" style="font-size:9px;">Tidak Ada</span>';
            } elseif ((int) ($liveMember['is_pending'] ?? 0) === 1) {
              $memberFlag = ' <span class="mkp-badge badge-warning" style="font-size:9px;">Pending</span>';
            } elseif (isset($liveMember['expire_date']) && $liveMember['expire_date'] < date('Y-m-d')) {
              $memberFlag = ' <span class="mkp-badge badge-danger" style="font-size:9px;">Expired</span>';
            }
            ?>
            <tr class="<?php echo $rowClass; ?>">
              <td style="text-align:center; font-weight:700;"><?php echo $requestId; ?></td>
              <td><code
                  style="font-size:12px; background:#f1f5f9; padding:2px 6px; border-radius:3px;"><?php echo htmlspecialchars((string) ($row['member_id'] ?: '-')); ?></code>
              </td>
              <td>
                <?php echo htmlspecialchars((string) ($row['member_name'] ?: '-')); ?>   <?php echo $memberFlag; ?>
              </td>
              <td><?php echo htmlspecialchars((string) ($row['member_type_name'] ?: '-')); ?></td>
              <td><code
                  style="font-size:11px; background:#f1f5f9; padding:1px 5px; border-radius:3px;"><?php echo $itemCode; ?></code>
              </td>
              <td><?php echo $itemTitle; ?></td>
              <td><?php echo htmlspecialchars((string) ($row['visit_location'] ?: '-')); ?></td>
              <td style="white-space:nowrap;">
                <?php echo htmlspecialchars(date('d M Y H:i', strtotime((string) $row['requested_at']))); ?>
              </td>
              <td style="text-align:center;">
                <span
                  class="mkp-badge badge-<?php echo htmlspecialchars($badgeClass); ?>"><?php echo htmlspecialchars(peminjamanStatusLabel($status)); ?></span>
              </td>
              <td>
                <span class="mkp-badge <?php echo $actionBadge; ?>">
                  <?php echo htmlspecialchars(peminjamanActionLabel((string) $row['action_type'])); ?>
                </span>
              </td>
              <td style="text-align:center;">
                <span class="mkp-badge <?php echo htmlspecialchars((string) ($firstLoanMeta['badge'] ?? 'badge-secondary')); ?>" style="font-size:10px;">
                  <?php echo htmlspecialchars((string) ($firstLoanMeta['label'] ?? '-')); ?>
                </span>
                <?php if (!empty($firstLoanMeta['detail'])) { ?>
                  <div style="font-size:9px; color:#64748b; margin-top:2px;">
                    <?php echo htmlspecialchars((string) $firstLoanMeta['detail']); ?>
                  </div>
                <?php } ?>
              </td>
              <td>
                <?php if ($isPending && $canWrite) { ?>
                  <div class="mkp-action-row" data-request-id="<?php echo $requestId; ?>"
                    style="display:flex; gap:4px; align-items:center; flex-wrap:wrap;">
                    <input type="text" class="form-control mkp-admin-note"
                      style="font-size:11px; height:28px; width:100px; flex:1;" placeholder="Catatan...">
                    <button type="button" class="btn btn-success btn-sm mkp-btn-approve"
                      style="font-size:11px; padding:3px 8px;" data-rid="<?php echo $requestId; ?>">✓ Setujui</button>
                    <button type="button" class="btn btn-danger btn-sm mkp-btn-reject"
                      style="font-size:11px; padding:3px 8px;" data-rid="<?php echo $requestId; ?>">✗ Tolak</button>
                  </div>
                <?php } else { ?>
                  <span style="color:#94a3b8; font-size:11px;">
                    <?php echo htmlspecialchars((string) ($row['admin_username'] ?: '')); ?>
                    <?php if (!empty($row['process_result'])) { ?>
                      — <?php echo htmlspecialchars((string) $row['process_result']); ?>
                    <?php } ?>
                  </span>
                <?php } ?>
              </td>
            </tr>

            <?php
            // Extra rows for additional items (if more than 1 item in the request)
            if (count($requestItems) > 1) {
              for ($i = 1; $i < count($requestItems); $i++) {
                $extraItem = $requestItems[$i];
                $extraLoanMeta = $resolveLoanStatusMeta($row, $extraItem);
                $extraRowClass = '';
                if (!empty($extraLoanMeta['is_overdue'])) {
                  $extraRowClass = 'row-overdue';
                } elseif (($extraLoanMeta['label'] ?? '') === 'Sedang Dipinjam') {
                  $extraRowClass = 'row-onloan';
                } elseif ($isPending) {
                  $extraRowClass = 'row-pending';
                } elseif ($isRejected) {
                  $extraRowClass = 'row-rejected';
                }
                ?>
                <tr class="<?php echo $extraRowClass; ?>">
                  <td colspan="6" style="text-align:right; color:#94a3b8; font-size:11px;">↳ item <?php echo ($i + 1); ?></td>
                  <td><code
                      style="font-size:11px; background:#f1f5f9; padding:1px 5px; border-radius:3px;"><?php echo htmlspecialchars((string) ($extraItem['item_code'] ?: '-')); ?></code>
                  </td>
                  <td><?php echo htmlspecialchars((string) ($extraItem['title'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string) ($extraItem['item_location'] ?? '-')); ?></td>
                  <td colspan="2" style="text-align:center;">
                    <span class="mkp-badge <?php echo htmlspecialchars((string) ($extraLoanMeta['badge'] ?? 'badge-secondary')); ?>" style="font-size:10px;">
                      <?php echo htmlspecialchars((string) ($extraLoanMeta['label'] ?? '-')); ?>
                    </span>
                    <?php if (!empty($extraLoanMeta['detail'])) { ?>
                      <div style="font-size:9px; color:#64748b; margin-top:2px;">
                        <?php echo htmlspecialchars((string) $extraLoanMeta['detail']); ?>
                      </div>
                    <?php } ?>
                  </td>
                  <td></td>
                </tr>
                <?php
              }
            }
            ?>

          <?php } ?>
        </tbody>
      </table>
    </div>

    <div class="mkp-pagination">
      <div>Menampilkan <?php echo count($rows); ?> dari <?php echo (int) $totalRows; ?> data</div>
      <div>
        <?php if ($page > 1) { ?>
          <a class="btn btn-default btn-sm" href="<?php echo htmlspecialchars($buildPageUrl($page - 1)); ?>">&laquo;
            Prev</a>
        <?php } ?>
        <span>Hal <?php echo (int) $page; ?> / <?php echo (int) $totalPages; ?></span>
        <?php if ($page < $totalPages) { ?>
          <a class="btn btn-default btn-sm" href="<?php echo htmlspecialchars($buildPageUrl($page + 1)); ?>">Next
            &raquo;</a>
        <?php } ?>
      </div>
    </div>


  </div>

  <!-- Toast notification container -->
  <div id="mkp-toast"
    style="display:none; position:fixed; top:20px; right:20px; z-index:9999; min-width:300px; max-width:450px; padding:14px 18px; border-radius:8px; font-size:13px; color:#fff; box-shadow:0 4px 20px rgba(0,0,0,0.25); transition:all 0.3s ease;">
  </div>

  <!-- Sinkronisasi manual (tanpa realtime) -->
  <div id="mkp-sync-bar"
    style="display:flex; justify-content:space-between; align-items:center; padding:6px 14px; background:#f1f5f9; border-radius:6px; margin-top:8px; font-size:11px; color:#64748b;">
    <div>
      🕒 <span id="mkp-sync-status">Realtime nonaktif</span>
      — Terakhir diperbarui: <strong id="mkp-sync-time"><?php echo date('H:i:s'); ?></strong>
    </div>
  </div>

  <script>
    (function () {
      var API_URL = <?php echo json_encode($ajaxUrl, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
      var PAGE_URL = <?php echo json_encode($pageUrl, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
      var toastEl = document.getElementById('mkp-toast');
      var toastTimer = null;
      var syncTime = document.getElementById('mkp-sync-time');
      var syncStatus = document.getElementById('mkp-sync-status');

      function padZero(n) { return n < 10 ? '0' + n : '' + n; }

      function showToast(message, type) {
        if (!toastEl) return;
        toastEl.style.background = type === 'success' ? '#16a34a' : type === 'error' ? '#dc2626' : '#2563eb';
        toastEl.textContent = message;
        toastEl.style.display = 'block';
        toastEl.style.opacity = '1';
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(function () {
          toastEl.style.opacity = '0';
          setTimeout(function () { toastEl.style.display = 'none'; }, 300);
        }, 4000);
      }

      function parseResponseJSON(res) {
        var contentType = (res.headers.get('content-type') || '').toLowerCase();
        if (contentType.indexOf('application/json') !== -1) {
          return res.json();
        }
        return res.text().then(function (text) {
          var clean = (text || '').replace(/\s+/g, ' ').trim();
          throw new Error(clean ? clean.substring(0, 180) : 'Respon server bukan JSON.');
        });
      }

      function setSyncStatus(message, color) {
        if (!syncStatus) return;
        syncStatus.textContent = message;
        if (color) syncStatus.style.color = color;
      }

      function updateSyncTimeNow() {
        if (!syncTime) return;
        var now = new Date();
        syncTime.textContent = padZero(now.getHours()) + ':' + padZero(now.getMinutes()) + ':' + padZero(now.getSeconds());
      }

      // Reload table + summary only when needed (manual update after action).
      function refreshTable() {
        var xhr = new XMLHttpRequest();
        var syncUrl = PAGE_URL + (PAGE_URL.indexOf('?') === -1 ? '?' : '&') + '_sync=' + Date.now();
        xhr.open('GET', syncUrl, true);
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        xhr.setRequestHeader('Cache-Control', 'no-cache');
        xhr.onreadystatechange = function () {
          if (xhr.readyState !== 4) return;

          if (xhr.status === 200) {
            var html = xhr.responseText;
            var tempDiv = document.createElement('div');
            tempDiv.innerHTML = html;
            var newSummary = tempDiv.querySelector('.mkp-summary-grid');
            var currentSummary = document.querySelector('.mkp-summary-grid');
            var newTable = tempDiv.querySelector('.mkp-table-wrapper');
            var currentTable = document.querySelector('.mkp-table-wrapper');
            if (newSummary && currentSummary) {
              currentSummary.innerHTML = newSummary.innerHTML;
            }
            if (newTable && currentTable) {
              currentTable.innerHTML = newTable.innerHTML;
            }
            updateSyncTimeNow();
            setSyncStatus('Diperbarui manual', '#0ea5e9');
            return;
          }
          setSyncStatus('Gagal sinkronisasi', '#dc2626');
        };
        xhr.onerror = function () {
          setSyncStatus('Gagal sinkronisasi', '#dc2626');
        };
        xhr.send();
      }

      var actionLocks = {};

      function lockAction(requestId) {
        actionLocks[String(requestId)] = true;
      }

      function unlockAction(requestId) {
        delete actionLocks[String(requestId)];
      }

      function isActionLocked(requestId) {
        return !!actionLocks[String(requestId)];
      }

      // AJAX approval/rejection
      function processRequest(requestId, decision, adminNote, btnEl) {
        requestId = String(requestId || '');
        if (requestId === '') return;
        if (isActionLocked(requestId)) return;

        if (decision === 'reject' && !adminNote) {
          showToast('Alasan penolakan wajib diisi!', 'error');
          return;
        }
        var confirmMsg = decision === 'approve'
          ? 'Setujui request #' + requestId + '?'
          : 'Tolak request #' + requestId + '?';
        if (!confirm(confirmMsg)) return;
        lockAction(requestId);

        var row = btnEl.closest('.mkp-action-row');
        if (row) {
          var btns = row.querySelectorAll('button');
          btns.forEach(function (b) { b.disabled = true; b.style.opacity = '0.5'; });
        }
        btnEl.textContent = '⏳ Proses...';

        var formData = new FormData();
        formData.append('action', 'process');
        formData.append('request_id', requestId);
        formData.append('decision', decision);
        formData.append('admin_note', adminNote);

        fetch(API_URL, {
          method: 'POST',
          body: formData,
          credentials: 'include'
        })
          .then(parseResponseJSON)
          .then(function (data) {
            if (data.ok) {
              var statusLabel = data.final_status === 'approved' ? 'Disetujui'
                : data.final_status === 'rejected' ? 'Ditolak'
                  : data.final_status;
              showToast('✅ Request #' + requestId + ' berhasil diproses! Status: ' + statusLabel, 'success');
              unlockAction(requestId);
              refreshTable();
            } else {
              showToast('❌ Gagal: ' + (data.message || 'Error tidak diketahui'), 'error');
              unlockAction(requestId);
              if (row) {
                var btns = row.querySelectorAll('button');
                btns.forEach(function (b) { b.disabled = false; b.style.opacity = '1'; });
              }
            }
          })
          .catch(function (err) {
            showToast('❌ Gagal koneksi ke server: ' + err.message, 'error');
            unlockAction(requestId);
            if (row) {
              var btns = row.querySelectorAll('button');
              btns.forEach(function (b) { b.disabled = false; b.style.opacity = '1'; });
            }
          });
      }

      // Event delegation for approve/reject buttons
      if (window.__mkpApprovalClickHandler) {
        document.removeEventListener('click', window.__mkpApprovalClickHandler, true);
      }
      window.__mkpApprovalClickHandler = function (e) {
        var target = e.target;
        if (!target || !target.closest) return;
        var btn = target.closest('.mkp-btn-approve, .mkp-btn-reject');
        if (!btn) return;

        e.preventDefault();
        if (typeof e.stopImmediatePropagation === 'function') {
          e.stopImmediatePropagation();
        } else {
          e.stopPropagation();
        }

        var rid = btn.getAttribute('data-rid');
        var row = btn.closest('.mkp-action-row');
        var noteInput = row ? row.querySelector('.mkp-admin-note') : null;
        var note = noteInput ? noteInput.value : '';

        if (btn.classList.contains('mkp-btn-approve')) {
          processRequest(rid, 'approve', note, btn);
        } else {
          processRequest(rid, 'reject', note, btn);
        }
      };
      document.addEventListener('click', window.__mkpApprovalClickHandler, true);

      setSyncStatus('Realtime nonaktif', '#94a3b8');
      updateSyncTimeNow();
    })();
  </script>
</div>
