<?php
/**
 * Plugin Name: pinjamanapproval
 * Plugin URI: https://github.com/Franklnir/plugin_peminjaman_buku.git
 * Description: Form peminjaman koleksi dari OPAC dengan approval admin (pinjam, kembali, perpanjang).
 * Version: 1.1.0
 * Author: Irsyad
 * Author URI: https://github.com/Franklnir/plugin_peminjaman_buku.git
 */

use SLiMS\Plugins;

if (defined('PEMINJAMAN_PLUGIN_BOOTSTRAPPED')) {
    return;
}
define('PEMINJAMAN_PLUGIN_BOOTSTRAPPED', true);

if (defined('MAGANGKPFITUR_USE_UPDATETERBARU')) {
    return;
}

require_once __DIR__ . '/lib.php';

if (isset($dbs) && $dbs instanceof mysqli) {
    peminjamanEnsureSchema($dbs);
}

$plugin = Plugins::getInstance();
$loanMenuLabel = peminjamanTranslate('menu_loan');
$loanMenuDesc = peminjamanTranslate('menu_loan_desc');
$approvalMenuLabel = peminjamanTranslate('menu_approval');
$approvalMenuDesc = peminjamanTranslate('menu_approval_desc');

$plugin->registerMenu(
    'opac',
    'Peminjaman',
    __DIR__ . '/peminjaman.php',
    $loanMenuDesc
);

$plugin->registerMenu(
    'circulation',
    $approvalMenuLabel,
    __DIR__ . '/approval.php',
    $approvalMenuDesc
);

$plugin->register(Plugins::CONTENT_BEFORE_LOAD, function ($opac) {
    $catalog = peminjamanGetTranslationCatalog();
    $navCatalog = [
        'home' => $catalog['nav_home'] ?? ['id' => 'Beranda', 'en' => 'Home'],
        'visitor' => $catalog['nav_visitor'] ?? ['id' => 'Kunjungan', 'en' => 'Visitor'],
        'information' => $catalog['nav_information'] ?? ['id' => 'Informasi', 'en' => 'Information'],
        'news' => $catalog['nav_news'] ?? ['id' => 'Berita', 'en' => 'News'],
        'location' => $catalog['nav_location'] ?? ['id' => 'Lokasi Perpustakaan', 'en' => 'Library Location'],
        'member_area' => $catalog['nav_member_area'] ?? ['id' => 'Area Anggota', 'en' => 'Member Area'],
        'librarian' => $catalog['nav_librarian'] ?? ['id' => 'Pustakawan', 'en' => 'Librarian'],
        'help' => $catalog['nav_help'] ?? ['id' => 'Bantuan', 'en' => 'Help'],
        'librarian_login' => $catalog['nav_librarian_login'] ?? ['id' => 'Login Pustakawan', 'en' => 'Librarian Login'],
        'loan' => $catalog['nav_loan'] ?? ['id' => 'Peminjaman', 'en' => 'Loan Request']
    ];

    $activeLang = strpos(peminjamanGetActiveLang(), 'id') === 0 ? 'id' : 'en';
    $activeLangJs = json_encode($activeLang, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $navCatalogJs = json_encode($navCatalog, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $heroSearchPlaceholder = $activeLang === 'id'
      ? 'Masukkan kata kunci koleksi...'
      : 'Enter keyword to search collection...';
    $heroSearchPlaceholderJs = json_encode($heroSearchPlaceholder, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $loanHeaderTitle = $activeLang === 'id' ? 'Peminjaman Koleksi' : 'Loan Request';
    $loanHeaderTitleJs = json_encode($loanHeaderTitle, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $js = $opac->js ?? '';
    $js .= <<<HTML
<style>
  .mkp-opac-target-page .result-search .c-header {
    background-image:
      linear-gradient(180deg, rgba(15, 23, 42, 0.45) 0%, rgba(15, 23, 42, 0.2) 38%, rgba(15, 23, 42, 0.38) 100%),
      url('template/default/assets/images/slide2.jpg') !important;
    background-size: cover !important;
    background-position: center center !important;
  }

  .mkp-opac-target-page .result-search .c-header .mask {
    background: linear-gradient(180deg, rgba(15, 23, 42, 0.2) 0%, rgba(15, 23, 42, 0.14) 55%, rgba(15, 23, 42, 0.24) 100%) !important;
  }

  .mkp-opac-target-page .mkp-opac-existing-search .card {
    background: rgba(255, 255, 255, 0.96) !important;
    border: 1px solid rgba(148, 163, 184, 0.42) !important;
    border-radius: 8px !important;
    box-shadow: 0 10px 30px rgba(15, 23, 42, 0.2) !important;
  }

  .mkp-opac-target-page .result-search .search .input-transparent {
    color: #1e293b !important;
  }

  .mkp-opac-target-page .result-search .search .input-transparent::placeholder {
    color: #94a3b8 !important;
  }

  body.mkp-with-injected-hero {
    background: #e5e7eb !important;
  }

  body.mkp-with-injected-hero .s-menu,
  body.mkp-with-injected-hero nav.s-menu {
    display: none !important;
  }

  body.mkp-with-injected-hero .s-main.s-login {
    margin-top: 0 !important;
    padding-top: 0 !important;
  }

  body.mkp-with-injected-hero .s-login-content {
    width: 100% !important;
    max-width: 100% !important;
    margin: 0 !important;
    padding: 0 !important;
    border-radius: 0 !important;
    box-shadow: none !important;
    background: transparent !important;
  }

  body.mkp-with-injected-hero #visitor-counter {
    min-height: calc(100vh - 232px) !important;
  }

  .mkp-special-hero {
    position: relative;
    min-height: 210px;
    color: #f8fafc;
    background-image:
      linear-gradient(180deg, rgba(15, 23, 42, 0.46) 0%, rgba(15, 23, 42, 0.62) 100%),
      url('template/default/assets/images/slide2.jpg');
    background-size: cover;
    background-position: center;
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
  }

  .mkp-special-hero-inner {
    position: relative;
    max-width: 1320px;
    margin: 0 auto;
    padding: 14px 18px 60px;
  }

  .mkp-special-hero-topbar {
    display: flex;
    align-items: center;
    gap: 16px;
  }

  .mkp-special-brand {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    color: #f8fafc !important;
    text-decoration: none !important;
    white-space: nowrap;
  }

  .mkp-special-brand-logo {
    width: 34px;
    height: 34px;
    object-fit: contain;
    display: inline-block;
  }

  .mkp-special-brand-name {
    font-size: 38px;
    font-weight: 600;
    letter-spacing: 0.2px;
    line-height: 1;
    text-shadow: 0 2px 6px rgba(0, 0, 0, 0.32);
  }

  .mkp-special-nav {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    align-items: center;
    gap: 18px;
    flex: 1;
    justify-content: flex-end;
    flex-wrap: wrap;
  }

  .mkp-special-nav-item a {
    color: rgba(255, 255, 255, 0.86);
    text-decoration: none;
    font-size: 17px;
    font-weight: 500;
    line-height: 1.2;
    text-shadow: 0 1px 3px rgba(0, 0, 0, 0.35);
  }

  .mkp-special-nav-item.is-active a {
    color: #ffffff;
    font-weight: 800;
  }

  .mkp-special-lang {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 20px;
    white-space: nowrap;
    text-decoration: none !important;
  }

  .mkp-special-lang-flag {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    text-decoration: none !important;
    line-height: 1;
  }

  .mkp-special-search {
    position: absolute;
    left: 50%;
    bottom: -28px;
    transform: translateX(-50%);
    width: min(760px, calc(100% - 36px));
    display: grid;
    grid-template-columns: 1fr 60px;
    background: rgba(255, 255, 255, 0.95);
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 12px 32px rgba(15, 23, 42, 0.3);
  }

  .mkp-special-search input {
    height: 56px;
    border: none;
    padding: 0 20px;
    color: #0f172a;
    font-size: 25px;
    font-weight: 500;
    background: transparent;
  }

  .mkp-special-search input::placeholder {
    color: #cbd5e1;
    opacity: 1;
  }

  .mkp-special-search button {
    border: none;
    background: transparent;
    color: #374151;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .mkp-special-search-icon {
    width: 18px;
    height: 18px;
    border: 2px solid #374151;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    box-sizing: border-box;
  }

  .mkp-special-search-icon::after {
    content: '';
    position: absolute;
    width: 8px;
    height: 2px;
    background: #374151;
    right: -6px;
    bottom: -1px;
    transform: rotate(42deg);
    border-radius: 2px;
  }

  @media (max-width: 1200px) {
    .mkp-special-brand-name {
      font-size: 31px;
    }

    .mkp-special-nav-item a {
      font-size: 15px;
    }

    .mkp-special-nav {
      gap: 12px;
    }

    .mkp-special-search input {
      font-size: 20px;
    }
  }

  @media (max-width: 991px) {
    .mkp-special-hero {
      min-height: 188px;
    }

    .mkp-special-hero-topbar {
      flex-direction: column;
      align-items: flex-start;
      gap: 12px;
    }

    .mkp-special-nav {
      justify-content: flex-start;
      width: 100%;
      overflow-x: auto;
      flex-wrap: nowrap;
      padding-bottom: 4px;
    }

    .mkp-special-lang {
      position: absolute;
      right: 18px;
      top: 16px;
    }

    .mkp-special-search {
      bottom: -22px;
      width: calc(100% - 24px);
    }

    .mkp-special-search input {
      height: 46px;
      font-size: 18px;
      padding: 0 14px;
    }

    .mkp-special-search button {
      font-size: 16px;
    }

    body.mkp-with-injected-hero #visitor-counter {
      min-height: calc(100vh - 210px) !important;
    }
  }
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {
  var currentPage = new URLSearchParams(window.location.search).get('p') || '';
  var activeLang = {$activeLangJs};
  var navCatalog = {$navCatalogJs};
  var heroSearchPlaceholder = {$heroSearchPlaceholderJs};
  var loanHeaderTitle = {$loanHeaderTitleJs};

  function normalizeText(value) {
    return (value || '').replace(/\\s+/g, ' ').trim().toLowerCase();
  }

  function getLabelByKey(key) {
    if (!navCatalog[key]) return '';
    return activeLang === 'id' ? navCatalog[key].id : navCatalog[key].en;
  }

  function getTopLevelAnchors(menu) {
    var anchors = [];
    if (!menu || !menu.children) return anchors;
    for (var i = 0; i < menu.children.length; i += 1) {
      var li = menu.children[i];
      if (!li || li.tagName !== 'LI') continue;
      var link = li.firstElementChild;
      if (link && link.tagName === 'A') {
        anchors.push(link);
      }
    }
    return anchors;
  }

  function getKeyByHref(href) {
    if (!href || href === '#' || href.toLowerCase().indexOf('javascript:') === 0) return null;

    var parsed;
    try {
      parsed = new URL(href, window.location.href);
    } catch (e) {
      return null;
    }

    var page = (parsed.searchParams.get('p') || '').toLowerCase();
    if (page === 'visitor') return 'visitor';
    if (page === 'libinfo') return 'information';
    if (page === 'news') return 'news';
    if (page === 'peta') return 'location';
    if (page === 'member') return 'member_area';
    if (page === 'librarian') return 'librarian';
    if (page === 'help') return 'help';
    if (page === 'login') return 'librarian_login';
    if (page === 'peminjaman') return 'loan';

    var path = (parsed.pathname || '').toLowerCase();
    if (!page && /(^|\\/)index\\.php$/.test(path)) {
      return 'home';
    }

    return null;
  }

  function setAnchorLabel(anchor, label) {
    if (!anchor || !label) return;
    if (anchor.querySelector('img,svg')) return;

    for (var i = 0; i < anchor.childNodes.length; i += 1) {
      var node = anchor.childNodes[i];
      if (node.nodeType === Node.TEXT_NODE && normalizeText(node.nodeValue) !== '') {
        node.nodeValue = label;
        return;
      }
    }

    if (!anchor.firstElementChild) {
      anchor.textContent = label;
    }
  }

  var aliasMap = {
    information: ['library information'],
    news: ['library news'],
    location: ['library location'],
    help: ['help on search'],
    librarian_login: ['librarian login']
  };

  var textLookup = {};
  Object.keys(navCatalog).forEach(function (key) {
    var item = navCatalog[key] || {};
    var idText = normalizeText(item.id || '');
    var enText = normalizeText(item.en || '');
    if (idText) textLookup[idText] = key;
    if (enText) textLookup[enText] = key;
    if (aliasMap[key]) {
      for (var i = 0; i < aliasMap[key].length; i += 1) {
        var alias = normalizeText(aliasMap[key][i] || '');
        if (alias) textLookup[alias] = key;
      }
    }
  });

  function resolveKey(anchor) {
    if (!anchor) return null;
    var href = anchor.getAttribute('href') || '';
    if (href.indexOf('logout=1') !== -1) return null;
    if (href.indexOf('p=member') !== -1 && href.indexOf('sec=') !== -1) return null;

    var byHref = getKeyByHref(href);
    if (byHref) return byHref;

    var byText = textLookup[normalizeText(anchor.textContent || '')];
    return byText || null;
  }

  function applyMenuTranslation(menu) {
    var anchors = getTopLevelAnchors(menu);
    for (var i = 0; i < anchors.length; i += 1) {
      var anchor = anchors[i];
      var key = resolveKey(anchor);
      if (!key) continue;
      setAnchorLabel(anchor, getLabelByKey(key));
    }
  }

  function insertLoanMenu(menu, isNavbar) {
    if (!menu) return;
    if (menu.querySelector('a[href*="p=peminjaman"]')) return;

    var itemLi = document.createElement('li');
    var itemA = document.createElement('a');
    itemA.href = 'index.php?p=peminjaman';
    itemA.textContent = getLabelByKey('loan');

    if (isNavbar) {
      itemLi.className = 'nav-item' + (currentPage === 'peminjaman' ? ' active' : '');
      itemA.className = 'nav-link';
    }

    itemLi.appendChild(itemA);

    var visitorAnchor = menu.querySelector('a[href*="p=visitor"]');
    var visitorLi = visitorAnchor ? visitorAnchor.closest('li') : null;
    if (visitorLi && visitorLi.parentNode) {
      visitorLi.parentNode.insertBefore(itemLi, visitorLi.nextSibling);
      return;
    }

    var homeAnchor = menu.querySelector('a[href="index.php"], a[href="./index.php"]');
    var homeLi = homeAnchor ? homeAnchor.closest('li') : null;
    if (homeLi && homeLi.parentNode) {
      homeLi.parentNode.insertBefore(itemLi, homeLi.nextSibling);
      return;
    }

    menu.appendChild(itemLi);
  }

  function insertLibrarianLoginMenu(menu, isNavbar) {
    if (!menu) return;
    if (menu.querySelector('a[href*="p=login"]')) return;

    var itemLi = document.createElement('li');
    var itemA = document.createElement('a');
    itemA.href = 'index.php?p=login';
    itemA.textContent = getLabelByKey('librarian_login');

    if (isNavbar) {
      itemLi.className = 'nav-item' + (currentPage === 'login' ? ' active' : '');
      itemA.className = 'nav-link';
    }

    itemLi.appendChild(itemA);

    var memberAnchor = menu.querySelector('a#navbarDropdown, a[href*="p=member"]');
    var memberLi = memberAnchor ? memberAnchor.closest('li') : null;
    if (memberLi && memberLi.parentNode) {
      memberLi.parentNode.insertBefore(itemLi, memberLi.nextSibling);
      return;
    }

    menu.appendChild(itemLi);
  }

  function normalizeLocationLinks(root) {
    if (!root || !root.querySelectorAll) return;
    var links = root.querySelectorAll('a[href*="p=peta"]');
    for (var i = 0; i < links.length; i += 1) {
      var link = links[i];
      if (!link) continue;

      // Revert to native popup behavior for Library Location (colorbox).
      if (link.dataset && link.dataset.mkpForceFullNav === '1' && link.parentNode) {
        var cloned = link.cloneNode(true);
        link.parentNode.replaceChild(cloned, link);
        link = cloned;
      }

      if (link.classList && !link.classList.contains('openPopUp')) {
        link.classList.add('openPopUp');
      }
      if (!link.getAttribute('width')) {
        link.setAttribute('width', '600');
      }
      if (!link.getAttribute('height')) {
        link.setAttribute('height', '400');
      }
      if (!link.getAttribute('title')) {
        link.setAttribute('title', getLabelByKey('location') || 'Library Location');
      }

      link.removeAttribute('data-toggle');
      link.removeAttribute('data-target');
      link.removeAttribute('data-mkp-force-full-nav');
    }
  }

  function isHeroTargetPage(page) {
    var key = (page || '').toLowerCase();
    return key === 'visitor'
      || key === 'peminjaman'
      || key === 'peta'
      || key === 'librarian'
      || key === 'libinfo';
  }

  function harmonizeHeroArea() {
    if (!isHeroTargetPage(currentPage)) return;
    if (document.body) {
      document.body.classList.add('mkp-opac-target-page');
    }

    // Cleanup: remove injected hero from previous plugin version (avoid duplicate banner).
    var oldInjected = document.querySelectorAll('.mkp-opac-hero');
    for (var i = 0; i < oldInjected.length; i += 1) {
      if (oldInjected[i] && oldInjected[i].parentNode) {
        oldInjected[i].parentNode.removeChild(oldInjected[i]);
      }
    }

    var existingSearchBlocks = document.querySelectorAll('.result-search .search');
    for (var j = 0; j < existingSearchBlocks.length; j += 1) {
      existingSearchBlocks[j].classList.add('mkp-opac-existing-search');
    }

    var keywordInput = document.querySelector('.result-search .search #search-input');
    if (keywordInput && !keywordInput.value) {
      keywordInput.setAttribute('placeholder', heroSearchPlaceholder);
    }

    if (currentPage === 'peminjaman') {
      var titleNodes = document.querySelectorAll('.s-main-page .s-main-search .s-main-title');
      for (var k = 0; k < titleNodes.length; k += 1) {
        if (titleNodes[k]) {
          titleNodes[k].textContent = loanHeaderTitle;
        }
      }

      // Default theme: page title shown in content area (h2 + hr).
      var defaultTitle = document.querySelector('.result-search > section.container.mt-8 > h2.mb-4, .result-search > section.container.mt-8 > h2');
      if (defaultTitle) {
        defaultTitle.textContent = loanHeaderTitle;
      }
    }
  }

  function buildLangHref(langCode) {
    var params = new URLSearchParams(window.location.search || '');
    if (!params.get('p')) {
      params.set('p', currentPage || 'visitor');
    }
    params.set('select_lang', langCode);
    var query = params.toString();
    return query ? ('index.php?' + query) : 'index.php';
  }

  function getBrandName() {
    var title = (document.title || '').trim();
    if (title.indexOf('|') !== -1) {
      var parts = title.split('|');
      var brand = (parts[parts.length - 1] || '').trim();
      if (brand) return brand;
    }
    var navbarBrand = document.querySelector('.navbar-brand, .s-brand');
    if (navbarBrand) {
      var brandText = (navbarBrand.textContent || '').trim();
      if (brandText) return brandText;
    }
    return 'Senayan';
  }

  function injectSpecialHero() {
    if (currentPage !== 'visitor') return;
    if (document.getElementById('mkpSpecialHero')) return;
    if (!document.body) return;

    var body = document.body;
    body.classList.add('mkp-with-injected-hero');

    var menuConfig = [
      {key: 'home', href: 'index.php', page: ''},
      {key: 'visitor', href: 'index.php?p=visitor', page: 'visitor'},
      {key: 'loan', href: 'index.php?p=peminjaman', page: 'peminjaman'},
      {key: 'information', href: 'index.php?p=libinfo', page: 'libinfo'},
      {key: 'location', href: 'index.php?p=peta', page: 'peta'},
      {key: 'news', href: 'index.php?p=news', page: 'news'},
      {key: 'help', href: 'index.php?p=help', page: 'help'},
      {key: 'librarian', href: 'index.php?p=librarian', page: 'librarian'},
      {key: 'member_area', href: 'index.php?p=member', page: 'member'},
      {key: 'librarian_login', href: 'index.php?p=login', page: 'login'}
    ];

    var menuHtml = '';
    for (var i = 0; i < menuConfig.length; i += 1) {
      var item = menuConfig[i];
      var label = getLabelByKey(item.key) || '';
      if (!label) continue;
      var activeClass = (currentPage === item.page || (!currentPage && !item.page)) ? ' is-active' : '';
      menuHtml += '<li class="mkp-special-nav-item' + activeClass + '"><a href="' + item.href + '">' + label + '</a></li>';
    }

    var langLabel = activeLang === 'id' ? 'Bahasa' : 'Language';
    var searchLabel = activeLang === 'id' ? 'Cari koleksi' : 'Search collection';
    var logoUrl = 'template/default/assets/images/rename_me_to_logo.png';
    var langSwitch = activeLang === 'id' ? 'en_US' : 'id_ID';
    var langFlag = activeLang === 'id' ? '🇺🇸' : '🇮🇩';
    var heroHtml = ''
      + '<section id="mkpSpecialHero" class="mkp-special-hero">'
      + '  <div class="mkp-special-hero-inner">'
      + '    <div class="mkp-special-hero-topbar">'
      + '      <a class="mkp-special-brand" href="index.php" aria-label="' + getBrandName() + '">'
      + '        <img class="mkp-special-brand-logo" src="' + logoUrl + '" alt="" aria-hidden="true" onerror="this.style.display=\\'none\\'">'
      + '        <span class="mkp-special-brand-name">' + getBrandName() + '</span>'
      + '      </a>'
      + '      <ul class="mkp-special-nav" aria-label="OPAC Menu">' + menuHtml + '</ul>'
      + '      <div class="mkp-special-lang" aria-label="' + langLabel + '">'
      + '        <a class="mkp-special-lang-flag" href="' + buildLangHref(langSwitch) + '" aria-label="' + langLabel + '">' + langFlag + '</a>'
      + '      </div>'
      + '    </div>'
      + '    <form class="mkp-special-search" action="index.php" method="get" role="search">'
      + '      <input type="text" name="keywords" placeholder="' + heroSearchPlaceholder + '" aria-label="' + searchLabel + '">'
      + '      <button type="submit" name="search" value="search" aria-label="' + searchLabel + '"><span class="mkp-special-search-icon" aria-hidden="true"></span></button>'
      + '    </form>'
      + '  </div>'
      + '</section>';

    body.insertAdjacentHTML('afterbegin', heroHtml);
  }

  var sideMenu = document.querySelector('.s-menu-content ul');
  var navbarMenu = document.querySelector('#navbarSupportedContent .navbar-nav');
  var isSyncingMenus = false;

  function syncMenusAndHero() {
    if (isSyncingMenus) return;
    isSyncingMenus = true;
    try {
      var staleHero = document.getElementById('mkpSpecialHero');
      if (staleHero && staleHero.parentNode) {
        staleHero.parentNode.removeChild(staleHero);
      }
      if (document.body) {
        document.body.classList.remove('mkp-with-injected-hero');
      }

      sideMenu = document.querySelector('.s-menu-content ul');
      navbarMenu = document.querySelector('#navbarSupportedContent .navbar-nav');

      applyMenuTranslation(sideMenu);
      applyMenuTranslation(navbarMenu);

      normalizeLocationLinks(document);
      insertLoanMenu(sideMenu, false);
      insertLoanMenu(navbarMenu, true);
      insertLibrarianLoginMenu(sideMenu, false);
      insertLibrarianLoginMenu(navbarMenu, true);
      normalizeLocationLinks(sideMenu);
      normalizeLocationLinks(navbarMenu);

      applyMenuTranslation(sideMenu);
      applyMenuTranslation(navbarMenu);
      harmonizeHeroArea();
    } finally {
      isSyncingMenus = false;
    }
  }

  syncMenusAndHero();

  // Keep labels synchronized even when other plugins mutate navbar later.
  var syncScheduled = false;
  function scheduleSync() {
    if (syncScheduled) return;
    syncScheduled = true;
    window.setTimeout(function () {
      syncScheduled = false;
      syncMenusAndHero();
    }, 80);
  }

  var menuObserver = new MutationObserver(function () {
    if (isSyncingMenus) return;
    scheduleSync();
  });

  if (document.body) {
    menuObserver.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }

  // Re-apply after other plugins mutate menu labels/items.
  var syncAttempts = 0;
  var syncTimer = window.setInterval(function () {
    syncAttempts += 1;
    syncMenusAndHero();
    if (syncAttempts >= 25) {
      window.clearInterval(syncTimer);
    }
  }, 120);
});
</script>
HTML;

    $opac->js = $js;
});
