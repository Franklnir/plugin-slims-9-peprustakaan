<?php
/**
 * Module: fitur updateterbaru (dibundel ke Magangkpfitur).
 */

use SLiMS\Plugins;

if (defined('MAGANGKPFITUR_UPDATEFITUR_BOOTSTRAPPED')) {
    return;
}
define('MAGANGKPFITUR_UPDATEFITUR_BOOTSTRAPPED', true);

require_once __DIR__ . '/lib.php';

// Schema sync is intentionally not executed here because plugins are loaded
// very early from sysconfig (before sessions start) and can slow down OPAC pages.

if (!function_exists('updatefiturnewNormalizeMenuLabel')) {
    function updatefiturnewNormalizeMenuLabel($label): string
    {
        $normalized = preg_replace('/\s+/u', ' ', trim((string) $label));
        return strtolower((string) $normalized);
    }
}

if (!function_exists('updatefiturnewDeduplicateApprovalMenus')) {
    function updatefiturnewDeduplicateApprovalMenus(Plugins $plugin, string $preferredApprovalPath, array $labelAliases = []): void
    {
        $moduleName = 'circulation';
        $moduleMenus = $plugin->getMenus($moduleName);
        if (!is_array($moduleMenus) || count($moduleMenus) < 2) {
            return;
        }

        $preferredPath = realpath($preferredApprovalPath);
        if ($preferredPath === false) {
            return;
        }

        $aliases = [];
        foreach ($labelAliases as $alias) {
            $normalizedAlias = updatefiturnewNormalizeMenuLabel($alias);
            if ($normalizedAlias !== '') {
                $aliases[] = $normalizedAlias;
            }
        }
        $aliases[] = updatefiturnewNormalizeMenuLabel(updatefiturnewTranslate('menu_approval'));
        $aliases[] = updatefiturnewNormalizeMenuLabel('Loan Approval');
        $aliases[] = updatefiturnewNormalizeMenuLabel('Approval Peminjaman');
        $aliases[] = updatefiturnewNormalizeMenuLabel('Peminjaman Approval');
        $aliases = array_values(array_unique(array_filter($aliases, static function ($value) {
            return $value !== '';
        })));

        $candidateMenus = [];
        foreach ($moduleMenus as $menuId => $menuMeta) {
            $menuLabel = isset($menuMeta[0]) ? updatefiturnewNormalizeMenuLabel($menuMeta[0]) : '';
            $menuPath = isset($menuMeta[3]) ? realpath((string) $menuMeta[3]) : false;
            $normalizedPath = $menuPath ? str_replace('\\', '/', $menuPath) : '';
            $matchesKnownPath = $normalizedPath !== ''
                && (preg_match('~/plugins/(peminjaman|updatefiturnew|updateterbaru)/approval\.php$~', $normalizedPath)
                    || strpos($normalizedPath, '/MagangKp/updateterbaru/approval.php') !== false);
            $matchesLabel = $menuLabel !== '' && in_array($menuLabel, $aliases, true);

            if ($matchesKnownPath || $matchesLabel) {
                $candidateMenus[(string) $menuId] = [
                    'path' => $menuPath,
                    'url' => isset($menuMeta[1]) ? (string) $menuMeta[1] : ''
                ];
            }
        }

        if (count($candidateMenus) <= 1) {
            return;
        }

        $keepMenuId = '';
        foreach ($candidateMenus as $menuId => $menuMeta) {
            if (($menuMeta['path'] ?? null) === $preferredPath) {
                $keepMenuId = $menuId;
                break;
            }
        }

        if ($keepMenuId === '') {
            foreach ($candidateMenus as $menuId => $menuMeta) {
                $menuPath = str_replace('\\', '/', (string) ($menuMeta['path'] ?? ''));
                if ($menuPath !== '' && strpos($menuPath, '/updateterbaru/') !== false) {
                    $keepMenuId = $menuId;
                    break;
                }
            }
        }

        if ($keepMenuId === '') {
            $keepMenuId = (string) array_key_first($candidateMenus);
        }

        $removeMenuIds = [];
        foreach ($candidateMenus as $menuId => $menuMeta) {
            if ($menuId !== $keepMenuId) {
                $removeMenuIds[] = $menuId;
            }
        }
        if (empty($removeMenuIds)) {
            return;
        }

        try {
            $pluginReflection = new ReflectionObject($plugin);
            while (!$pluginReflection->hasProperty('menus') && ($parent = $pluginReflection->getParentClass())) {
                $pluginReflection = $parent;
            }
            if (!$pluginReflection->hasProperty('menus')) {
                return;
            }

            $menusProperty = $pluginReflection->getProperty('menus');
            $menusProperty->setAccessible(true);
            $allMenus = $menusProperty->getValue($plugin);
            if (!isset($allMenus[$moduleName]) || !is_array($allMenus[$moduleName])) {
                return;
            }

            foreach ($removeMenuIds as $menuId) {
                unset($allMenus[$moduleName][$menuId]);
            }
            $menusProperty->setValue($plugin, $allMenus);
        } catch (Throwable $exception) {
            return;
        }

        if (isset($_SESSION['priv'][$moduleName]['menus']) && is_array($_SESSION['priv'][$moduleName]['menus'])) {
            $allowedMenus = $_SESSION['priv'][$moduleName]['menus'];
            $removedMenuHashes = [];
            foreach ($removeMenuIds as $menuId) {
                $removedUrl = (string) ($candidateMenus[$menuId]['url'] ?? '');
                if ($removedUrl !== '') {
                    $removedMenuHashes[] = md5($removedUrl);
                }
            }

            $keptMenuUrl = (string) ($candidateMenus[$keepMenuId]['url'] ?? '');
            $keptMenuHash = $keptMenuUrl !== '' ? md5($keptMenuUrl) : '';
            if ($keptMenuHash !== '') {
                $hadRemovedHash = false;
                foreach ($removedMenuHashes as $removedHash) {
                    if (in_array($removedHash, $allowedMenus, true)) {
                        $hadRemovedHash = true;
                        break;
                    }
                }
                if ($hadRemovedHash && !in_array($keptMenuHash, $allowedMenus, true)) {
                    $allowedMenus[] = $keptMenuHash;
                }
            }

            if (!empty($removedMenuHashes)) {
                $allowedMenus = array_values(array_diff($allowedMenus, $removedMenuHashes));
            }
            $_SESSION['priv'][$moduleName]['menus'] = array_values(array_unique($allowedMenus));
        }
    }
}

if (!function_exists('updatefiturnewPlaceReportingMenuAfterAnchor')) {
    function updatefiturnewPlaceReportingMenuAfterAnchor(
        Plugins $plugin,
        string $preferredMenuPath,
        array $anchorLabelAliases = [],
        array $menuLabelAliases = []
    ): void {
        $moduleName = 'reporting';
        $moduleMenus = $plugin->getMenus($moduleName);
        if (!is_array($moduleMenus) || count($moduleMenus) < 2) {
            return;
        }

        $preferredPath = realpath($preferredMenuPath);
        if ($preferredPath === false) {
            return;
        }

        $anchorAliases = [];
        foreach ($anchorLabelAliases as $alias) {
            $normalizedAlias = updatefiturnewNormalizeMenuLabel($alias);
            if ($normalizedAlias !== '') {
                $anchorAliases[] = $normalizedAlias;
            }
        }
        $anchorAliases[] = updatefiturnewNormalizeMenuLabel('Jadwal Visitor per Lokasi');
        $anchorAliases = array_values(array_unique(array_filter($anchorAliases, static function ($value) {
            return $value !== '';
        })));

        $menuAliases = [];
        foreach ($menuLabelAliases as $alias) {
            $normalizedAlias = updatefiturnewNormalizeMenuLabel($alias);
            if ($normalizedAlias !== '') {
                $menuAliases[] = $normalizedAlias;
            }
        }
        $menuAliases[] = updatefiturnewNormalizeMenuLabel(updatefiturnewTranslate('menu_feedback'));
        $menuAliases[] = updatefiturnewNormalizeMenuLabel('Kritik Saran');
        $menuAliases[] = updatefiturnewNormalizeMenuLabel('Visitor Feedback');
        $menuAliases = array_values(array_unique(array_filter($menuAliases, static function ($value) {
            return $value !== '';
        })));

        $anchorMenuId = '';
        $targetMenuId = '';
        foreach ($moduleMenus as $menuId => $menuMeta) {
            $menuLabel = isset($menuMeta[0]) ? updatefiturnewNormalizeMenuLabel($menuMeta[0]) : '';
            $menuPath = isset($menuMeta[3]) ? realpath((string) $menuMeta[3]) : false;

            if ($targetMenuId === '' && (($menuPath && $menuPath === $preferredPath) || ($menuLabel !== '' && in_array($menuLabel, $menuAliases, true)))) {
                $targetMenuId = (string) $menuId;
            }
            if ($anchorMenuId === '' && $menuLabel !== '' && in_array($menuLabel, $anchorAliases, true)) {
                $anchorMenuId = (string) $menuId;
            }
        }

        if ($targetMenuId === '' || $anchorMenuId === '' || $targetMenuId === $anchorMenuId || !isset($moduleMenus[$targetMenuId])) {
            return;
        }

        $targetMenuMeta = $moduleMenus[$targetMenuId];
        unset($moduleMenus[$targetMenuId]);

        $reorderedMenus = [];
        $inserted = false;
        foreach ($moduleMenus as $menuId => $menuMeta) {
            $reorderedMenus[$menuId] = $menuMeta;
            if ((string) $menuId === $anchorMenuId) {
                $reorderedMenus[$targetMenuId] = $targetMenuMeta;
                $inserted = true;
            }
        }
        if (!$inserted) {
            $reorderedMenus[$targetMenuId] = $targetMenuMeta;
        }

        try {
            $groupMenu = \SLiMS\GroupMenu::getInstance();
            $groupReflection = new ReflectionObject($groupMenu);
            if ($groupReflection->hasProperty('group')) {
                $groupProperty = $groupReflection->getProperty('group');
                $groupProperty->setAccessible(true);
                $groupData = $groupProperty->getValue($groupMenu);

                if (is_array($groupData)) {
                    foreach ($groupData as $groupName => $groupMenus) {
                        if (!is_array($groupMenus)) {
                            continue;
                        }
                        if (!in_array($anchorMenuId, $groupMenus, true) || !in_array($targetMenuId, $groupMenus, true)) {
                            continue;
                        }

                        $updatedGroupMenus = array_values(array_filter($groupMenus, static function ($menuId) use ($targetMenuId) {
                            return (string) $menuId !== $targetMenuId;
                        }));

                        $finalGroupMenus = [];
                        $groupInserted = false;
                        foreach ($updatedGroupMenus as $groupMenuId) {
                            $finalGroupMenus[] = $groupMenuId;
                            if ((string) $groupMenuId === $anchorMenuId) {
                                $finalGroupMenus[] = $targetMenuId;
                                $groupInserted = true;
                            }
                        }
                        if (!$groupInserted) {
                            $finalGroupMenus[] = $targetMenuId;
                        }

                        $groupData[$groupName] = $finalGroupMenus;
                    }
                    $groupProperty->setValue($groupMenu, $groupData);
                }
            }
        } catch (Throwable $exception) {
            // keep menu reorder fallback even if group reorder cannot be applied
        }

        try {
            $pluginReflection = new ReflectionObject($plugin);
            while (!$pluginReflection->hasProperty('menus') && ($parent = $pluginReflection->getParentClass())) {
                $pluginReflection = $parent;
            }
            if (!$pluginReflection->hasProperty('menus')) {
                return;
            }

            $menusProperty = $pluginReflection->getProperty('menus');
            $menusProperty->setAccessible(true);
            $allMenus = $menusProperty->getValue($plugin);
            if (!isset($allMenus[$moduleName]) || !is_array($allMenus[$moduleName])) {
                return;
            }

            $allMenus[$moduleName] = $reorderedMenus;
            $menusProperty->setValue($plugin, $allMenus);
        } catch (Throwable $exception) {
            return;
        }
    }
}

$plugin = Plugins::getInstance();
$loanMenuLabel = 'Peminjaman';
$loanMenuDesc = updatefiturnewTranslate('menu_loan_desc');
$approvalMenuLabel = updatefiturnewTranslate('menu_approval');
$approvalMenuDesc = updatefiturnewTranslate('menu_approval_desc');
$feedbackMenuLabel = updatefiturnewTranslate('menu_feedback');
$feedbackMenuDesc = updatefiturnewTranslate('menu_feedback_desc');

$plugin->registerMenu(
    'opac',
    $loanMenuLabel,
    __DIR__ . '/updateterbaru.php',
    $loanMenuDesc
);

$plugin->registerMenu(
    'circulation',
    $approvalMenuLabel,
    __DIR__ . '/approval.php',
    $approvalMenuDesc
);

$reportingGroupName = function_exists('__') ? __('REPORTING FORM') : 'REPORTING FORM';
Plugins::group($reportingGroupName, function () use ($plugin, $feedbackMenuLabel, $feedbackMenuDesc) {
    $plugin->registerMenu(
        'reporting',
        $feedbackMenuLabel,
        __DIR__ . '/kritik_saran.php',
        $feedbackMenuDesc
    );
});

$updatefiturnewApprovalAliases = [
    $approvalMenuLabel,
    'Loan Approval',
    'Approval Peminjaman',
    'Peminjaman Approval'
];
$updatefiturnewFeedbackAliases = [
    $feedbackMenuLabel,
    'Kritik Saran',
    'Visitor Feedback'
];
$updatefiturnewVisitorScheduleAliases = [
    'Jadwal Visitor per Lokasi'
];
updatefiturnewDeduplicateApprovalMenus($plugin, __DIR__ . '/approval.php', $updatefiturnewApprovalAliases);
updatefiturnewPlaceReportingMenuAfterAnchor(
    $plugin,
    __DIR__ . '/kritik_saran.php',
    $updatefiturnewVisitorScheduleAliases,
    $updatefiturnewFeedbackAliases
);
$plugin->register(Plugins::ADMIN_SESSION_AFTER_START, function () use (
    $plugin,
    $updatefiturnewApprovalAliases,
    $updatefiturnewVisitorScheduleAliases,
    $updatefiturnewFeedbackAliases
) {
    updatefiturnewDeduplicateApprovalMenus($plugin, __DIR__ . '/approval.php', $updatefiturnewApprovalAliases);
    updatefiturnewPlaceReportingMenuAfterAnchor(
        $plugin,
        __DIR__ . '/kritik_saran.php',
        $updatefiturnewVisitorScheduleAliases,
        $updatefiturnewFeedbackAliases
    );
});

$plugin->register(Plugins::CONTENT_BEFORE_LOAD, function ($opac) {
    $catalog = updatefiturnewGetTranslationCatalog();
    $navCatalog = [
        'home' => $catalog['nav_home'] ?? ['id' => 'Beranda', 'en' => 'Home'],
        'visitor' => $catalog['nav_visitor'] ?? ['id' => 'Kunjungan', 'en' => 'Visitor'],
        'information' => $catalog['nav_information'] ?? ['id' => 'Informasi', 'en' => 'Information'],
        'news' => $catalog['nav_news'] ?? ['id' => 'Berita', 'en' => 'News'],
        'location' => $catalog['nav_location'] ?? ['id' => 'Lokasi Perpustakaan', 'en' => 'Library Location'],
        'member_area' => $catalog['nav_member_area'] ?? ['id' => 'Area Anggota', 'en' => 'Member Area'],
        'librarian' => $catalog['nav_librarian'] ?? ['id' => 'Pustakawan', 'en' => 'Librarian'],
        'help' => $catalog['nav_help'] ?? ['id' => 'Bantuan', 'en' => 'Help'],
        'librarian_login' => $catalog['nav_librarian_login'] ?? ['id' => 'Login Pustakawan', 'en' => 'Librarian Login'],
        'loan' => $catalog['nav_loan'] ?? ['id' => 'Peminjaman', 'en' => 'Loan Request']
    ];

    $activeLang = strpos(updatefiturnewGetActiveLang(), 'id') === 0 ? 'id' : 'en';
    $activeLangJs = json_encode($activeLang, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $navCatalogJs = json_encode($navCatalog, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $heroSearchPlaceholder = $activeLang === 'id'
      ? 'Masukkan kata kunci koleksi...'
      : 'Enter keyword to search collection...';
    $heroSearchPlaceholderJs = json_encode($heroSearchPlaceholder, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $loanHeaderTitle = $activeLang === 'id' ? 'Peminjaman Koleksi' : 'Loan Request';
    $loanHeaderTitleJs = json_encode($loanHeaderTitle, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $js = $opac->js ?? '';
    $js .= <<<HTML
<script>
document.addEventListener('DOMContentLoaded', function () {
  var hiddenPages = ['member', 'librarian', 'help', 'news'];
  var hiddenText = [
    'area anggota',
    'member area',
    'pustakawan',
    'librarian',
    'bantuan',
    'help',
    'berita',
    'news'
  ];

  function normalizeText(value) {
    return String(value || '').replace(/\\s+/g, ' ').trim().toLowerCase();
  }

  function shouldHideLink(link) {
    if (!link || !link.getAttribute) return false;
    var href = String(link.getAttribute('href') || '').toLowerCase();
    var text = normalizeText(link.textContent);

    var byHref = hiddenPages.some(function (pageKey) {
      return href.indexOf('p=' + pageKey) !== -1;
    });
    if (byHref) return true;

    if (text === '') return false;
    return hiddenText.indexOf(text) !== -1;
  }

  function getRemovableNode(link) {
    if (!link || !link.closest) return link;
    return link.closest('li, .nav-item, .menu-item, .dropdown-item, .navbar-nav > li, .s-menu-content li, footer li') || link;
  }

  function shouldHideSlimsText(text) {
    var normalized = normalizeText(text);
    if (normalized === '') return false;
    return normalized.indexOf('slims') !== -1 || normalized.indexOf('powered by') !== -1;
  }

  function hideSlimsBranding() {
    var brandingNodes = document.querySelectorAll(
      'footer a, footer small, footer code, ' +
      '.s-footer a, .s-footer small, .s-footer code, ' +
      '.s-footer-tagline, .s-footer-about, ' +
      '#visitor-counter a, #visitor-counter small, #visitor-counter code, ' +
      '.text-right.text-grey, .text-right .text-grey'
    );

    brandingNodes.forEach(function (node) {
      if (!node || !shouldHideSlimsText(node.textContent || '')) return;

      var removable =
        node.closest('.text-right') ||
        node.closest('.s-footer-tagline, .s-footer-about') ||
        node.closest('li') ||
        node;

      if (!removable) return;
      removable.style.display = 'none';
      removable.setAttribute('data-updatefiturnew-hidden', '1');
    });
  }

  function applyHide() {
    var allLinks = document.querySelectorAll('a');
    allLinks.forEach(function (link) {
      if (!shouldHideLink(link)) return;
      var target = getRemovableNode(link);
      if (!target) return;
      target.style.display = 'none';
      target.setAttribute('data-updatefiturnew-hidden', '1');
    });

    hideSlimsBranding();
  }

  applyHide();
  var observer = new MutationObserver(function () {
    applyHide();
  });
  observer.observe(document.body, {childList: true, subtree: true});
  window.setTimeout(function () {
    observer.disconnect();
  }, 20000);
});
</script>
HTML;
    $js .= <<<HTML
<style>
  .mkp-opac-target-page .result-search .c-header {
    background-image:
      linear-gradient(180deg, rgba(15, 23, 42, 0.45) 0%, rgba(15, 23, 42, 0.2) 38%, rgba(15, 23, 42, 0.38) 100%),
      url('template/default/assets/images/slide2.jpg') !important;
    background-size: cover !important;
    background-position: center center !important;
  }

  .mkp-opac-target-page .result-search .c-header .mask {
    background: linear-gradient(180deg, rgba(15, 23, 42, 0.2) 0%, rgba(15, 23, 42, 0.14) 55%, rgba(15, 23, 42, 0.24) 100%) !important;
  }

  .mkp-opac-target-page .mkp-opac-existing-search .card {
    background: rgba(255, 255, 255, 0.96) !important;
    border: 1px solid rgba(148, 163, 184, 0.42) !important;
    border-radius: 8px !important;
    box-shadow: 0 10px 30px rgba(15, 23, 42, 0.2) !important;
  }

  .mkp-opac-target-page .result-search .search .input-transparent {
    color: #1e293b !important;
  }

  .mkp-opac-target-page .result-search .search .input-transparent::placeholder {
    color: #94a3b8 !important;
  }

  body.mkp-with-injected-hero {
    background: #e5e7eb !important;
  }

  body.mkp-with-injected-hero .s-menu,
  body.mkp-with-injected-hero nav.s-menu {
    display: none !important;
  }

  body.mkp-with-injected-hero .s-main.s-login {
    margin-top: 0 !important;
    padding-top: 0 !important;
  }

  body.mkp-with-injected-hero .s-login-content {
    width: 100% !important;
    max-width: 100% !important;
    margin: 0 !important;
    padding: 0 !important;
    border-radius: 0 !important;
    box-shadow: none !important;
    background: transparent !important;
  }

  body.mkp-with-injected-hero #visitor-counter {
    min-height: calc(100vh - 232px) !important;
  }

  .mkp-special-hero {
    position: relative;
    min-height: 210px;
    color: #f8fafc;
    background-image:
      linear-gradient(180deg, rgba(15, 23, 42, 0.46) 0%, rgba(15, 23, 42, 0.62) 100%),
      url('template/default/assets/images/slide2.jpg');
    background-size: cover;
    background-position: center;
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
  }

  .mkp-special-hero-inner {
    position: relative;
    max-width: 1320px;
    margin: 0 auto;
    padding: 14px 18px 60px;
  }

  .mkp-special-hero-topbar {
    display: flex;
    align-items: center;
    gap: 16px;
  }

  .mkp-special-brand {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    color: #f8fafc !important;
    text-decoration: none !important;
    white-space: nowrap;
  }

  .mkp-special-brand-logo {
    width: 34px;
    height: 34px;
    object-fit: contain;
    display: inline-block;
  }

  .mkp-special-brand-name {
    font-size: 38px;
    font-weight: 600;
    letter-spacing: 0.2px;
    line-height: 1;
    text-shadow: 0 2px 6px rgba(0, 0, 0, 0.32);
  }

  .mkp-special-nav {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    align-items: center;
    gap: 18px;
    flex: 1;
    justify-content: flex-end;
    flex-wrap: wrap;
  }

  .mkp-special-nav-item a {
    color: rgba(255, 255, 255, 0.86);
    text-decoration: none;
    font-size: 17px;
    font-weight: 500;
    line-height: 1.2;
    text-shadow: 0 1px 3px rgba(0, 0, 0, 0.35);
  }

  .mkp-special-nav-item.is-active a {
    color: #ffffff;
    font-weight: 800;
  }

  .mkp-special-lang {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 20px;
    white-space: nowrap;
    text-decoration: none !important;
  }

  .mkp-special-lang-flag {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    text-decoration: none !important;
    line-height: 1;
  }

  .mkp-special-search {
    position: absolute;
    left: 50%;
    bottom: -28px;
    transform: translateX(-50%);
    width: min(760px, calc(100% - 36px));
    display: grid;
    grid-template-columns: 1fr 60px;
    background: rgba(255, 255, 255, 0.95);
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 12px 32px rgba(15, 23, 42, 0.3);
  }

  .mkp-special-search input {
    height: 56px;
    border: none;
    padding: 0 20px;
    color: #0f172a;
    font-size: 25px;
    font-weight: 500;
    background: transparent;
  }

  .mkp-special-search input::placeholder {
    color: #cbd5e1;
    opacity: 1;
  }

  .mkp-special-search button {
    border: none;
    background: transparent;
    color: #374151;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .mkp-special-search-icon {
    width: 18px;
    height: 18px;
    border: 2px solid #374151;
    border-radius: 50%;
    display: inline-block;
    position: relative;
    box-sizing: border-box;
  }

  .mkp-special-search-icon::after {
    content: '';
    position: absolute;
    width: 8px;
    height: 2px;
    background: #374151;
    right: -6px;
    bottom: -1px;
    transform: rotate(42deg);
    border-radius: 2px;
  }

  @media (max-width: 1200px) {
    .mkp-special-brand-name {
      font-size: 31px;
    }

    .mkp-special-nav-item a {
      font-size: 15px;
    }

    .mkp-special-nav {
      gap: 12px;
    }

    .mkp-special-search input {
      font-size: 20px;
    }
  }

  @media (max-width: 991px) {
    .mkp-special-hero {
      min-height: 188px;
    }

    .mkp-special-hero-topbar {
      flex-direction: column;
      align-items: flex-start;
      gap: 12px;
    }

    .mkp-special-nav {
      justify-content: flex-start;
      width: 100%;
      overflow-x: auto;
      flex-wrap: nowrap;
      padding-bottom: 4px;
    }

    .mkp-special-lang {
      position: absolute;
      right: 18px;
      top: 16px;
    }

    .mkp-special-search {
      bottom: -22px;
      width: calc(100% - 24px);
    }

    .mkp-special-search input {
      height: 46px;
      font-size: 18px;
      padding: 0 14px;
    }

    .mkp-special-search button {
      font-size: 16px;
    }

    body.mkp-with-injected-hero #visitor-counter {
      min-height: calc(100vh - 210px) !important;
    }
  }
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {
  var currentPage = new URLSearchParams(window.location.search).get('p') || '';
  var activeLang = {$activeLangJs};
  var navCatalog = {$navCatalogJs};
  var heroSearchPlaceholder = {$heroSearchPlaceholderJs};
  var loanHeaderTitle = {$loanHeaderTitleJs};

  function normalizeText(value) {
    return (value || '').replace(/\\s+/g, ' ').trim().toLowerCase();
  }

  function getLabelByKey(key) {
    if (!navCatalog[key]) return '';
    return activeLang === 'id' ? navCatalog[key].id : navCatalog[key].en;
  }

  function getTopLevelAnchors(menu) {
    var anchors = [];
    if (!menu || !menu.children) return anchors;
    for (var i = 0; i < menu.children.length; i += 1) {
      var li = menu.children[i];
      if (!li || li.tagName !== 'LI') continue;
      var link = li.firstElementChild;
      if (link && link.tagName === 'A') {
        anchors.push(link);
      }
    }
    return anchors;
  }

  function getKeyByHref(href) {
    if (!href || href === '#' || href.toLowerCase().indexOf('javascript:') === 0) return null;

    var parsed;
    try {
      parsed = new URL(href, window.location.href);
    } catch (e) {
      return null;
    }

    var page = (parsed.searchParams.get('p') || '').toLowerCase();
    if (page === 'visitor') return 'visitor';
    if (page === 'libinfo') return 'information';
    if (page === 'news') return 'news';
    if (page === 'peta') return 'location';
    if (page === 'member') return 'member_area';
    if (page === 'librarian') return 'librarian';
    if (page === 'help') return 'help';
    if (page === 'login') return 'librarian_login';
    if (page === 'peminjaman') return 'loan';

    var path = (parsed.pathname || '').toLowerCase();
    if (!page && /(^|\\/)index\\.php$/.test(path)) {
      return 'home';
    }

    return null;
  }

  function setAnchorLabel(anchor, label) {
    if (!anchor || !label) return;
    if (anchor.querySelector('img,svg')) return;

    for (var i = 0; i < anchor.childNodes.length; i += 1) {
      var node = anchor.childNodes[i];
      if (node.nodeType === Node.TEXT_NODE && normalizeText(node.nodeValue) !== '') {
        node.nodeValue = label;
        return;
      }
    }

    if (!anchor.firstElementChild) {
      anchor.textContent = label;
    }
  }

  var aliasMap = {
    information: ['library information'],
    news: ['library news'],
    location: ['library location'],
    help: ['help on search'],
    librarian_login: ['librarian login']
  };

  var textLookup = {};
  Object.keys(navCatalog).forEach(function (key) {
    var item = navCatalog[key] || {};
    var idText = normalizeText(item.id || '');
    var enText = normalizeText(item.en || '');
    if (idText) textLookup[idText] = key;
    if (enText) textLookup[enText] = key;
    if (aliasMap[key]) {
      for (var i = 0; i < aliasMap[key].length; i += 1) {
        var alias = normalizeText(aliasMap[key][i] || '');
        if (alias) textLookup[alias] = key;
      }
    }
  });

  function resolveKey(anchor) {
    if (!anchor) return null;
    var href = anchor.getAttribute('href') || '';
    if (href.indexOf('logout=1') !== -1) return null;
    if (href.indexOf('p=member') !== -1 && href.indexOf('sec=') !== -1) return null;

    var byHref = getKeyByHref(href);
    if (byHref) return byHref;

    var byText = textLookup[normalizeText(anchor.textContent || '')];
    return byText || null;
  }

  function applyMenuTranslation(menu) {
    var anchors = getTopLevelAnchors(menu);
    for (var i = 0; i < anchors.length; i += 1) {
      var anchor = anchors[i];
      var key = resolveKey(anchor);
      if (!key) continue;
      setAnchorLabel(anchor, getLabelByKey(key));
    }
  }

  function insertLoanMenu(menu, isNavbar) {
    if (!menu) return;
    if (menu.querySelector('a[href*="p=peminjaman"]')) return;

    var itemLi = document.createElement('li');
    var itemA = document.createElement('a');
    itemA.href = 'index.php?p=peminjaman';
    itemA.textContent = getLabelByKey('loan');

    if (isNavbar) {
      itemLi.className = 'nav-item' + (currentPage === 'peminjaman' ? ' active' : '');
      itemA.className = 'nav-link';
    }

    itemLi.appendChild(itemA);

    var visitorAnchor = menu.querySelector('a[href*="p=visitor"]');
    var visitorLi = visitorAnchor ? visitorAnchor.closest('li') : null;
    if (visitorLi && visitorLi.parentNode) {
      visitorLi.parentNode.insertBefore(itemLi, visitorLi.nextSibling);
      return;
    }

    var homeAnchor = menu.querySelector('a[href="index.php"], a[href="./index.php"]');
    var homeLi = homeAnchor ? homeAnchor.closest('li') : null;
    if (homeLi && homeLi.parentNode) {
      homeLi.parentNode.insertBefore(itemLi, homeLi.nextSibling);
      return;
    }

    menu.appendChild(itemLi);
  }

  function insertLibrarianLoginMenu(menu, isNavbar) {
    if (!menu) return;
    if (menu.querySelector('a[href*="p=login"]')) return;

    var itemLi = document.createElement('li');
    var itemA = document.createElement('a');
    itemA.href = 'index.php?p=login';
    itemA.textContent = getLabelByKey('librarian_login');

    if (isNavbar) {
      itemLi.className = 'nav-item' + (currentPage === 'login' ? ' active' : '');
      itemA.className = 'nav-link';
    }

    itemLi.appendChild(itemA);

    var memberAnchor = menu.querySelector('a#navbarDropdown, a[href*="p=member"]');
    var memberLi = memberAnchor ? memberAnchor.closest('li') : null;
    if (memberLi && memberLi.parentNode) {
      memberLi.parentNode.insertBefore(itemLi, memberLi.nextSibling);
      return;
    }

    menu.appendChild(itemLi);
  }

  function normalizeLocationLinks(root) {
    if (!root || !root.querySelectorAll) return;
    var links = root.querySelectorAll('a[href*="p=peta"]');
    for (var i = 0; i < links.length; i += 1) {
      var link = links[i];
      if (!link) continue;

      // Revert to native popup behavior for Library Location (colorbox).
      if (link.dataset && link.dataset.mkpForceFullNav === '1' && link.parentNode) {
        var cloned = link.cloneNode(true);
        link.parentNode.replaceChild(cloned, link);
        link = cloned;
      }

      if (link.classList && !link.classList.contains('openPopUp')) {
        link.classList.add('openPopUp');
      }
      if (!link.getAttribute('width')) {
        link.setAttribute('width', '600');
      }
      if (!link.getAttribute('height')) {
        link.setAttribute('height', '400');
      }
      if (!link.getAttribute('title')) {
        link.setAttribute('title', getLabelByKey('location') || 'Library Location');
      }

      link.removeAttribute('data-toggle');
      link.removeAttribute('data-target');
      link.removeAttribute('data-mkp-force-full-nav');
    }
  }

  function isHeroTargetPage(page) {
    var key = (page || '').toLowerCase();
    return key === 'visitor'
      || key === 'peminjaman'
      || key === 'peta'
      || key === 'librarian'
      || key === 'libinfo';
  }

  function harmonizeHeroArea() {
    if (!isHeroTargetPage(currentPage)) return;
    if (document.body) {
      document.body.classList.add('mkp-opac-target-page');
    }

    // Cleanup: remove injected hero from previous plugin version (avoid duplicate banner).
    var oldInjected = document.querySelectorAll('.mkp-opac-hero');
    for (var i = 0; i < oldInjected.length; i += 1) {
      if (oldInjected[i] && oldInjected[i].parentNode) {
        oldInjected[i].parentNode.removeChild(oldInjected[i]);
      }
    }

    var existingSearchBlocks = document.querySelectorAll('.result-search .search');
    for (var j = 0; j < existingSearchBlocks.length; j += 1) {
      existingSearchBlocks[j].classList.add('mkp-opac-existing-search');
    }

    var keywordInput = document.querySelector('.result-search .search #search-input');
    if (keywordInput && !keywordInput.value) {
      keywordInput.setAttribute('placeholder', heroSearchPlaceholder);
    }

    if (currentPage === 'peminjaman') {
      var titleNodes = document.querySelectorAll('.s-main-page .s-main-search .s-main-title');
      for (var k = 0; k < titleNodes.length; k += 1) {
        if (titleNodes[k]) {
          titleNodes[k].textContent = loanHeaderTitle;
        }
      }

      // Default theme: page title shown in content area (h2 + hr).
      var defaultTitle = document.querySelector('.result-search > section.container.mt-8 > h2.mb-4, .result-search > section.container.mt-8 > h2');
      if (defaultTitle) {
        defaultTitle.textContent = loanHeaderTitle;
      }
    }
  }

  function buildLangHref(langCode) {
    var params = new URLSearchParams(window.location.search || '');
    if (!params.get('p')) {
      params.set('p', currentPage || 'visitor');
    }
    params.set('select_lang', langCode);
    var query = params.toString();
    return query ? ('index.php?' + query) : 'index.php';
  }

  function getBrandName() {
    var title = (document.title || '').trim();
    if (title.indexOf('|') !== -1) {
      var parts = title.split('|');
      var brand = (parts[parts.length - 1] || '').trim();
      if (brand) return brand;
    }
    var navbarBrand = document.querySelector('.navbar-brand, .s-brand');
    if (navbarBrand) {
      var brandText = (navbarBrand.textContent || '').trim();
      if (brandText) return brandText;
    }
    return 'Senayan';
  }

  function injectSpecialHero() {
    if (currentPage !== 'visitor') return;
    if (document.getElementById('mkpSpecialHero')) return;
    if (!document.body) return;

    var body = document.body;
    body.classList.add('mkp-with-injected-hero');

    var menuConfig = [
      {key: 'home', href: 'index.php', page: ''},
      {key: 'visitor', href: 'index.php?p=visitor', page: 'visitor'},
      {key: 'loan', href: 'index.php?p=peminjaman', page: 'peminjaman'},
      {key: 'information', href: 'index.php?p=libinfo', page: 'libinfo'},
      {key: 'location', href: 'index.php?p=peta', page: 'peta'},
      {key: 'news', href: 'index.php?p=news', page: 'news'},
      {key: 'help', href: 'index.php?p=help', page: 'help'},
      {key: 'librarian', href: 'index.php?p=librarian', page: 'librarian'},
      {key: 'member_area', href: 'index.php?p=member', page: 'member'},
      {key: 'librarian_login', href: 'index.php?p=login', page: 'login'}
    ];

    var menuHtml = '';
    for (var i = 0; i < menuConfig.length; i += 1) {
      var item = menuConfig[i];
      var label = getLabelByKey(item.key) || '';
      if (!label) continue;
      var activeClass = (currentPage === item.page || (!currentPage && !item.page)) ? ' is-active' : '';
      menuHtml += '<li class="mkp-special-nav-item' + activeClass + '"><a href="' + item.href + '">' + label + '</a></li>';
    }

    var langLabel = activeLang === 'id' ? 'Bahasa' : 'Language';
    var searchLabel = activeLang === 'id' ? 'Cari koleksi' : 'Search collection';
    var logoUrl = 'template/default/assets/images/rename_me_to_logo.png';
    var langSwitch = activeLang === 'id' ? 'en_US' : 'id_ID';
    var langFlag = activeLang === 'id' ? '🇺🇸' : '🇮🇩';
    var heroHtml = ''
      + '<section id="mkpSpecialHero" class="mkp-special-hero">'
      + '  <div class="mkp-special-hero-inner">'
      + '    <div class="mkp-special-hero-topbar">'
      + '      <a class="mkp-special-brand" href="index.php" aria-label="' + getBrandName() + '">'
      + '        <img class="mkp-special-brand-logo" src="' + logoUrl + '" alt="" aria-hidden="true" onerror="this.style.display=\\'none\\'">'
      + '        <span class="mkp-special-brand-name">' + getBrandName() + '</span>'
      + '      </a>'
      + '      <ul class="mkp-special-nav" aria-label="OPAC Menu">' + menuHtml + '</ul>'
      + '      <div class="mkp-special-lang" aria-label="' + langLabel + '">'
      + '        <a class="mkp-special-lang-flag" href="' + buildLangHref(langSwitch) + '" aria-label="' + langLabel + '">' + langFlag + '</a>'
      + '      </div>'
      + '    </div>'
      + '    <form class="mkp-special-search" action="index.php" method="get" role="search">'
      + '      <input type="text" name="keywords" placeholder="' + heroSearchPlaceholder + '" aria-label="' + searchLabel + '">'
      + '      <button type="submit" name="search" value="search" aria-label="' + searchLabel + '"><span class="mkp-special-search-icon" aria-hidden="true"></span></button>'
      + '    </form>'
      + '  </div>'
      + '</section>';

    body.insertAdjacentHTML('afterbegin', heroHtml);
  }

  var sideMenu = document.querySelector('.s-menu-content ul');
  var navbarMenu = document.querySelector('#navbarSupportedContent .navbar-nav');
  var isSyncingMenus = false;

  function syncMenusAndHero() {
    if (isSyncingMenus) return;
    isSyncingMenus = true;
    try {
      var staleHero = document.getElementById('mkpSpecialHero');
      if (staleHero && staleHero.parentNode) {
        staleHero.parentNode.removeChild(staleHero);
      }
      if (document.body) {
        document.body.classList.remove('mkp-with-injected-hero');
      }

      sideMenu = document.querySelector('.s-menu-content ul');
      navbarMenu = document.querySelector('#navbarSupportedContent .navbar-nav');

      applyMenuTranslation(sideMenu);
      applyMenuTranslation(navbarMenu);

      normalizeLocationLinks(document);
      insertLoanMenu(sideMenu, false);
      insertLoanMenu(navbarMenu, true);
      insertLibrarianLoginMenu(sideMenu, false);
      insertLibrarianLoginMenu(navbarMenu, true);
      normalizeLocationLinks(sideMenu);
      normalizeLocationLinks(navbarMenu);

      applyMenuTranslation(sideMenu);
      applyMenuTranslation(navbarMenu);
      harmonizeHeroArea();
    } finally {
      isSyncingMenus = false;
    }
  }

  syncMenusAndHero();

  // Keep labels synchronized even when other plugins mutate navbar later.
  var syncScheduled = false;
  function scheduleSync() {
    if (syncScheduled) return;
    syncScheduled = true;
    window.setTimeout(function () {
      syncScheduled = false;
      syncMenusAndHero();
    }, 80);
  }

  var menuObserver = new MutationObserver(function () {
    if (isSyncingMenus) return;
    scheduleSync();
  });

  if (document.body) {
    menuObserver.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }

  // Re-apply after other plugins mutate menu labels/items.
  var syncAttempts = 0;
  var syncTimer = window.setInterval(function () {
    syncAttempts += 1;
    syncMenusAndHero();
    if (syncAttempts >= 25) {
      window.clearInterval(syncTimer);
    }
  }, 120);
});
</script>
HTML;

    $js .= <<<HTML
<style>
  .mkp-feedback-board {
    max-width: 1320px;
    margin: 16px auto 20px;
    padding: 0 14px;
  }

  .mkp-feedback-card {
    background: rgba(255, 255, 255, 0.96);
    border: 1px solid rgba(148, 163, 184, 0.42);
    border-radius: 10px;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.14);
    overflow: hidden;
  }

  .mkp-feedback-card-head {
    padding: 12px 14px;
    border-bottom: 1px solid rgba(148, 163, 184, 0.35);
    background: linear-gradient(180deg, #f8fafc 0%, #eef2f7 100%);
  }

  .mkp-feedback-card-head h4 {
    margin: 0;
    font-size: 16px;
    color: #1e293b;
    font-weight: 700;
  }

  .mkp-feedback-card-body {
    padding: 10px 12px 14px;
  }

  .mkp-feedback-table-wrap {
    overflow-x: auto;
  }

  .mkp-feedback-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    color: #1f2937;
  }

  .mkp-feedback-table th,
  .mkp-feedback-table td {
    border: 1px solid rgba(148, 163, 184, 0.35);
    padding: 8px;
    vertical-align: top;
    text-align: left;
  }

  .mkp-feedback-table th {
    background: #f1f5f9;
    font-weight: 700;
    white-space: nowrap;
  }

  .mkp-feedback-type {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 3px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
  }

  .mkp-feedback-type.kritik {
    background: #fee2e2;
    color: #991b1b;
  }

  .mkp-feedback-type.saran {
    background: #dcfce7;
    color: #166534;
  }

  .mkp-feedback-text {
    margin-top: 6px;
    line-height: 1.45;
    white-space: pre-wrap;
  }

  .mkp-feedback-empty {
    border: 1px dashed #94a3b8;
    border-radius: 8px;
    padding: 10px;
    color: #475569;
    background: #f8fafc;
  }

  .mkp-feedback-overlay {
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.56);
    z-index: 9999;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 18px;
  }

  .mkp-feedback-overlay.is-open {
    display: flex;
  }

  .mkp-feedback-dialog {
    width: min(640px, 100%);
    background: #ffffff;
    border-radius: 12px;
    border: 1px solid rgba(148, 163, 184, 0.45);
    box-shadow: 0 16px 42px rgba(15, 23, 42, 0.35);
    overflow: hidden;
  }

  .mkp-feedback-dialog-head {
    padding: 12px 14px;
    border-bottom: 1px solid rgba(148, 163, 184, 0.35);
    background: linear-gradient(180deg, #f8fafc 0%, #eef2f7 100%);
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .mkp-feedback-dialog-head h4 {
    margin: 0;
    font-size: 17px;
    color: #0f172a;
    font-weight: 700;
  }

  .mkp-feedback-dialog-head button {
    border: none;
    background: transparent;
    color: #334155;
    font-size: 20px;
    line-height: 1;
    cursor: pointer;
  }

  .mkp-feedback-dialog-body {
    padding: 12px 14px 14px;
  }

  .mkp-feedback-meta {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 8px;
    margin-bottom: 10px;
  }

  .mkp-feedback-meta-item {
    border: 1px solid rgba(148, 163, 184, 0.35);
    border-radius: 8px;
    padding: 8px;
    background: #f8fafc;
  }

  .mkp-feedback-meta-item small {
    display: block;
    font-size: 11px;
    color: #64748b;
  }

  .mkp-feedback-meta-item strong {
    display: block;
    margin-top: 2px;
    color: #0f172a;
    font-size: 13px;
  }

  .mkp-feedback-form label {
    display: block;
    font-size: 12px;
    color: #334155;
    font-weight: 700;
    margin-bottom: 4px;
  }

  .mkp-feedback-type-select {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 10px;
  }

  .mkp-feedback-type-select label {
    margin: 0;
    font-size: 13px;
    font-weight: 600;
    color: #1e293b;
    display: inline-flex;
    align-items: center;
    gap: 6px;
  }

  .mkp-feedback-form textarea {
    width: 100%;
    min-height: 112px;
    border: 1px solid rgba(148, 163, 184, 0.6);
    border-radius: 8px;
    padding: 9px 10px;
    resize: vertical;
    color: #0f172a;
    font-size: 14px;
    box-sizing: border-box;
  }

  .mkp-feedback-actions {
    margin-top: 10px;
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    justify-content: flex-end;
  }

  .mkp-feedback-actions button {
    border: none;
    border-radius: 8px;
    padding: 8px 14px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
  }

  .mkp-feedback-btn-save {
    background: #0ea5e9;
    color: #ffffff;
  }

  .mkp-feedback-btn-cancel {
    background: #e2e8f0;
    color: #1e293b;
  }

  .mkp-feedback-inline-msg {
    margin-top: 8px;
    font-size: 12px;
    color: #334155;
  }

  @media (max-width: 768px) {
    .mkp-feedback-board {
      margin-top: 10px;
      padding: 0 8px;
    }
  }
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {
  var pageParams = new URLSearchParams(window.location.search || '');
  var currentPage = (pageParams.get('p') || '').toLowerCase();
  if (currentPage !== 'visitor') return;

  // Kritik/saran sekarang diisi melalui dropdown Visitor (bukan popup otomatis).
  return;

  var feedbackApiBase = 'index.php?p=visitor&visitor_feedback_api=1';
  var feedbackOverlay = null;
  var feedbackContext = null;
  var lastVisitorEventKey = '';
  var lastVisitorEventAt = 0;

  function normalizeText(value) {
    return String(value || '').replace(/\\s+/g, ' ').trim();
  }

  function roomCodeFromUrl(urlLike) {
    try {
      var parsed = new URL(urlLike || window.location.href, window.location.href);
      return normalizeText(parsed.searchParams.get('room') || '');
    } catch (e) {
      return normalizeText(pageParams.get('room') || '');
    }
  }

  function parseQueryString(serialized) {
    var out = {};
    if (!serialized) return out;
    String(serialized).split('&').forEach(function (pair) {
      if (!pair) return;
      var idx = pair.indexOf('=');
      var key = idx >= 0 ? pair.slice(0, idx) : pair;
      var val = idx >= 0 ? pair.slice(idx + 1) : '';
      key = decodeURIComponent(key.replace(/\\+/g, ' '));
      val = decodeURIComponent(val.replace(/\\+/g, ' '));
      out[key] = val;
    });
    return out;
  }

  function parseVisitorPayload(raw) {
    if (!raw) return null;
    if (typeof raw === 'object') return raw;
    try {
      return JSON.parse(String(raw));
    } catch (e) {
      return null;
    }
  }

  function shouldTreatAsVisitorSuccess(payload) {
    if (!payload || typeof payload !== 'object') return false;
    var message = String(payload.message || '').toLowerCase();
    if (message === '') return false;

    var failHints = [
      "can't be empty",
      'error inserting',
      'please fill institution',
      'sorry',
      'gagal',
      'tidak dapat',
      'tidak bisa'
    ];
    for (var i = 0; i < failHints.length; i += 1) {
      if (message.indexOf(failHints[i]) !== -1) return false;
    }
    return true;
  }

  function ensureFeedbackOverlay() {
    if (feedbackOverlay) return feedbackOverlay;
    var overlay = document.getElementById('mkpFeedbackOverlay');
    if (overlay) {
      feedbackOverlay = overlay;
      return feedbackOverlay;
    }

    overlay = document.createElement('div');
    overlay.id = 'mkpFeedbackOverlay';
    overlay.className = 'mkp-feedback-overlay';
    overlay.innerHTML = ''
      + '<div class="mkp-feedback-dialog" role="dialog" aria-modal="true" aria-labelledby="mkpFeedbackTitle">'
      + '  <div class="mkp-feedback-dialog-head">'
      + '    <h4 id="mkpFeedbackTitle">Kritik &amp; Saran</h4>'
      + '    <button type="button" data-feedback-close="1" aria-label="Tutup">&times;</button>'
      + '  </div>'
      + '  <div class="mkp-feedback-dialog-body">'
      + '    <div class="mkp-feedback-meta">'
      + '      <div class="mkp-feedback-meta-item"><small>Lokasi</small><strong id="mkpFeedbackMetaLocation">-</strong></div>'
      + '      <div class="mkp-feedback-meta-item"><small>Member</small><strong id="mkpFeedbackMetaMember">-</strong></div>'
      + '      <div class="mkp-feedback-meta-item"><small>Nama</small><strong id="mkpFeedbackMetaName">-</strong></div>'
      + '      <div class="mkp-feedback-meta-item"><small>Tipe / Instansi</small><strong id="mkpFeedbackMetaType">-</strong></div>'
      + '    </div>'
      + '    <form id="mkpFeedbackForm" class="mkp-feedback-form">'
      + '      <label>Jenis Masukan</label>'
      + '      <div class="mkp-feedback-type-select">'
      + '        <label><input type="radio" name="feedback_type" value="saran" checked> Saran</label>'
      + '        <label><input type="radio" name="feedback_type" value="kritik"> Kritik</label>'
      + '      </div>'
      + '      <label for="mkpFeedbackText">Isi Kritik/Saran</label>'
      + '      <textarea id="mkpFeedbackText" name="feedback_text" maxlength="3000" required placeholder="Tulis kritik atau saran Anda..."></textarea>'
      + '      <div class="mkp-feedback-actions">'
      + '        <button type="button" class="mkp-feedback-btn-cancel" data-feedback-close="1">Cancel</button>'
      + '        <button type="submit" class="mkp-feedback-btn-save">Simpan</button>'
      + '      </div>'
      + '      <div id="mkpFeedbackInlineMsg" class="mkp-feedback-inline-msg"></div>'
      + '    </form>'
      + '  </div>'
      + '</div>';

    document.body.appendChild(overlay);
    overlay.addEventListener('click', function (event) {
      if (event.target === overlay || event.target.getAttribute('data-feedback-close') === '1') {
        closeFeedbackOverlay();
      }
    });

    var form = overlay.querySelector('#mkpFeedbackForm');
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      submitFeedbackForm();
    });

    feedbackOverlay = overlay;
    return feedbackOverlay;
  }

  function openFeedbackOverlay(context) {
    var overlay = ensureFeedbackOverlay();
    feedbackContext = context || null;
    if (!feedbackContext) return;

    var memberId = normalizeText(feedbackContext.member_id || '');
    var memberLabel = memberId || (String(feedbackContext.visitor_kind || '') === 'rombongan' ? 'ROMBONGAN' : 'NON-ANGGOTA');
    var typeLabel = memberId
      ? normalizeText(feedbackContext.member_type_name || '') || 'Anggota'
      : normalizeText(feedbackContext.institution || '') || '-';

    overlay.querySelector('#mkpFeedbackMetaLocation').textContent = normalizeText(feedbackContext.visit_location || '-') || '-';
    overlay.querySelector('#mkpFeedbackMetaMember').textContent = memberLabel;
    overlay.querySelector('#mkpFeedbackMetaName').textContent = normalizeText(feedbackContext.member_name || '-') || '-';
    overlay.querySelector('#mkpFeedbackMetaType').textContent = typeLabel;
    overlay.querySelector('#mkpFeedbackText').value = '';
    overlay.querySelector('#mkpFeedbackInlineMsg').textContent = '';
    overlay.classList.add('is-open');
    overlay.querySelector('#mkpFeedbackText').focus();
  }

  function closeFeedbackOverlay() {
    if (!feedbackOverlay) return;
    feedbackOverlay.classList.remove('is-open');
    var msg = feedbackOverlay.querySelector('#mkpFeedbackInlineMsg');
    if (msg) msg.textContent = '';
  }

  function fetchJson(url, options) {
    return fetch(url, options || {}).then(function (res) {
      return res.text().then(function (txt) {
        var data = parseVisitorPayload(txt);
        if (data && typeof data === 'object') return data;
        throw new Error('Response API tidak valid.');
      });
    });
  }

  function submitFeedbackForm() {
    if (!feedbackContext) return;
    var form = document.getElementById('mkpFeedbackForm');
    var msg = document.getElementById('mkpFeedbackInlineMsg');
    if (!form || !msg) return;

    var formData = new FormData(form);
    var textVal = normalizeText(formData.get('feedback_text') || '');
    if (textVal === '') {
      msg.textContent = 'Isi kritik/saran tidak boleh kosong.';
      return;
    }
    formData.set('feedback_text', textVal);
    formData.set('member_id', normalizeText(feedbackContext.member_id || ''));
    formData.set('member_name', normalizeText(feedbackContext.member_name || 'Visitor'));
    formData.set('institution', normalizeText(feedbackContext.institution || ''));
    formData.set('member_type_name', normalizeText(feedbackContext.member_type_name || ''));
    formData.set('room_code', normalizeText(feedbackContext.room_code || roomCodeFromUrl(window.location.href)));
    formData.set('visit_location', normalizeText(feedbackContext.visit_location || ''));
    formData.set('checkin_at', normalizeText(feedbackContext.checkin_at || ''));

    msg.textContent = 'Menyimpan...';
    fetchJson(feedbackApiBase + '&action=submit', {
      method: 'POST',
      body: formData,
      credentials: 'same-origin'
    }).then(function (payload) {
      if (!payload || !payload.ok) {
        msg.textContent = (payload && payload.message) ? String(payload.message) : 'Gagal menyimpan kritik/saran.';
        return;
      }
      closeFeedbackOverlay();
    }).catch(function () {
      msg.textContent = 'Gagal menyimpan kritik/saran.';
    });
  }

  function openOverlayByVisitorInput(memberInput, institution, roomCode, payload) {
    memberInput = normalizeText(memberInput);
    institution = normalizeText(institution);
    roomCode = normalizeText(roomCode || roomCodeFromUrl(window.location.href));
    if (memberInput === '') return;
    if (!shouldTreatAsVisitorSuccess(payload)) return;

    var signature = [memberInput, institution, roomCode, normalizeText(payload && payload.message ? payload.message : '')].join('|');
    var nowMs = Date.now();
    if (signature === lastVisitorEventKey && (nowMs - lastVisitorEventAt) < 2500) {
      return;
    }
    lastVisitorEventKey = signature;
    lastVisitorEventAt = nowMs;

    var contextData = new FormData();
    contextData.set('member_input', memberInput);
    contextData.set('institution', institution);
    contextData.set('room_code', roomCode);
    fetchJson(feedbackApiBase + '&action=context', {
      method: 'POST',
      body: contextData,
      credentials: 'same-origin'
    }).then(function (contextPayload) {
      var context = (contextPayload && contextPayload.context && typeof contextPayload.context === 'object')
        ? contextPayload.context
        : null;
      if (!context) {
        context = {
          member_id: '',
          member_name: memberInput,
          institution: institution,
          member_type_name: '',
          visitor_kind: institution !== '' ? 'rombongan' : 'non_anggota',
          room_code: roomCode,
          visit_location: roomCode || '-',
          checkin_at: ''
        };
      }
      openFeedbackOverlay(context);
    }).catch(function () {
      openFeedbackOverlay({
        member_id: '',
        member_name: memberInput,
        institution: institution,
        member_type_name: '',
        visitor_kind: institution !== '' ? 'rombongan' : 'non_anggota',
        room_code: roomCode,
        visit_location: roomCode || '-',
        checkin_at: ''
      });
    });
  }

  function hookAxiosVisitorSubmit() {
    if (!window.axios || !window.axios.interceptors || window.__mkpFeedbackAxiosHooked) return false;
    window.__mkpFeedbackAxiosHooked = true;
    axios.interceptors.response.use(function (response) {
      try {
        var config = response && response.config ? response.config : {};
        var url = String(config.url || '');
        if (url.toLowerCase().indexOf('p=visitor') === -1) return response;

        var memberInput = '';
        var institution = '';
        var roomCode = roomCodeFromUrl(url);
        var reqData = config.data;
        if (reqData && typeof FormData !== 'undefined' && reqData instanceof FormData) {
          memberInput = normalizeText(reqData.get('memberID') || '');
          institution = normalizeText(reqData.get('institution') || '');
        } else if (typeof reqData === 'string') {
          var parsed = parseQueryString(reqData);
          memberInput = normalizeText(parsed.memberID || '');
          institution = normalizeText(parsed.institution || '');
        } else if (reqData && typeof reqData === 'object') {
          memberInput = normalizeText(reqData.memberID || '');
          institution = normalizeText(reqData.institution || '');
        }
        openOverlayByVisitorInput(memberInput, institution, roomCode, response.data || null);
      } catch (e) {}
      return response;
    }, function (error) {
      return Promise.reject(error);
    });
    return true;
  }

  function hookJqueryVisitorSubmit() {
    if (!window.jQuery || window.__mkpFeedbackJqHooked) return false;
    window.__mkpFeedbackJqHooked = true;
    jQuery(document).ajaxSuccess(function (_event, xhr, settings) {
      try {
        settings = settings || {};
        var url = String(settings.url || '');
        if (url.toLowerCase().indexOf('p=visitor') === -1) return;

        var payload = parseVisitorPayload(xhr && (xhr.responseJSON || xhr.responseText));
        var parsed = parseQueryString(settings.data || '');
        var memberInput = normalizeText(parsed.memberID || '');
        var institution = normalizeText(parsed.institution || '');
        var roomCode = roomCodeFromUrl(url);
        openOverlayByVisitorInput(memberInput, institution, roomCode, payload);
      } catch (e) {}
    });
    return true;
  }

  ensureFeedbackOverlay();
  hookAxiosVisitorSubmit();
  hookJqueryVisitorSubmit();

  var hookRetry = 0;
  var hookTimer = window.setInterval(function () {
    hookRetry += 1;
    hookAxiosVisitorSubmit();
    hookJqueryVisitorSubmit();
    if (hookRetry >= 40) {
      window.clearInterval(hookTimer);
    }
  }, 250);

});
</script>
HTML;

    $js .= <<<HTML
<style>
  .ufn-visitor-feedback-box {
    display: none;
    margin-bottom: 12px;
    padding: 12px;
    border: 1px solid rgba(148, 163, 184, 0.45);
    border-radius: 10px;
    background: rgba(248, 250, 252, 0.92);
  }

  .ufn-visitor-feedback-box .ufn-feedback-title {
    margin: 0 0 8px;
    font-size: 14px;
    font-weight: 700;
    color: #0f172a;
  }

  .ufn-visitor-feedback-box .ufn-feedback-type {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin-bottom: 8px;
  }

  .ufn-visitor-feedback-box .ufn-feedback-type label {
    margin: 0;
    font-size: 13px;
    font-weight: 600;
    color: #1f2937;
    display: inline-flex;
    align-items: center;
    gap: 6px;
  }

  .ufn-visitor-feedback-box textarea {
    width: 100%;
    min-height: 96px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    padding: 8px 10px;
    resize: vertical;
    box-sizing: border-box;
  }

  .ufn-visitor-feedback-actions {
    margin-top: 8px;
    display: flex;
    gap: 8px;
    justify-content: flex-end;
  }

  .ufn-visitor-feedback-actions .btn {
    min-width: 96px;
  }
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {
  var params = new URLSearchParams(window.location.search || '');
  var currentPage = (params.get('p') || '').toLowerCase();
  if (currentPage !== 'visitor') return;

  var feedbackApiBase = 'index.php?p=visitor&visitor_feedback_api=1';

  function normalizeText(value) {
    return String(value || '').replace(/\\s+/g, ' ').trim();
  }

  function parseJsonSafe(raw) {
    if (!raw) return null;
    if (typeof raw === 'object') return raw;
    try {
      return JSON.parse(String(raw));
    } catch (e) {
      return null;
    }
  }

  function setCounterInfo(message) {
    var info = document.getElementById('counterInfo');
    if (info) {
      info.innerHTML = String(message || '');
    }
  }

  function getRoomCodeFromUrl() {
    return normalizeText(params.get('room') || '');
  }

  function hasNativeFeedbackVisitor(form, typeSelect) {
    if (!form || !typeSelect) return false;
    var hasFeedbackOption = false;
    for (var i = 0; i < typeSelect.options.length; i += 1) {
      if ((typeSelect.options[i].value || '').toLowerCase() === 'kritik_saran') {
        hasFeedbackOption = true;
        break;
      }
    }
    if (!hasFeedbackOption) return false;

    var hasNativeFields = !!(
      form.querySelector('#feedbackText')
      || form.querySelector('textarea[name="feedbackText"]')
      || form.querySelector('input[name="feedbackType"]')
      || form.querySelector('.magangkp-feedback-fields')
    );

    return hasNativeFields;
  }

  function ensureFeedbackOption(typeSelect) {
    if (!typeSelect) return;
    var hasOption = false;
    for (var i = 0; i < typeSelect.options.length; i += 1) {
      if ((typeSelect.options[i].value || '').toLowerCase() === 'kritik_saran') {
        hasOption = true;
        break;
      }
    }
    if (hasOption) return;

    var option = document.createElement('option');
    option.value = 'kritik_saran';
    option.textContent = 'Kritik dan Saran';

    var inserted = false;
    for (var j = 0; j < typeSelect.options.length; j += 1) {
      if ((typeSelect.options[j].value || '').toLowerCase() === 'rombongan') {
        if (typeSelect.options[j].nextSibling) {
          typeSelect.insertBefore(option, typeSelect.options[j].nextSibling);
        } else {
          typeSelect.appendChild(option);
        }
        inserted = true;
        break;
      }
    }
    if (!inserted) {
      typeSelect.appendChild(option);
    }
  }

  function getSubmitButton(form) {
    if (!form) return null;
    return form.querySelector('#counter, input[type=\"submit\"], button[type=\"submit\"], button:not([type])');
  }

  function ensureFeedbackBox(form) {
    if (!form) return null;
    var box = form.querySelector('#ufnVisitorFeedbackBox');
    if (box) return box;

    box = document.createElement('div');
    box.id = 'ufnVisitorFeedbackBox';
    box.className = 'ufn-visitor-feedback-box';
    box.innerHTML = ''
      + '<div class=\"ufn-feedback-title\">Jenis Masukan</div>'
      + '<div class=\"ufn-feedback-type\">'
      + '  <label><input type=\"radio\" name=\"ufn_feedback_type\" value=\"saran\" checked> Saran</label>'
      + '  <label><input type=\"radio\" name=\"ufn_feedback_type\" value=\"kritik\"> Kritik</label>'
      + '</div>'
      + '<div class=\"ufn-feedback-title\">Isi Kritik/Saran</div>'
      + '<textarea id=\"ufnFeedbackText\" maxlength=\"3000\" placeholder=\"Tulis kritik atau saran Anda...\"></textarea>'
      + '<div class=\"ufn-visitor-feedback-actions\">'
      + '  <button type=\"button\" class=\"btn btn-default\" id=\"ufnFeedbackCancelBtn\">Cancel</button>'
      + '  <button type=\"button\" class=\"btn btn-primary\" id=\"ufnFeedbackSendBtn\">Kirim</button>'
      + '</div>';

    var submitButton = getSubmitButton(form);
    var submitContainer = submitButton ? (submitButton.closest('.col-lg-12, .col-md-12, .col-sm-12, .col-xs-12, .form-group') || submitButton.parentNode) : null;
    if (submitContainer && submitContainer.parentNode) {
      submitContainer.parentNode.insertBefore(box, submitContainer);
    } else {
      form.appendChild(box);
    }

    var cancelBtn = box.querySelector('#ufnFeedbackCancelBtn');
    if (cancelBtn && !cancelBtn.dataset.ufnBound) {
      cancelBtn.dataset.ufnBound = '1';
      cancelBtn.addEventListener('click', function () {
        var typeSelect = form.querySelector('#visitorType, select[name=\"visitorType\"]');
        if (typeSelect) {
          typeSelect.value = 'member';
          typeSelect.dispatchEvent(new Event('change', { bubbles: true }));
        }
        setCounterInfo('Mode kritik/saran dibatalkan.');
      });
    }

    var sendBtn = box.querySelector('#ufnFeedbackSendBtn');
    if (sendBtn && !sendBtn.dataset.ufnBound) {
      sendBtn.dataset.ufnBound = '1';
      sendBtn.addEventListener('click', function () {
        submitFeedback(form);
      });
    }

    return box;
  }

  function setFormModeState(form) {
    if (!form) return;
    var typeSelect = form.querySelector('#visitorType, select[name=\"visitorType\"]');
    if (!typeSelect) return;
    var isFeedbackMode = (typeSelect.value || '').toLowerCase() === 'kritik_saran';

    var box = ensureFeedbackBox(form);
    if (box) {
      box.style.display = isFeedbackMode ? 'block' : 'none';
    }

    var submitButton = getSubmitButton(form);
    if (submitButton) {
      if (!submitButton.dataset.ufnOriginalLabel) {
        submitButton.dataset.ufnOriginalLabel = submitButton.tagName === 'INPUT'
          ? (submitButton.value || 'Add')
          : (submitButton.textContent || 'Add');
      }
      var targetLabel = isFeedbackMode ? 'Kirim Kritik/Saran' : submitButton.dataset.ufnOriginalLabel;
      if (submitButton.tagName === 'INPUT') {
        submitButton.value = targetLabel;
      } else {
        submitButton.textContent = targetLabel;
      }
    }

    var institutionInput = form.querySelector('#institution, input[name=\"institution\"]');
    if (institutionInput) {
      var institutionWrapper = institutionInput.closest('.col-lg-6, .col-lg-12, .col-md-6, .col-md-12, .col-sm-6, .col-sm-12, .col-xs-6, .col-xs-12, .form-group');
      if (isFeedbackMode) {
        institutionInput.required = false;
        institutionInput.removeAttribute('pattern');
        institutionInput.removeAttribute('title');
        if (institutionWrapper) {
          institutionWrapper.style.display = 'none';
        }
      } else if (institutionWrapper) {
        institutionWrapper.style.display = '';
      }
    }

    var purposeSelect = form.querySelector('#visitorPurpose, select[name=\"visitorPurpose\"]');
    if (purposeSelect && isFeedbackMode) {
      purposeSelect.required = false;
      purposeSelect.value = '';
      var purposeWrapper = purposeSelect.closest('.magangkp-standard-purpose-field');
      if (purposeWrapper) {
        purposeWrapper.style.display = 'none';
      }
    }
  }

  function getFeedbackType(form) {
    var checked = form.querySelector('input[name=\"ufn_feedback_type\"]:checked');
    var value = checked ? (checked.value || '') : '';
    value = normalizeText(value).toLowerCase();
    return value === 'kritik' ? 'kritik' : 'saran';
  }

  function postForm(url, payload) {
    var body = new URLSearchParams();
    Object.keys(payload).forEach(function (key) {
      body.append(key, payload[key] == null ? '' : String(payload[key]));
    });
    return fetch(url, {
      method: 'POST',
      body: body.toString(),
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      credentials: 'same-origin'
    }).then(function (response) {
      return response.text().then(function (text) {
        var payloadJson = parseJsonSafe(text);
        return payloadJson || { ok: false, message: 'Response API tidak valid.' };
      });
    });
  }

  function submitFeedback(form) {
    if (!form) return;
    var typeSelect = form.querySelector('#visitorType, select[name=\"visitorType\"]');
    if (!typeSelect || (typeSelect.value || '').toLowerCase() !== 'kritik_saran') {
      return;
    }

    var visitLocationInput = form.querySelector('#visitLocation, select[name=\"visitLocation\"]');
    var memberInput = form.querySelector('#memberID, input[name=\"memberID\"]');
    var institutionInput = form.querySelector('#institution, input[name=\"institution\"]');
    var feedbackTextInput = form.querySelector('#ufnFeedbackText');

    var visitLocation = normalizeText(visitLocationInput ? visitLocationInput.value : '');
    var memberValue = normalizeText(memberInput ? memberInput.value : '');
    var institutionValue = normalizeText(institutionInput ? institutionInput.value : '');
    var feedbackType = getFeedbackType(form);
    var feedbackText = normalizeText(feedbackTextInput ? feedbackTextInput.value : '');

    if (visitLocation === '') {
      setCounterInfo('Pilih lokasi kunjungan terlebih dahulu.');
      if (visitLocationInput) visitLocationInput.focus();
      return;
    }
    if (memberValue === '') {
      setCounterInfo('Isi Member ID atau Nama terlebih dahulu.');
      if (memberInput) memberInput.focus();
      return;
    }
    if (feedbackText === '') {
      setCounterInfo('Isi kritik/saran tidak boleh kosong.');
      if (feedbackTextInput) feedbackTextInput.focus();
      return;
    }

    var sendButton = form.querySelector('#ufnFeedbackSendBtn');
    var submitButton = getSubmitButton(form);
    if (sendButton) sendButton.disabled = true;
    if (submitButton) submitButton.disabled = true;
    setCounterInfo('Menyimpan kritik/saran...');

    postForm(feedbackApiBase + '&action=context', {
      member_input: memberValue,
      institution: institutionValue,
      room_code: getRoomCodeFromUrl()
    }).then(function (contextResponse) {
      var context = (contextResponse && contextResponse.context && typeof contextResponse.context === 'object')
        ? contextResponse.context
        : {};
      var payload = {
        member_id: normalizeText(context.member_id || ''),
        member_name: normalizeText(context.member_name || '') || memberValue,
        institution: normalizeText(context.institution || '') || institutionValue,
        member_type_name: normalizeText(context.member_type_name || ''),
        room_code: normalizeText(context.room_code || '') || getRoomCodeFromUrl(),
        visit_location: visitLocation,
        checkin_at: normalizeText(context.checkin_at || ''),
        feedback_type: feedbackType,
        feedback_text: feedbackText
      };

      return postForm(feedbackApiBase + '&action=submit', payload);
    }).then(function (saveResponse) {
      var isOk = !!(saveResponse && saveResponse.ok);
      var message = (saveResponse && saveResponse.message)
        ? String(saveResponse.message)
        : (isOk ? 'Kritik/saran berhasil disimpan.' : 'Gagal menyimpan kritik/saran.');

      setCounterInfo(message);
      if (!isOk) return;

      if (feedbackTextInput) feedbackTextInput.value = '';
      var saranRadio = form.querySelector('input[name=\"ufn_feedback_type\"][value=\"saran\"]');
      if (saranRadio) saranRadio.checked = true;
      if (memberInput) memberInput.value = '';

      typeSelect.value = 'member';
      typeSelect.dispatchEvent(new Event('change', { bubbles: true }));
    }).catch(function () {
      setCounterInfo('Gagal menyimpan kritik/saran.');
    }).finally(function () {
      if (sendButton) sendButton.disabled = false;
      if (submitButton) submitButton.disabled = false;
    });
  }

  function bindFormHandlers(form) {
    if (!form || form.dataset.ufnFeedbackBound === '1') return;
    form.dataset.ufnFeedbackBound = '1';

    form.addEventListener('submit', function (event) {
      var typeSelect = form.querySelector('#visitorType, select[name=\"visitorType\"]');
      if (!typeSelect || (typeSelect.value || '').toLowerCase() !== 'kritik_saran') {
        return;
      }
      event.preventDefault();
      if (typeof event.stopImmediatePropagation === 'function') {
        event.stopImmediatePropagation();
      }
      event.stopPropagation();
      submitFeedback(form);
      return false;
    }, true);
  }

  function initFeedbackMode() {
    var form = document.getElementById('visitorCounterForm');
    if (!form) return false;
    var typeSelect = form.querySelector('#visitorType, select[name=\"visitorType\"]');
    if (!typeSelect) return false;

    // Prevent double handlers when visitor plugin already provides kritik/saran mode.
    if (hasNativeFeedbackVisitor(form, typeSelect)) {
      return true;
    }

    ensureFeedbackOption(typeSelect);
    ensureFeedbackBox(form);
    setFormModeState(form);
    bindFormHandlers(form);

    if (typeSelect.dataset.ufnFeedbackChangeBound !== '1') {
      typeSelect.dataset.ufnFeedbackChangeBound = '1';
      typeSelect.addEventListener('change', function () {
        window.setTimeout(function () {
          setFormModeState(form);
        }, 0);
      });
    }

    return true;
  }

  if (!initFeedbackMode()) {
    var retryCount = 0;
    var retryTimer = window.setInterval(function () {
      retryCount += 1;
      if (initFeedbackMode() || retryCount >= 80) {
        window.clearInterval(retryTimer);
      }
    }, 150);
  }

  var observer = new MutationObserver(function () {
    initFeedbackMode();
  });
  observer.observe(document.body, { childList: true, subtree: true });
  window.setTimeout(function () {
    observer.disconnect();
  }, 20000);
});
</script>
HTML;

    $opac->js = $js;
});
