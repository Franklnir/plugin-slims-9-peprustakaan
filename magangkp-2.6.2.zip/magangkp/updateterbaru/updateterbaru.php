<?php

defined('INDEX_AUTH') or die('Direct access not allowed!');

require_once __DIR__ . '/lib.php';

if ($dbs instanceof mysqli) {
  updatefiturnewEnsureSchema($dbs);
}

$isVisitorFeedbackApi = isset($_REQUEST['visitor_feedback_api']) && (string) ($_REQUEST['visitor_feedback_api'] ?? '') === '1';
if ($isVisitorFeedbackApi) {
  while (ob_get_level() > 0) {
    ob_end_clean();
  }
  header('Content-Type: application/json; charset=utf-8');
  header('Cache-Control: no-cache, no-store, must-revalidate');

  $response = static function (array $payload): void {
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  };

  $action = strtolower(trim((string) ($_REQUEST['action'] ?? 'list')));
  $isPost = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST';

  if ($action === 'context') {
    $memberInput = trim((string) ($_REQUEST['member_input'] ?? ''));
    $institution = trim((string) ($_REQUEST['institution'] ?? ''));
    $roomCode = trim((string) ($_REQUEST['room_code'] ?? ''));
    $looksLikeMemberId = updatefiturnewLooksLikeMemberId($memberInput);
    $context = updatefiturnewFindLatestVisitorContext($dbs, $memberInput, $institution, $roomCode);

    if (!is_array($context)) {
      $memberLookup = $looksLikeMemberId
        ? updatefiturnewGetMemberFresh($dbs, $memberInput)
        : updatefiturnewGetMemberFreshByName($dbs, $memberInput);
      if ($memberLookup) {
        $context = [
          'member_id' => (string) ($memberLookup['member_id'] ?? ''),
          'member_name' => (string) ($memberLookup['member_name'] ?? $memberInput),
          'institution' => (string) ($memberLookup['inst_name'] ?? ''),
          'member_type_name' => (string) ($memberLookup['member_type_name'] ?? ''),
          'visitor_kind' => 'anggota',
          'room_code' => $roomCode,
          'visit_location' => updatefiturnewResolveVisitorLocationLabel($dbs, $roomCode, ''),
          'checkin_at' => updatefiturnewNow()
        ];
      } else {
        $context = [
          'member_id' => $looksLikeMemberId ? '' : updatefiturnewFeedbackVisitorNameMarker(),
          'member_name' => $memberInput !== '' ? $memberInput : 'Visitor',
          'institution' => $institution,
          'member_type_name' => '',
          'visitor_kind' => updatefiturnewClassifyVisitorKind('', $memberInput, $institution),
          'room_code' => $roomCode,
          'visit_location' => updatefiturnewResolveVisitorLocationLabel($dbs, $roomCode, ''),
          'checkin_at' => updatefiturnewNow()
        ];
      }
    }

    if (!$looksLikeMemberId && trim((string) ($context['member_id'] ?? '')) === '') {
      $context['member_id'] = updatefiturnewFeedbackVisitorNameMarker();
    }

    $response([
      'ok' => true,
      'context' => $context
    ]);
  }

  if ($action === 'submit') {
    if (!$isPost) {
      $response([
        'ok' => false,
        'message' => 'Metode submit harus POST.'
      ]);
    }

    $error = '';
    $created = updatefiturnewCreateVisitorFeedback($dbs, [
      'member_id' => (string) ($_POST['member_id'] ?? ''),
      'member_name' => (string) ($_POST['member_name'] ?? ''),
      'institution' => (string) ($_POST['institution'] ?? ''),
      'member_type_name' => (string) ($_POST['member_type_name'] ?? ''),
      'room_code' => (string) ($_POST['room_code'] ?? ''),
      'visit_location' => (string) ($_POST['visit_location'] ?? ''),
      'checkin_at' => (string) ($_POST['checkin_at'] ?? ''),
      'feedback_type' => (string) ($_POST['feedback_type'] ?? 'saran'),
      'feedback_text' => (string) ($_POST['feedback_text'] ?? ''),
      'created_ip' => (string) ip()
    ], $error);

    if (!$created) {
      $response([
        'ok' => false,
        'message' => $error !== '' ? $error : 'Gagal menyimpan kritik/saran.'
      ]);
    }

    $response([
      'ok' => true,
      'message' => 'Kritik/saran berhasil disimpan.',
      'feedback' => $created
    ]);
  }

  if ($action === 'list') {
    $limit = isset($_REQUEST['limit']) ? (int) $_REQUEST['limit'] : 60;
    $rows = updatefiturnewGetRecentVisitorFeedback($dbs, $limit);
    $response([
      'ok' => true,
      'rows' => $rows
    ]);
  }

  $response([
    'ok' => false,
    'message' => 'Aksi API tidak dikenali.'
  ]);
}

$mode = strtolower(trim((string) ($_REQUEST['mode'] ?? 'login')));
if (!in_array($mode, ['login', 'status'], true)) {
  $mode = 'login';
}

$messages = [
  'success' => [],
  'error' => [],
  'info' => []
];
$isPostRequest = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST';

$flashBagKey = 'updatefiturnew_flash_messages';
if (isset($_SESSION[$flashBagKey]) && is_array($_SESSION[$flashBagKey])) {
  foreach (['success', 'error', 'info'] as $messageType) {
    if (!empty($_SESSION[$flashBagKey][$messageType]) && is_array($_SESSION[$flashBagKey][$messageType])) {
      foreach ($_SESSION[$flashBagKey][$messageType] as $flashMessage) {
        $flashMessage = trim((string) $flashMessage);
        if ($flashMessage !== '') {
          $messages[$messageType][] = $flashMessage;
        }
      }
    }
  }
  unset($_SESSION[$flashBagKey]);
}

$buildPeminjamanUrl = function (array $params = []): string {
  $query = ['p' => 'peminjaman'];
  foreach ($params as $key => $value) {
    if ($value === null) {
      continue;
    }
    $value = trim((string) $value);
    if ($value === '') {
      continue;
    }
    $query[(string) $key] = $value;
  }
  return 'index.php?' . http_build_query($query);
};

$redirectVisitorUrl = 'index.php?p=visitor&destination=' . rawurlencode($buildPeminjamanUrl());
$pushFlashAndRedirect = function (string $url, array $flash = []) use ($flashBagKey): void {
  if (!isset($_SESSION[$flashBagKey]) || !is_array($_SESSION[$flashBagKey])) {
    $_SESSION[$flashBagKey] = [
      'success' => [],
      'error' => [],
      'info' => []
    ];
  }
  foreach (['success', 'error', 'info'] as $messageType) {
    if (empty($flash[$messageType]) || !is_array($flash[$messageType])) {
      continue;
    }
    foreach ($flash[$messageType] as $message) {
      $message = trim((string) $message);
      if ($message !== '') {
        $_SESSION[$flashBagKey][$messageType][] = $message;
      }
    }
  }
  header('Location: ' . $url);
  exit;
};

$locations = updatefiturnewGetLocationOptions($dbs, $sysconf);
$today = date('Y-m-d');
$authMember = null;
$visitWindow = [
  'allowed' => true,
  'location' => '',
  'reason' => '',
  'open_time' => null,
  'close_time' => null
];
$loanServiceOpen = true;
$dailyLimitValue = updatefiturnewGetDailyLoanLimit($dbs, 3);
$sameItemDailyLimitValue = updatefiturnewGetSameItemDailyLimit($dbs, 3);
$maxExtendLimitValue = updatefiturnewGetMaxExtendLimit($dbs, 2);
$allowLoanWithoutVisitor = updatefiturnewGetAllowLoanWithoutVisitor($dbs, false);
$useVisitorScheduleForLoan = updatefiturnewGetUseVisitorScheduleForLoan($dbs, true);
$dailyLoanUsage = [
  'limit' => $dailyLimitValue,
  'used' => 0,
  'remaining' => $dailyLimitValue
];

$resolveVisitWindow = static function (string $location) use ($dbs, $useVisitorScheduleForLoan): array {
  if ($useVisitorScheduleForLoan) {
    return updatefiturnewGetVisitWindowStatus($dbs, $location);
  }
  return [
    'allowed' => true,
    'location' => $location,
    'reason' => 'Mode jadwal pengunjung untuk updatefiturnew dinonaktifkan oleh admin.',
    'open_time' => null,
    'close_time' => null
  ];
};

if (!isset($_SESSION['updatefiturnew_cart']) || !is_array($_SESSION['updatefiturnew_cart'])) {
  $_SESSION['updatefiturnew_cart'] = [];
}

$auth = $_SESSION['updatefiturnew_auth'] ?? null;
if (is_array($auth) && !empty($auth['member_id'])) {
  // Real-time member data refresh: prevent stale session if admin modifies member
  $freshMember = updatefiturnewGetMemberFresh($dbs, (string) $auth['member_id']);
  if (!$freshMember) {
    unset($_SESSION['updatefiturnew_auth'], $_SESSION['updatefiturnew_cart']);
    $auth = null;
    $_SESSION['updatefiturnew_cart'] = [];
    $messages['error'][] = 'Data member tidak ditemukan di database. Silakan login ulang atau hubungi admin.';
  } elseif ((int) ($freshMember['is_pending'] ?? 0) === 1) {
    unset($_SESSION['updatefiturnew_auth'], $_SESSION['updatefiturnew_cart']);
    $auth = null;
    $_SESSION['updatefiturnew_cart'] = [];
    $messages['error'][] = 'Akun member Anda masih dalam status pending. Silakan hubungi admin perpustakaan.';
  } elseif (isset($freshMember['expire_date']) && $freshMember['expire_date'] < date('Y-m-d')) {
    unset($_SESSION['updatefiturnew_auth'], $_SESSION['updatefiturnew_cart']);
    $auth = null;
    $_SESSION['updatefiturnew_cart'] = [];
    $messages['error'][] = 'Keanggotaan Anda sudah kedaluwarsa (expired: ' . htmlspecialchars($freshMember['expire_date']) . '). Silakan hubungi admin untuk perpanjangan.';
  } else {
    // Keep session minimal: do not persist personal login data.
    $visitLocationSession = updatefiturnewNormalizeText((string) ($auth['visit_location'] ?? ''), 120);
    if ($visitLocationSession === '' && !empty($locations[0])) {
      $visitLocationSession = (string) $locations[0];
    }
    $_SESSION['updatefiturnew_auth'] = [
      'member_id' => (string) $freshMember['member_id'],
      'visit_location' => $visitLocationSession,
      'login_at' => (string) ($auth['login_at'] ?? updatefiturnewNow())
    ];
    $auth = $_SESSION['updatefiturnew_auth'];
    $authMember = $freshMember;

    // Visitor check (can be disabled from admin approval settings).
    if (!$allowLoanWithoutVisitor) {
      $stillVisitedToday = updatefiturnewHasVisitorToday($dbs, (string) $auth['member_id']);
      if (!$stillVisitedToday) {
        unset($_SESSION['updatefiturnew_auth'], $_SESSION['updatefiturnew_cart']);
        $auth = null;
        $_SESSION['updatefiturnew_cart'] = [];
        $pushFlashAndRedirect($redirectVisitorUrl, [
          'error' => ['Sesi updatefiturnew ditutup karena data visitor hari ini belum ditemukan. Silakan isi form Visitor terlebih dahulu.']
        ]);
      }
    }

    if ($auth) {
      $visitWindow = $resolveVisitWindow((string) ($auth['visit_location'] ?? ''));
      if (empty($visitWindow['allowed'])) {
        $loanServiceOpen = false;
        $messages['info'][] = 'Layanan updatefiturnew sedang tutup. ' . (string) ($visitWindow['reason'] ?? 'Silakan coba kembali saat jam layanan visitor buka.');
      }
    }
  }
}

if (isset($_POST['logout_updatefiturnew'])) {
  unset($_SESSION['updatefiturnew_auth'], $_SESSION['updatefiturnew_cart']);
  $_SESSION['updatefiturnew_cart'] = [];
  $auth = null;
  $messages['success'][] = 'Logout berhasil dari fitur updatefiturnew.';
}

if (isset($_POST['login_updatefiturnew'])) {
  $mode = 'login';
  $loginIdentifier = trim((string) ($_POST['member_login'] ?? ($_POST['member_email'] ?? '')));
  $password = (string) ($_POST['member_password'] ?? '');
  $visitLocation = updatefiturnewNormalizeText((string) ($_POST['visit_location'] ?? ''), 120);

  if ($loginIdentifier === '' || $password === '' || $visitLocation === '') {
    $messages['error'][] = 'Email/ID member, kata sandi, dan lokasi wajib diisi.';
  } else {
    $visitWindowLogin = $resolveVisitWindow($visitLocation);
    if (empty($visitWindowLogin['allowed'])) {
      $messages['error'][] = 'Login tidak dapat diproses karena layanan updatefiturnew sedang tutup. ' . (string) ($visitWindowLogin['reason'] ?? 'Ikuti jadwal layanan visitor.');
      $loanServiceOpen = false;
      $visitWindow = $visitWindowLogin;
    } else {
      $member = updatefiturnewFindMemberByLoginIdentifier($dbs, $loginIdentifier);

      if (!$member || !updatefiturnewVerifyPassword($dbs, (string) $member['member_id'], $password, (string) ($member['mpasswd'] ?? ''))) {
        $messages['error'][] = 'Login gagal. Pastikan Email/ID Member dan kata sandi benar, atau hubungi admin.';
      } elseif ((int) ($member['is_pending'] ?? 0) === 1) {
        $messages['error'][] = 'Akun member Anda masih dalam status pending. Silakan hubungi admin perpustakaan.';
      } elseif (isset($member['expire_date']) && $member['expire_date'] < date('Y-m-d')) {
        $messages['error'][] = 'Keanggotaan Anda sudah kedaluwarsa (expired: ' . htmlspecialchars($member['expire_date']) . '). Silakan hubungi admin untuk perpanjangan.';
      } else {
        $memberId = (string) $member['member_id'];
        if (!$allowLoanWithoutVisitor && !updatefiturnewHasVisitorToday($dbs, $memberId)) {
          $pushFlashAndRedirect($redirectVisitorUrl, [
            'error' => ['Login berhasil, tetapi Anda belum isi visitor hari ini. Anda akan diarahkan ke halaman Visitor.']
          ]);
        } else {
          $_SESSION['updatefiturnew_auth'] = [
            'member_id' => $memberId,
            'visit_location' => $visitLocation,
            'login_at' => updatefiturnewNow()
          ];
          $_SESSION['updatefiturnew_cart'] = [];
          $auth = $_SESSION['updatefiturnew_auth'];
          $authMember = $member;
          $visitWindow = $visitWindowLogin;
          $loanServiceOpen = true;
          $messages['success'][] = 'Login berhasil. Anda bisa membuat request transaksi updatefiturnew.';
        }
      }
    }
  }
}

$loginIdentifierInput = trim((string) ($_POST['member_login'] ?? ($_POST['member_email'] ?? '')));

if ($auth && isset($_POST['update_location'])) {
  $newLocation = updatefiturnewNormalizeText((string) ($_POST['visit_location'] ?? ''), 120);
  if ($newLocation === '') {
    $messages['error'][] = 'Lokasi kunjungan harus dipilih.';
  } else {
    $_SESSION['updatefiturnew_auth']['visit_location'] = $newLocation;
    $auth = $_SESSION['updatefiturnew_auth'];
    $visitWindow = $resolveVisitWindow($newLocation);
    $loanServiceOpen = !empty($visitWindow['allowed']);
    if ($loanServiceOpen) {
      $messages['success'][] = 'Lokasi kunjungan berhasil diperbarui.';
    } else {
      $messages['info'][] = 'Lokasi diperbarui, namun layanan updatefiturnew sedang tutup. ' . (string) ($visitWindow['reason'] ?? '');
    }
  }
}

if ($auth && isset($_POST['add_item_code'])) {
  if (!$loanServiceOpen) {
    $messages['error'][] = 'Peminjaman ditutup sementara karena jadwal visitor sedang tidak aktif.';
  } else {
    $itemCode = trim((string) ($_POST['item_code'] ?? ''));
    if ($itemCode === '') {
      $messages['error'][] = 'Item code / barcode wajib diisi.';
    } else {
      $item = updatefiturnewFindItemByCode($dbs, $itemCode);
      if (!$item) {
        $messages['error'][] = 'Item code tidak ditemukan.';
      } elseif ((int) ($item['no_loan'] ?? 0) > 0) {
        $messages['error'][] = 'Item "' . htmlspecialchars((string) ($item['title'] ?? $itemCode)) . '" tidak diizinkan untuk dipinjam (status: ' . htmlspecialchars((string) ($item['item_status_name'] ?? 'No Loan')) . ').';
      } else {
        $normalizedCode = (string) $item['item_code'];
        $dailyLimit = updatefiturnewCheckSameItemDailyLimit(
          $dbs,
          (string) ($auth['member_id'] ?? ''),
          $normalizedCode,
          $sameItemDailyLimitValue
        );
        if (empty($dailyLimit['allowed'])) {
          $messages['error'][] = (string) ($dailyLimit['message'] ?? 'Batas updatefiturnew harian untuk item ini sudah tercapai.');
        } else {
          $usageNow = updatefiturnewGetDailyLoanUsage($dbs, (string) ($auth['member_id'] ?? ''), (int) ($dailyLoanUsage['limit'] ?? 3));
          $plannedCartCount = count($_SESSION['updatefiturnew_cart']);
          if (!isset($_SESSION['updatefiturnew_cart'][$normalizedCode])) {
            $plannedCartCount++;
          }
          if (((int) ($usageNow['used'] ?? 0) + $plannedCartCount) > (int) ($usageNow['limit'] ?? 3)) {
            $messages['error'][] = 'Batas pinjam harian tercapai. Maksimal ' . (int) ($usageNow['limit'] ?? 3) . ' buku per hari, sisa kuota saat ini: ' . (int) ($usageNow['remaining'] ?? 0) . '.';
          } else {
            $_SESSION['updatefiturnew_cart'][$normalizedCode] = [
              'item_code' => $normalizedCode,
              'title' => (string) ($item['title'] ?? '-'),
              'location' => (string) ($item['location_name'] ?? '-'),
              'on_loan' => (int) ($item['on_loan'] ?? 0)
            ];
            if ((int) ($item['on_loan'] ?? 0) > 0) {
              $messages['info'][] = 'Item masuk daftar request, tetapi saat ini statusnya masih dipinjam. Admin akan memutuskan saat approval.';
            } else {
              $messages['success'][] = 'Item berhasil ditambahkan ke daftar request pinjam.';
            }
          }
        }
      }
    }
  }
}

if ($auth && isset($_POST['remove_item_code'])) {
  $removeCode = trim((string) ($_POST['remove_code'] ?? ''));
  if ($removeCode !== '' && isset($_SESSION['updatefiturnew_cart'][$removeCode])) {
    unset($_SESSION['updatefiturnew_cart'][$removeCode]);
    $messages['success'][] = 'Item dihapus dari daftar request.';
  }
}

if ($auth && isset($_POST['clear_cart'])) {
  $_SESSION['updatefiturnew_cart'] = [];
  $messages['success'][] = 'Daftar request pinjam dikosongkan.';
}

if ($auth && isset($_POST['submit_loan_request'])) {
  if (!$loanServiceOpen) {
    $messages['error'][] = 'Peminjaman ditutup sementara karena jadwal visitor sedang tidak aktif.';
  } else {
    $cartItems = array_values($_SESSION['updatefiturnew_cart']);
    $requestItems = [];
    $unavailableItems = [];

    // Re-validate all cart items in real-time before submitting
    foreach ($cartItems as $cartItem) {
      $itemCode = trim((string) ($cartItem['item_code'] ?? ''));
      if ($itemCode === '') {
        continue;
      }
      $freshItem = updatefiturnewFindItemByCode($dbs, $itemCode);
      if (!$freshItem) {
        $unavailableItems[] = $itemCode . ' (tidak ditemukan)';
        continue;
      }
      if ((int) ($freshItem['no_loan'] ?? 0) > 0) {
        $unavailableItems[] = $itemCode . ' (tidak boleh dipinjam)';
        continue;
      }

      $dailyLimit = updatefiturnewCheckSameItemDailyLimit(
        $dbs,
        (string) ($auth['member_id'] ?? ''),
        $itemCode,
        $sameItemDailyLimitValue
      );
      if (empty($dailyLimit['allowed'])) {
        $unavailableItems[] = $itemCode . ' (batas harian tercapai)';
        $messages['error'][] = (string) ($dailyLimit['message'] ?? '');
        continue;
      }

      $requestItems[] = [
        'item_code' => $itemCode,
        'loan_id' => null
      ];
    }

    if (count($unavailableItems) > 0) {
      $messages['info'][] = 'Beberapa item tidak bisa diproses: ' . implode(', ', $unavailableItems);
    }

    if (count($requestItems) < 1) {
      $messages['error'][] = 'Tidak ada item valid untuk request pinjam.';
    } else {
      $usageNow = updatefiturnewGetDailyLoanUsage($dbs, (string) ($auth['member_id'] ?? ''), (int) ($dailyLoanUsage['limit'] ?? 3));
      $requestedCount = count($requestItems);
      if (((int) ($usageNow['used'] ?? 0) + $requestedCount) > (int) ($usageNow['limit'] ?? 3)) {
        $messages['error'][] = 'Permintaan melebihi batas pinjam harian. Maksimal ' . (int) ($usageNow['limit'] ?? 3) . ' buku per hari. Sisa kuota hari ini: ' . (int) ($usageNow['remaining'] ?? 0) . '.';
      } else {
      $memberContext = $authMember ?: updatefiturnewGetMemberFresh($dbs, (string) ($auth['member_id'] ?? ''));
      $error = '';
      $created = updatefiturnewCreateRequest($dbs, [
        'action_type' => 'loan',
        'member_id' => (string) ($auth['member_id'] ?? ''),
        'member_email' => (string) ($memberContext['member_email'] ?? ''),
        'member_name' => (string) ($memberContext['member_name'] ?? ''),
        'member_type_name' => (string) ($memberContext['member_type_name'] ?? '-'),
        'visit_location' => (string) ($auth['visit_location'] ?? ''),
        'request_note' => trim((string) ($_POST['request_note_loan'] ?? '')),
        'created_ip' => (string) ip()
      ], $requestItems, $error);

      if ($created) {
        $_SESSION['updatefiturnew_cart'] = [];
        $messages['success'][] = 'Request pinjam berhasil dikirim. Kode request: ' . $created['request_code'];
      } else {
        $messages['error'][] = 'Gagal membuat request pinjam. ' . ($error ?: 'Coba lagi.');
      }
      }
    }
  }
}

if ($auth && isset($_POST['submit_return_request'])) {
  if (!$loanServiceOpen) {
    $messages['error'][] = 'Layanan pengembalian via OPAC ditutup sementara karena jadwal visitor tidak aktif.';
  } else {
    $selectedLoans = isset($_POST['loan_ids_return']) && is_array($_POST['loan_ids_return'])
      ? array_map('intval', $_POST['loan_ids_return'])
      : [];

    $activeLoans = updatefiturnewGetActiveLoans($dbs, (string) $auth['member_id']);
    $loanMap = [];
    foreach ($activeLoans as $loanRow) {
      $loanMap[(int) $loanRow['loan_id']] = $loanRow;
    }

    $requestItems = [];
    $pendingByLoan = updatefiturnewGetPendingRequestMapForMemberLoanIds($dbs, (string) ($auth['member_id'] ?? ''), $selectedLoans);
    foreach ($selectedLoans as $loanId) {
      if (!isset($loanMap[$loanId])) {
        continue;
      }
      if (isset($pendingByLoan[$loanId])) {
        $messages['error'][] = 'Sudah ada request pending untuk Loan ID #' . (int) $loanId . '. Tunggu admin memproses request sebelumnya.';
        continue;
      }

      $checkItemCode = (string) ($loanMap[$loanId]['item_code'] ?? '');
      $requestItems[] = [
        'item_code' => $checkItemCode,
        'loan_id' => $loanId
      ];
    }

    $memberContext = $authMember ?: updatefiturnewGetMemberFresh($dbs, (string) ($auth['member_id'] ?? ''));
    $error = '';
    $created = updatefiturnewCreateRequest($dbs, [
      'action_type' => 'return',
      'member_id' => (string) ($auth['member_id'] ?? ''),
      'member_email' => (string) ($memberContext['member_email'] ?? ''),
      'member_name' => (string) ($memberContext['member_name'] ?? ''),
      'member_type_name' => (string) ($memberContext['member_type_name'] ?? '-'),
      'visit_location' => (string) ($auth['visit_location'] ?? ''),
      'request_note' => trim((string) ($_POST['request_note_return'] ?? '')),
      'created_ip' => (string) ip()
    ], $requestItems, $error);

    if ($created) {
      // Auto-approve return request — pengembalian tidak perlu approval admin
      $autoResult = updatefiturnewProcessRequest(
        $dbs,
        (int) $created['request_id'],
        true, // approve
        'Pengembalian otomatis diproses.',
        [
          'uid' => 0,
          'username' => 'system (auto-return)'
        ],
        $sysconf ?? []
      );
      if (!empty($autoResult['ok']) && ($autoResult['final_status'] ?? '') === 'approved') {
        $messages['success'][] = 'Buku berhasil dikembalikan! (Kode: ' . $created['request_code'] . ')';
      } else {
        $messages['success'][] = 'Request kembali dikirim. Kode: ' . $created['request_code'] . '. ' . ($autoResult['message'] ?? '');
      }
    } else {
      $messages['error'][] = 'Gagal membuat request kembali. ' . ($error ?: 'Pilih minimal satu item pinjaman.');
    }
  }
}

if ($auth && isset($_POST['submit_extend_request'])) {
  if (!$loanServiceOpen) {
    $messages['error'][] = 'Layanan perpanjangan via OPAC ditutup sementara karena jadwal visitor tidak aktif.';
  } else {
    $selectedLoans = isset($_POST['loan_ids_extend']) && is_array($_POST['loan_ids_extend'])
      ? array_map('intval', $_POST['loan_ids_extend'])
      : [];

    $activeLoans = updatefiturnewGetActiveLoans($dbs, (string) $auth['member_id']);
    $loanMap = [];
    foreach ($activeLoans as $loanRow) {
      $loanMap[(int) $loanRow['loan_id']] = $loanRow;
    }

    $pendingByLoan = updatefiturnewGetPendingRequestMapForMemberLoanIds($dbs, (string) ($auth['member_id'] ?? ''), $selectedLoans);
    $requestItems = [];

    foreach ($selectedLoans as $loanId) {
      if (!isset($loanMap[$loanId])) {
        $messages['error'][] = 'Loan ID #' . (int) $loanId . ' tidak ditemukan pada pinjaman aktif Anda.';
        continue;
      }

      if (isset($pendingByLoan[$loanId])) {
        $messages['error'][] = 'Loan ID #' . (int) $loanId . ' masih memiliki request pending. Tunggu admin memproses request sebelumnya.';
        continue;
      }

      $validation = updatefiturnewValidateExtendLoan(
        $dbs,
        (string) ($auth['member_id'] ?? ''),
        (int) $loanId,
        (int) $maxExtendLimitValue
      );
      if (empty($validation['allowed'])) {
        $messages['error'][] = (string) ($validation['message'] ?? ('Loan ID #' . (int) $loanId . ' tidak dapat diperpanjang.'));
        continue;
      }

      $requestItems[] = [
        'item_code' => (string) ($loanMap[$loanId]['item_code'] ?? ''),
        'loan_id' => (int) $loanId
      ];
    }

    if (count($requestItems) < 1) {
      $messages['error'][] = 'Tidak ada Loan ID valid untuk request perpanjangan.';
    } else {
      $memberContext = $authMember ?: updatefiturnewGetMemberFresh($dbs, (string) ($auth['member_id'] ?? ''));
      $error = '';
      $created = updatefiturnewCreateRequest($dbs, [
        'action_type' => 'extend',
        'member_id' => (string) ($auth['member_id'] ?? ''),
        'member_email' => (string) ($memberContext['member_email'] ?? ''),
        'member_name' => (string) ($memberContext['member_name'] ?? ''),
        'member_type_name' => (string) ($memberContext['member_type_name'] ?? '-'),
        'visit_location' => (string) ($auth['visit_location'] ?? ''),
        'request_note' => trim((string) ($_POST['request_note_extend'] ?? '')),
        'created_ip' => (string) ip()
      ], $requestItems, $error);

      if ($created) {
        $messages['success'][] = 'Request perpanjangan berhasil dikirim. Kode request: ' . $created['request_code'];
      } else {
        $messages['error'][] = 'Gagal membuat request perpanjangan. ' . ($error ?: 'Coba lagi.');
      }
    }
  }
}

if ($isPostRequest) {
  $redirectParams = [];
  $postedMode = strtolower(trim((string) ($_POST['mode'] ?? $mode)));
  if (in_array($postedMode, ['login', 'status'], true)) {
    $redirectParams['mode'] = $postedMode;
  }

  if (isset($_POST['check_status'])) {
    $redirectParams['check_status'] = '1';
    $statusMember = trim((string) ($_POST['status_member_id'] ?? ''));
    if ($statusMember !== '') {
      $redirectParams['status_member_id'] = $statusMember;
    }
    $statusFilter = trim((string) ($_POST['status_list_filter'] ?? ''));
    if ($statusFilter !== '') {
      $redirectParams['status_list_filter'] = $statusFilter;
    }
    $statusMonth = trim((string) ($_POST['status_list_month'] ?? ''));
    if ($statusMonth !== '') {
      $redirectParams['status_list_month'] = $statusMonth;
    }
  }

  if (isset($_POST['member_list_filter']) || isset($_POST['member_list_month'])) {
    $memberFilter = trim((string) ($_POST['member_list_filter'] ?? ''));
    if ($memberFilter !== '') {
      $redirectParams['member_list_filter'] = $memberFilter;
    }
    $memberMonth = trim((string) ($_POST['member_list_month'] ?? ''));
    if ($memberMonth !== '') {
      $redirectParams['member_list_month'] = $memberMonth;
    }
  }

  if (!$auth) {
    $postedLocation = trim((string) ($_POST['visit_location'] ?? ''));
    if ($postedLocation !== '') {
      $redirectParams['visit_location'] = $postedLocation;
    }
  }

  $pushFlashAndRedirect($buildPeminjamanUrl($redirectParams), $messages);
}



$auth = $_SESSION['updatefiturnew_auth'] ?? null;
$cart = $_SESSION['updatefiturnew_cart'] ?? [];
$activeLoans = [];
$memberRequests = [];
$cartLiveItemMap = [];
$pendingRequestMapByItem = [];
$pendingRequestMapByLoan = [];
$loanExtendMeta = [];

if ($auth && !empty($auth['member_id'])) {
  $authMember = updatefiturnewGetMemberFresh($dbs, (string) $auth['member_id']);
  if (!$authMember) {
    unset($_SESSION['updatefiturnew_auth'], $_SESSION['updatefiturnew_cart']);
    $auth = null;
    $cart = [];
    $messages['error'][] = 'Data member tidak ditemukan. Silakan login ulang.';
  } else {
    $sessionLocation = trim((string) ($auth['visit_location'] ?? ''));
    if ($sessionLocation === '' && !empty($locations[0])) {
      $sessionLocation = (string) $locations[0];
      $_SESSION['updatefiturnew_auth']['visit_location'] = $sessionLocation;
      $auth = $_SESSION['updatefiturnew_auth'];
    }

    $visitWindow = $resolveVisitWindow($sessionLocation);
    $loanServiceOpen = !empty($visitWindow['allowed']);
    if (!$loanServiceOpen) {
      $windowInfo = 'Layanan updatefiturnew sedang tutup. ' . (string) ($visitWindow['reason'] ?? '');
      if (!in_array($windowInfo, $messages['info'], true)) {
        $messages['info'][] = $windowInfo;
      }
    }

    $dailyLoanUsage = updatefiturnewGetDailyLoanUsage($dbs, (string) $auth['member_id'], (int) ($dailyLoanUsage['limit'] ?? 3));
    $activeLoans = updatefiturnewGetActiveLoans($dbs, (string) $auth['member_id']);
    $memberRequests = updatefiturnewGetRequestsByMemberId($dbs, (string) $auth['member_id'], 20);
  }
} else {
  $candidateLocation = trim((string) ($_REQUEST['visit_location'] ?? ''));
  if ($candidateLocation !== '') {
    $visitWindow = $resolveVisitWindow($candidateLocation);
    $loanServiceOpen = !empty($visitWindow['allowed']);
  }
}

if (count($cart) > 0) {
  $cartCodes = [];
  foreach ($cart as $cartRow) {
    $code = trim((string) ($cartRow['item_code'] ?? ''));
    if ($code !== '') {
      $cartCodes[] = $code;
    }
  }
  if (count($cartCodes) > 0) {
    $cartLiveItemMap = updatefiturnewGetItemsByCodes($dbs, $cartCodes);
  }
}

if ($auth && count($activeLoans) > 0) {
  $loanCodes = [];
  $loanIds = [];
  foreach ($activeLoans as $loanRow) {
    $code = trim((string) ($loanRow['item_code'] ?? ''));
    if ($code !== '') {
      $loanCodes[] = $code;
    }
    $loanId = (int) ($loanRow['loan_id'] ?? 0);
    if ($loanId > 0) {
      $loanIds[] = $loanId;
      $renewedCount = (int) ($loanRow['renewed'] ?? 0);
      $canExtend = $maxExtendLimitValue > 0 && $renewedCount < $maxExtendLimitValue;
      $loanExtendMeta[$loanId] = [
        'allowed' => $canExtend,
        'renewed' => $renewedCount,
        'max' => (int) $maxExtendLimitValue,
        'message' => $canExtend
          ? 'Loan ID siap diperpanjang.'
          : (
            $maxExtendLimitValue < 1
              ? 'Perpanjangan sedang dinonaktifkan oleh admin.'
              : 'Maksimal perpanjangan tercapai (' . $renewedCount . '/' . $maxExtendLimitValue . ').'
          )
      ];
    }
  }
  if (count($loanCodes) > 0) {
    $pendingRequestMapByItem = updatefiturnewGetPendingRequestMapForMemberItems($dbs, (string) ($auth['member_id'] ?? ''), $loanCodes);
  }
  if (count($loanIds) > 0) {
    $pendingRequestMapByLoan = updatefiturnewGetPendingRequestMapForMemberLoanIds($dbs, (string) ($auth['member_id'] ?? ''), $loanIds);
  }
}

$userFilterSessionKey = 'updatefiturnew_user_filter_state';
if (!isset($_SESSION[$userFilterSessionKey]) || !is_array($_SESSION[$userFilterSessionKey])) {
  $_SESSION[$userFilterSessionKey] = [];
}

$statusFilterDefaults = [
  'status_member_id' => '',
  'status_list_filter' => 'all',
  'status_list_month' => '',
  'check_status' => '0'
];
$memberFilterDefaults = [
  'member_list_filter' => 'all',
  'member_list_month' => ''
];

$statusFilterScope = 'status';
$memberFilterScope = 'member:' . (string) ($auth['member_id'] ?? 'guest');

$savedStatusFilterState = $_SESSION[$userFilterSessionKey][$statusFilterScope] ?? [];
if (!is_array($savedStatusFilterState)) {
  $savedStatusFilterState = [];
}
$savedMemberFilterState = $_SESSION[$userFilterSessionKey][$memberFilterScope] ?? [];
if (!is_array($savedMemberFilterState)) {
  $savedMemberFilterState = [];
}

$statusFilterKeys = array_keys($statusFilterDefaults);
$memberFilterKeys = array_keys($memberFilterDefaults);

$hasExplicitStatusFilter = false;
foreach ($statusFilterKeys as $statusFilterKey) {
  if (array_key_exists($statusFilterKey, $_REQUEST)) {
    $hasExplicitStatusFilter = true;
    break;
  }
}
$statusFilterState = $statusFilterDefaults;
if ($hasExplicitStatusFilter) {
  foreach ($statusFilterKeys as $statusFilterKey) {
    $statusFilterState[$statusFilterKey] = trim((string) ($_REQUEST[$statusFilterKey] ?? $statusFilterDefaults[$statusFilterKey]));
  }
} elseif (count($savedStatusFilterState) > 0) {
  foreach ($statusFilterKeys as $statusFilterKey) {
    $statusFilterState[$statusFilterKey] = trim((string) ($savedStatusFilterState[$statusFilterKey] ?? $statusFilterDefaults[$statusFilterKey]));
  }
}
if (array_key_exists('check_status', $_REQUEST)) {
  $statusFilterState['check_status'] = '1';
} else {
  $statusCheckValue = strtolower((string) ($statusFilterState['check_status'] ?? '0'));
  $statusFilterState['check_status'] = ($statusCheckValue === '1' || $statusCheckValue === 'true') ? '1' : '0';
}

$hasExplicitMemberFilter = false;
foreach ($memberFilterKeys as $memberFilterKey) {
  if (array_key_exists($memberFilterKey, $_REQUEST)) {
    $hasExplicitMemberFilter = true;
    break;
  }
}
$memberFilterState = $memberFilterDefaults;
if ($hasExplicitMemberFilter) {
  foreach ($memberFilterKeys as $memberFilterKey) {
    $memberFilterState[$memberFilterKey] = trim((string) ($_REQUEST[$memberFilterKey] ?? $memberFilterDefaults[$memberFilterKey]));
  }
} elseif (count($savedMemberFilterState) > 0) {
  foreach ($memberFilterKeys as $memberFilterKey) {
    $memberFilterState[$memberFilterKey] = trim((string) ($savedMemberFilterState[$memberFilterKey] ?? $memberFilterDefaults[$memberFilterKey]));
  }
}

$buildRequestItemMap = static function (array $rows) use ($dbs): array {
  if (count($rows) < 1) {
    return [];
  }
  $requestIds = [];
  foreach ($rows as $rowData) {
    $requestId = (int) ($rowData['request_id'] ?? 0);
    if ($requestId > 0) {
      $requestIds[$requestId] = $requestId;
    }
  }
  if (count($requestIds) < 1) {
    return [];
  }
  return updatefiturnewGetItemDetailMapForRequests($dbs, array_values($requestIds));
};

$collapseRequestRowsByLoanCycle = static function (array $rows, array $itemMap): array {
  if (count($rows) < 2) {
    return $rows;
  }

  $buildLoanCycleKey = static function (array $requestRow, array $requestItems): ?string {
    $action = strtolower(trim((string) ($requestRow['action_type'] ?? '')));
    if (!in_array($action, ['loan', 'extend', 'renew', 'renewal', 'return'], true)) {
      return null;
    }
    if (count($requestItems) !== 1) {
      return null;
    }
    $loanId = (int) ($requestItems[0]['loan_id'] ?? 0);
    if ($loanId < 1) {
      return null;
    }
    $memberId = trim((string) ($requestRow['member_id'] ?? ''));
    if ($memberId === '') {
      return null;
    }
    return $memberId . ':' . $loanId;
  };

  $getRowPriority = static function (array $requestRow): int {
    $status = strtolower(trim((string) ($requestRow['status'] ?? '')));
    $action = strtolower(trim((string) ($requestRow['action_type'] ?? '')));

    if ($action === 'return' && in_array($status, ['approved', 'partial'], true)) {
      return 700;
    }
    if ($action === 'return' && in_array($status, ['pending', 'processing'], true)) {
      return 650;
    }
    if (in_array($action, ['extend', 'renew', 'renewal'], true) && $status === 'pending') {
      return 620;
    }
    if (in_array($action, ['extend', 'renew', 'renewal'], true) && $status === 'processing') {
      return 610;
    }
    if (in_array($action, ['extend', 'renew', 'renewal'], true) && in_array($status, ['approved', 'partial'], true)) {
      return 600;
    }
    if ($action === 'loan' && in_array($status, ['approved', 'partial'], true)) {
      return 500;
    }
    if ($status === 'pending') {
      return 300;
    }
    if ($status === 'processing') {
      return 250;
    }
    if (in_array($status, ['rejected', 'failed'], true)) {
      return 200;
    }
    return 100;
  };

  $groupBestRows = [];
  $standaloneRowIds = [];
  foreach ($rows as $rowData) {
    $requestId = (int) ($rowData['request_id'] ?? 0);
    $cycleKey = $buildLoanCycleKey($rowData, $itemMap[$requestId] ?? []);
    if ($cycleKey === null) {
      $standaloneRowIds[$requestId] = true;
      continue;
    }

    $priority = $getRowPriority($rowData);
    $requestedAtTs = strtotime((string) ($rowData['requested_at'] ?? '')) ?: 0;

    if (!isset($groupBestRows[$cycleKey])) {
      $groupBestRows[$cycleKey] = [
        'priority' => $priority,
        'requested_at_ts' => $requestedAtTs,
        'request_id' => $requestId
      ];
      continue;
    }

    $best = $groupBestRows[$cycleKey];
    $shouldReplace = false;
    if ($priority > (int) $best['priority']) {
      $shouldReplace = true;
    } elseif ($priority === (int) $best['priority']) {
      if ($requestedAtTs > (int) $best['requested_at_ts']) {
        $shouldReplace = true;
      } elseif ($requestedAtTs === (int) $best['requested_at_ts'] && $requestId > (int) $best['request_id']) {
        $shouldReplace = true;
      }
    }

    if ($shouldReplace) {
      $groupBestRows[$cycleKey] = [
        'priority' => $priority,
        'requested_at_ts' => $requestedAtTs,
        'request_id' => $requestId
      ];
    }
  }

  $selectedRowIds = $standaloneRowIds;
  foreach ($groupBestRows as $bestMeta) {
    $selectedRowIds[(int) ($bestMeta['request_id'] ?? 0)] = true;
  }
  if (count($selectedRowIds) < 1) {
    return $rows;
  }

  $collapsedRows = [];
  foreach ($rows as $rowData) {
    $requestId = (int) ($rowData['request_id'] ?? 0);
    if (isset($selectedRowIds[$requestId])) {
      $collapsedRows[] = $rowData;
    }
  }
  return $collapsedRows;
};

$statusRows = [];
$statusMemberId = trim((string) ($statusFilterState['status_member_id'] ?? ''));
$explicitCheckStatus = array_key_exists('check_status', $_REQUEST);
$requestedStatusCheck = (string) ($statusFilterState['check_status'] ?? '0') === '1';
$isCheckingStatus = $mode === 'status' && $requestedStatusCheck;
if ($isCheckingStatus) {
  if ($statusMemberId === '') {
    if ($explicitCheckStatus) {
      $messages['error'][] = 'Member ID wajib diisi untuk cek status.';
    }
    $isCheckingStatus = false;
  } else {
    $statusRows = updatefiturnewGetRequestsByMemberId($dbs, $statusMemberId, 50);
    $statusRows = $collapseRequestRowsByLoanCycle($statusRows, $buildRequestItemMap($statusRows));
    if (count($statusRows) < 1) {
      $messages['info'][] = 'Belum ada data request updatefiturnew untuk Member ID tersebut.';
    }
  }
}

if (count($memberRequests) > 0) {
  $memberRequests = $collapseRequestRowsByLoanCycle($memberRequests, $buildRequestItemMap($memberRequests));
}

$buildRelativeMeta = static function (string $datetimeValue): array {
  $requestedDate = preg_match('/^\d{4}-\d{2}-\d{2}/', $datetimeValue) ? substr($datetimeValue, 0, 10) : '';
  $relativeLabel = 'Telah Lalu';
  $relativeBadge = 'secondary';
  if ($requestedDate === date('Y-m-d')) {
    $relativeLabel = 'Hari Ini';
    $relativeBadge = 'primary';
  } elseif ($requestedDate === date('Y-m-d', strtotime('-1 day'))) {
    $relativeLabel = 'Kemarin';
    $relativeBadge = 'warning';
  }
  return [
    'label' => $relativeLabel,
    'badge' => $relativeBadge
  ];
};

$requestFilterOptions = [
  'all' => 'Semua',
  'approved' => 'Disetujui',
  'rejected' => 'Ditolak',
  'renewed' => 'Diperpanjang',
  'returned' => 'Dikembalikan',
  'today' => 'Hari Ini',
  'yesterday' => 'Kemarin',
  'past' => 'Telah Lalu'
];

$normalizeRequestFilter = static function (string $value) use ($requestFilterOptions): string {
  $value = trim(strtolower($value));
  if (!array_key_exists($value, $requestFilterOptions)) {
    return 'all';
  }
  return $value;
};

$normalizeMonthFilter = static function (string $value): string {
  $value = trim($value);
  if ($value === '' || !preg_match('/^\d{4}-\d{2}$/', $value)) {
    return '';
  }
  return $value;
};

$filterRequestRows = static function (array $rows, string $filterKey, string $monthFilter = ''): array {
  $filterKey = trim(strtolower($filterKey));
  $monthFilter = trim($monthFilter);
  if ($filterKey === '' || $filterKey === 'all') {
    if ($monthFilter === '') {
      return $rows;
    }
  }

  $today = date('Y-m-d');
  $yesterday = date('Y-m-d', strtotime('-1 day'));
  $filtered = [];

  foreach ($rows as $row) {
    $status = (string) ($row['status'] ?? '');
    $action = strtolower(trim((string) ($row['action_type'] ?? '')));
    $approvedCount = (int) ($row['item_approved'] ?? 0);
    $isApprovedLike = ($status === 'approved') || ($status === 'partial' && $approvedCount > 0);
    $isRejectedLike = in_array($status, ['rejected', 'failed'], true) || ($status === 'partial' && $approvedCount < 1);
    $isRenewAction = in_array($action, ['extend', 'renew', 'renewal'], true);
    $requestedAt = (string) ($row['requested_at'] ?? '');
    $requestedDate = preg_match('/^\d{4}-\d{2}-\d{2}/', $requestedAt) ? substr($requestedAt, 0, 10) : '';
    $requestedMonth = $requestedDate !== '' ? substr($requestedDate, 0, 7) : '';

    if ($monthFilter !== '' && $requestedMonth !== $monthFilter) {
      continue;
    }

    $match = false;
    if ($filterKey === '' || $filterKey === 'all') {
      $match = true;
    } elseif ($filterKey === 'approved') {
      $match = $action === 'loan' && $isApprovedLike;
    } elseif ($filterKey === 'rejected') {
      $match = $isRejectedLike;
    } elseif ($filterKey === 'renewed') {
      $match = $isRenewAction && $isApprovedLike;
    } elseif ($filterKey === 'returned') {
      $match = $action === 'return' && $isApprovedLike;
    } elseif ($filterKey === 'today') {
      $match = ($requestedDate === $today);
    } elseif ($filterKey === 'yesterday') {
      $match = ($requestedDate === $yesterday);
    } elseif ($filterKey === 'past') {
      $match = ($requestedDate !== '' && $requestedDate !== $today && $requestedDate !== $yesterday);
    }

    if ($match) {
      $filtered[] = $row;
    }
  }

  return $filtered;
};

$resolveUserRequestRowClass = static function (array $row): string {
  $status = strtolower(trim((string) ($row['status'] ?? '')));
  $action = strtolower(trim((string) ($row['action_type'] ?? '')));
  $approvedCount = (int) ($row['item_approved'] ?? 0);
  $isApprovedLike = ($status === 'approved') || ($status === 'partial' && $approvedCount > 0);
  $isPendingLike = in_array($status, ['pending', 'processing'], true);
  $isExtendAction = in_array($action, ['extend', 'renew', 'renewal'], true);

  if ($action === 'return' && $isApprovedLike) {
    return 'updatefiturnew-row-returned';
  }
  if ($isExtendAction && ($isApprovedLike || $isPendingLike)) {
    return 'updatefiturnew-row-extended';
  }
  if ($action === 'loan' && $isApprovedLike) {
    return 'updatefiturnew-row-onloan';
  }

  return '';
};

$statusListFilter = $normalizeRequestFilter((string) ($statusFilterState['status_list_filter'] ?? 'all'));
$memberListFilter = $normalizeRequestFilter((string) ($memberFilterState['member_list_filter'] ?? 'all'));
$statusListMonth = $normalizeMonthFilter((string) ($statusFilterState['status_list_month'] ?? ''));
$memberListMonth = $normalizeMonthFilter((string) ($memberFilterState['member_list_month'] ?? ''));

$_SESSION[$userFilterSessionKey][$statusFilterScope] = [
  'status_member_id' => $statusMemberId,
  'status_list_filter' => $statusListFilter,
  'status_list_month' => $statusListMonth,
  'check_status' => ($statusMemberId !== '' && $requestedStatusCheck) ? '1' : '0'
];
$_SESSION[$userFilterSessionKey][$memberFilterScope] = [
  'member_list_filter' => $memberListFilter,
  'member_list_month' => $memberListMonth
];

$filteredStatusRows = $filterRequestRows($statusRows, $statusListFilter, $statusListMonth);
$filteredMemberRequests = $filterRequestRows($memberRequests, $memberListFilter, $memberListMonth);
$statusItemMap = [];
if (count($filteredStatusRows) > 0) {
  $statusRequestIds = [];
  foreach ($filteredStatusRows as $statusRow) {
    $rid = (int) ($statusRow['request_id'] ?? 0);
    if ($rid > 0) {
      $statusRequestIds[] = $rid;
    }
  }
  if (count($statusRequestIds) > 0) {
    $statusItemMap = updatefiturnewGetItemDetailMapForRequests($dbs, $statusRequestIds);
  }
}

$selectedLocation = trim((string) ($auth['visit_location'] ?? ($_REQUEST['visit_location'] ?? '')));
$isGuestLoginState = !$auth;
$mustPickLocationFirst = $isGuestLoginState && $selectedLocation === '';
$windowLocationLabel = $selectedLocation !== '' ? $selectedLocation : '-';
$locationServiceMap = [];
$hasAnyOpenLocation = false;
foreach ($locations as $locationOption) {
  $locationName = trim((string) $locationOption);
  if ($locationName === '') {
    continue;
  }
  $locationWindow = $resolveVisitWindow($locationName);
  $isLocationOpen = !empty($locationWindow['allowed']);
  $locationServiceMap[$locationName] = [
    'allowed' => $isLocationOpen,
    'reason' => (string) ($locationWindow['reason'] ?? '')
  ];
  if ($isLocationOpen) {
    $hasAnyOpenLocation = true;
  }
}

$allLocationsClosed = !$auth && !$hasAnyOpenLocation;
$selectedLocationMeta = $locationServiceMap[$selectedLocation] ?? null;
$loginBySelectedLocationOpen = false;
if (!$mustPickLocationFirst && is_array($selectedLocationMeta)) {
  $loginBySelectedLocationOpen = !empty($selectedLocationMeta['allowed']);
}
$loginInputEnabled = (!$mustPickLocationFirst && $loginBySelectedLocationOpen);
$loginBySelectedLocationReason = '';
if ($mustPickLocationFirst) {
  $loginBySelectedLocationReason = 'Pilih lokasi kunjungan terlebih dahulu.';
} elseif (is_array($selectedLocationMeta)) {
  $loginBySelectedLocationReason = (string) ($selectedLocationMeta['reason'] ?? '');
} else {
  $loginBySelectedLocationReason = (string) ($visitWindow['reason'] ?? '');
}
if ($allLocationsClosed) {
  $allClosedInfo = 'Semua lokasi layanan updatefiturnew sedang tutup. Pilih lokasi untuk cek jadwal buka.';
  if (!in_array($allClosedInfo, $messages['info'], true)) {
    $messages['info'][] = $allClosedInfo;
  }
}

$locationServiceMapJs = json_encode($locationServiceMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$loginLocationClosedText = json_encode('Login nonaktif: perpustakaan tutup untuk lokasi ini.', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$loginChooseLocationText = json_encode('Pilih lokasi kunjungan terlebih dahulu.', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$loginAllClosedText = json_encode('Mode Login dinonaktifkan karena semua lokasi sedang tutup.', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$allLocationsClosedJs = $allLocationsClosed ? 'true' : 'false';

?>
<style>
  .updatefiturnew-wrap {
    --pmj-surface: #ffffff;
    --pmj-surface-soft: #f8fafc;
    --pmj-border: rgba(30, 41, 59, 0.35);
    --pmj-text: #0b1220;
    --pmj-muted: #1e293b;
    --pmj-accent: #0ea5e9;
    --pmj-warning: #d97706;
    --pmj-danger: #dc2626;
    --pmj-shadow: 0 8px 18px rgba(15, 23, 42, 0.12);
    width: 100%;
    max-width: 1420px;
    margin: 0 auto;
    padding: 10px 10px 22px;
  }

  .updatefiturnew-card {
    background: var(--pmj-surface);
    border: 1px solid var(--pmj-border);
    border-radius: 12px;
    box-shadow: var(--pmj-shadow);
    padding: 20px;
    margin-bottom: 16px;
  }

  .updatefiturnew-title {
    margin: 0 0 12px;
    font-size: 1.48rem;
    font-weight: 800;
    letter-spacing: 0.01em;
    color: var(--pmj-text);
  }

  .updatefiturnew-subtitle {
    margin: 0 0 14px;
    color: var(--pmj-muted);
  }

  .updatefiturnew-table-wrap {
    overflow-x: auto;
    border: 1px solid var(--pmj-border);
    border-radius: 12px;
    background: var(--pmj-surface-soft);
  }

  .updatefiturnew-wrap,
  .updatefiturnew-card,
  .updatefiturnew-form-row,
  .updatefiturnew-table-wrap,
  .updatefiturnew-table {
    direction: ltr;
  }

  .s-main-page .s-main-content.s-main-content-wide {
    max-width: 1500px;
    margin-left: auto !important;
    margin-right: auto !important;
    padding-left: 16px !important;
    padding-right: 16px !important;
  }

  .s-main-page .s-main-content.s-main-content-wide>.row {
    margin-left: -8px !important;
    margin-right: -8px !important;
  }

  .s-main-page .s-main-content.s-main-content-wide>.row>[class*="col-"] {
    padding-left: 8px !important;
    padding-right: 8px !important;
  }

  .s-main-page .s-main-content.updatefiturnew-force-wide {
    max-width: 1680px !important;
    width: 100% !important;
    margin-left: auto !important;
    margin-right: auto !important;
    padding-left: 14px !important;
    padding-right: 14px !important;
  }

  .s-main-page .s-main-content.updatefiturnew-force-wide > .row > .updatefiturnew-main-column {
    flex: 0 0 100% !important;
    max-width: 100% !important;
    width: 100% !important;
  }

  .s-main-page .s-main-content.updatefiturnew-force-wide .updatefiturnew-hidden-sidebar {
    display: none !important;
  }

  .updatefiturnew-table {
    width: 100%;
    border-collapse: collapse;
  }

  .updatefiturnew-table th,
  .updatefiturnew-table td {
    border: 1px solid rgba(148, 163, 184, 0.5);
    padding: 10px;
    color: var(--pmj-text);
    font-size: 15px;
    font-weight: 600;
    vertical-align: top;
    text-align: left;
  }

  .updatefiturnew-table th {
    background: linear-gradient(180deg, #e2e8f0 0%, #cbd5e1 100%);
    font-weight: 800;
    white-space: nowrap;
  }

  .updatefiturnew-table tbody tr:nth-child(even) {
    background: rgba(248, 250, 252, 0.8);
  }

  .updatefiturnew-row-overdue td {
    background: #fef2f2 !important;
    border-color: #fecaca !important;
    color: #7f1d1d;
  }

  .updatefiturnew-row-returned td {
    background: #e5e7eb !important;
    border-color: #cbd5e1 !important;
    color: #334155;
  }

  .updatefiturnew-row-onloan td {
    background: #fffbeb !important;
    border-color: #fcd34d !important;
    color: #78350f;
  }

  .updatefiturnew-row-extended td {
    background: #facc15 !important;
    border-color: #eab308 !important;
    color: #422006;
  }

  .updatefiturnew-form-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 12px;
  }

  .updatefiturnew-compact-row {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    align-items: center;
  }

  .updatefiturnew-label {
    color: var(--pmj-text);
    font-weight: 600;
    margin-bottom: 6px;
    display: block;
  }

  .updatefiturnew-password-field {
    position: relative;
  }

  .updatefiturnew-password-field .form-control {
    padding-right: 46px;
  }

  .updatefiturnew-password-toggle {
    position: absolute;
    right: 8px;
    top: 50%;
    transform: translateY(-50%);
    width: 32px;
    height: 32px;
    border: none;
    border-radius: 8px;
    background: transparent;
    color: #475569;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0;
  }

  .updatefiturnew-password-toggle:hover {
    background: rgba(148, 163, 184, 0.2);
    color: #0f172a;
  }

  .updatefiturnew-password-toggle:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .updatefiturnew-password-toggle .icon-eye-off {
    display: none;
  }

  .updatefiturnew-password-toggle.is-visible .icon-eye {
    display: none;
  }

  .updatefiturnew-password-toggle.is-visible .icon-eye-off {
    display: inline;
  }

  .updatefiturnew-badge {
    display: inline-block;
    padding: 5px 12px;
    border-radius: 999px;
    font-size: 13px;
    font-weight: 800;
    line-height: 1.2;
    color: #fff;
  }

  .updatefiturnew-badge.badge-success {
    background: #16a34a;
  }

  .updatefiturnew-badge.badge-danger {
    background: #dc2626;
  }

  .updatefiturnew-badge.badge-warning {
    background: #d97706;
  }

  .updatefiturnew-badge.badge-info {
    background: #0284c7;
  }

  .updatefiturnew-badge.badge-primary {
    background: #1d4ed8;
  }

  .updatefiturnew-badge.badge-secondary {
    background: #4b5563;
  }

  .updatefiturnew-muted {
    color: var(--pmj-muted);
    font-size: 13px;
  }

  .updatefiturnew-window-status {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    border-radius: 10px;
    padding: 10px 12px;
    border: 1px solid #bae6fd;
    background: #eff6ff;
    color: #0c4a6e;
    margin-bottom: 14px;
    font-size: 13px;
  }

  .updatefiturnew-window-status.is-closed {
    border-color: #fed7aa;
    background: #fff7ed;
    color: #9a3412;
  }

  .updatefiturnew-status-stack {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    align-items: center;
  }

  .updatefiturnew-status-note {
    font-size: 11px;
    color: var(--pmj-muted);
    margin-top: 4px;
    display: block;
  }

  .updatefiturnew-member-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 10px;
  }

  .updatefiturnew-member-grid .item {
    border: 1px solid rgba(148, 163, 184, 0.45);
    border-radius: 10px;
    padding: 10px;
    background: var(--pmj-surface-soft);
  }

  .updatefiturnew-member-grid .item strong {
    display: block;
    color: #334155;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: .04em;
  }

  .updatefiturnew-member-grid .item span {
    display: block;
    color: var(--pmj-text);
    margin-top: 4px;
    font-weight: 600;
  }

  .updatefiturnew-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .updatefiturnew-empty {
    border: 1px dashed #94a3b8;
    border-radius: 10px;
    padding: 12px;
    color: #334155;
    background: #f8fafc;
  }

  .updatefiturnew-quota-box {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 12px;
    border: 1px solid #fde68a;
    border-radius: 999px;
    background: #fffbeb;
    color: #92400e;
    font-weight: 700;
    font-size: 12px;
    margin-bottom: 12px;
  }

  .updatefiturnew-wrap .form-control,
  .updatefiturnew-wrap .btn {
    font-size: 14px;
  }

  .updatefiturnew-wrap input::placeholder {
    color: #64748b;
    opacity: 1;
  }

  @media (max-width: 640px) {
    .updatefiturnew-wrap {
      padding: 8px 4px 16px;
    }

    .s-main-page .s-main-content.s-main-content-wide {
      padding-left: 8px !important;
      padding-right: 8px !important;
    }

    .updatefiturnew-card {
      padding: 12px;
    }

    .updatefiturnew-table th,
    .updatefiturnew-table td {
      font-size: 12px;
      padding: 7px;
    }
  }
</style>

<div class="updatefiturnew-wrap s-main">
  <div class="updatefiturnew-card">
    <h2 class="updatefiturnew-title">Peminjaman Koleksi</h2>

    <form method="get" class="updatefiturnew-form-row">
      <input type="hidden" name="p" value="peminjaman">
      <div>
        <label class="updatefiturnew-label" for="modeSelect">Mode Layanan</label>
        <select id="modeSelect" name="mode" class="form-control" onchange="this.form.submit()">
          <option value="login" <?php echo $mode === 'login' ? ' selected' : ''; ?>>Login</option>
          <option value="status" <?php echo $mode === 'status' ? ' selected' : ''; ?>>Cek Status Peminjaman</option>
        </select>
      </div>
    </form>
  </div>

  <?php foreach (['error' => 'danger', 'success' => 'success'] as $messageType => $alertClass) { ?>
    <?php foreach ($messages[$messageType] as $message) { ?>
      <div class="alert alert-<?php echo $alertClass; ?>"><?php echo htmlspecialchars($message); ?></div>
    <?php } ?>
  <?php } ?>

  <?php if ($mode === 'login') { ?>
    <div class="updatefiturnew-window-status<?php echo $loanServiceOpen ? '' : ' is-closed'; ?>">
      <div><strong><?php echo $loanServiceOpen ? 'Jam Layanan Aktif' : 'Jam Layanan Tutup'; ?></strong></div>
      <div>
        Lokasi: <strong><?php echo htmlspecialchars($windowLocationLabel); ?></strong><br>
        <?php echo htmlspecialchars((string) ($visitWindow['reason'] ?? ($loanServiceOpen ? 'Layanan mengikuti jadwal visitor.' : 'Layanan updatefiturnew ditutup sementara.'))); ?>
      </div>
    </div>
  <?php } ?>

  <?php if ($mode === 'status') { ?>
    <div class="updatefiturnew-card">
      <h3 class="updatefiturnew-title">Cek Status Peminjaman Koleksi</h3>
      <form method="get" class="updatefiturnew-form-row">
        <input type="hidden" name="p" value="peminjaman">
        <input type="hidden" name="mode" value="status">
        <div>
          <label class="updatefiturnew-label" for="statusMemberId">Member ID</label>
          <input type="text" id="statusMemberId" name="status_member_id" class="form-control"
            value="<?php echo htmlspecialchars($statusMemberId); ?>" placeholder="Masukkan Member ID">
        </div>
        <div>
          <label class="updatefiturnew-label" for="statusListFilter">Filter Status</label>
          <select id="statusListFilter" name="status_list_filter" class="form-control">
            <?php foreach ($requestFilterOptions as $filterKey => $filterLabel) { ?>
              <option value="<?php echo htmlspecialchars($filterKey); ?>" <?php echo $statusListFilter === $filterKey ? ' selected' : ''; ?>>
                <?php echo htmlspecialchars($filterLabel); ?>
              </option>
            <?php } ?>
          </select>
        </div>
        <div>
          <label class="updatefiturnew-label" for="statusListMonth">Filter Bulan</label>
          <input type="month" id="statusListMonth" name="status_list_month" class="form-control"
            value="<?php echo htmlspecialchars($statusListMonth); ?>">
        </div>
        <div style="align-self:end;">
          <button type="submit" name="check_status" class="btn btn-primary">Cek Status</button>
        </div>
      </form>

      <?php if (count($statusRows) > 0) { ?>
        <?php if (count($filteredStatusRows) < 1) { ?>
          <div class="updatefiturnew-empty" style="margin-top:12px;">Data tidak ditemukan untuk filter yang dipilih.</div>
        <?php } else { ?>
        <div class="updatefiturnew-table-wrap" style="margin-top:12px;">
          <table class="updatefiturnew-table">
            <thead>
              <tr>
                <th>Kode Request</th>
                <th>Aksi</th>
                <th>Lokasi</th>
                <th>Status</th>
                <th>Waktu Request</th>
                <th>Catatan Admin</th>
              </tr>
            </thead>
              <tbody>
              <?php foreach ($filteredStatusRows as $row) {
                $requestItems = $statusItemMap[(int) ($row['request_id'] ?? 0)] ?? [];
                $relativeMeta = $buildRelativeMeta((string) ($row['requested_at'] ?? ''));
                $requestRowClass = $resolveUserRequestRowClass($row);
                ?>
                <tr class="<?php echo htmlspecialchars($requestRowClass); ?>">
                  <td><?php echo htmlspecialchars((string) $row['request_code']); ?></td>
                  <td><?php echo htmlspecialchars(updatefiturnewActionLabel((string) $row['action_type'])); ?></td>
                  <td><?php echo htmlspecialchars((string) ($row['visit_location'] ?: '-')); ?></td>
                  <td>
                    <div class="updatefiturnew-status-stack">
                      <span
                        class="updatefiturnew-badge badge-<?php echo htmlspecialchars(updatefiturnewBadgeClass((string) $row['status'])); ?>">
                        <?php echo htmlspecialchars(updatefiturnewStatusLabel((string) $row['status'])); ?>
                      </span>
                      <span class="updatefiturnew-badge badge-<?php echo htmlspecialchars((string) ($relativeMeta['badge'] ?? 'secondary')); ?>">
                        <?php echo htmlspecialchars((string) ($relativeMeta['label'] ?? 'Telah Lalu')); ?>
                      </span>
                    </div>
                  </td>
                  <td><?php echo htmlspecialchars((string) $row['requested_at']); ?></td>
                  <td><?php echo htmlspecialchars((string) ($row['admin_note'] ?: $row['process_result'] ?: '-')); ?></td>
                </tr>
                <?php if (count($requestItems) > 0) { ?>
                  <tr>
                    <td colspan="6" style="padding:4px 8px 12px;">
                      <table class="updatefiturnew-table" style="margin:0; font-size:13px;">
                        <thead>
                          <tr>
                            <th>Item Code</th>
                            <th>Judul</th>
                            <th>Lokasi Item</th>
                            <th>Status Item</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($requestItems as $ri) { ?>
                            <tr>
                              <td><?php echo htmlspecialchars((string) ($ri['item_code'] ?: '-')); ?></td>
                              <td><?php echo htmlspecialchars((string) $ri['title']); ?></td>
                              <td><?php echo htmlspecialchars((string) $ri['item_location']); ?></td>
                              <td>
                                <span
                                  class="updatefiturnew-badge badge-<?php echo htmlspecialchars(updatefiturnewBadgeClass((string) $ri['item_status'])); ?>">
                                  <?php echo htmlspecialchars(updatefiturnewStatusLabel((string) $ri['item_status'])); ?>
                                </span>
                                <?php if (trim((string) ($ri['process_message'] ?? '')) !== '') { ?>
                                  <br><small><?php echo htmlspecialchars((string) $ri['process_message']); ?></small>
                                <?php } ?>
                              </td>
                            </tr>
                          <?php } ?>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                <?php } ?>
              <?php } ?>
            </tbody>
          </table>
        </div>
        <?php } ?>
      <?php } ?>
    </div>
  <?php } else { ?>

    <?php if (!$auth) { ?>
      <div class="updatefiturnew-card">
        <h3 class="updatefiturnew-title">Login Member</h3>
        <form method="post" class="updatefiturnew-form-row">
          <input type="hidden" name="mode" value="login">
          <div>
            <label class="updatefiturnew-label" for="visitLocation">Lokasi Kunjungan</label>
            <select id="visitLocation" name="visit_location" class="form-control" required>
              <option value="">Pilih Lokasi</option>
              <?php foreach ($locations as $location) { ?>
                <option value="<?php echo htmlspecialchars($location); ?>" <?php echo $selectedLocation === $location ? ' selected' : ''; ?>>
                  <?php echo htmlspecialchars($location); ?>
                </option>
              <?php } ?>
            </select>
          </div>
          <div>
            <label class="updatefiturnew-label" for="memberEmail">Email / ID Member</label>
            <input type="text" id="memberEmail" name="member_login" class="form-control" placeholder="email@contoh.com atau ID member"
              value="<?php echo htmlspecialchars($loginIdentifierInput); ?>" required<?php echo $loginInputEnabled ? '' : ' disabled'; ?>>
          </div>
          <div>
            <label class="updatefiturnew-label" for="memberPassword">Password (bisa ID Member)</label>
            <div class="updatefiturnew-password-field">
              <input type="password" id="memberPassword" name="member_password" class="form-control" required<?php echo $loginInputEnabled ? '' : ' disabled'; ?>>
              <button type="button" id="toggleMemberPassword" class="updatefiturnew-password-toggle" aria-label="Tampilkan password" title="Lihat password"<?php echo $loginInputEnabled ? '' : ' disabled'; ?>>
                <span class="icon-eye" aria-hidden="true">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 12C2.8 7.8 6.8 5 12 5C17.2 5 21.2 7.8 23 12C21.2 16.2 17.2 19 12 19C6.8 19 2.8 16.2 1 12Z" stroke="currentColor" stroke-width="1.8"/>
                    <circle cx="12" cy="12" r="3.2" stroke="currentColor" stroke-width="1.8"/>
                  </svg>
                </span>
                <span class="icon-eye-off" aria-hidden="true">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 3L22 21" stroke="currentColor" stroke-width="1.8"/>
                    <path d="M10.58 10.58C10.22 10.94 10 11.44 10 12C10 13.1 10.9 14 12 14C12.56 14 13.06 13.78 13.42 13.42" stroke="currentColor" stroke-width="1.8"/>
                    <path d="M6.7 6.7C4.32 8.06 2.52 9.95 1.4 12C3.2 16.2 7.2 19 12.4 19C14.32 19 16.05 18.62 17.54 17.92" stroke="currentColor" stroke-width="1.8"/>
                    <path d="M20.28 14.96C21.35 14.11 22.22 13.1 22.9 12C21.1 7.8 17.1 5 11.9 5C11.14 5 10.41 5.06 9.71 5.19" stroke="currentColor" stroke-width="1.8"/>
                  </svg>
                </span>
              </button>
            </div>
          </div>
          <div style="align-self:end;">
            <button id="loginSubmitBtn" type="submit" name="login_updatefiturnew" class="btn btn-primary"<?php echo $loginBySelectedLocationOpen ? '' : ' disabled'; ?>>Login</button>
          </div>
          <div style="grid-column:1 / -1;">
            <small id="loginServiceNotice" class="updatefiturnew-status-note"<?php echo $loginBySelectedLocationOpen ? ' style="display:none;"' : ''; ?>>
              <?php
              $loginNotice = trim($loginBySelectedLocationReason);
              if ($loginNotice === '') {
                $loginNotice = 'Perpustakaan sedang tutup untuk lokasi ini.';
              }
              echo 'Login nonaktif: ' . htmlspecialchars($loginNotice);
              ?>
            </small>
          </div>
        </form>
      </div>
    <?php } else { ?>
      <div class="updatefiturnew-card">
        <div class="updatefiturnew-compact-row" style="justify-content:space-between; margin-bottom:12px;">
          <h3 class="updatefiturnew-title" style="margin:0;">Dashboard Request Peminjaman</h3>
          <form method="post" style="margin:0;">
            <input type="hidden" name="mode" value="login">
            <button type="submit" name="logout_updatefiturnew" class="btn btn-outline-secondary">Logout</button>
          </form>
        </div>

        <div class="updatefiturnew-member-grid">
          <div class="item"><strong>Member
              Name</strong><span><?php echo htmlspecialchars((string) ($authMember['member_name'] ?? '-')); ?></span></div>
          <div class="item"><strong>Member
              ID</strong><span><?php echo htmlspecialchars((string) $auth['member_id']); ?></span></div>
          <div class="item"><strong>Member
              Email</strong><span><?php echo htmlspecialchars((string) ($authMember['member_email'] ?? '-')); ?></span></div>
          <div class="item"><strong>Member
              Type</strong><span><?php echo htmlspecialchars((string) ($authMember['member_type_name'] ?? '-')); ?></span></div>
          <div class="item"><strong>Register
              Date</strong><span><?php echo htmlspecialchars((string) ($authMember['register_date'] ?? '-')); ?></span></div>
          <div class="item"><strong>Expiry
              Date</strong><span><?php echo htmlspecialchars((string) ($authMember['expire_date'] ?? '-')); ?></span></div>
        </div>

        <form method="post" class="updatefiturnew-form-row" style="margin-top:12px;">
          <input type="hidden" name="mode" value="login">
          <div>
            <label class="updatefiturnew-label" for="visitLocationUpdate">Lokasi Peminjaman</label>
            <select id="visitLocationUpdate" name="visit_location" class="form-control">
              <?php foreach ($locations as $location) { ?>
                <option value="<?php echo htmlspecialchars($location); ?>" <?php echo $selectedLocation === $location ? ' selected' : ''; ?>><?php echo htmlspecialchars($location); ?></option>
              <?php } ?>
            </select>
          </div>
          <div style="align-self:end;">
            <button type="submit" name="update_location" class="btn btn-default">Simpan Lokasi</button>
          </div>
        </form>
      </div>

      <div class="updatefiturnew-card">
        <h3 class="updatefiturnew-title">Insert Item Code / Barcode</h3>
        <div class="updatefiturnew-quota-box">
          Kuota pinjam hari ini: <?php echo (int) ($dailyLoanUsage['used'] ?? 0); ?> / <?php echo (int) ($dailyLoanUsage['limit'] ?? $dailyLimitValue); ?>
          (sisa <?php echo (int) ($dailyLoanUsage['remaining'] ?? 0); ?>)
        </div>
        <form method="post" class="updatefiturnew-form-row">
          <input type="hidden" name="mode" value="login">
          <div>
            <label class="updatefiturnew-label" for="itemCodeInput">Item Code / Barcode</label>
            <input type="text" id="itemCodeInput" name="item_code" class="form-control" placeholder="Masukkan barcode item">
          </div>
          <div style="align-self:end;" class="updatefiturnew-actions">
            <button type="submit" name="add_item_code" class="btn btn-primary"<?php echo $loanServiceOpen ? '' : ' disabled'; ?>>Tambah</button>
            <button type="submit" name="clear_cart" class="btn btn-danger">Kosongkan</button>
          </div>
        </form>
        <?php if (!$loanServiceOpen) { ?>
          <small class="updatefiturnew-status-note">Aksi pinjam/nonaktif: <?php echo htmlspecialchars((string) ($visitWindow['reason'] ?? 'Mengikuti jadwal visitor.')); ?></small>
        <?php } ?>

        <?php if (count($cart) > 0) { ?>
          <div class="updatefiturnew-table-wrap" style="margin-top: 12px;">
            <table class="updatefiturnew-table">
              <thead>
                <tr>
                  <th>Item Code</th>
                  <th>Judul</th>
                  <th>Lokasi Item</th>
                  <th>Status Saat Ini</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($cart as $cartRow) {
                  // Use batch-loaded item snapshot to avoid N+1 queries.
                  $liveItem = $cartLiveItemMap[(string) ($cartRow['item_code'] ?? '')] ?? null;
                  $liveOnLoan = $liveItem ? (int) ($liveItem['on_loan'] ?? 0) : 0;
                  $liveLocation = $liveItem ? (string) ($liveItem['location_name'] ?? '-') : '-';
                  $liveNoLoan = $liveItem ? (int) ($liveItem['no_loan'] ?? 0) : 0;
                  ?>
                  <tr>
                    <td><?php echo htmlspecialchars((string) $cartRow['item_code']); ?></td>
                    <td><?php echo htmlspecialchars((string) $cartRow['title']); ?></td>
                    <td><?php echo htmlspecialchars($liveLocation); ?></td>
                    <td><?php
                    if ($liveNoLoan > 0) {
                      echo '<span class="updatefiturnew-badge badge-danger">Tidak Boleh Dipinjam</span>';
                    } elseif ($liveOnLoan > 0) {
                      echo '<span class="updatefiturnew-badge badge-warning">Sedang Dipinjam</span>';
                    } else {
                      echo '<span class="updatefiturnew-badge badge-success">Tersedia</span>';
                    }
                    ?></td>
                    <td>
                      <form method="post" style="margin:0;">
                        <input type="hidden" name="mode" value="login">
                        <input type="hidden" name="remove_code"
                          value="<?php echo htmlspecialchars((string) $cartRow['item_code']); ?>">
                        <button type="submit" name="remove_item_code" class="btn btn-sm btn-danger">Hapus</button>
                      </form>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>

          <form method="post" style="margin-top:12px;">
            <input type="hidden" name="mode" value="login">
            <button type="submit" name="submit_loan_request" class="btn btn-success"<?php echo $loanServiceOpen ? '' : ' disabled'; ?>>Selesaikan Transaksi (ESC)</button>
          </form>
        <?php } else { ?>
          <div class="updatefiturnew-empty" style="margin-top:12px;">Belum ada item di daftar request pinjam.</div>
        <?php } ?>
      </div>

      <div class="updatefiturnew-card">
        <h3 class="updatefiturnew-title">Request Pengembalian &amp; Perpanjangan Buku</h3>
        <small class="updatefiturnew-status-note">Maksimal perpanjangan dari admin: <?php echo (int) $maxExtendLimitValue; ?>x per loan ID.</small>

        <?php if (count($activeLoans) < 1) { ?>
          <div class="updatefiturnew-empty">Tidak ada pinjaman aktif untuk member ini.</div>
        <?php } else { ?>
          <div class="updatefiturnew-table-wrap">
            <table class="updatefiturnew-table">
              <thead>
                <tr>
                  <th>Loan ID</th>
                  <th>Item Code</th>
                  <th>Judul</th>
                  <th>Lokasi Item</th>
                  <th>Loan Date</th>
                  <th>Due Date</th>
                  <th>Status</th>
                  <th style="min-width:200px;">Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($activeLoans as $loan) {
                  $loanId = (int) $loan['loan_id'];
                  $loanMeta = updatefiturnewGetLoanStatusMeta($loan);
                  $pRow = $pendingRequestMapByLoan[$loanId] ?? null;
                  $pendingActionType = strtolower(trim((string) ($pRow['action_type'] ?? '')));
                  $loanRowClass = (string) ($loanMeta['row_class'] ?? '');
                  if (in_array($pendingActionType, ['extend', 'renew', 'renewal'], true)) {
                    $loanRowClass = 'updatefiturnew-row-extended';
                  } elseif ($pendingActionType === 'return') {
                    $loanRowClass = 'updatefiturnew-row-returned';
                  }
                  $recencyBadge = match ((string) ($loanMeta['recency_key'] ?? 'past')) {
                    'today' => 'primary',
                    'yesterday' => 'warning',
                    default => 'secondary'
                  };
                  ?>
                  <tr class="<?php echo htmlspecialchars($loanRowClass); ?>">
                    <td><?php echo $loanId; ?></td>
                    <td><?php echo htmlspecialchars((string) $loan['item_code']); ?></td>
                    <td><?php echo htmlspecialchars((string) $loan['title']); ?></td>
                    <td><?php echo htmlspecialchars((string) ($loan['item_location'] ?? '-')); ?></td>
                    <td><?php echo htmlspecialchars((string) $loan['loan_date']); ?></td>
                    <td><?php echo htmlspecialchars((string) $loan['due_date']); ?></td>
                    <td>
                      <div class="updatefiturnew-status-stack">
                        <span class="updatefiturnew-badge badge-<?php echo htmlspecialchars($recencyBadge); ?>">
                          <?php echo htmlspecialchars((string) ($loanMeta['recency_label'] ?? 'Telah Lalu')); ?>
                        </span>
                        <span
                          class="updatefiturnew-badge badge-<?php echo htmlspecialchars((string) ($loanMeta['state_badge'] ?? 'info')); ?>">
                          <?php echo htmlspecialchars((string) ($loanMeta['state_label'] ?? 'Aktif')); ?>
                        </span>
                      </div>
                      <?php if ((int) ($loan['renewed'] ?? 0) > 0) { ?>
                        <small class="updatefiturnew-status-note">Perpanjangan: <?php echo (int) $loan['renewed']; ?>x</small>
                      <?php } ?>
                    </td>
                    <td>
                      <?php
                      $hasPendingReq = is_array($pRow);
                      $extendMeta = $loanExtendMeta[$loanId] ?? [
                        'allowed' => true,
                        'message' => '',
                        'renewed' => (int) ($loan['renewed'] ?? 0),
                        'max' => (int) $maxExtendLimitValue
                      ];
                      if ($hasPendingReq) {
                        ?>
                        <span class="updatefiturnew-badge badge-warning" style="font-size:11px;">
                          ⏳ Menunggu Approval
                          (<?php echo htmlspecialchars(updatefiturnewActionLabel((string) ($pRow['action_type'] ?? ''))); ?>)
                        </span>
                      <?php } else { ?>
                        <div style="display:flex; gap:6px; flex-wrap:wrap;">
                          <form method="post" style="margin:0;">
                            <input type="hidden" name="mode" value="login">
                            <input type="hidden" name="loan_ids_return[]" value="<?php echo $loanId; ?>">
                            <button type="submit" name="submit_return_request" class="btn btn-sm btn-warning"
                              <?php echo $loanServiceOpen ? '' : ' disabled'; ?>
                              style="font-size:12px; padding:4px 12px; font-weight:600;"
                              onclick="return confirm('Request kembali item <?php echo htmlspecialchars((string) $loan['item_code']); ?>?');">
                              📦 Kembali
                            </button>
                          </form>
                          <form method="post" style="margin:0;">
                            <input type="hidden" name="mode" value="login">
                            <input type="hidden" name="loan_ids_extend[]" value="<?php echo $loanId; ?>">
                            <button type="submit" name="submit_extend_request" class="btn btn-sm btn-info"
                              <?php echo ($loanServiceOpen && !empty($extendMeta['allowed'])) ? '' : ' disabled'; ?>
                              style="font-size:12px; padding:4px 12px; font-weight:600;"
                              onclick="return confirm('Request perpanjang untuk Loan ID #<?php echo $loanId; ?> (<?php echo htmlspecialchars((string) ($loan['item_code'] ?? '')); ?>)?');">
                              🔁 Perpanjang
                            </button>
                          </form>
                        </div>
                        <?php if (empty($extendMeta['allowed'])) { ?>
                          <small class="updatefiturnew-status-note" style="display:block; margin-top:4px;">
                            <?php echo htmlspecialchars((string) ($extendMeta['message'] ?? 'Perpanjangan tidak diizinkan.')); ?>
                          </small>
                        <?php } ?>
                      <?php } ?>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        <?php } ?>
      </div>

      <div class="updatefiturnew-card">
        <h3 class="updatefiturnew-title">Riwayat Status Request</h3>
        <?php if (count($memberRequests) < 1) { ?>
          <div class="updatefiturnew-empty">Belum ada riwayat request updatefiturnew.</div>
        <?php } else { ?>
          <form method="get" class="updatefiturnew-form-row" style="margin-bottom:12px;">
            <input type="hidden" name="p" value="peminjaman">
            <input type="hidden" name="mode" value="login">
            <div>
              <label class="updatefiturnew-label" for="memberListFilter">Filter Riwayat</label>
              <select id="memberListFilter" name="member_list_filter" class="form-control">
                <?php foreach ($requestFilterOptions as $filterKey => $filterLabel) { ?>
                  <option value="<?php echo htmlspecialchars($filterKey); ?>" <?php echo $memberListFilter === $filterKey ? ' selected' : ''; ?>>
                    <?php echo htmlspecialchars($filterLabel); ?>
                  </option>
                <?php } ?>
              </select>
            </div>
            <div>
              <label class="updatefiturnew-label" for="memberListMonth">Filter Bulan</label>
              <input type="month" id="memberListMonth" name="member_list_month" class="form-control"
                value="<?php echo htmlspecialchars($memberListMonth); ?>">
            </div>
            <div style="align-self:end;" class="updatefiturnew-actions">
              <button type="submit" class="btn btn-primary">Terapkan Filter</button>
              <a href="<?php echo htmlspecialchars($buildPeminjamanUrl([
                'mode' => 'login',
                'member_list_filter' => $memberListFilter,
                'member_list_month' => $memberListMonth
              ])); ?>" class="btn btn-info">Refresh</a>
            </div>
          </form>

          <?php if (count($filteredMemberRequests) < 1) { ?>
            <div class="updatefiturnew-empty" style="margin-bottom:12px;">Data riwayat tidak ditemukan untuk filter yang dipilih.</div>
          <?php } else { ?>
          <div class="updatefiturnew-table-wrap">
            <table class="updatefiturnew-table">
              <thead>
                <tr>
                  <th>Kode Request</th>
                  <th>Aksi</th>
                  <th>Status</th>
                  <th>Lokasi</th>
                  <th>Item</th>
                  <th>Waktu Request</th>
                  <th>Catatan</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($filteredMemberRequests as $row) {
                  $relativeMeta = $buildRelativeMeta((string) ($row['requested_at'] ?? ''));
                  $requestRowClass = $resolveUserRequestRowClass($row);
                  ?>
                  <tr class="<?php echo htmlspecialchars($requestRowClass); ?>">
                    <td><?php echo htmlspecialchars((string) $row['request_code']); ?></td>
                    <td><?php echo htmlspecialchars(updatefiturnewActionLabel((string) $row['action_type'])); ?></td>
                    <td>
                      <div class="updatefiturnew-status-stack">
                        <span
                          class="updatefiturnew-badge badge-<?php echo htmlspecialchars(updatefiturnewBadgeClass((string) $row['status'])); ?>">
                          <?php echo htmlspecialchars(updatefiturnewStatusLabel((string) $row['status'])); ?>
                        </span>
                        <span class="updatefiturnew-badge badge-<?php echo htmlspecialchars((string) ($relativeMeta['badge'] ?? 'secondary')); ?>">
                          <?php echo htmlspecialchars((string) ($relativeMeta['label'] ?? 'Telah Lalu')); ?>
                        </span>
                      </div>
                    </td>
                    <td><?php echo htmlspecialchars((string) ($row['visit_location'] ?: '-')); ?></td>
                    <td><?php echo htmlspecialchars((string) ($row['item_list'] ?: '-')); ?></td>
                    <td><?php echo htmlspecialchars((string) $row['requested_at']); ?></td>
                    <td><?php echo htmlspecialchars((string) ($row['admin_note'] ?: $row['process_result'] ?: '-')); ?></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <?php } ?>
        <?php } ?>
      </div>

    <?php } ?>
  <?php } ?>
</div>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    var wrap = document.querySelector('.updatefiturnew-wrap');
    if (!wrap) return;

    var mainContent = wrap.closest('.s-main-content');
    if (mainContent) {
      mainContent.classList.add('s-main-content-wide', 'container-fluid', 'updatefiturnew-force-wide');
      mainContent.classList.remove('container');
    }

    var mainColumn = wrap.closest('.row > [class*="col-"]');
    if (mainColumn) {
      mainColumn.classList.add('updatefiturnew-main-column', 'col-lg-12', 'col-md-12', 'col-sm-12', 'col-xs-12');
      mainColumn.classList.remove('col-lg-8', 'col-lg-9', 'col-md-8', 'col-md-9', 'col-sm-8', 'col-sm-9');
    }

    var mainRow = mainColumn ? mainColumn.parentElement : null;
    if (!mainRow) return;

    Array.prototype.forEach.call(mainRow.children, function (child) {
      if (child === mainColumn) return;
      if (typeof child.className !== 'string') return;
      if (child.className.indexOf('col-') === -1) return;
      child.classList.add('updatefiturnew-hidden-sidebar');
    });
  });
</script>
<?php if (!$auth) { ?>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      var locationMap = <?php echo $locationServiceMapJs ?: '{}'; ?>;
      var allLocationsClosed = <?php echo $allLocationsClosedJs; ?>;
      var locationClosedText = <?php echo $loginLocationClosedText; ?>;
      var chooseLocationText = <?php echo $loginChooseLocationText; ?>;
      var allClosedText = <?php echo $loginAllClosedText; ?>;

      var modeSelect = document.getElementById('modeSelect');
      var visitLocation = document.getElementById('visitLocation');
      var memberEmail = document.getElementById('memberEmail');
      var memberPassword = document.getElementById('memberPassword');
      var toggleMemberPassword = document.getElementById('toggleMemberPassword');
      var loginSubmitBtn = document.getElementById('loginSubmitBtn');
      var loginServiceNotice = document.getElementById('loginServiceNotice');

      if (toggleMemberPassword && memberPassword) {
        toggleMemberPassword.addEventListener('click', function () {
          if (toggleMemberPassword.disabled || memberPassword.disabled) return;
          var isVisible = memberPassword.type === 'text';
          memberPassword.type = isVisible ? 'password' : 'text';
          toggleMemberPassword.classList.toggle('is-visible', !isVisible);
          toggleMemberPassword.setAttribute('aria-label', isVisible ? 'Tampilkan password' : 'Sembunyikan password');
          toggleMemberPassword.setAttribute('title', isVisible ? 'Lihat password' : 'Sembunyikan password');
        });
      }

      function syncLoginStateByLocation() {
        if (!visitLocation || !loginSubmitBtn) {
          return;
        }
        var selected = visitLocation.value || '';
        var meta = locationMap[selected] || null;
        var isLocationChosen = selected !== '';
        var isOpen = !!(meta && meta.allowed);
        var reason = meta && meta.reason ? String(meta.reason) : '';

        if (allLocationsClosed) {
          if (memberEmail) memberEmail.disabled = true;
          if (memberPassword) memberPassword.disabled = true;
          if (toggleMemberPassword) toggleMemberPassword.disabled = true;
          loginSubmitBtn.disabled = true;
          if (loginServiceNotice) {
            loginServiceNotice.style.display = '';
            loginServiceNotice.textContent = allClosedText;
          }
          return;
        }

        if (!isLocationChosen) {
          if (memberEmail) memberEmail.disabled = true;
          if (memberPassword) memberPassword.disabled = true;
          if (toggleMemberPassword) toggleMemberPassword.disabled = true;
          loginSubmitBtn.disabled = true;
          if (loginServiceNotice) {
            loginServiceNotice.style.display = '';
            loginServiceNotice.textContent = chooseLocationText;
          }
          return;
        }

        if (memberEmail) memberEmail.disabled = !isOpen;
        if (memberPassword) memberPassword.disabled = !isOpen;
        if (toggleMemberPassword) toggleMemberPassword.disabled = !isOpen;
        loginSubmitBtn.disabled = !isOpen;
        if (loginServiceNotice) {
          if (isOpen) {
            loginServiceNotice.style.display = 'none';
            loginServiceNotice.textContent = '';
          } else {
            loginServiceNotice.style.display = '';
            loginServiceNotice.textContent = reason !== '' ? ('Login nonaktif: ' + reason) : locationClosedText;
          }
        }
      }

      if (visitLocation) {
        visitLocation.addEventListener('change', syncLoginStateByLocation);
        syncLoginStateByLocation();
      }
    });
  </script>
<?php } ?>
