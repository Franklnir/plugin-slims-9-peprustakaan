<?php

defined('INDEX_AUTH') or die('Direct access not allowed!');

require_once __DIR__ . '/lib.php';

require LIB . 'ip_based_access.inc.php';
do_checkIP('smc');
do_checkIP('smc-reporting');

if (session_status() !== PHP_SESSION_ACTIVE) {
    require SB . 'admin/default/session.inc.php';
}
require SB . 'admin/default/session_check.inc.php';

updatefiturnewEnsureSchema($dbs);

$canRead = utility::havePrivilege('reporting', 'r');
if (!$canRead) {
    die('<div class="errorBox">' . __('You don\'t have enough privileges to access this area!') . '</div>');
}

$currentMenuId = trim((string) ($_GET['id'] ?? ''));
$baseUrl = 'plugin_container.php?mod=reporting' . ($currentMenuId !== '' ? '&id=' . urlencode($currentMenuId) : '');
$filterSessionKey = 'updatefiturnew_feedback_filter_state';
$todayDate = date('Y-m-d');

$isValidDate = static function (string $value): bool {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return false;
    }
    $dateObj = DateTime::createFromFormat('Y-m-d', $value);
    return $dateObj instanceof DateTime && $dateObj->format('Y-m-d') === $value;
};

$sanitizeFilterState = static function (array $source) use ($isValidDate): array {
    $feedbackType = strtolower(trim((string) ($source['feedback_type'] ?? 'all')));
    if (!in_array($feedbackType, ['all', 'kritik', 'saran'], true)) {
        $feedbackType = 'all';
    }

    $visitLocation = trim((string) ($source['visit_location'] ?? 'all'));
    if ($visitLocation === '' || strtolower($visitLocation) === 'all') {
        $visitLocation = 'all';
    }
    if (function_exists('mb_substr')) {
        $visitLocation = mb_substr($visitLocation, 0, 120);
    } else {
        $visitLocation = substr($visitLocation, 0, 120);
    }

    $keyword = trim((string) ($source['keyword'] ?? ''));
    if (function_exists('mb_substr')) {
        $keyword = mb_substr($keyword, 0, 200);
    } else {
        $keyword = substr($keyword, 0, 200);
    }

    $dateFrom = trim((string) ($source['date_from'] ?? ''));
    $dateTo = trim((string) ($source['date_to'] ?? ''));
    if (!$isValidDate($dateFrom)) {
        $dateFrom = '';
    }
    if (!$isValidDate($dateTo)) {
        $dateTo = '';
    }
    if ($dateFrom !== '' && $dateTo !== '' && strtotime($dateFrom) > strtotime($dateTo)) {
        $tmpDate = $dateFrom;
        $dateFrom = $dateTo;
        $dateTo = $tmpDate;
    }

    $limit = (int) ($source['limit'] ?? 200);
    if ($limit < 20) {
        $limit = 20;
    }
    if ($limit > 500) {
        $limit = 500;
    }

    return [
        'feedback_type' => $feedbackType,
        'visit_location' => $visitLocation,
        'keyword' => $keyword,
        'date_from' => $dateFrom,
        'date_to' => $dateTo,
        'limit' => $limit
    ];
};

$defaultFilterState = $sanitizeFilterState([
    'date_from' => $todayDate,
    'date_to' => $todayDate
]);

$resetRequested = (string) ($_GET['filter_reset'] ?? '') === '1';
if ($resetRequested) {
    $_SESSION[$filterSessionKey] = $defaultFilterState;
    header('Location: ' . $baseUrl);
    exit;
}

$filterKeys = ['feedback_type', 'visit_location', 'keyword', 'date_from', 'date_to', 'limit'];
$hasIncomingFilter = (string) ($_GET['filter_apply'] ?? '') === '1';
if (!$hasIncomingFilter) {
    foreach ($filterKeys as $filterKey) {
        if (array_key_exists($filterKey, $_GET)) {
            $hasIncomingFilter = true;
            break;
        }
    }
}

if ($hasIncomingFilter) {
    $filterState = $sanitizeFilterState($_GET);
    $_SESSION[$filterSessionKey] = $filterState;
} elseif (isset($_SESSION[$filterSessionKey]) && is_array($_SESSION[$filterSessionKey])) {
    $filterState = $sanitizeFilterState($_SESSION[$filterSessionKey]);
} else {
    $filterState = $defaultFilterState;
    $_SESSION[$filterSessionKey] = $filterState;
}

$feedbackType = $filterState['feedback_type'];
$visitLocation = $filterState['visit_location'];
$keyword = $filterState['keyword'];
$dateFrom = $filterState['date_from'];
$dateTo = $filterState['date_to'];
$limit = (int) $filterState['limit'];

if (!$hasIncomingFilter && $dateFrom === '' && $dateTo === '') {
    $filterState['date_from'] = $todayDate;
    $filterState['date_to'] = $todayDate;
    $_SESSION[$filterSessionKey] = $filterState;
    $dateFrom = $todayDate;
    $dateTo = $todayDate;
}

$resolvedLocationExpr = "COALESCE(NULLIF(TRIM(vf.visit_location), ''), '-')";
$resolvedVisitorKindExpr = "CASE
    WHEN COALESCE(NULLIF(TRIM(vf.visitor_kind), ''), '') <> '' THEN TRIM(vf.visitor_kind)
    WHEN COALESCE(NULLIF(TRIM(vf.member_id), ''), '') <> '' THEN 'anggota'
    ELSE 'non_anggota'
END";
$resolvedFeedbackDateExpr = "COALESCE(vf.created_at, vf.updated_at, vf.checkin_at)";

$locationOptions = ['all' => 'Semua Lokasi'];
$appendLocationOption = static function (array &$options, string $label): void {
    $normalized = trim(strip_tags($label));
    if ($normalized === '' || $normalized === '-') {
        return;
    }
    $options[$normalized] = $normalized;
};

// 1) Lokasi dari setting (lokasimaps) -> sumber master lokasi.
foreach (updatefiturnewGetLocationOptions($dbs, $sysconf) as $masterLocation) {
    $appendLocationOption($locationOptions, (string) $masterLocation);
}

// 2) Lokasi dari visitor_count.visit_location.
$locationQuerySql = "SELECT DISTINCT TRIM(vc.visit_location) AS location_label
    FROM visitor_count AS vc
    WHERE vc.visit_location IS NOT NULL AND TRIM(vc.visit_location) <> ''
    ORDER BY location_label ASC";
if ($locationQuery = $dbs->query($locationQuerySql)) {
    while ($locationRow = $locationQuery->fetch_assoc()) {
        $appendLocationOption($locationOptions, (string) ($locationRow['location_label'] ?? ''));
    }
    $locationQuery->free_result();
}

// 3) Lokasi dari histori feedback.
$feedbackLocationQuerySql = "SELECT DISTINCT TRIM(vf.visit_location) AS location_label
    FROM updatefiturnew_visitor_feedback AS vf
    WHERE vf.visit_location IS NOT NULL AND TRIM(vf.visit_location) <> ''
    ORDER BY location_label ASC";
if ($feedbackLocationQuery = $dbs->query($feedbackLocationQuerySql)) {
    while ($feedbackLocationRow = $feedbackLocationQuery->fetch_assoc()) {
        $appendLocationOption($locationOptions, (string) ($feedbackLocationRow['location_label'] ?? ''));
    }
    $feedbackLocationQuery->free_result();
}

if (count($locationOptions) < 2) {
    $fallbackLocation = trim(strip_tags((string) ($sysconf['library_name'] ?? 'Lokasi Utama')));
    if ($fallbackLocation !== '') {
        $appendLocationOption($locationOptions, $fallbackLocation);
    }
}

if ($visitLocation !== 'all' && !isset($locationOptions[$visitLocation])) {
    $locationOptions[$visitLocation] = $visitLocation;
}

$filterSql = [];
if ($feedbackType !== 'all') {
    $filterSql[] = "vf.feedback_type = '" . $dbs->escape_string($feedbackType) . "'";
}
if ($visitLocation !== 'all') {
    $filterSql[] = "{$resolvedLocationExpr} = '" . $dbs->escape_string($visitLocation) . "'";
}
if ($keyword !== '') {
    $keywordLike = '%' . $dbs->escape_string($keyword) . '%';
    $filterSql[] = "(vf.member_id LIKE '{$keywordLike}'
        OR vf.member_name LIKE '{$keywordLike}'
        OR vf.institution LIKE '{$keywordLike}'
        OR vf.member_type_name LIKE '{$keywordLike}'
        OR {$resolvedLocationExpr} LIKE '{$keywordLike}'
        OR vf.feedback_text LIKE '{$keywordLike}')";
}
if ($isValidDate($dateFrom)) {
    $filterSql[] = "DATE({$resolvedFeedbackDateExpr}) >= '" . $dbs->escape_string($dateFrom) . "'";
}
if ($isValidDate($dateTo)) {
    $filterSql[] = "DATE({$resolvedFeedbackDateExpr}) <= '" . $dbs->escape_string($dateTo) . "'";
}

$whereSql = count($filterSql) > 0 ? 'WHERE ' . implode(' AND ', $filterSql) : '';
$rows = [];
$sql = "SELECT vf.feedback_id, vf.member_id, vf.member_name, vf.institution, vf.member_type_name,
               vf.visitor_kind, vf.room_code, vf.visit_location, vf.feedback_type, vf.feedback_text, vf.created_at,
               {$resolvedFeedbackDateExpr} AS feedback_at,
               {$resolvedVisitorKindExpr} AS resolved_visitor_kind,
               {$resolvedLocationExpr} AS resolved_visit_location,
               '' AS room_name
        FROM updatefiturnew_visitor_feedback AS vf
        {$whereSql}
        ORDER BY vf.feedback_id DESC
        LIMIT {$limit}";

if ($query = $dbs->query($sql)) {
    while ($row = $query->fetch_assoc()) {
        $memberId = trim((string) ($row['member_id'] ?? ''));
        $memberName = trim((string) ($row['member_name'] ?? ''));
        $institution = trim((string) ($row['institution'] ?? ''));
        $memberTypeName = trim((string) ($row['member_type_name'] ?? ''));
        $visitorKindRow = trim((string) ($row['resolved_visitor_kind'] ?? 'non_anggota'));
        $visitLocation = trim((string) ($row['visit_location'] ?? ''));
        $roomCode = trim((string) ($row['room_code'] ?? ''));
        $resolvedVisitLocation = trim((string) ($row['resolved_visit_location'] ?? ''));
        $createdAt = trim((string) ($row['created_at'] ?? ''));
        $feedbackAt = trim((string) ($row['feedback_at'] ?? ''));
        if ($feedbackAt === '') {
            $feedbackAt = $createdAt;
        }
        $feedbackTypeRow = updatefiturnewNormalizeVisitorFeedbackType((string) ($row['feedback_type'] ?? 'saran'));
        $feedbackText = trim((string) ($row['feedback_text'] ?? ''));

        if ($visitLocation === '') {
            $visitLocation = $resolvedVisitLocation !== '' ? $resolvedVisitLocation : ($roomCode !== '' ? $roomCode : '-');
        }

        $memberLabel = $memberId !== ''
            ? $memberId
            : ($visitorKindRow === 'rombongan' ? 'ROMBONGAN' : 'NON-ANGGOTA');

        $typeOrInstitution = $memberId !== ''
            ? ($memberTypeName !== '' ? $memberTypeName : 'Anggota')
            : ($institution !== '' ? $institution : '-');

        $rows[] = [
            'visit_location' => $visitLocation,
            'member_label' => $memberLabel,
            'member_name' => $memberName !== '' ? $memberName : '-',
            'created_at' => $feedbackAt,
            'created_at_label' => ($feedbackAt !== '' && strtotime($feedbackAt) !== false)
                ? date('d M Y H:i:s', strtotime($feedbackAt))
                : '-',
            'visitor_kind' => $visitorKindRow,
            'type_or_institution' => $typeOrInstitution,
            'feedback_type' => $feedbackTypeRow,
            'feedback_text' => $feedbackText !== '' ? $feedbackText : '-'
        ];
    }
    $query->free_result();
}

$kritikRows = [];
$saranRows = [];
foreach ($rows as $feedbackRow) {
    if ((string) ($feedbackRow['feedback_type'] ?? '') === 'kritik') {
        $kritikRows[] = $feedbackRow;
        continue;
    }
    $saranRows[] = $feedbackRow;
}

$resetUrl = $baseUrl . '&filter_reset=1';
?>
<style>
  .updatefiturnew-feedback-admin {
    margin: 12px auto;
    max-width: 100%;
    width: 100%;
    box-sizing: border-box;
    padding: 0 12px;
  }

  .updatefiturnew-feedback-admin .mkp-card {
    background: #ffffff;
    border: 1px solid #dbe2ea;
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
    overflow: hidden;
  }

  .updatefiturnew-feedback-admin .mkp-card-head {
    padding: 12px 14px;
    border-bottom: 1px solid #dbe2ea;
    background: linear-gradient(180deg, #f8fafc 0%, #eef2f7 100%);
  }

  .updatefiturnew-feedback-admin .mkp-card-head h3 {
    margin: 0;
    font-size: 20px;
    color: #0f172a;
    font-weight: 800;
  }

  .updatefiturnew-feedback-admin .mkp-card-body {
    padding: 14px 16px 16px;
  }

  .updatefiturnew-feedback-admin .mkp-filter {
    display: grid;
    grid-template-columns: 140px 220px minmax(220px, 1fr) 160px 160px 120px auto;
    gap: 8px;
    align-items: end;
    margin-bottom: 12px;
  }

  .updatefiturnew-feedback-admin .mkp-filter label {
    display: block;
    font-size: 12px;
    font-weight: 800;
    color: #0f172a;
    margin-bottom: 4px;
  }

  .updatefiturnew-feedback-admin .mkp-filter select,
  .updatefiturnew-feedback-admin .mkp-filter input {
    width: 100%;
    height: 34px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 0 8px;
    font-size: 13px;
    font-weight: 600;
    color: #0f172a;
    box-sizing: border-box;
  }

  .updatefiturnew-feedback-admin .mkp-filter-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .updatefiturnew-feedback-admin .mkp-filter-actions .btn {
    height: 34px;
    border-radius: 6px;
    font-size: 13px;
    padding: 0 12px;
  }

  .updatefiturnew-feedback-admin .mkp-filter-note {
    margin: -4px 0 10px;
    font-size: 12px;
    color: #475569;
  }

  .updatefiturnew-feedback-admin .mkp-table-section {
    margin-top: 12px;
  }

  .updatefiturnew-feedback-admin .mkp-table-section .mkp-table-wrap {
    margin-left: 0;
    margin-right: 0;
  }

  .updatefiturnew-feedback-admin .mkp-table-section h4 {
    margin: 0 0 8px;
    font-size: 15px;
    color: #0f172a;
    font-weight: 800;
  }

  .updatefiturnew-feedback-admin .mkp-table-wrap {
    overflow-x: auto;
  }

  .updatefiturnew-feedback-admin .mkp-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    color: #0f172a;
  }

  .updatefiturnew-feedback-admin .mkp-table th,
  .updatefiturnew-feedback-admin .mkp-table td {
    border: 1px solid #dbe2ea;
    padding: 10px;
    vertical-align: top;
    text-align: left;
  }

  .updatefiturnew-feedback-admin .mkp-table td {
    font-weight: 600;
    color: #0f172a;
  }

  .updatefiturnew-feedback-admin .mkp-table th:last-child,
  .updatefiturnew-feedback-admin .mkp-table td:last-child {
    min-width: 420px;
    width: 45%;
  }

  .updatefiturnew-feedback-admin .mkp-table th {
    white-space: nowrap;
    font-weight: 800;
    color: #0f172a;
    background: #e2e8f0;
  }

  .updatefiturnew-feedback-admin .mkp-feedback-type {
    display: inline-flex;
    align-items: center;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
    padding: 3px 8px;
  }

  .updatefiturnew-feedback-admin .mkp-feedback-type.kritik {
    background: #dcfce7;
    color: #166534;
  }

  .updatefiturnew-feedback-admin .mkp-feedback-type.saran {
    background: #dbeafe;
    color: #1d4ed8;
  }

  .updatefiturnew-feedback-admin .mkp-feedback-text {
    margin-top: 8px;
    line-height: 1.6;
    white-space: pre-wrap;
    min-height: 76px;
    padding: 10px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    background: #f1f5f9;
    font-size: 14px;
    font-weight: 700;
    color: #0f172a;
  }

  .updatefiturnew-feedback-admin .mkp-empty {
    border: 1px dashed #94a3b8;
    border-radius: 8px;
    padding: 10px;
    color: #475569;
    background: #f8fafc;
  }

  @media (max-width: 1100px) {
    .updatefiturnew-feedback-admin .mkp-filter {
      grid-template-columns: repeat(2, minmax(180px, 1fr));
    }
  }

  @media (max-width: 640px) {
    .updatefiturnew-feedback-admin {
      padding: 0 8px;
    }

    .updatefiturnew-feedback-admin .mkp-filter {
      grid-template-columns: 1fr;
    }

    .updatefiturnew-feedback-admin .mkp-table th:last-child,
    .updatefiturnew-feedback-admin .mkp-table td:last-child {
      min-width: 280px;
    }

    .updatefiturnew-feedback-admin .mkp-feedback-text {
      min-height: 60px;
      font-size: 13px;
    }
  }
</style>

<div class="menuBox updatefiturnew-feedback-admin">
  <div class="mkp-card">
    <div class="mkp-card-head">
      <h3>Kritik Saran</h3>
    </div>
    <div class="mkp-card-body">
      <form method="get" action="plugin_container.php" class="mkp-filter">
        <input type="hidden" name="mod" value="reporting">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($currentMenuId); ?>">
        <input type="hidden" name="filter_apply" value="1">
        <div>
          <label for="feedbackType">Jenis</label>
          <select id="feedbackType" name="feedback_type">
            <option value="all"<?php echo $feedbackType === 'all' ? ' selected' : ''; ?>>Semua</option>
            <option value="kritik"<?php echo $feedbackType === 'kritik' ? ' selected' : ''; ?>>Kritik</option>
            <option value="saran"<?php echo $feedbackType === 'saran' ? ' selected' : ''; ?>>Saran</option>
          </select>
        </div>
        <div>
          <label for="visitLocation">Lokasi</label>
          <select id="visitLocation" name="visit_location">
            <?php foreach ($locationOptions as $locationValue => $locationLabel): ?>
              <option value="<?php echo htmlspecialchars($locationValue); ?>"<?php echo $visitLocation === $locationValue ? ' selected' : ''; ?>>
                <?php echo htmlspecialchars($locationLabel); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label for="feedbackKeyword">Cari</label>
          <input id="feedbackKeyword" type="text" name="keyword" value="<?php echo htmlspecialchars($keyword); ?>" placeholder="Member, nama, instansi, isi...">
        </div>
        <div>
          <label for="feedbackDateFrom">Dari</label>
          <input id="feedbackDateFrom" type="date" name="date_from" value="<?php echo htmlspecialchars($dateFrom); ?>">
        </div>
        <div>
          <label for="feedbackDateTo">Sampai</label>
          <input id="feedbackDateTo" type="date" name="date_to" value="<?php echo htmlspecialchars($dateTo); ?>">
        </div>
        <div>
          <label for="feedbackLimit">Limit</label>
          <select id="feedbackLimit" name="limit">
            <?php foreach ([100, 200, 300, 500] as $optLimit): ?>
              <option value="<?php echo $optLimit; ?>"<?php echo $limit === $optLimit ? ' selected' : ''; ?>><?php echo $optLimit; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mkp-filter-actions">
          <button type="submit" class="btn btn-primary">Filter</button>
          <a class="btn btn-default" href="<?php echo htmlspecialchars($resetUrl); ?>">Reset</a>
        </div>
      </form>
      <div class="mkp-filter-note">Filter terakhir tersimpan otomatis untuk sesi admin ini. Default tanggal: hari ini.</div>

      <?php if (count($rows) < 1): ?>
        <div class="mkp-empty">Belum ada data kritik/saran.</div>
      <?php else: ?>
        <?php if ($feedbackType !== 'saran'): ?>
        <div class="mkp-table-section">
          <h4>Tabel Kritik (<?php echo count($kritikRows); ?>)</h4>
          <?php if (count($kritikRows) < 1): ?>
            <div class="mkp-empty">Tidak ada data kritik untuk filter saat ini.</div>
          <?php else: ?>
            <div class="mkp-table-wrap">
              <table class="mkp-table">
                <thead>
                  <tr>
                    <th>Lokasi</th>
                    <th>Member</th>
                    <th>Nama</th>
                    <th>Tanggal Isi</th>
                    <th>Tipe Member / Instansi</th>
                    <th>Isi Kritik</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($kritikRows as $row): ?>
                    <tr>
                      <td><?php echo htmlspecialchars($row['visit_location']); ?></td>
                      <td><?php echo htmlspecialchars($row['member_label']); ?></td>
                      <td><?php echo htmlspecialchars($row['member_name']); ?></td>
                      <td><?php echo htmlspecialchars($row['created_at_label']); ?></td>
                      <td><?php echo htmlspecialchars($row['type_or_institution']); ?></td>
                      <td>
                        <span class="mkp-feedback-type kritik">Kritik</span>
                        <div class="mkp-feedback-text"><?php echo nl2br(htmlspecialchars($row['feedback_text'])); ?></div>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if ($feedbackType !== 'kritik'): ?>
        <div class="mkp-table-section">
          <h4>Tabel Saran (<?php echo count($saranRows); ?>)</h4>
          <?php if (count($saranRows) < 1): ?>
            <div class="mkp-empty">Tidak ada data saran untuk filter saat ini.</div>
          <?php else: ?>
            <div class="mkp-table-wrap">
              <table class="mkp-table">
                <thead>
                  <tr>
                    <th>Lokasi</th>
                    <th>Member</th>
                    <th>Nama</th>
                    <th>Tanggal Isi</th>
                    <th>Tipe Member / Instansi</th>
                    <th>Isi Saran</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($saranRows as $row): ?>
                    <tr>
                      <td><?php echo htmlspecialchars($row['visit_location']); ?></td>
                      <td><?php echo htmlspecialchars($row['member_label']); ?></td>
                      <td><?php echo htmlspecialchars($row['member_name']); ?></td>
                      <td><?php echo htmlspecialchars($row['created_at_label']); ?></td>
                      <td><?php echo htmlspecialchars($row['type_or_institution']); ?></td>
                      <td>
                        <span class="mkp-feedback-type saran">Saran</span>
                        <div class="mkp-feedback-text"><?php echo nl2br(htmlspecialchars($row['feedback_text'])); ?></div>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</div>
