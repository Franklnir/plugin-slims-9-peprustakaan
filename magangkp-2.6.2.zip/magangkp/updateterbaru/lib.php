<?php

if (!function_exists('updatefiturnewGetActiveLang')) {
    function updatefiturnewGetActiveLang(): string
    {
        global $sysconf;
        $lang = '';
        if (!empty($_GET['select_lang'])) {
            $lang = (string) $_GET['select_lang'];
        } elseif (!empty($_COOKIE['select_lang'])) {
            $lang = (string) $_COOKIE['select_lang'];
        } elseif (is_array($sysconf) && !empty($sysconf['default_lang'])) {
            $lang = (string) $sysconf['default_lang'];
        }
        $lang = strtolower(trim($lang));
        return $lang !== '' ? $lang : 'en_us';
    }
}

if (!function_exists('updatefiturnewGetTranslationCatalog')) {
    function updatefiturnewGetTranslationCatalog(): array
    {
        return [
            'menu_loan' => [
                'id' => 'Peminjaman',
                'en' => 'Loan Request'
            ],
            'menu_loan_desc' => [
                'id' => 'Login anggota untuk request pinjam/kembali/perpanjang koleksi dengan approval admin',
                'en' => 'Member login for borrow/return/renew requests with admin approval'
            ],
            'menu_approval' => [
                'id' => 'Approval Peminjaman',
                'en' => 'Loan Approval'
            ],
            'menu_approval_desc' => [
                'id' => 'Persetujuan transaksi peminjaman dari OPAC',
                'en' => 'Approval queue for loan transactions submitted from OPAC'
            ],
            'menu_feedback' => [
                'id' => 'Kritik Saran',
                'en' => 'Visitor Feedback'
            ],
            'menu_feedback_desc' => [
                'id' => 'Daftar kritik dan saran dari form visitor',
                'en' => 'List of feedback submitted from visitor form'
            ],
            'nav_home' => [
                'id' => 'Beranda',
                'en' => 'Home'
            ],
            'nav_visitor' => [
                'id' => 'Kunjungan',
                'en' => 'Visitor'
            ],
            'nav_information' => [
                'id' => 'Informasi',
                'en' => 'Information'
            ],
            'nav_news' => [
                'id' => 'Berita',
                'en' => 'News'
            ],
            'nav_location' => [
                'id' => 'Lokasi Perpustakaan',
                'en' => 'Library Location'
            ],
            'nav_member_area' => [
                'id' => 'Area Anggota',
                'en' => 'Member Area'
            ],
            'nav_librarian' => [
                'id' => 'Pustakawan',
                'en' => 'Librarian'
            ],
            'nav_help' => [
                'id' => 'Bantuan',
                'en' => 'Help'
            ],
            'nav_librarian_login' => [
                'id' => 'Login Pustakawan',
                'en' => 'Librarian Login'
            ],
            'nav_loan' => [
                'id' => 'Peminjaman',
                'en' => 'Loan Request'
            ]
        ];
    }
}

if (!function_exists('updatefiturnewTranslate')) {
    function updatefiturnewTranslate(string $key): string
    {
        $lang = updatefiturnewGetActiveLang();
        $isId = strpos($lang, 'id') === 0;

        $map = updatefiturnewGetTranslationCatalog();

        if (!isset($map[$key])) {
            return $key;
        }
        return $isId ? $map[$key]['id'] : $map[$key]['en'];
    }
}

if (!function_exists('updatefiturnewEnsureColumn')) {
    function updatefiturnewEnsureColumn(mysqli $dbs, string $table, string $column, string $definition): void
    {
        $tableEsc = $dbs->escape_string($table);
        $columnEsc = $dbs->escape_string($column);
        $query = $dbs->query("SHOW COLUMNS FROM `{$tableEsc}` LIKE '{$columnEsc}'");
        $exists = $query && $query->num_rows > 0;
        if ($query) {
            $query->free_result();
        }
        if (!$exists) {
            $dbs->query("ALTER TABLE `{$tableEsc}` ADD COLUMN {$definition}");
        }
    }
}

if (!function_exists('updatefiturnewEnsureIndex')) {
    function updatefiturnewEnsureIndex(mysqli $dbs, string $table, string $indexName, string $definition): void
    {
        $tableEsc = $dbs->escape_string($table);
        $indexEsc = $dbs->escape_string($indexName);
        $query = $dbs->query("SHOW INDEX FROM `{$tableEsc}` WHERE Key_name = '{$indexEsc}'");
        $exists = $query && $query->num_rows > 0;
        if ($query) {
            $query->free_result();
        }
        if (!$exists) {
            $dbs->query("ALTER TABLE `{$tableEsc}` ADD INDEX `{$indexEsc}` {$definition}");
        }
    }
}

if (!function_exists('updatefiturnewTableExists')) {
    function updatefiturnewTableExists(mysqli $dbs, string $table): bool
    {
        $tableEsc = $dbs->escape_string($table);
        $query = $dbs->query("SHOW TABLES LIKE '{$tableEsc}'");
        $exists = $query && $query->num_rows > 0;
        if ($query) {
            $query->free_result();
        }
        return $exists;
    }
}

if (!function_exists('updatefiturnewSyncLegacySettings')) {
    function updatefiturnewSyncLegacySettings(mysqli $dbs): void
    {
        $pairs = [
            [
                'legacy' => 'peminjaman_daily_loan_limit',
                'targets' => ['updatefiturnew_daily_loan_limit', 'updatefiturnew_daily_limit', 'ufn_daily_limit']
            ],
            [
                'legacy' => 'peminjaman_sameitem_limit',
                'targets' => ['updatefiturnew_sameitem_limit', 'updatefiturnew_same_item_daily_limit', 'ufn_sameitem_limit']
            ],
            [
                'legacy' => 'peminjaman_no_visitor',
                'targets' => ['updatefiturnew_no_visitor', 'updatefiturnew_allow_no_visit', 'ufn_no_visitor']
            ],
            [
                'legacy' => 'peminjaman_use_vschedule',
                'targets' => ['updatefiturnew_use_vschedule', 'updatefiturnew_use_visit_sched', 'ufn_use_vschedule']
            ]
        ];

        foreach ($pairs as $pair) {
            $legacyName = trim((string) ($pair['legacy'] ?? ''));
            $targets = is_array($pair['targets'] ?? null) ? $pair['targets'] : [];
            if ($legacyName === '' || count($targets) < 1) {
                continue;
            }

            $legacyValue = null;
            $legacyEsc = $dbs->escape_string($legacyName);
            if ($query = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='{$legacyEsc}' LIMIT 1")) {
                if ($row = $query->fetch_assoc()) {
                    $legacyValue = (string) ($row['setting_value'] ?? '');
                }
                $query->free_result();
            }

            if ($legacyValue === null) {
                continue;
            }

            $hasTargetValue = false;
            foreach ($targets as $targetName) {
                $targetEsc = $dbs->escape_string((string) $targetName);
                if ($query = $dbs->query("SELECT 1 FROM setting WHERE setting_name='{$targetEsc}' LIMIT 1")) {
                    if ($query->num_rows > 0) {
                        $hasTargetValue = true;
                    }
                    $query->free_result();
                }
                if ($hasTargetValue) {
                    break;
                }
            }

            if ($hasTargetValue) {
                continue;
            }

            updatefiturnewUpsertSettingAliasValue($dbs, $targets, $legacyValue);
        }
    }
}

if (!function_exists('updatefiturnewSyncLegacyPeminjamanData')) {
    function updatefiturnewSyncLegacyPeminjamanData(mysqli $dbs): void
    {
        static $syncedInRequest = false;
        if ($syncedInRequest) {
            return;
        }
        $syncedInRequest = true;

        $sessionKey = 'updatefiturnew_legacy_sync_checked_at';
        $nowTs = time();
        $syncInterval = 600; // 10 minutes
        if (session_status() === PHP_SESSION_ACTIVE) {
            $lastCheckedTs = isset($_SESSION[$sessionKey]) ? (int) $_SESSION[$sessionKey] : 0;
            if ($lastCheckedTs > 0 && ($nowTs - $lastCheckedTs) < $syncInterval) {
                return;
            }
        }

        if (!updatefiturnewTableExists($dbs, 'peminjaman_request') || !updatefiturnewTableExists($dbs, 'peminjaman_request_item')) {
            if (session_status() === PHP_SESSION_ACTIVE) {
                $_SESSION[$sessionKey] = $nowTs;
            }
            return;
        }

        updatefiturnewSyncLegacySettings($dbs);

        $dbs->query("INSERT INTO updatefiturnew_request
            (request_code, member_id, member_email, member_name, member_type_name, visit_location,
             action_type, status, request_note, admin_uid, admin_username, admin_note,
             process_result, requested_at, decided_at, processed_at, created_ip, updated_at)
            SELECT pr.request_code, pr.member_id, pr.member_email, pr.member_name, pr.member_type_name, pr.visit_location,
                   pr.action_type, pr.status, pr.request_note, pr.admin_uid, pr.admin_username, pr.admin_note,
                   pr.process_result, pr.requested_at, pr.decided_at, pr.processed_at, pr.created_ip, pr.updated_at
            FROM peminjaman_request AS pr
            LEFT JOIN updatefiturnew_request AS ur ON ur.request_code = pr.request_code
            WHERE ur.request_id IS NULL");

        $dbs->query("INSERT INTO updatefiturnew_request_item
            (request_id, item_code, loan_id, item_status, process_message, created_at, updated_at)
            SELECT ur.request_id, pri.item_code, pri.loan_id, pri.item_status, pri.process_message, pri.created_at, pri.updated_at
            FROM peminjaman_request_item AS pri
            INNER JOIN peminjaman_request AS pr ON pr.request_id = pri.request_id
            INNER JOIN updatefiturnew_request AS ur ON ur.request_code = pr.request_code
            LEFT JOIN updatefiturnew_request_item AS uri
              ON uri.request_id = ur.request_id
             AND COALESCE(uri.item_code, '') = COALESCE(pri.item_code, '')
             AND COALESCE(uri.loan_id, 0) = COALESCE(pri.loan_id, 0)
             AND COALESCE(uri.item_status, 'pending') = COALESCE(pri.item_status, 'pending')
             AND COALESCE(uri.process_message, '') = COALESCE(pri.process_message, '')
             AND COALESCE(uri.created_at, '1970-01-01 00:00:00') = COALESCE(pri.created_at, '1970-01-01 00:00:00')
             AND COALESCE(uri.updated_at, '1970-01-01 00:00:00') = COALESCE(pri.updated_at, '1970-01-01 00:00:00')
            WHERE uri.request_item_id IS NULL");

        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION[$sessionKey] = $nowTs;
        }
    }
}

if (!function_exists('updatefiturnewEnsureSchema')) {
    function updatefiturnewEnsureSchema(mysqli $dbs): void
    {
        static $schemaEnsuredInRequest = false;
        if ($schemaEnsuredInRequest) {
            return;
        }
        $schemaEnsuredInRequest = true;

        $sessionKey = 'updatefiturnew_schema_checked_at';
        $nowTs = time();
        $schemaCheckInterval = 3600; // 1 hour
        if (session_status() === PHP_SESSION_ACTIVE) {
            $lastCheckedTs = isset($_SESSION[$sessionKey]) ? (int) $_SESSION[$sessionKey] : 0;
            if ($lastCheckedTs > 0 && ($nowTs - $lastCheckedTs) < $schemaCheckInterval) {
                updatefiturnewSyncLegacyPeminjamanData($dbs);
                return;
            }
        }

        $dbs->query("CREATE TABLE IF NOT EXISTS `updatefiturnew_request` (
            `request_id` INT(11) NOT NULL AUTO_INCREMENT,
            `request_code` VARCHAR(40) NOT NULL,
            `member_id` VARCHAR(20) NOT NULL,
            `member_email` VARCHAR(120) DEFAULT NULL,
            `member_name` VARCHAR(120) DEFAULT NULL,
            `member_type_name` VARCHAR(80) DEFAULT NULL,
            `visit_location` VARCHAR(120) DEFAULT NULL,
            `action_type` VARCHAR(20) NOT NULL,
            `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
            `request_note` TEXT,
            `admin_uid` INT(11) DEFAULT NULL,
            `admin_username` VARCHAR(100) DEFAULT NULL,
            `admin_note` TEXT,
            `process_result` TEXT,
            `requested_at` DATETIME NOT NULL,
            `decided_at` DATETIME DEFAULT NULL,
            `processed_at` DATETIME DEFAULT NULL,
            `created_ip` VARCHAR(45) DEFAULT NULL,
            `updated_at` DATETIME DEFAULT NULL,
            PRIMARY KEY (`request_id`),
            UNIQUE KEY `request_code` (`request_code`),
            KEY `member_id` (`member_id`),
            KEY `member_email` (`member_email`),
            KEY `status` (`status`),
            KEY `action_type` (`action_type`),
            KEY `requested_at` (`requested_at`),
            KEY `visit_location` (`visit_location`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $dbs->query("CREATE TABLE IF NOT EXISTS `updatefiturnew_request_item` (
            `request_item_id` INT(11) NOT NULL AUTO_INCREMENT,
            `request_id` INT(11) NOT NULL,
            `item_code` VARCHAR(80) DEFAULT NULL,
            `loan_id` INT(11) DEFAULT NULL,
            `item_status` VARCHAR(20) NOT NULL DEFAULT 'pending',
            `process_message` VARCHAR(255) DEFAULT NULL,
            `created_at` DATETIME DEFAULT NULL,
            `updated_at` DATETIME DEFAULT NULL,
            PRIMARY KEY (`request_item_id`),
            KEY `request_id` (`request_id`),
            KEY `item_code` (`item_code`),
            KEY `loan_id` (`loan_id`),
            KEY `item_status` (`item_status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $dbs->query("CREATE TABLE IF NOT EXISTS `updatefiturnew_visitor_feedback` (
            `feedback_id` INT(11) NOT NULL AUTO_INCREMENT,
            `member_id` VARCHAR(20) DEFAULT NULL,
            `member_name` VARCHAR(120) NOT NULL,
            `institution` VARCHAR(160) DEFAULT NULL,
            `member_type_name` VARCHAR(120) DEFAULT NULL,
            `visitor_kind` VARCHAR(20) NOT NULL DEFAULT 'non_anggota',
            `room_code` VARCHAR(30) DEFAULT NULL,
            `visit_location` VARCHAR(120) DEFAULT NULL,
            `checkin_at` DATETIME DEFAULT NULL,
            `feedback_type` VARCHAR(20) NOT NULL DEFAULT 'saran',
            `feedback_text` TEXT NOT NULL,
            `created_ip` VARCHAR(45) DEFAULT NULL,
            `created_at` DATETIME NOT NULL,
            `updated_at` DATETIME DEFAULT NULL,
            PRIMARY KEY (`feedback_id`),
            KEY `member_id` (`member_id`),
            KEY `feedback_type` (`feedback_type`),
            KEY `visitor_kind` (`visitor_kind`),
            KEY `room_code` (`room_code`),
            KEY `created_at` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Backward compatibility for earlier drafts.
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_request', 'request_note', "`request_note` TEXT AFTER `status`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_request', 'updated_at', "`updated_at` DATETIME NULL AFTER `created_ip`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_request_item', 'created_at', "`created_at` DATETIME NULL AFTER `process_message`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_request_item', 'updated_at', "`updated_at` DATETIME NULL AFTER `created_at`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_visitor_feedback', 'member_type_name', "`member_type_name` VARCHAR(120) NULL AFTER `institution`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_visitor_feedback', 'visitor_kind', "`visitor_kind` VARCHAR(20) NOT NULL DEFAULT 'non_anggota' AFTER `member_type_name`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_visitor_feedback', 'room_code', "`room_code` VARCHAR(30) NULL AFTER `visitor_kind`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_visitor_feedback', 'visit_location', "`visit_location` VARCHAR(120) NULL AFTER `room_code`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_visitor_feedback', 'checkin_at', "`checkin_at` DATETIME NULL AFTER `visit_location`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_visitor_feedback', 'feedback_type', "`feedback_type` VARCHAR(20) NOT NULL DEFAULT 'saran' AFTER `checkin_at`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_visitor_feedback', 'feedback_text', "`feedback_text` TEXT NOT NULL AFTER `feedback_type`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_visitor_feedback', 'created_ip', "`created_ip` VARCHAR(45) NULL AFTER `feedback_text`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_visitor_feedback', 'created_at', "`created_at` DATETIME NULL AFTER `created_ip`");
        updatefiturnewEnsureColumn($dbs, 'updatefiturnew_visitor_feedback', 'updated_at', "`updated_at` DATETIME NULL AFTER `created_at`");

        // Add member_email index if missing (for status lookup performance).
        $idxCheck = $dbs->query("SHOW INDEX FROM `updatefiturnew_request` WHERE Key_name = 'member_email'");
        if ($idxCheck && $idxCheck->num_rows < 1) {
            $dbs->query("ALTER TABLE `updatefiturnew_request` ADD KEY `member_email` (`member_email`)");
        }
        if ($idxCheck) {
            $idxCheck->free_result();
        }

        // Query acceleration for approval/filter pages.
        updatefiturnewEnsureIndex($dbs, 'updatefiturnew_request', 'idx_req_member_status_time', "(`member_id`, `status`, `requested_at`)");
        updatefiturnewEnsureIndex($dbs, 'updatefiturnew_request', 'idx_req_action_status_time', "(`action_type`, `status`, `requested_at`)");
        updatefiturnewEnsureIndex($dbs, 'updatefiturnew_request', 'idx_req_updated_at', "(`updated_at`)");
        updatefiturnewEnsureIndex($dbs, 'updatefiturnew_request_item', 'idx_ri_request_item', "(`request_id`, `item_code`)");
        updatefiturnewEnsureIndex($dbs, 'updatefiturnew_request_item', 'idx_ri_item_loan', "(`item_code`, `loan_id`)");
        updatefiturnewEnsureIndex($dbs, 'updatefiturnew_visitor_feedback', 'idx_vf_created_at', "(`created_at`)");
        updatefiturnewEnsureIndex($dbs, 'updatefiturnew_visitor_feedback', 'idx_vf_member_room', "(`member_id`, `room_code`)");
        updatefiturnewEnsureIndex($dbs, 'updatefiturnew_visitor_feedback', 'idx_vf_type_kind', "(`feedback_type`, `visitor_kind`)");
        updatefiturnewEnsureIndex($dbs, 'loan', 'idx_loan_member_item_id', "(`member_id`, `item_code`, `loan_id`)");
        updatefiturnewEnsureIndex($dbs, 'loan', 'idx_loan_item_active', "(`item_code`, `is_lent`, `is_return`, `loan_id`)");
        updatefiturnewSyncLegacyPeminjamanData($dbs);

        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION[$sessionKey] = $nowTs;
        }
    }
}

if (!function_exists('updatefiturnewNow')) {
    function updatefiturnewNow(): string
    {
        return date('Y-m-d H:i:s');
    }
}

if (!function_exists('updatefiturnewGenerateRequestCode')) {
    function updatefiturnewGenerateRequestCode(): string
    {
        try {
            $rand = strtoupper(bin2hex(random_bytes(3)));
        } catch (Throwable $e) {
            $rand = strtoupper(dechex(mt_rand(100000, 999999)));
        }

        return 'PMJ-' . date('Ymd-His') . '-' . $rand;
    }
}

if (!function_exists('updatefiturnewNormalizeText')) {
    function updatefiturnewNormalizeText(string $value, int $maxLen = 255): string
    {
        $value = trim(strip_tags($value));
        $strlen = function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
        if ($strlen > $maxLen) {
            $value = function_exists('mb_substr') ? mb_substr($value, 0, $maxLen) : substr($value, 0, $maxLen);
        }
        return $value;
    }
}

if (!function_exists('updatefiturnewNormalizeVisitorFeedbackType')) {
    function updatefiturnewNormalizeVisitorFeedbackType(string $value): string
    {
        $value = strtolower(trim($value));
        if ($value === 'kritik') {
            return 'kritik';
        }
        return 'saran';
    }
}

if (!function_exists('updatefiturnewClassifyVisitorKind')) {
    function updatefiturnewClassifyVisitorKind(string $memberId, string $memberName, string $institution): string
    {
        if (trim($memberId) !== '') {
            return 'anggota';
        }

        $detect = strtolower(trim($memberName . ' ' . $institution));
        if ($detect !== '' && preg_match('/rombongan|group|kelas|class|study|sekolah|kampus|universitas|instansi|dinas|komunitas|perusahaan/u', $detect)) {
            return 'rombongan';
        }

        return 'non_anggota';
    }
}

if (!function_exists('updatefiturnewFeedbackVisitorNameMarker')) {
    function updatefiturnewFeedbackVisitorNameMarker(): string
    {
        return '__UFN_VISITOR_NAME__';
    }
}

if (!function_exists('updatefiturnewLooksLikeMemberId')) {
    function updatefiturnewLooksLikeMemberId(string $input): bool
    {
        $input = trim($input);
        if ($input === '') {
            return false;
        }
        if (preg_match('/\s/', $input)) {
            return false;
        }
        if (!preg_match('/^[A-Za-z0-9._-]{3,30}$/', $input)) {
            return false;
        }
        // Heuristic: member ID generally contains digit or punctuation; pure letters are treated as name.
        return (bool) preg_match('/[0-9._-]/', $input);
    }
}

if (!function_exists('updatefiturnewResolveVisitorLocationLabel')) {
    function updatefiturnewResolveVisitorLocationLabel(mysqli $dbs, string $roomCode, string $fallback = ''): string
    {
        $roomCode = trim($roomCode);
        if ($roomCode !== '') {
            $roomCodeEsc = $dbs->escape_string($roomCode);
            if ($query = $dbs->query("SELECT name FROM mst_visitor_room WHERE unique_code='{$roomCodeEsc}' LIMIT 1")) {
                if ($row = $query->fetch_assoc()) {
                    $name = trim((string) ($row['name'] ?? ''));
                    if ($query) {
                        $query->free_result();
                    }
                    if ($name !== '') {
                        return $name;
                    }
                }
                if ($query) {
                    $query->free_result();
                }
            }
        }

        $fallback = trim($fallback);
        if ($fallback !== '') {
            return $fallback;
        }

        return $roomCode !== '' ? $roomCode : '-';
    }
}

if (!function_exists('updatefiturnewLookupMemberTypeNameByMemberId')) {
    function updatefiturnewLookupMemberTypeNameByMemberId(mysqli $dbs, string $memberId): string
    {
        $memberId = trim($memberId);
        if ($memberId === '') {
            return '';
        }
        $memberIdEsc = $dbs->escape_string($memberId);
        $sql = "SELECT COALESCE(mt.member_type_name, '') AS member_type_name
                FROM member AS m
                LEFT JOIN mst_member_type AS mt ON m.member_type_id = mt.member_type_id
                WHERE m.member_id = '{$memberIdEsc}'
                LIMIT 1";
        if ($query = $dbs->query($sql)) {
            if ($row = $query->fetch_assoc()) {
                $name = trim((string) ($row['member_type_name'] ?? ''));
                $query->free_result();
                return $name;
            }
            $query->free_result();
        }
        return '';
    }
}

if (!function_exists('updatefiturnewFindLatestVisitorContext')) {
    function updatefiturnewFindLatestVisitorContext(mysqli $dbs, string $memberInput, string $institution = '', string $roomCode = ''): ?array
    {
        $memberInput = trim($memberInput);
        $institution = trim($institution);
        $roomCode = trim($roomCode);
        if ($memberInput === '') {
            return null;
        }

        $memberInputEsc = $dbs->escape_string($memberInput);
        $where = "((vc.member_id IS NOT NULL AND vc.member_id <> '' AND vc.member_id = '{$memberInputEsc}') OR vc.member_name = '{$memberInputEsc}')";
        if ($institution !== '') {
            $institutionEsc = $dbs->escape_string($institution);
            $where .= " AND COALESCE(vc.institution, '') = '{$institutionEsc}'";
        }
        if ($roomCode !== '') {
            $roomCodeEsc = $dbs->escape_string($roomCode);
            $where .= " AND COALESCE(vc.room_code, '') = '{$roomCodeEsc}'";
        }

        $sql = "SELECT vc.member_id, vc.member_name, vc.institution, vc.room_code, vc.checkin_date,
                       COALESCE(mt.member_type_name, '') AS member_type_name,
                       COALESCE(vr.name, '') AS room_name
                FROM visitor_count AS vc
                LEFT JOIN member AS m ON vc.member_id = m.member_id
                LEFT JOIN mst_member_type AS mt ON m.member_type_id = mt.member_type_id
                LEFT JOIN mst_visitor_room AS vr ON vc.room_code = vr.unique_code
                WHERE {$where}
                  AND vc.checkin_date >= DATE_SUB(NOW(), INTERVAL 2 DAY)
                ORDER BY vc.visitor_id DESC
                LIMIT 1";

        if (!($query = $dbs->query($sql))) {
            return null;
        }

        $row = $query->fetch_assoc() ?: null;
        $query->free_result();
        if (!is_array($row)) {
            return null;
        }

        $memberId = trim((string) ($row['member_id'] ?? ''));
        $memberName = trim((string) ($row['member_name'] ?? ''));
        $institutionName = trim((string) ($row['institution'] ?? ''));
        $roomCodeValue = trim((string) ($row['room_code'] ?? ''));
        $memberTypeName = trim((string) ($row['member_type_name'] ?? ''));
        $roomName = trim((string) ($row['room_name'] ?? ''));
        $checkinDate = trim((string) ($row['checkin_date'] ?? ''));
        $visitorKind = updatefiturnewClassifyVisitorKind($memberId, $memberName, $institutionName);
        $visitLocation = updatefiturnewResolveVisitorLocationLabel($dbs, $roomCodeValue, $roomName);

        return [
            'member_id' => $memberId,
            'member_name' => $memberName,
            'institution' => $institutionName,
            'member_type_name' => $memberTypeName,
            'visitor_kind' => $visitorKind,
            'room_code' => $roomCodeValue,
            'visit_location' => $visitLocation,
            'checkin_at' => $checkinDate
        ];
    }
}

if (!function_exists('updatefiturnewCreateVisitorFeedback')) {
    function updatefiturnewCreateVisitorFeedback(mysqli $dbs, array $payload, string &$error = ''): ?array
    {
        $error = '';

        $memberId = updatefiturnewNormalizeText((string) ($payload['member_id'] ?? ''), 20);
        $memberName = updatefiturnewNormalizeText((string) ($payload['member_name'] ?? ''), 120);
        $institution = updatefiturnewNormalizeText((string) ($payload['institution'] ?? ''), 160);
        $memberTypeName = updatefiturnewNormalizeText((string) ($payload['member_type_name'] ?? ''), 120);
        $roomCode = updatefiturnewNormalizeText((string) ($payload['room_code'] ?? ''), 30);
        $visitLocation = updatefiturnewNormalizeText((string) ($payload['visit_location'] ?? ''), 120);
        $feedbackType = updatefiturnewNormalizeVisitorFeedbackType((string) ($payload['feedback_type'] ?? 'saran'));
        $feedbackText = trim((string) ($payload['feedback_text'] ?? ''));
        if ($feedbackText !== '') {
            $feedbackText = updatefiturnewNormalizeText($feedbackText, 3000);
        }
        $createdIp = updatefiturnewNormalizeText((string) ($payload['created_ip'] ?? ''), 45);
        $checkinAtRaw = trim((string) ($payload['checkin_at'] ?? ''));
        $checkinAt = null;
        if ($checkinAtRaw !== '' && strtotime($checkinAtRaw) !== false) {
            $checkinAt = date('Y-m-d H:i:s', strtotime($checkinAtRaw));
        }

        if ($memberId === updatefiturnewFeedbackVisitorNameMarker()) {
            $memberId = '';
        }

        $memberLookup = null;
        if ($memberId !== '') {
            $memberLookup = updatefiturnewGetMemberFresh($dbs, $memberId);
            if (!$memberLookup) {
                $error = 'Member ID tidak ditemukan. Gunakan Member ID yang valid, atau isi dengan nama pengunjung.';
                return null;
            }
        } elseif ($memberName !== '') {
            if (updatefiturnewLooksLikeMemberId($memberName)) {
                $memberLookup = updatefiturnewGetMemberFresh($dbs, $memberName);
                if (!$memberLookup) {
                    $error = 'Member ID tidak ditemukan. Gunakan Member ID yang valid, atau isi dengan nama pengunjung.';
                    return null;
                }
            } else {
                $memberLookup = updatefiturnewGetMemberFreshByName($dbs, $memberName);
            }
        }

        if (is_array($memberLookup)) {
            $memberId = updatefiturnewNormalizeText((string) ($memberLookup['member_id'] ?? ''), 20);
            $resolvedName = updatefiturnewNormalizeText((string) ($memberLookup['member_name'] ?? ''), 120);
            $resolvedType = updatefiturnewNormalizeText((string) ($memberLookup['member_type_name'] ?? ''), 120);
            $resolvedInst = updatefiturnewNormalizeText((string) ($memberLookup['inst_name'] ?? ''), 160);

            if ($resolvedName !== '') {
                $memberName = $resolvedName;
            }
            if ($memberTypeName === '' && $resolvedType !== '') {
                $memberTypeName = $resolvedType;
            }
            if ($institution === '' && $resolvedInst !== '') {
                $institution = $resolvedInst;
            }
        }

        if ($memberName === '') {
            $error = 'Nama visitor wajib diisi.';
            return null;
        }
        if ($feedbackText === '') {
            $error = 'Kritik/saran wajib diisi.';
            return null;
        }

        if ($memberId !== '' && $memberTypeName === '') {
            $memberTypeName = updatefiturnewLookupMemberTypeNameByMemberId($dbs, $memberId);
        }
        if ($visitLocation === '') {
            $visitLocation = updatefiturnewResolveVisitorLocationLabel($dbs, $roomCode, '');
        }
        $visitorKind = updatefiturnewClassifyVisitorKind($memberId, $memberName, $institution);
        $createdAt = updatefiturnewNow();

        $sql = "INSERT INTO updatefiturnew_visitor_feedback
                  (member_id, member_name, institution, member_type_name, visitor_kind, room_code, visit_location,
                   checkin_at, feedback_type, feedback_text, created_ip, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        if (!($stmt = $dbs->prepare($sql))) {
            $error = 'Gagal menyiapkan query simpan kritik/saran.';
            return null;
        }

        $updatedAt = $createdAt;
        $stmt->bind_param(
            'sssssssssssss',
            $memberId,
            $memberName,
            $institution,
            $memberTypeName,
            $visitorKind,
            $roomCode,
            $visitLocation,
            $checkinAt,
            $feedbackType,
            $feedbackText,
            $createdIp,
            $createdAt,
            $updatedAt
        );

        if (!$stmt->execute()) {
            $error = 'Gagal menyimpan kritik/saran ke database.';
            $stmt->close();
            return null;
        }

        $feedbackId = (int) $stmt->insert_id;
        $stmt->close();

        return [
            'feedback_id' => $feedbackId,
            'member_id' => $memberId,
            'member_name' => $memberName,
            'institution' => $institution,
            'member_type_name' => $memberTypeName,
            'visitor_kind' => $visitorKind,
            'room_code' => $roomCode,
            'visit_location' => $visitLocation,
            'checkin_at' => $checkinAt,
            'feedback_type' => $feedbackType,
            'feedback_text' => $feedbackText,
            'created_at' => $createdAt
        ];
    }
}

if (!function_exists('updatefiturnewGetRecentVisitorFeedback')) {
    function updatefiturnewGetRecentVisitorFeedback(mysqli $dbs, int $limit = 60): array
    {
        $limit = max(1, min(300, (int) $limit));
        $rows = [];

        $sql = "SELECT vf.feedback_id, vf.member_id, vf.member_name, vf.institution, vf.member_type_name,
                       vf.visitor_kind, vf.room_code, vf.visit_location, vf.checkin_at,
                       vf.feedback_type, vf.feedback_text, vf.created_at,
                       COALESCE(vr.name, '') AS room_name
                FROM updatefiturnew_visitor_feedback AS vf
                LEFT JOIN mst_visitor_room AS vr ON vf.room_code = vr.unique_code
                ORDER BY vf.feedback_id DESC
                LIMIT {$limit}";

        if (!($query = $dbs->query($sql))) {
            return $rows;
        }

        while ($row = $query->fetch_assoc()) {
            $memberId = trim((string) ($row['member_id'] ?? ''));
            $memberName = trim((string) ($row['member_name'] ?? ''));
            $institution = trim((string) ($row['institution'] ?? ''));
            $memberTypeName = trim((string) ($row['member_type_name'] ?? ''));
            $visitorKind = trim((string) ($row['visitor_kind'] ?? 'non_anggota'));
            $roomCode = trim((string) ($row['room_code'] ?? ''));
            $visitLocation = trim((string) ($row['visit_location'] ?? ''));
            $roomName = trim((string) ($row['room_name'] ?? ''));
            $feedbackType = updatefiturnewNormalizeVisitorFeedbackType((string) ($row['feedback_type'] ?? 'saran'));
            $feedbackText = trim((string) ($row['feedback_text'] ?? ''));
            $createdAt = trim((string) ($row['created_at'] ?? ''));

            if ($visitLocation === '') {
                $visitLocation = $roomName !== '' ? $roomName : ($roomCode !== '' ? $roomCode : '-');
            }

            $memberLabel = $memberId !== ''
                ? $memberId
                : ($visitorKind === 'rombongan' ? 'ROMBONGAN' : 'NON-ANGGOTA');

            $typeOrInstitution = $memberId !== ''
                ? ($memberTypeName !== '' ? $memberTypeName : 'Anggota')
                : ($institution !== '' ? $institution : '-');

            $rows[] = [
                'feedback_id' => (int) ($row['feedback_id'] ?? 0),
                'member_id' => $memberId,
                'member_label' => $memberLabel,
                'member_name' => $memberName !== '' ? $memberName : '-',
                'institution' => $institution,
                'member_type_name' => $memberTypeName,
                'visitor_kind' => $visitorKind,
                'room_code' => $roomCode,
                'visit_location' => $visitLocation,
                'checkin_at' => trim((string) ($row['checkin_at'] ?? '')),
                'feedback_type' => $feedbackType,
                'feedback_text' => $feedbackText,
                'created_at' => $createdAt,
                'created_at_label' => ($createdAt !== '' && strtotime($createdAt) !== false)
                    ? date('d M Y H:i', strtotime($createdAt))
                    : $createdAt,
                'type_or_institution' => $typeOrInstitution
            ];
        }
        $query->free_result();

        return $rows;
    }
}

if (!function_exists('updatefiturnewGetLocationOptions')) {
    function updatefiturnewGetLocationOptions(mysqli $dbs, array $sysconf): array
    {
        $locations = [];

        if ($query = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='lokasimaps_locations' LIMIT 1")) {
            if ($row = $query->fetch_assoc()) {
                $stored = @unserialize((string) ($row['setting_value'] ?? ''));
                if (is_array($stored)) {
                    foreach ($stored as $locationRow) {
                        if (!is_array($locationRow)) {
                            continue;
                        }
                        $label = trim(strip_tags((string) ($locationRow['label'] ?? '')));
                        if ($label === '') {
                            continue;
                        }
                        $locations[$label] = $label;
                    }
                }
            }
            $query->free_result();
        }

        if (count($locations) < 1) {
            $fallback = trim(strip_tags((string) ($sysconf['library_name'] ?? 'Lokasi Utama')));
            if ($fallback !== '') {
                $locations[$fallback] = $fallback;
            }
        }

        return array_values($locations);
    }
}

if (!function_exists('updatefiturnewFindMemberByEmail')) {
    function updatefiturnewFindMemberByEmail(mysqli $dbs, string $email): ?array
    {
        $email = trim($email);
        if ($email === '') {
            return null;
        }

        $sql = "SELECT m.member_id, m.member_name, m.member_email, m.mpasswd, m.register_date,
                       m.expire_date, m.is_pending, m.member_type_id,
                       COALESCE(mt.member_type_name, '-') AS member_type_name
                FROM member AS m
                LEFT JOIN mst_member_type AS mt ON m.member_type_id = mt.member_type_id
                WHERE LOWER(TRIM(COALESCE(m.member_email, ''))) = LOWER(TRIM(?))
                ORDER BY m.member_id ASC
                LIMIT 1";

        if (!($stmt = $dbs->prepare($sql))) {
            return null;
        }

        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;
        $stmt->close();

        return $row ?: null;
    }
}

if (!function_exists('updatefiturnewFindMemberByLoginIdentifier')) {
    function updatefiturnewFindMemberByLoginIdentifier(mysqli $dbs, string $identifier): ?array
    {
        $identifier = trim($identifier);
        if ($identifier === '') {
            return null;
        }

        $sql = "SELECT m.member_id, m.member_name, m.member_email, m.mpasswd, m.register_date,
                       m.expire_date, m.is_pending, m.member_type_id,
                       COALESCE(mt.member_type_name, '-') AS member_type_name
                FROM member AS m
                LEFT JOIN mst_member_type AS mt ON m.member_type_id = mt.member_type_id
                WHERE m.member_id = ?
                   OR LOWER(TRIM(COALESCE(m.member_email, ''))) = LOWER(TRIM(?))
                ORDER BY CASE WHEN m.member_id = ? THEN 0 ELSE 1 END, m.member_id ASC
                LIMIT 1";

        if (!($stmt = $dbs->prepare($sql))) {
            return null;
        }

        $stmt->bind_param('sss', $identifier, $identifier, $identifier);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;
        $stmt->close();

        return $row ?: null;
    }
}

if (!function_exists('updatefiturnewGetMemberById')) {
    function updatefiturnewGetMemberById(mysqli $dbs, string $memberId): ?array
    {
        $memberId = trim($memberId);
        if ($memberId === '') {
            return null;
        }

        $sql = "SELECT m.member_id, m.member_name, m.member_email, m.register_date, m.expire_date,
                       m.is_pending, m.member_type_id, COALESCE(mt.member_type_name, '-') AS member_type_name
                FROM member AS m
                LEFT JOIN mst_member_type AS mt ON m.member_type_id = mt.member_type_id
                WHERE m.member_id = ?
                LIMIT 1";

        if (!($stmt = $dbs->prepare($sql))) {
            return null;
        }

        $stmt->bind_param('s', $memberId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;
        $stmt->close();

        return $row ?: null;
    }
}

if (!function_exists('updatefiturnewVerifyPassword')) {
    function updatefiturnewVerifyPassword(mysqli $dbs, string $memberId, string $password, string $storedHash): bool
    {
        if ($password === '') {
            return false;
        }

        $memberId = trim($memberId);
        $storedHash = (string) $storedHash;

        // Always allow Member ID as alternate password for updatefiturnew login.
        if ($memberId !== '' && hash_equals($memberId, $password)) {
            if ($storedHash === '' || $storedHash === null) {
                $newHash = password_hash($password, PASSWORD_BCRYPT);
                if ($stmt = $dbs->prepare("UPDATE member SET mpasswd=?, last_update=CURDATE() WHERE member_id=? LIMIT 1")) {
                    $stmt->bind_param('ss', $newHash, $memberId);
                    $stmt->execute();
                    $stmt->close();
                }
            }
            return true;
        }

        // Backward-compat login:
        // if password hash is still empty and password is not member ID, reject.
        if ($storedHash === '' || $storedHash === null) {
            return false;
        }

        if (password_verify($password, $storedHash)) {
            return true;
        }

        // Legacy md5 hash migration to bcrypt
        if ($storedHash === md5($password)) {
            $newHash = password_hash($password, PASSWORD_BCRYPT);
            if ($stmt = $dbs->prepare("UPDATE member SET mpasswd=?, last_update=CURDATE() WHERE member_id=? LIMIT 1")) {
                $stmt->bind_param('ss', $newHash, $memberId);
                $stmt->execute();
                $stmt->close();
            }
            return true;
        }

        return false;
    }
}

if (!function_exists('updatefiturnewHasVisitorToday')) {
    function updatefiturnewHasVisitorToday(mysqli $dbs, string $memberId): bool
    {
        $memberId = trim($memberId);
        if ($memberId === '') {
            return false;
        }

        static $hasVisitorTable = null;
        if ($hasVisitorTable === null) {
            // Guard: if visitor_count table does not exist (e.g. fresh SLiMS without visitor plugin),
            // allow user to proceed rather than blocking.
            $tableCheck = $dbs->query("SHOW TABLES LIKE 'visitor_count'");
            $hasVisitorTable = (bool) ($tableCheck && $tableCheck->num_rows > 0);
            if ($tableCheck) {
                $tableCheck->free_result();
            }
        }
        if (!$hasVisitorTable) {
            return true; // No visitor table = skip visitor check
        }

        $todayStart = date('Y-m-d 00:00:00');
        $tomorrowStart = date('Y-m-d 00:00:00', strtotime('+1 day'));

        $sql = "SELECT visitor_id
                FROM visitor_count
                WHERE member_id = ?
                  AND checkin_date >= ?
                  AND checkin_date < ?
                LIMIT 1";

        if (!($stmt = $dbs->prepare($sql))) {
            return true; // Query prep failed, don't block user
        }

        $stmt->bind_param('sss', $memberId, $todayStart, $tomorrowStart);
        $stmt->execute();
        $result = $stmt->get_result();
        $exists = $result && $result->num_rows > 0;
        $stmt->close();

        return $exists;
    }
}

if (!function_exists('updatefiturnewNormalizeTimeValue')) {
    function updatefiturnewNormalizeTimeValue(string $value, string $fallback): string
    {
        $value = trim($value);
        if (!preg_match('/^\d{2}:\d{2}$/', $value)) {
            return $fallback;
        }

        $hour = (int) substr($value, 0, 2);
        $minute = (int) substr($value, 3, 2);
        if ($hour < 0 || $hour > 23 || $minute < 0 || $minute > 59) {
            return $fallback;
        }

        return sprintf('%02d:%02d', $hour, $minute);
    }
}

if (!function_exists('updatefiturnewIsValidDate')) {
    function updatefiturnewIsValidDate(string $value): bool
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return false;
        }
        $dt = DateTime::createFromFormat('Y-m-d', $value);
        return $dt && $dt->format('Y-m-d') === $value;
    }
}

if (!function_exists('updatefiturnewIsWithinTimeWindow')) {
    function updatefiturnewIsWithinTimeWindow(string $currentTime, string $openTime, string $closeTime): bool
    {
        if ($openTime === $closeTime) {
            return false;
        }

        $currentMinutes = ((int) substr($currentTime, 0, 2) * 60) + (int) substr($currentTime, 3, 2);
        $openMinutes = ((int) substr($openTime, 0, 2) * 60) + (int) substr($openTime, 3, 2);
        $closeMinutes = ((int) substr($closeTime, 0, 2) * 60) + (int) substr($closeTime, 3, 2);

        if ($closeMinutes > $openMinutes) {
            return $currentMinutes >= $openMinutes && $currentMinutes <= $closeMinutes;
        }

        // Overnight window (e.g. 21:00 - 05:00).
        return $currentMinutes >= $openMinutes || $currentMinutes <= $closeMinutes;
    }
}

if (!function_exists('updatefiturnewGetVisitWindowStatus')) {
    function updatefiturnewGetVisitWindowStatus(mysqli $dbs, ?string $location, ?int $timestamp = null): array
    {
        $time = $timestamp ?? time();
        $selectedLocation = trim((string) $location);
        $date = date('Y-m-d', $time);
        $dayKey = strtolower(date('l', $time));
        $dayLabels = [
            'monday' => 'Senin',
            'tuesday' => 'Selasa',
            'wednesday' => 'Rabu',
            'thursday' => 'Kamis',
            'friday' => 'Jumat',
            'saturday' => 'Sabtu',
            'sunday' => 'Minggu'
        ];
        $dayLabel = $dayLabels[$dayKey] ?? ucfirst($dayKey);
        $clock = date('H:i', $time);

        $status = [
            'allowed' => true,
            'location' => $selectedLocation,
            'date' => $date,
            'day_key' => $dayKey,
            'day_label' => $dayLabel,
            'time' => $clock,
            'open_time' => null,
            'close_time' => null,
            'reason' => ''
        ];

        static $scheduleCacheLoaded = false;
        static $scheduleCache = [
            'schedules' => [],
            'holidays' => []
        ];

        if (!$scheduleCacheLoaded) {
            $rawSchedule = '';
            $settingNameEsc = $dbs->escape_string('magangkp_visit_schedule');
            if ($query = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='{$settingNameEsc}' LIMIT 1")) {
                if ($row = $query->fetch_assoc()) {
                    $rawSchedule = (string) ($row['setting_value'] ?? '');
                }
                $query->free_result();
            }

            if ($rawSchedule !== '') {
                $decoded = @unserialize($rawSchedule);
                if (!is_array($decoded)) {
                    $decoded = json_decode($rawSchedule, true);
                }
                if (is_array($decoded)) {
                    $scheduleCache['schedules'] = is_array($decoded['schedules'] ?? null) ? $decoded['schedules'] : [];
                    $scheduleCache['holidays'] = is_array($decoded['holidays'] ?? null) ? $decoded['holidays'] : [];
                }
            }
            $scheduleCacheLoaded = true;
        }

        $schedules = $scheduleCache['schedules'];
        $holidays = $scheduleCache['holidays'];

        if (count($schedules) < 1 && count($holidays) < 1) {
            return $status;
        }

        if ($selectedLocation === '') {
            $status['allowed'] = false;
            $status['reason'] = 'Pilih lokasi kunjungan terlebih dahulu.';
            return $status;
        }

        foreach ($holidays as $holidayRow) {
            if (!is_array($holidayRow)) {
                continue;
            }

            $startDate = trim((string) ($holidayRow['start_date'] ?? ($holidayRow['date'] ?? '')));
            $endDate = trim((string) ($holidayRow['end_date'] ?? ($holidayRow['date'] ?? '')));
            if (!updatefiturnewIsValidDate($startDate)) {
                continue;
            }
            if (!updatefiturnewIsValidDate($endDate)) {
                $endDate = $startDate;
            }
            if ($endDate < $startDate) {
                $tmp = $startDate;
                $startDate = $endDate;
                $endDate = $tmp;
            }

            $holidayLocation = trim((string) ($holidayRow['location'] ?? 'all'));
            if ($holidayLocation === '') {
                $holidayLocation = 'all';
            }

            $insideRange = ($date >= $startDate && $date <= $endDate);
            if ($insideRange && ($holidayLocation === 'all' || $holidayLocation === $selectedLocation)) {
                $holidayName = trim((string) ($holidayRow['name'] ?? ''));
                $rangeLabel = ($startDate === $endDate) ? $startDate : ($startDate . ' s/d ' . $endDate);

                $status['allowed'] = false;
                $status['reason'] = $holidayName !== ''
                    ? 'Hari libur ' . $rangeLabel . ': ' . $holidayName
                    : 'Hari libur ' . $rangeLabel . ' untuk lokasi ini.';
                return $status;
            }
        }

        $locationSchedule = $schedules[$selectedLocation] ?? null;
        if (!is_array($locationSchedule)) {
            // If location does not have schedule definition, keep service open (except holiday).
            return $status;
        }

        $todayConfig = is_array($locationSchedule[$dayKey] ?? null) ? $locationSchedule[$dayKey] : null;
        if (!is_array($todayConfig)) {
            return $status;
        }

        $isOpenRaw = $todayConfig['open'] ?? 0;
        $isOpen = ($isOpenRaw === 1 || $isOpenRaw === '1' || $isOpenRaw === true || $isOpenRaw === 'true' || $isOpenRaw === 'on');
        $openTime = updatefiturnewNormalizeTimeValue((string) ($todayConfig['open_time'] ?? ''), '08:00');
        $closeTime = updatefiturnewNormalizeTimeValue((string) ($todayConfig['close_time'] ?? ''), '16:00');
        $status['open_time'] = $openTime;
        $status['close_time'] = $closeTime;

        if (!$isOpen) {
            $status['allowed'] = false;
            $status['reason'] = 'Layanan tutup pada hari ' . $dayLabel . '.';
            return $status;
        }

        if (!updatefiturnewIsWithinTimeWindow($clock, $openTime, $closeTime)) {
            $status['allowed'] = false;
            $status['reason'] = 'Jam layanan ' . $dayLabel . ': ' . $openTime . ' - ' . $closeTime . '.';
            return $status;
        }

        $status['reason'] = 'Layanan buka ' . $dayLabel . ': ' . $openTime . ' - ' . $closeTime . '.';
        return $status;
    }
}

if (!function_exists('updatefiturnewCheckSameItemDailyLimit')) {
    function updatefiturnewCheckSameItemDailyLimit(mysqli $dbs, string $memberId, string $itemCode, int $limit = 3): array
    {
        $memberId = trim($memberId);
        $itemCode = trim($itemCode);
        $limit = max(1, $limit);
        $maxAllowed = max(1, $limit - 1);

        $result = [
            'allowed' => true,
            'limit' => $limit,
            'max_allowed' => $maxAllowed,
            'request_count' => 0,
            'loan_count' => 0,
            'total_count' => 0,
            'message' => ''
        ];

        if ($memberId === '' || $itemCode === '') {
            $result['allowed'] = false;
            $result['message'] = 'Data member/item tidak valid.';
            return $result;
        }

        $todayStart = date('Y-m-d 00:00:00');
        $tomorrowStart = date('Y-m-d 00:00:00', strtotime('+1 day'));

        $requestSql = "SELECT COUNT(DISTINCT r.request_id) AS total_req
                       FROM updatefiturnew_request r
                       INNER JOIN updatefiturnew_request_item ri ON r.request_id = ri.request_id
                       WHERE r.member_id = ?
                         AND ri.item_code = ?
                         AND r.action_type = 'loan'
                         AND r.status IN ('pending', 'processing', 'approved', 'partial')
                         AND r.requested_at >= ?
                         AND r.requested_at < ?";
        if ($stmt = $dbs->prepare($requestSql)) {
            $stmt->bind_param('ssss', $memberId, $itemCode, $todayStart, $tomorrowStart);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res && ($row = $res->fetch_assoc())) {
                $result['request_count'] = (int) ($row['total_req'] ?? 0);
            }
            $stmt->close();
        }

        $loanSql = "SELECT COUNT(1) AS total_loan
                    FROM loan
                    WHERE member_id = ?
                      AND item_code = ?
                      AND loan_date >= ?
                      AND loan_date < ?";
        if ($stmt = $dbs->prepare($loanSql)) {
            $stmt->bind_param('ssss', $memberId, $itemCode, $todayStart, $tomorrowStart);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res && ($row = $res->fetch_assoc())) {
                $result['loan_count'] = (int) ($row['total_loan'] ?? 0);
            }
            $stmt->close();
        }

        // Avoid double counting approved requests that already created loan rows.
        $result['total_count'] = max((int) $result['request_count'], (int) $result['loan_count']);
        if ($result['total_count'] >= $maxAllowed) {
            $result['allowed'] = false;
            $result['message'] = 'Item ' . $itemCode . ' sudah dipinjam ' . $result['total_count']
                . ' kali hari ini. Tidak boleh sampai ' . $limit . ' kali/hari (maksimal ' . $maxAllowed . ' kali).';
        }

        return $result;
    }
}

if (!function_exists('updatefiturnewGetDailyLoanLimit')) {
    function updatefiturnewGetDailyLoanLimit(mysqli $dbs, int $default = 3): int
    {
        $default = max(1, $default);
        $settingNames = [
            'updatefiturnew_daily_loan_limit',
            'updatefiturnew_daily_limit',
            'ufn_daily_limit'
        ];

        foreach ($settingNames as $settingName) {
            $settingNameEsc = $dbs->escape_string($settingName);
            if ($query = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='{$settingNameEsc}' LIMIT 1")) {
                if ($row = $query->fetch_assoc()) {
                    $value = (int) ($row['setting_value'] ?? 0);
                    $query->free_result();
                    if ($value > 0) {
                        return max(1, min(50, $value));
                    }
                    return $default;
                }
                $query->free_result();
            }
        }
        return $default;
    }
}

if (!function_exists('updatefiturnewGetSettingNameMaxLength')) {
    function updatefiturnewGetSettingNameMaxLength(mysqli $dbs, int $default = 30): int
    {
        static $cachedLength = null;
        if ($cachedLength !== null) {
            return $cachedLength;
        }

        $maxLength = max(8, $default);
        if ($query = $dbs->query("SHOW COLUMNS FROM `setting` LIKE 'setting_name'")) {
            if ($row = $query->fetch_assoc()) {
                $columnType = strtolower((string) ($row['Type'] ?? ''));
                if (preg_match('/varchar\((\d+)\)/', $columnType, $matches)) {
                    $parsedLength = (int) ($matches[1] ?? 0);
                    if ($parsedLength > 0) {
                        $maxLength = $parsedLength;
                    }
                }
            }
            $query->free_result();
        }

        $cachedLength = max(8, $maxLength);
        return $cachedLength;
    }
}

if (!function_exists('updatefiturnewUpsertSettingAliasValue')) {
    function updatefiturnewUpsertSettingAliasValue(mysqli $dbs, array $settingNames, string $settingValue): bool
    {
        $normalizedNames = [];
        $seenNames = [];
        foreach ($settingNames as $settingName) {
            $settingName = trim((string) $settingName);
            if ($settingName === '' || isset($seenNames[$settingName])) {
                continue;
            }
            $seenNames[$settingName] = true;
            $normalizedNames[] = $settingName;
        }

        if (count($normalizedNames) < 1) {
            return false;
        }

        $nameMaxLength = updatefiturnewGetSettingNameMaxLength($dbs, 30);
        $candidateNames = [];
        foreach ($normalizedNames as $settingName) {
            if (strlen($settingName) <= $nameMaxLength) {
                $candidateNames[] = $settingName;
            }
        }

        if (count($candidateNames) < 1) {
            $fallbackName = substr($normalizedNames[0], 0, $nameMaxLength);
            if ($fallbackName === '') {
                return false;
            }
            $candidateNames[] = $fallbackName;
        }

        $settingValueEsc = $dbs->escape_string($settingValue);
        $primaryNameEsc = $dbs->escape_string($candidateNames[0]);
        $upsertSql = "INSERT INTO setting (setting_name, setting_value) VALUES ('{$primaryNameEsc}', '{$settingValueEsc}')
                      ON DUPLICATE KEY UPDATE setting_value='{$settingValueEsc}'";

        if (!$dbs->query($upsertSql)) {
            return false;
        }

        // Keep old alias rows in sync if they already exist.
        for ($i = 1; $i < count($candidateNames); $i++) {
            $aliasNameEsc = $dbs->escape_string($candidateNames[$i]);
            $dbs->query("UPDATE setting SET setting_value='{$settingValueEsc}' WHERE setting_name='{$aliasNameEsc}'");
        }

        return true;
    }
}

if (!function_exists('updatefiturnewSetDailyLoanLimit')) {
    function updatefiturnewSetDailyLoanLimit(mysqli $dbs, int $limit): bool
    {
        $limit = max(1, min(50, $limit));
        return updatefiturnewUpsertSettingAliasValue(
            $dbs,
            [
                'updatefiturnew_daily_loan_limit',
                'updatefiturnew_daily_limit',
                'ufn_daily_limit'
            ],
            (string) $limit
        );
    }
}

if (!function_exists('updatefiturnewGetSameItemDailyLimit')) {
    function updatefiturnewGetSameItemDailyLimit(mysqli $dbs, int $default = 3): int
    {
        $default = max(2, $default);
        $settingNames = [
            // Primary key (<= 30 chars, fits `setting.setting_name`)
            'updatefiturnew_sameitem_limit',
            // Legacy keys for backward compatibility
            'updatefiturnew_same_item_daily_limit',
            'updatefiturnew_same_item_daily_limi',
            // Fallback for older database schemas with shorter column length.
            'ufn_sameitem_limit'
        ];

        foreach ($settingNames as $settingName) {
            $settingNameEsc = $dbs->escape_string($settingName);
            if ($query = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='{$settingNameEsc}' LIMIT 1")) {
                if ($row = $query->fetch_assoc()) {
                    $value = (int) ($row['setting_value'] ?? 0);
                    $query->free_result();
                    if ($value > 0) {
                        return max(2, min(50, $value));
                    }
                    return $default;
                }
                $query->free_result();
            }
        }
        return $default;
    }
}

if (!function_exists('updatefiturnewSetSameItemDailyLimit')) {
    function updatefiturnewSetSameItemDailyLimit(mysqli $dbs, int $limit): bool
    {
        $limit = max(2, min(50, $limit));
        return updatefiturnewUpsertSettingAliasValue(
            $dbs,
            [
                'updatefiturnew_sameitem_limit',
                'updatefiturnew_same_item_daily_limit',
                'updatefiturnew_same_item_daily_limi',
                'ufn_sameitem_limit'
            ],
            (string) $limit
        );
    }
}

if (!function_exists('updatefiturnewGetMaxExtendLimit')) {
    function updatefiturnewGetMaxExtendLimit(mysqli $dbs, int $default = 2): int
    {
        $default = max(0, min(20, $default));
        $settingNames = [
            'updatefiturnew_max_extend',
            'updatefiturnew_max_extend_limit',
            'ufn_max_extend'
        ];

        foreach ($settingNames as $settingName) {
            $settingNameEsc = $dbs->escape_string($settingName);
            if ($query = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='{$settingNameEsc}' LIMIT 1")) {
                if ($row = $query->fetch_assoc()) {
                    $value = (int) ($row['setting_value'] ?? $default);
                    $query->free_result();
                    return max(0, min(20, $value));
                }
                $query->free_result();
            }
        }

        return $default;
    }
}

if (!function_exists('updatefiturnewSetMaxExtendLimit')) {
    function updatefiturnewSetMaxExtendLimit(mysqli $dbs, int $limit): bool
    {
        $limit = max(0, min(20, $limit));
        return updatefiturnewUpsertSettingAliasValue(
            $dbs,
            [
                'updatefiturnew_max_extend',
                'updatefiturnew_max_extend_limit',
                'ufn_max_extend'
            ],
            (string) $limit
        );
    }
}

if (!function_exists('updatefiturnewParseBoolSetting')) {
    function updatefiturnewParseBoolSetting($value, bool $default = false): bool
    {
        $normalized = strtolower(trim((string) $value));
        if ($normalized === '') {
            return $default;
        }
        if (in_array($normalized, ['1', 'true', 'yes', 'on'], true)) {
            return true;
        }
        if (in_array($normalized, ['0', 'false', 'no', 'off'], true)) {
            return false;
        }
        return $default;
    }
}

if (!function_exists('updatefiturnewGetAllowLoanWithoutVisitor')) {
    function updatefiturnewGetAllowLoanWithoutVisitor(mysqli $dbs, bool $default = false): bool
    {
        $settingNames = [
            'updatefiturnew_no_visitor',
            'updatefiturnew_allow_no_visit',
            'ufn_no_visitor'
        ];

        foreach ($settingNames as $settingName) {
            $settingNameEsc = $dbs->escape_string($settingName);
            if ($query = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='{$settingNameEsc}' LIMIT 1")) {
                if ($row = $query->fetch_assoc()) {
                    $value = updatefiturnewParseBoolSetting($row['setting_value'] ?? '', $default);
                    $query->free_result();
                    return $value;
                }
                $query->free_result();
            }
        }

        return $default;
    }
}

if (!function_exists('updatefiturnewSetAllowLoanWithoutVisitor')) {
    function updatefiturnewSetAllowLoanWithoutVisitor(mysqli $dbs, bool $enabled): bool
    {
        return updatefiturnewUpsertSettingAliasValue(
            $dbs,
            [
                'updatefiturnew_no_visitor',
                'updatefiturnew_allow_no_visit',
                'ufn_no_visitor'
            ],
            $enabled ? '1' : '0'
        );
    }
}

if (!function_exists('updatefiturnewGetUseVisitorScheduleForLoan')) {
    function updatefiturnewGetUseVisitorScheduleForLoan(mysqli $dbs, bool $default = true): bool
    {
        $settingNames = [
            'updatefiturnew_use_vschedule',
            'updatefiturnew_use_visit_sched',
            'ufn_use_vschedule'
        ];

        foreach ($settingNames as $settingName) {
            $settingNameEsc = $dbs->escape_string($settingName);
            if ($query = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='{$settingNameEsc}' LIMIT 1")) {
                if ($row = $query->fetch_assoc()) {
                    $value = updatefiturnewParseBoolSetting($row['setting_value'] ?? '', $default);
                    $query->free_result();
                    return $value;
                }
                $query->free_result();
            }
        }

        return $default;
    }
}

if (!function_exists('updatefiturnewSetUseVisitorScheduleForLoan')) {
    function updatefiturnewSetUseVisitorScheduleForLoan(mysqli $dbs, bool $enabled): bool
    {
        return updatefiturnewUpsertSettingAliasValue(
            $dbs,
            [
                'updatefiturnew_use_vschedule',
                'updatefiturnew_use_visit_sched',
                'ufn_use_vschedule'
            ],
            $enabled ? '1' : '0'
        );
    }
}

if (!function_exists('updatefiturnewCountMemberLoanToday')) {
    function updatefiturnewCountMemberLoanToday(mysqli $dbs, string $memberId): int
    {
        $memberId = trim($memberId);
        if ($memberId === '') {
            return 0;
        }

        $todayStart = date('Y-m-d 00:00:00');
        $tomorrowStart = date('Y-m-d 00:00:00', strtotime('+1 day'));
        $requestCount = 0;
        $loanCount = 0;

        $requestSql = "SELECT COUNT(ri.request_item_id) AS total_req
                       FROM updatefiturnew_request AS r
                       INNER JOIN updatefiturnew_request_item AS ri ON r.request_id = ri.request_id
                       WHERE r.member_id = ?
                         AND r.action_type = 'loan'
                         AND r.status IN ('pending', 'processing', 'approved', 'partial')
                         AND r.requested_at >= ?
                         AND r.requested_at < ?";
        if ($stmt = $dbs->prepare($requestSql)) {
            $stmt->bind_param('sss', $memberId, $todayStart, $tomorrowStart);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res && ($row = $res->fetch_assoc())) {
                $requestCount = (int) ($row['total_req'] ?? 0);
            }
            $stmt->close();
        }

        $sql = "SELECT COUNT(1) AS total_loan
                FROM loan
                WHERE member_id = ?
                  AND loan_date >= ?
                  AND loan_date < ?";
        if ($stmt = $dbs->prepare($sql)) {
            $stmt->bind_param('sss', $memberId, $todayStart, $tomorrowStart);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res && ($row = $res->fetch_assoc())) {
                $loanCount = (int) ($row['total_loan'] ?? 0);
            }
            $stmt->close();
        }

        return max(0, max($requestCount, $loanCount));
    }
}

if (!function_exists('updatefiturnewGetDailyLoanUsage')) {
    function updatefiturnewGetDailyLoanUsage(mysqli $dbs, string $memberId, int $defaultLimit = 3): array
    {
        $limit = updatefiturnewGetDailyLoanLimit($dbs, $defaultLimit);
        $used = updatefiturnewCountMemberLoanToday($dbs, $memberId);
        $remaining = max(0, $limit - $used);

        return [
            'limit' => $limit,
            'used' => $used,
            'remaining' => $remaining
        ];
    }
}

if (!function_exists('updatefiturnewGetLoanStatusMeta')) {
    function updatefiturnewGetLoanStatusMeta(array $loan): array
    {
        $today = date('Y-m-d');
        $yesterday = date('Y-m-d', strtotime('-1 day'));

        $loanDate = trim((string) ($loan['loan_date'] ?? ''));
        $loanDateShort = preg_match('/^\d{4}-\d{2}-\d{2}/', $loanDate) ? substr($loanDate, 0, 10) : '';
        $dueDate = trim((string) ($loan['due_date'] ?? ''));
        $dueDateShort = preg_match('/^\d{4}-\d{2}-\d{2}/', $dueDate) ? substr($dueDate, 0, 10) : '';
        $renewed = (int) ($loan['renewed'] ?? 0);
        $isLent = (int) ($loan['is_lent'] ?? 1);
        $isReturn = (int) ($loan['is_return'] ?? 0);
        $isOverdue = (int) ($loan['is_overdue'] ?? 0) > 0;

        $recencyKey = 'past';
        $recencyLabel = 'Telah Lalu';
        if ($loanDateShort === $today) {
            $recencyKey = 'today';
            $recencyLabel = 'Hari Ini';
        } elseif ($loanDateShort === $yesterday) {
            $recencyKey = 'yesterday';
            $recencyLabel = 'Kemarin';
        }

        $stateKey = 'active';
        $stateLabel = 'Sedang Dipinjam';
        $stateBadge = 'warning';
        if ($isReturn === 1 || $isLent !== 1) {
            $stateKey = 'returned';
            $stateLabel = 'Sudah Dikembalikan';
            $stateBadge = 'secondary';
        } elseif ($isOverdue || ($dueDateShort !== '' && $dueDateShort < $today)) {
            $stateKey = 'overdue';
            $stateLabel = 'Terlambat';
            $stateBadge = 'danger';
        } elseif ($renewed > 0) {
            $stateKey = 'renewed';
            $stateLabel = 'Diperpanjang';
            $stateBadge = 'warning';
        }

        $rowClass = '';
        if ($stateKey === 'overdue') {
            $rowClass = 'updatefiturnew-row-overdue';
        } elseif ($stateKey === 'returned') {
            $rowClass = 'updatefiturnew-row-returned';
        } elseif ($stateKey === 'renewed') {
            $rowClass = 'updatefiturnew-row-extended';
        } elseif ($stateKey === 'active') {
            $rowClass = 'updatefiturnew-row-onloan';
        }

        return [
            'recency_key' => $recencyKey,
            'recency_label' => $recencyLabel,
            'state_key' => $stateKey,
            'state_label' => $stateLabel,
            'state_badge' => $stateBadge,
            'is_overdue' => $stateKey === 'overdue',
            'row_class' => $rowClass
        ];
    }
}

if (!function_exists('updatefiturnewFindItemByCode')) {
    function updatefiturnewFindItemByCode(mysqli $dbs, string $itemCode): ?array
    {
        $itemCode = trim($itemCode);
        if ($itemCode === '') {
            return null;
        }

        $sql = "SELECT i.item_code, i.item_status_id, b.title,
                       COALESCE(ist.no_loan, 0) AS no_loan,
                       COALESCE(ist.item_status_name, '') AS item_status_name,
                       COALESCE(loc.location_name, '') AS location_name,
                       (SELECT COUNT(1) FROM loan AS l WHERE l.item_code=i.item_code AND l.is_lent=1 AND l.is_return=0) AS on_loan
                FROM item AS i
                LEFT JOIN biblio AS b ON i.biblio_id = b.biblio_id
                LEFT JOIN mst_item_status AS ist ON i.item_status_id = ist.item_status_id
                LEFT JOIN mst_location AS loc ON i.location_id = loc.location_id
                WHERE i.item_code = ?
                LIMIT 1";

        if (!($stmt = $dbs->prepare($sql))) {
            return null;
        }

        $stmt->bind_param('s', $itemCode);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;
        $stmt->close();

        return $row ?: null;
    }
}

if (!function_exists('updatefiturnewGetItemsByCodes')) {
    function updatefiturnewGetItemsByCodes(mysqli $dbs, array $itemCodes): array
    {
        $map = [];
        if (count($itemCodes) < 1) {
            return $map;
        }

        $cleanCodes = [];
        foreach ($itemCodes as $itemCode) {
            $itemCode = trim((string) $itemCode);
            if ($itemCode === '') {
                continue;
            }
            $cleanCodes[$itemCode] = $itemCode;
        }
        if (count($cleanCodes) < 1) {
            return $map;
        }

        $in = [];
        foreach ($cleanCodes as $itemCode) {
            $in[] = "'" . $dbs->real_escape_string($itemCode) . "'";
        }
        if (count($in) < 1) {
            return $map;
        }

        $sql = "SELECT i.item_code, i.item_status_id, b.title,
                       COALESCE(ist.no_loan, 0) AS no_loan,
                       COALESCE(ist.item_status_name, '') AS item_status_name,
                       COALESCE(loc.location_name, '') AS location_name,
                       (SELECT COUNT(1) FROM loan AS l WHERE l.item_code=i.item_code AND l.is_lent=1 AND l.is_return=0) AS on_loan
                FROM item AS i
                LEFT JOIN biblio AS b ON i.biblio_id = b.biblio_id
                LEFT JOIN mst_item_status AS ist ON i.item_status_id = ist.item_status_id
                LEFT JOIN mst_location AS loc ON i.location_id = loc.location_id
                WHERE i.item_code IN (" . implode(',', $in) . ")";

        if ($query = $dbs->query($sql)) {
            while ($row = $query->fetch_assoc()) {
                $code = (string) ($row['item_code'] ?? '');
                if ($code === '') {
                    continue;
                }
                $map[$code] = $row;
            }
            $query->free_result();
        }

        return $map;
    }
}

if (!function_exists('updatefiturnewGetPendingRequestMapForMemberItems')) {
    function updatefiturnewGetPendingRequestMapForMemberItems(mysqli $dbs, string $memberId, array $itemCodes): array
    {
        $memberId = trim($memberId);
        if ($memberId === '' || count($itemCodes) < 1) {
            return [];
        }

        $cleanCodes = [];
        foreach ($itemCodes as $itemCode) {
            $itemCode = trim((string) $itemCode);
            if ($itemCode === '') {
                continue;
            }
            $cleanCodes[$itemCode] = $itemCode;
        }
        if (count($cleanCodes) < 1) {
            return [];
        }

        $in = [];
        foreach ($cleanCodes as $itemCode) {
            $in[] = "'" . $dbs->real_escape_string($itemCode) . "'";
        }
        if (count($in) < 1) {
            return [];
        }

        $memberEsc = $dbs->real_escape_string($memberId);
        $sql = "SELECT ri.item_code, r.request_id, r.action_type
                FROM updatefiturnew_request AS r
                INNER JOIN updatefiturnew_request_item AS ri ON r.request_id = ri.request_id
                WHERE r.member_id = '{$memberEsc}'
                  AND r.status = 'pending'
                  AND ri.item_code IN (" . implode(',', $in) . ")
                ORDER BY r.request_id DESC";

        $map = [];
        if ($query = $dbs->query($sql)) {
            while ($row = $query->fetch_assoc()) {
                $itemCode = (string) ($row['item_code'] ?? '');
                if ($itemCode === '' || isset($map[$itemCode])) {
                    continue;
                }
                $map[$itemCode] = [
                    'request_id' => (int) ($row['request_id'] ?? 0),
                    'action_type' => (string) ($row['action_type'] ?? '')
                ];
            }
            $query->free_result();
        }

        return $map;
    }
}

if (!function_exists('updatefiturnewGetPendingRequestMapForMemberLoanIds')) {
    function updatefiturnewGetPendingRequestMapForMemberLoanIds(mysqli $dbs, string $memberId, array $loanIds): array
    {
        $memberId = trim($memberId);
        if ($memberId === '' || count($loanIds) < 1) {
            return [];
        }

        $cleanLoanIds = [];
        foreach ($loanIds as $loanId) {
            $loanId = (int) $loanId;
            if ($loanId > 0) {
                $cleanLoanIds[$loanId] = $loanId;
            }
        }
        if (count($cleanLoanIds) < 1) {
            return [];
        }

        $in = implode(',', $cleanLoanIds);
        $memberEsc = $dbs->real_escape_string($memberId);

        $sql = "SELECT ri.loan_id, r.request_id, r.action_type
                FROM updatefiturnew_request AS r
                INNER JOIN updatefiturnew_request_item AS ri ON r.request_id = ri.request_id
                WHERE r.member_id = '{$memberEsc}'
                  AND r.status IN ('pending', 'processing')
                  AND ri.loan_id IN ({$in})
                ORDER BY r.request_id DESC";

        $map = [];
        if ($query = $dbs->query($sql)) {
            while ($row = $query->fetch_assoc()) {
                $loanId = (int) ($row['loan_id'] ?? 0);
                if ($loanId < 1 || isset($map[$loanId])) {
                    continue;
                }
                $map[$loanId] = [
                    'request_id' => (int) ($row['request_id'] ?? 0),
                    'action_type' => (string) ($row['action_type'] ?? '')
                ];
            }
            $query->free_result();
        }

        return $map;
    }
}

if (!function_exists('updatefiturnewValidateExtendLoan')) {
    function updatefiturnewValidateExtendLoan(mysqli $dbs, string $memberId, int $loanId, int $maxExtendLimit = 2): array
    {
        $memberId = trim($memberId);
        $loanId = (int) $loanId;
        $maxExtendLimit = max(0, min(20, $maxExtendLimit));

        $result = [
            'allowed' => false,
            'message' => '',
            'loan' => null
        ];

        if ($memberId === '' || $loanId < 1) {
            $result['message'] = 'Loan ID tidak valid.';
            return $result;
        }

        $sql = "SELECT loan_id, member_id, item_code, loan_date, due_date, renewed, is_lent, is_return
                FROM loan
                WHERE loan_id = ? AND member_id = ?
                LIMIT 1";
        if (!($stmt = $dbs->prepare($sql))) {
            $result['message'] = 'Gagal menyiapkan validasi loan.';
            return $result;
        }

        $stmt->bind_param('is', $loanId, $memberId);
        $stmt->execute();
        $queryResult = $stmt->get_result();
        $loan = $queryResult ? $queryResult->fetch_assoc() : null;
        $stmt->close();

        if (!$loan) {
            $result['message'] = 'Data pinjaman tidak ditemukan untuk member ini.';
            return $result;
        }

        if ((int) ($loan['is_lent'] ?? 0) !== 1 || (int) ($loan['is_return'] ?? 0) === 1) {
            $result['message'] = 'Status pinjaman tidak aktif atau sudah dikembalikan.';
            return $result;
        }

        $renewed = (int) ($loan['renewed'] ?? 0);
        if ($maxExtendLimit < 1) {
            $result['message'] = 'Perpanjangan sedang dinonaktifkan oleh admin.';
            return $result;
        }
        if ($renewed >= $maxExtendLimit) {
            $result['message'] = 'Batas perpanjangan tercapai untuk Loan ID #' . $loanId . '. Maksimal ' . $maxExtendLimit . 'x.';
            return $result;
        }

        $result['allowed'] = true;
        $result['loan'] = $loan;
        return $result;
    }
}

if (!function_exists('updatefiturnewComputeExtensionDueDateFromPrevious')) {
    function updatefiturnewComputeExtensionDueDateFromPrevious(
        mysqli $dbs,
        int $loanId,
        string $memberId,
        string $previousDueDate
    ): string {
        $loanId = (int) $loanId;
        $memberId = trim($memberId);
        $baseDueDate = trim($previousDueDate);

        if ($loanId < 1 || $memberId === '') {
            return '';
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}/', $baseDueDate)) {
            $baseDueDate = date('Y-m-d');
        } else {
            $baseDueDate = substr($baseDueDate, 0, 10);
        }

        $loanPeriode = 0;
        $loanDate = '';
        $ruleSql = "SELECT l.loan_date,
                           l.due_date,
                           COALESCE(lr.loan_periode, 0) AS loan_periode_rule,
                           COALESCE(mt.loan_periode, 0) AS loan_periode_member
                    FROM loan AS l
                    LEFT JOIN mst_loan_rules AS lr ON lr.loan_rules_id = l.loan_rules_id
                    LEFT JOIN member AS m ON m.member_id = l.member_id
                    LEFT JOIN mst_member_type AS mt ON mt.member_type_id = m.member_type_id
                    WHERE l.loan_id = ? AND l.member_id = ?
                    LIMIT 1";
        if ($ruleStmt = $dbs->prepare($ruleSql)) {
            $ruleStmt->bind_param('is', $loanId, $memberId);
            $ruleStmt->execute();
            $ruleResult = $ruleStmt->get_result();
            if ($ruleResult && ($ruleRow = $ruleResult->fetch_assoc())) {
                $loanDate = trim((string) ($ruleRow['loan_date'] ?? ''));
                $loanPeriode = (int) ($ruleRow['loan_periode_rule'] ?? 0);
                if ($loanPeriode < 1) {
                    $loanPeriode = (int) ($ruleRow['loan_periode_member'] ?? 0);
                }
            }
            $ruleStmt->close();
        }

        if ($loanPeriode < 1) {
            $loanDateOnly = preg_match('/^\d{4}-\d{2}-\d{2}/', $loanDate) ? substr($loanDate, 0, 10) : '';
            if ($loanDateOnly !== '') {
                $diffDays = (int) floor((strtotime($baseDueDate) - strtotime($loanDateOnly)) / 86400);
                if ($diffDays > 0 && $diffDays <= 365) {
                    $loanPeriode = $diffDays;
                }
            }
        }
        if ($loanPeriode < 1) {
            return '';
        }

        // Extend from previous due date so each renewal adds period cumulatively.
        $newDueDate = simbio_date::getNextDate($loanPeriode, $baseDueDate);
        $holidayDayName = $_SESSION['holiday_dayname'] ?? ['Sun'];
        $holidayDate = $_SESSION['holiday_date'] ?? [];
        $newDueDate = simbio_date::getNextDateNotHoliday($newDueDate, $holidayDayName, $holidayDate);

        return trim((string) $newDueDate);
    }
}

if (!function_exists('updatefiturnewGetOnLoanCountMapByItemCodes')) {
    function updatefiturnewGetOnLoanCountMapByItemCodes(mysqli $dbs, array $itemCodes): array
    {
        $map = [];
        if (count($itemCodes) < 1) {
            return $map;
        }

        $cleanCodes = [];
        foreach ($itemCodes as $itemCode) {
            $itemCode = trim((string) $itemCode);
            if ($itemCode === '') {
                continue;
            }
            $cleanCodes[$itemCode] = $itemCode;
        }
        if (count($cleanCodes) < 1) {
            return $map;
        }

        $in = [];
        foreach ($cleanCodes as $itemCode) {
            $in[] = "'" . $dbs->real_escape_string($itemCode) . "'";
        }
        if (count($in) < 1) {
            return $map;
        }

        $sql = "SELECT item_code, COUNT(1) AS total_on_loan
                FROM loan
                WHERE is_lent = 1
                  AND is_return = 0
                  AND item_code IN (" . implode(',', $in) . ")
                GROUP BY item_code";
        if ($query = $dbs->query($sql)) {
            while ($row = $query->fetch_assoc()) {
                $itemCode = (string) ($row['item_code'] ?? '');
                if ($itemCode === '') {
                    continue;
                }
                $map[$itemCode] = (int) ($row['total_on_loan'] ?? 0);
            }
            $query->free_result();
        }

        return $map;
    }
}

if (!function_exists('updatefiturnewGetActiveLoans')) {
    function updatefiturnewGetActiveLoans(mysqli $dbs, string $memberId): array
    {
        $rows = [];
        $memberId = trim($memberId);
        if ($memberId === '') {
            return $rows;
        }

        $sql = "SELECT l.loan_id, l.item_code, l.loan_date, l.due_date, l.renewed,
                       l.is_lent, l.is_return,
                       COALESCE(b.title, '-') AS title,
                       COALESCE(loc.location_name, '-') AS item_location,
                       CASE WHEN l.due_date < CURDATE() THEN 1 ELSE 0 END AS is_overdue
                FROM loan AS l
                LEFT JOIN item AS i ON l.item_code = i.item_code
                LEFT JOIN biblio AS b ON i.biblio_id = b.biblio_id
                LEFT JOIN mst_location AS loc ON i.location_id = loc.location_id
                WHERE l.member_id = ?
                  AND l.is_lent = 1
                  AND l.is_return = 0
                ORDER BY l.loan_id DESC";

        if (!($stmt = $dbs->prepare($sql))) {
            return $rows;
        }

        $stmt->bind_param('s', $memberId);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($result && ($row = $result->fetch_assoc())) {
            $rows[] = $row;
        }
        $stmt->close();

        return $rows;
    }
}

if (!function_exists('updatefiturnewCreateRequest')) {
    function updatefiturnewCreateRequest(mysqli $dbs, array $header, array $items, string &$error = ''): ?array
    {
        $error = '';

        if (count($items) < 1) {
            $error = 'Item transaksi belum dipilih.';
            return null;
        }

        $actionType = updatefiturnewNormalizeText((string) ($header['action_type'] ?? ''), 20);
        if (!in_array($actionType, ['loan', 'return', 'extend', 'renew', 'renewal'], true)) {
            $error = 'Aksi transaksi tidak valid.';
            return null;
        }

        $requestCode = updatefiturnewGenerateRequestCode();
        $requestedAt = updatefiturnewNow();
        $updatedAt = $requestedAt;

        $memberId = updatefiturnewNormalizeText((string) ($header['member_id'] ?? ''), 20);
        if ($memberId === '') {
            $error = 'Member ID tidak valid.';
            return null;
        }

        $memberEmail = updatefiturnewNormalizeText((string) ($header['member_email'] ?? ''), 120);
        $memberName = updatefiturnewNormalizeText((string) ($header['member_name'] ?? ''), 120);
        $memberTypeName = updatefiturnewNormalizeText((string) ($header['member_type_name'] ?? ''), 80);
        $visitLocation = updatefiturnewNormalizeText((string) ($header['visit_location'] ?? ''), 120);
        $requestNote = trim((string) ($header['request_note'] ?? ''));
        if ($requestNote !== '') {
            $requestNote = updatefiturnewNormalizeText($requestNote, 5000);
        }
        $createdIp = updatefiturnewNormalizeText((string) ($header['created_ip'] ?? ''), 45);

        $dbs->begin_transaction();

        try {
            $sql = "INSERT INTO updatefiturnew_request
                    (request_code, member_id, member_email, member_name, member_type_name, visit_location,
                     action_type, status, request_note, requested_at, created_ip, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?)";
            $stmt = $dbs->prepare($sql);
            if (!$stmt) {
                throw new Exception('Gagal menyiapkan query header request.');
            }

            $stmt->bind_param(
                'sssssssssss',
                $requestCode,
                $memberId,
                $memberEmail,
                $memberName,
                $memberTypeName,
                $visitLocation,
                $actionType,
                $requestNote,
                $requestedAt,
                $createdIp,
                $updatedAt
            );

            if (!$stmt->execute()) {
                $stmt->close();
                throw new Exception('Gagal menyimpan header request.');
            }
            $requestId = (int) $dbs->insert_id;
            $stmt->close();

            $itemSql = "INSERT INTO updatefiturnew_request_item
                        (request_id, item_code, loan_id, item_status, process_message, created_at, updated_at)
                        VALUES (?, ?, ?, 'pending', NULL, ?, ?)";
            $itemStmt = $dbs->prepare($itemSql);
            if (!$itemStmt) {
                throw new Exception('Gagal menyiapkan query item request.');
            }

            foreach ($items as $item) {
                $itemCode = updatefiturnewNormalizeText((string) ($item['item_code'] ?? ''), 80);
                $loanId = (int) ($item['loan_id'] ?? 0);
                $loanIdParam = $loanId > 0 ? $loanId : null;

                if ($itemCode === '' && $loanIdParam === null) {
                    continue;
                }

                $itemStmt->bind_param('isiss', $requestId, $itemCode, $loanIdParam, $requestedAt, $updatedAt);
                if (!$itemStmt->execute()) {
                    throw new Exception('Gagal menyimpan item request.');
                }
            }
            $itemStmt->close();

            $dbs->commit();

            return [
                'request_id' => $requestId,
                'request_code' => $requestCode
            ];
        } catch (Throwable $e) {
            $dbs->rollback();
            $error = $e->getMessage();
            return null;
        }
    }
}

if (!function_exists('updatefiturnewStatusLabel')) {
    function updatefiturnewStatusLabel(string $status): string
    {
        $map = [
            'pending' => 'Pending',
            'processing' => 'Diproses',
            'approved' => 'Disetujui',
            'rejected' => 'Ditolak',
            'partial' => 'Parsial',
            'failed' => 'Gagal'
        ];

        return $map[$status] ?? ucfirst($status);
    }
}

if (!function_exists('updatefiturnewActionLabel')) {
    function updatefiturnewActionLabel(string $action): string
    {
        $map = [
            'loan' => 'Pinjam',
            'return' => 'Kembali',
            'extend' => 'Perpanjang',
            'renew' => 'Perpanjang',
            'renewal' => 'Perpanjang',

        ];

        return $map[$action] ?? strtoupper($action);
    }
}

if (!function_exists('updatefiturnewBadgeClass')) {
    function updatefiturnewBadgeClass(string $status): string
    {
        $map = [
            'pending' => 'warning',
            'processing' => 'info',
            'approved' => 'success',
            'rejected' => 'danger',
            'partial' => 'primary',
            'failed' => 'secondary'
        ];

        return $map[$status] ?? 'secondary';
    }
}

if (!function_exists('updatefiturnewGetRequestsByMemberId')) {
    function updatefiturnewGetRequestsByMemberId(mysqli $dbs, string $memberId, int $limit = 30): array
    {
        $rows = [];
        $memberId = trim($memberId);
        $limit = max(1, min(200, $limit));
        if ($memberId === '') {
            return $rows;
        }

        $sql = "SELECT r.request_id, r.request_code, r.member_id, r.member_name, r.member_email,
                       r.member_type_name, r.visit_location, r.action_type, r.status,
                       r.request_note, r.admin_note, r.process_result, r.requested_at,
                       r.decided_at, r.processed_at,
                       COUNT(i.request_item_id) AS item_total,
                       SUM(CASE WHEN i.item_status='approved' THEN 1 ELSE 0 END) AS item_approved,
                       SUM(CASE WHEN i.item_status='failed' THEN 1 ELSE 0 END) AS item_failed,
                       SUM(CASE WHEN i.item_status='rejected' THEN 1 ELSE 0 END) AS item_rejected,
                       GROUP_CONCAT(
                         CASE
                           WHEN i.item_code IS NULL OR i.item_code = '' THEN CONCAT('#LOAN-', COALESCE(i.loan_id, 0))
                           WHEN i.loan_id IS NULL OR i.loan_id = 0 THEN i.item_code
                           ELSE CONCAT(i.item_code, ' (#', i.loan_id, ')')
                         END
                         ORDER BY i.request_item_id ASC
                         SEPARATOR ', '
                       ) AS item_list
                FROM updatefiturnew_request AS r
                LEFT JOIN updatefiturnew_request_item AS i ON r.request_id = i.request_id
                WHERE r.member_id = ?
                GROUP BY r.request_id
                ORDER BY r.request_id DESC
                LIMIT {$limit}";

        if (!($stmt = $dbs->prepare($sql))) {
            return $rows;
        }

        $stmt->bind_param('s', $memberId);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($result && ($row = $result->fetch_assoc())) {
            $rows[] = $row;
        }
        $stmt->close();

        return $rows;
    }
}

if (!function_exists('updatefiturnewGetRequestById')) {
    function updatefiturnewGetRequestById(mysqli $dbs, int $requestId): ?array
    {
        $sql = "SELECT * FROM updatefiturnew_request WHERE request_id = ? LIMIT 1";
        if (!($stmt = $dbs->prepare($sql))) {
            return null;
        }

        $stmt->bind_param('i', $requestId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;
        $stmt->close();

        return $row ?: null;
    }
}

if (!function_exists('updatefiturnewGetRequestItems')) {
    function updatefiturnewGetRequestItems(mysqli $dbs, int $requestId): array
    {
        $rows = [];
        $sql = "SELECT * FROM updatefiturnew_request_item WHERE request_id = ? ORDER BY request_item_id ASC";
        if (!($stmt = $dbs->prepare($sql))) {
            return $rows;
        }

        $stmt->bind_param('i', $requestId);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($result && ($row = $result->fetch_assoc())) {
            $rows[] = $row;
        }
        $stmt->close();

        return $rows;
    }
}

if (!function_exists('updatefiturnewLoadCirculationLibraries')) {
    function updatefiturnewLoadCirculationLibraries(): void
    {
        if (!class_exists('simbio_dbop', false)) {
            require_once SIMBIO . 'simbio_DB/simbio_dbop.inc.php';
        }
        if (!class_exists('simbio_date', false)) {
            require_once SIMBIO . 'simbio_UTILS/simbio_date.inc.php';
        }
        if (!class_exists('member', false)) {
            require_once MDLBS . 'membership/member_base_lib.inc.php';
        }
        if (!class_exists('circapi', false)) {
            require_once LIB . 'circulation_api.inc.php';
        }
        if (!class_exists('circulation', false)) {
            require_once MDLBS . 'circulation/circulation_base_lib.inc.php';
        }

        // Safety: ensure circulation constants are defined (in case loaded out of order)
        if (!defined('ITEM_SESSION_ADDED')) {
            define('ITEM_SESSION_ADDED', 3);
        }
        if (!defined('ITEM_UNAVAILABLE')) {
            define('ITEM_UNAVAILABLE', 4);
        }
        if (!defined('TRANS_FLUSH_ERROR')) {
            define('TRANS_FLUSH_ERROR', 5);
        }
        if (!defined('TRANS_FLUSH_SUCCESS')) {
            define('TRANS_FLUSH_SUCCESS', 6);
        }
        if (!defined('LOAN_NOT_PERMITTED')) {
            define('LOAN_NOT_PERMITTED', 7);
        }
        if (!defined('LOAN_NOT_PERMITTED_PENDING')) {
            define('LOAN_NOT_PERMITTED_PENDING', 8);
        }
        if (!defined('ITEM_LOAN_FORBID')) {
            define('ITEM_LOAN_FORBID', 9);
        }
        if (!defined('ITEM_RESERVED')) {
            define('ITEM_RESERVED', 10);
        }
        if (!defined('LOAN_LIMIT_REACHED')) {
            define('LOAN_LIMIT_REACHED', 2);
        }
        if (!defined('ITEM_NOT_FOUND')) {
            define('ITEM_NOT_FOUND', 1);
        }
    }
}

if (!function_exists('updatefiturnewMapAddLoanCodeMessage')) {
    function updatefiturnewMapAddLoanCodeMessage($code): string
    {
        $map = [
            LOAN_LIMIT_REACHED => 'Batas pinjaman anggota sudah penuh.',
            ITEM_NOT_FOUND => 'Item / barcode tidak ditemukan.',
            ITEM_UNAVAILABLE => 'Item sedang dipinjam anggota lain.',
            LOAN_NOT_PERMITTED => 'Keanggotaan sudah kedaluwarsa.',
            LOAN_NOT_PERMITTED_PENDING => 'Keanggotaan masih pending persetujuan.',
            ITEM_LOAN_FORBID => 'Item tidak boleh dipinjam.',
            ITEM_RESERVED => 'Item sedang direservasi anggota lain.'
        ];

        return $map[$code] ?? 'Gagal menambahkan item ke transaksi pinjam.';
    }
}

if (!function_exists('updatefiturnewBackupSession')) {
    function updatefiturnewBackupSession(array $keys): array
    {
        $snapshot = [];
        foreach ($keys as $key) {
            $snapshot[$key] = [
                'exists' => array_key_exists($key, $_SESSION),
                'value' => $_SESSION[$key] ?? null
            ];
        }
        return $snapshot;
    }
}

if (!function_exists('updatefiturnewRestoreSession')) {
    function updatefiturnewRestoreSession(array $snapshot): void
    {
        foreach ($snapshot as $key => $info) {
            if (!is_array($info) || !array_key_exists('exists', $info)) {
                continue;
            }
            if ($info['exists']) {
                $_SESSION[$key] = $info['value'];
            } else {
                unset($_SESSION[$key]);
            }
        }
    }
}

if (!function_exists('updatefiturnewExecuteApprovedAction')) {
    function updatefiturnewExecuteApprovedAction(mysqli $dbs, array $request, array $items, array $adminInfo, array $sysconf = []): array
    {
        updatefiturnewLoadCirculationLibraries();

        $memberId = (string) ($request['member_id'] ?? '');
        $actionType = (string) ($request['action_type'] ?? 'loan');
        $adminUid = (int) ($adminInfo['uid'] ?? ($_SESSION['uid'] ?? 0));

        $result = [
            'item_updates' => [],
            'success_count' => 0,
            'failed_count' => 0,
            'summary' => ''
        ];

        $sessionSnapshot = updatefiturnewBackupSession([
            'memberID',
            'temp_loan',
            'reborrowed',
            'receipt_record',
            'uid'
        ]);

        $_SESSION['memberID'] = $memberId;
        $_SESSION['uid'] = $adminUid;
        $_SESSION['temp_loan'] = [];
        $_SESSION['reborrowed'] = [];
        unset($_SESSION['receipt_record']);

        try {
            $circulation = new circulation($dbs, $dbs->escape_string($memberId));
            $circulation->ignore_holidays_fine_calc = $sysconf['ignore_holidays_fine_calc'] ?? false;
            $circulation->holiday_dayname = $_SESSION['holiday_dayname'] ?? ['Sun'];
            $circulation->holiday_date = $_SESSION['holiday_date'] ?? [];

            if (!$circulation->valid()) {
                error_log('[PEMINJAMAN DEBUG] Member NOT valid for memberId=' . $memberId);
                foreach ($items as $item) {
                    $result['item_updates'][(int) $item['request_item_id']] = [
                        'status' => 'failed',
                        'message' => 'Member tidak valid / tidak ditemukan.'
                    ];
                    $result['failed_count']++;
                }

                $result['summary'] = 'Member tidak valid, proses dibatalkan.';
                return $result;
            }

            if ($actionType === 'loan') {
                $queuedItems = [];
                $dailyLimit = updatefiturnewGetDailyLoanLimit($dbs, 3);
                // Request yang sedang diproses sudah berstatus "processing",
                // jadi count harian akan ikut menghitung request ini juga.
                // Kurangi jumlah item request saat ini agar kuota tidak "termakan diri sendiri".
                $usedTodayRaw = updatefiturnewCountMemberLoanToday($dbs, $memberId);
                $usedToday = max(0, $usedTodayRaw - count($items));
                $remainingQuota = max(0, $dailyLimit - $usedToday);

                foreach ($items as $item) {
                    $itemId = (int) $item['request_item_id'];
                    $itemCode = trim((string) ($item['item_code'] ?? ''));
                    if ($itemCode === '') {
                        $result['item_updates'][$itemId] = [
                            'status' => 'failed',
                            'message' => 'Item code kosong.'
                        ];
                        $result['failed_count']++;
                        continue;
                    }

                    if ($remainingQuota < 1) {
                        $result['item_updates'][$itemId] = [
                            'status' => 'failed',
                            'message' => 'Batas pinjam harian tercapai. Maksimal ' . $dailyLimit . ' buku per hari.'
                        ];
                        $result['failed_count']++;
                        continue;
                    }

                    $add = $circulation->addLoanSession($itemCode);
                    error_log('[PEMINJAMAN DEBUG] addLoanSession(' . $itemCode . ') returned: ' . var_export($add, true));
                    if ($add === ITEM_SESSION_ADDED) {
                        $queuedItems[$itemId] = $itemCode;
                        $remainingQuota--;
                        continue;
                    }

                    $result['item_updates'][$itemId] = [
                        'status' => 'failed',
                        'message' => updatefiturnewMapAddLoanCodeMessage($add)
                    ];
                    $result['failed_count']++;
                }

                if (count($queuedItems) > 0) {
                    $flush = $circulation->finishLoanSession();
                    error_log('[PEMINJAMAN DEBUG] finishLoanSession returned: ' . var_export($flush, true) . ', error: ' . var_export($circulation->error ?? '', true));
                    error_log('[PEMINJAMAN DEBUG] temp_loan after flush: ' . var_export($_SESSION['temp_loan'] ?? '(unset)', true));

                    if ($flush === TRANS_FLUSH_SUCCESS) {
                        $loanLookupSql = "SELECT loan_id
                                          FROM loan
                                          WHERE member_id = ? AND item_code = ?
                                          ORDER BY loan_id DESC
                                          LIMIT 1";
                        $loanLookupStmt = $dbs->prepare($loanLookupSql);

                        foreach ($queuedItems as $itemId => $itemCode) {
                            $resolvedLoanId = 0;
                            if ($loanLookupStmt) {
                                $loanLookupStmt->bind_param('ss', $memberId, $itemCode);
                                $loanLookupStmt->execute();
                                $loanLookupResult = $loanLookupStmt->get_result();
                                if ($loanLookupResult && ($loanLookupRow = $loanLookupResult->fetch_assoc())) {
                                    $resolvedLoanId = (int) ($loanLookupRow['loan_id'] ?? 0);
                                }
                                if ($loanLookupResult) {
                                    $loanLookupResult->free_result();
                                }
                            }

                            $result['item_updates'][$itemId] = [
                                'status' => 'approved',
                                'message' => 'Peminjaman disetujui dan transaksi berhasil dibuat.',
                                'loan_id' => $resolvedLoanId > 0 ? $resolvedLoanId : null
                            ];
                            $result['success_count']++;
                        }

                        if ($loanLookupStmt) {
                            $loanLookupStmt->close();
                        }
                    } else {
                        $errorMessage = trim((string) $circulation->error);
                        if ($errorMessage === '') {
                            $errorMessage = 'Gagal menyimpan transaksi peminjaman.';
                        }
                        foreach ($queuedItems as $itemId => $itemCode) {
                            $result['item_updates'][$itemId] = [
                                'status' => 'failed',
                                'message' => $errorMessage
                            ];
                            $result['failed_count']++;
                        }
                    }
                }
            } elseif ($actionType === 'return') {
                foreach ($items as $item) {
                    $itemId = (int) $item['request_item_id'];
                    $loanId = (int) ($item['loan_id'] ?? 0);
                    $itemCode = trim((string) ($item['item_code'] ?? ''));

                    if ($loanId < 1 && $itemCode !== '') {
                        $loanSql = "SELECT loan_id, item_code, is_lent, is_return FROM loan
                                    WHERE member_id=? AND item_code=?
                                    ORDER BY loan_id DESC LIMIT 1";
                        if ($loanStmt = $dbs->prepare($loanSql)) {
                            $loanStmt->bind_param('ss', $memberId, $itemCode);
                            $loanStmt->execute();
                            $loanResult = $loanStmt->get_result();
                            if ($loanRow = $loanResult->fetch_assoc()) {
                                $loanId = (int) $loanRow['loan_id'];
                            }
                            $loanStmt->close();
                        }
                    }

                    if ($loanId < 1) {
                        $result['item_updates'][$itemId] = [
                            'status' => 'failed',
                            'message' => 'Loan ID tidak valid.'
                        ];
                        $result['failed_count']++;
                        continue;
                    }

                    $loanCheckSql = "SELECT loan_id, item_code, is_lent, is_return FROM loan WHERE loan_id=? AND member_id=? LIMIT 1";
                    $loanData = null;
                    if ($loanCheckStmt = $dbs->prepare($loanCheckSql)) {
                        $loanCheckStmt->bind_param('is', $loanId, $memberId);
                        $loanCheckStmt->execute();
                        $loanResult = $loanCheckStmt->get_result();
                        if ($loanResult) {
                            $loanData = $loanResult->fetch_assoc();
                        }
                        $loanCheckStmt->close();
                    }

                    if (!$loanData) {
                        $result['item_updates'][$itemId] = [
                            'status' => 'failed',
                            'message' => 'Data pinjaman tidak ditemukan untuk member ini.'
                        ];
                        $result['failed_count']++;
                        continue;
                    }

                    if ((int) $loanData['is_lent'] !== 1 || (int) $loanData['is_return'] === 1) {
                        $result['item_updates'][$itemId] = [
                            'status' => 'failed',
                            'message' => 'Status pinjaman tidak aktif / sudah dikembalikan.'
                        ];
                        $result['failed_count']++;
                        continue;
                    }

                    $returnStatus = $circulation->returnItem($loanId);
                    if ($returnStatus === true || $returnStatus === ITEM_RESERVED) {
                        $result['item_updates'][$itemId] = [
                            'status' => 'approved',
                            'message' => $returnStatus === ITEM_RESERVED
                                ? 'Dikembalikan. Catatan: item sedang direservasi anggota lain.'
                                : 'Pengembalian berhasil diproses.'
                        ];
                        $result['success_count']++;
                    } else {
                        $result['item_updates'][$itemId] = [
                            'status' => 'failed',
                            'message' => 'Gagal memproses pengembalian.'
                        ];
                        $result['failed_count']++;
                    }
                }
            } elseif (in_array($actionType, ['extend', 'renew', 'renewal'], true)) {
                $maxExtendLimit = updatefiturnewGetMaxExtendLimit($dbs, 2);
                foreach ($items as $item) {
                    $itemId = (int) ($item['request_item_id'] ?? 0);
                    $loanId = (int) ($item['loan_id'] ?? 0);
                    $itemCode = trim((string) ($item['item_code'] ?? ''));

                    if ($loanId < 1 && $itemCode !== '') {
                        $loanSql = "SELECT loan_id
                                    FROM loan
                                    WHERE member_id = ?
                                      AND item_code = ?
                                      AND is_lent = 1
                                      AND is_return = 0
                                    ORDER BY loan_id DESC
                                    LIMIT 1";
                        if ($loanStmt = $dbs->prepare($loanSql)) {
                            $loanStmt->bind_param('ss', $memberId, $itemCode);
                            $loanStmt->execute();
                            $loanResult = $loanStmt->get_result();
                            if ($loanResult && ($loanRow = $loanResult->fetch_assoc())) {
                                $loanId = (int) ($loanRow['loan_id'] ?? 0);
                            }
                            $loanStmt->close();
                        }
                    }

                    $validation = updatefiturnewValidateExtendLoan($dbs, $memberId, $loanId, $maxExtendLimit);
                    if (empty($validation['allowed'])) {
                        $result['item_updates'][$itemId] = [
                            'status' => 'failed',
                            'message' => (string) ($validation['message'] ?? 'Perpanjangan tidak diizinkan.')
                        ];
                        $result['failed_count']++;
                        continue;
                    }
                    $previousDueDate = trim((string) (($validation['loan']['due_date'] ?? '')));

                    $extendStatus = $circulation->extendItemLoan($loanId);
                    if ($extendStatus === ITEM_RESERVED) {
                        $result['item_updates'][$itemId] = [
                            'status' => 'failed',
                            'message' => 'Perpanjangan ditolak: item sedang direservasi anggota lain.'
                        ];
                        $result['failed_count']++;
                        continue;
                    }

                    if ($extendStatus !== true) {
                        $result['item_updates'][$itemId] = [
                            'status' => 'failed',
                            'message' => 'Gagal memproses perpanjangan.'
                        ];
                        $result['failed_count']++;
                        continue;
                    }

                    $extendedDueDate = updatefiturnewComputeExtensionDueDateFromPrevious($dbs, $loanId, $memberId, $previousDueDate);
                    if ($extendedDueDate !== '') {
                        $overrideSql = "UPDATE loan
                                        SET due_date = ?
                                        WHERE loan_id = ? AND member_id = ?
                                        LIMIT 1";
                        if ($overrideStmt = $dbs->prepare($overrideSql)) {
                            $overrideStmt->bind_param('sis', $extendedDueDate, $loanId, $memberId);
                            $overrideStmt->execute();
                            $overrideStmt->close();
                        }
                    }

                    $newDueDate = '';
                    $newRenewed = null;
                    $refreshSql = "SELECT due_date, renewed FROM loan WHERE loan_id = ? LIMIT 1";
                    if ($refreshStmt = $dbs->prepare($refreshSql)) {
                        $refreshStmt->bind_param('i', $loanId);
                        $refreshStmt->execute();
                        $refreshResult = $refreshStmt->get_result();
                        if ($refreshResult && ($refreshRow = $refreshResult->fetch_assoc())) {
                            $newDueDate = trim((string) ($refreshRow['due_date'] ?? ''));
                            $newRenewed = isset($refreshRow['renewed']) ? (int) $refreshRow['renewed'] : null;
                        }
                        $refreshStmt->close();
                    }

                    $message = 'Perpanjangan berhasil diproses.';
                    if ($newDueDate !== '') {
                        $message .= ' Due date baru: ' . $newDueDate . '.';
                    }
                    if ($newRenewed !== null) {
                        $message .= ' Total perpanjangan: ' . $newRenewed . 'x.';
                    }

                    $result['item_updates'][$itemId] = [
                        'status' => 'approved',
                        'message' => $message,
                        'loan_id' => $loanId
                    ];
                    $result['success_count']++;
                }
            } else {
                foreach ($items as $item) {
                    $result['item_updates'][(int) $item['request_item_id']] = [
                        'status' => 'failed',
                        'message' => 'Jenis aksi tidak didukung.'
                    ];
                    $result['failed_count']++;
                }
            }

            if ($result['success_count'] > 0 && $result['failed_count'] > 0) {
                $result['summary'] = 'Sebagian item berhasil diproses.';
            } elseif ($result['success_count'] > 0) {
                $result['summary'] = 'Semua item berhasil diproses.';
            } else {
                $result['summary'] = 'Tidak ada item yang berhasil diproses.';
            }

            return $result;
        } finally {
            updatefiturnewRestoreSession($sessionSnapshot);
        }
    }
}

if (!function_exists('updatefiturnewProcessRequest')) {
    function updatefiturnewProcessRequest(mysqli $dbs, int $requestId, bool $approve, string $adminNote, array $adminInfo, array $sysconf = []): array
    {
        $request = updatefiturnewGetRequestById($dbs, $requestId);
        if (!$request) {
            return [
                'ok' => false,
                'message' => 'Data request tidak ditemukan.'
            ];
        }

        $currentStatus = strtolower(trim((string) ($request['status'] ?? '')));
        if ($currentStatus === '') {
            $currentStatus = 'pending';
        }

        if (!$approve) {
            if ($currentStatus === 'rejected') {
                return [
                    'ok' => true,
                    'message' => 'Request sudah ditolak sebelumnya.',
                    'final_status' => 'rejected'
                ];
            }
            if (!in_array($currentStatus, ['pending', 'processing'], true)) {
                return [
                    'ok' => false,
                    'message' => 'Request ini sudah diproses sebelumnya.'
                ];
            }
        } elseif ($currentStatus !== 'pending') {
            return [
                'ok' => false,
                'message' => 'Request ini sudah diproses sebelumnya.'
            ];
        }

        $items = updatefiturnewGetRequestItems($dbs, $requestId);
        $adminUid = (int) ($adminInfo['uid'] ?? 0);
        $adminUsername = updatefiturnewNormalizeText((string) ($adminInfo['username'] ?? ''), 100);
        $adminNote = trim($adminNote);
        $now = updatefiturnewNow();

        if (!$approve) {
            $rejectNote = $adminNote !== '' ? $adminNote : 'Ditolak oleh admin.';

            $updateSql = "UPDATE updatefiturnew_request
                          SET status='rejected', admin_uid=?, admin_username=?, admin_note=?,
                              process_result=?, decided_at=?, processed_at=?, updated_at=?
                          WHERE request_id=? AND LOWER(TRIM(status)) IN ('pending','processing')";

            if (!($stmt = $dbs->prepare($updateSql))) {
                return ['ok' => false, 'message' => 'Gagal menyiapkan query penolakan request.'];
            }

            $processResult = 'Request ditolak admin.';
            $stmt->bind_param('issssssi', $adminUid, $adminUsername, $rejectNote, $processResult, $now, $now, $now, $requestId);
            $stmt->execute();
            $affected = $stmt->affected_rows;
            $stmt->close();

            if ($affected < 1) {
                $latest = updatefiturnewGetRequestById($dbs, $requestId);
                $latestStatus = strtolower(trim((string) ($latest['status'] ?? '')));
                if ($latestStatus === 'rejected') {
                    return ['ok' => true, 'message' => 'Request sudah ditolak sebelumnya.', 'final_status' => 'rejected'];
                }
                return ['ok' => false, 'message' => 'Request sudah diproses oleh admin lain.'];
            }

            $itemUpdateSql = "UPDATE updatefiturnew_request_item
                              SET item_status='rejected', process_message=?, updated_at=?
                              WHERE request_id=? AND LOWER(TRIM(item_status)) IN ('pending','processing')";
            if ($itemStmt = $dbs->prepare($itemUpdateSql)) {
                $itemMessage = 'Ditolak admin: ' . $rejectNote;
                $itemStmt->bind_param('ssi', $itemMessage, $now, $requestId);
                $itemStmt->execute();
                $itemStmt->close();
            }

            return [
                'ok' => true,
                'message' => 'Request berhasil ditolak.',
                'final_status' => 'rejected'
            ];
        }

        $lockSql = "UPDATE updatefiturnew_request
                    SET status='processing', admin_uid=?, admin_username=?, admin_note=?, decided_at=?, updated_at=?
                    WHERE request_id=? AND LOWER(TRIM(status))='pending'";
        if (!($lockStmt = $dbs->prepare($lockSql))) {
            return ['ok' => false, 'message' => 'Gagal menyiapkan query approval request.'];
        }

        $lockStmt->bind_param('issssi', $adminUid, $adminUsername, $adminNote, $now, $now, $requestId);
        $lockStmt->execute();
        $locked = $lockStmt->affected_rows;
        $lockStmt->close();

        if ($locked < 1) {
            return ['ok' => false, 'message' => 'Request sudah diproses oleh admin lain.'];
        }

        $process = updatefiturnewExecuteApprovedAction($dbs, $request, $items, $adminInfo, $sysconf);

        $successCount = (int) ($process['success_count'] ?? 0);
        $failedCount = (int) ($process['failed_count'] ?? 0);

        $finalStatus = 'failed';
        if ($successCount > 0 && $failedCount > 0) {
            $finalStatus = 'partial';
        } elseif ($successCount > 0) {
            $finalStatus = 'approved';
        }

        $itemUpdates = $process['item_updates'] ?? [];
        foreach ($itemUpdates as $itemId => $itemUpdate) {
            $status = updatefiturnewNormalizeText((string) ($itemUpdate['status'] ?? 'failed'), 20);
            $message = updatefiturnewNormalizeText((string) ($itemUpdate['message'] ?? ''), 255);

            $loanId = (int) ($itemUpdate['loan_id'] ?? 0);
            $itemSql = "UPDATE updatefiturnew_request_item
                        SET item_status=?, process_message=?,
                            loan_id = CASE WHEN ? > 0 THEN ? ELSE loan_id END,
                            updated_at=?
                        WHERE request_item_id=?";
            if ($itemStmt = $dbs->prepare($itemSql)) {
                $itemStmt->bind_param('ssiisi', $status, $message, $loanId, $loanId, $now, $itemId);
                $itemStmt->execute();
                $itemStmt->close();
            }
        }

        $summary = trim((string) ($process['summary'] ?? ''));
        if ($summary === '') {
            $summary = sprintf('Berhasil: %d item, Gagal: %d item', $successCount, $failedCount);
        }

        $updateSql = "UPDATE updatefiturnew_request
                      SET status=?, admin_uid=?, admin_username=?, admin_note=?,
                          process_result=?, processed_at=?, updated_at=?
                      WHERE request_id=?";

        if (!($stmt = $dbs->prepare($updateSql))) {
            return ['ok' => false, 'message' => 'Gagal memperbarui status akhir request.'];
        }

        $stmt->bind_param('sisssssi', $finalStatus, $adminUid, $adminUsername, $adminNote, $summary, $now, $now, $requestId);
        $stmt->execute();
        $stmt->close();

        return [
            'ok' => true,
            'message' => 'Request berhasil diproses.',
            'final_status' => $finalStatus,
            'success_count' => $successCount,
            'failed_count' => $failedCount
        ];
    }
}

if (!function_exists('updatefiturnewBuildAdminFilterSql')) {
    function updatefiturnewBuildAdminFilterSql(mysqli $dbs, array $filters): array
    {
        $where = [];

        $status = trim((string) ($filters['status'] ?? 'all'));
        if ($status !== '' && $status !== 'all') {
            $allowed = ['pending', 'processing', 'approved', 'rejected', 'partial', 'failed'];
            if (in_array($status, $allowed, true)) {
                $where[] = "r.status = '" . $dbs->escape_string($status) . "'";
            }
        }

        $action = trim((string) ($filters['action_type'] ?? 'all'));
        if ($action !== '' && $action !== 'all') {
            $allowedAction = ['loan', 'return', 'extend', 'renew', 'renewal'];
            if (in_array($action, $allowedAction, true)) {
                $where[] = "r.action_type = '" . $dbs->escape_string($action) . "'";
            }
        }

        $location = trim((string) ($filters['visit_location'] ?? 'all'));
        if ($location !== '' && $location !== 'all') {
            $where[] = "TRIM(COALESCE(r.visit_location, '')) = '" . $dbs->escape_string($location) . "'";
        }

        $dateFrom = trim((string) ($filters['date_from'] ?? ''));
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) {
            $where[] = "r.requested_at >= '" . $dbs->escape_string($dateFrom) . " 00:00:00'";
        }

        $dateTo = trim((string) ($filters['date_to'] ?? ''));
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) {
            $where[] = "r.requested_at <= '" . $dbs->escape_string($dateTo) . " 23:59:59'";
        }

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $kw = $dbs->escape_string($keyword);
            $where[] = "(
                r.request_code LIKE '%{$kw}%'
                OR r.member_id LIKE '%{$kw}%'
                OR r.member_name LIKE '%{$kw}%'
                OR r.member_email LIKE '%{$kw}%'
                OR r.visit_location LIKE '%{$kw}%'
                OR EXISTS (
                    SELECT 1 FROM updatefiturnew_request_item i2
                    WHERE i2.request_id = r.request_id
                      AND (
                        COALESCE(i2.item_code, '') LIKE '%{$kw}%'
                        OR CAST(COALESCE(i2.loan_id, 0) AS CHAR) LIKE '%{$kw}%'
                      )
                )
            )";
        }

        $whereSql = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';

        return [
            'where_sql' => $whereSql,
            'status' => $status,
            'action_type' => $action,
            'visit_location' => $location,
            'keyword' => $keyword,
            'date_from' => $dateFrom,
            'date_to' => $dateTo
        ];
    }
}

if (!function_exists('updatefiturnewGetDistinctVisitLocations')) {
    function updatefiturnewGetDistinctVisitLocations(mysqli $dbs): array
    {
        $options = [];
        $sql = "SELECT DISTINCT TRIM(COALESCE(visit_location, '')) AS visit_location
                FROM updatefiturnew_request
                WHERE visit_location IS NOT NULL AND TRIM(visit_location) <> ''
                ORDER BY visit_location ASC";
        if ($query = $dbs->query($sql)) {
            while ($row = $query->fetch_assoc()) {
                $label = trim((string) ($row['visit_location'] ?? ''));
                if ($label === '') {
                    continue;
                }
                $options[$label] = $label;
            }
            $query->free_result();
        }
        return array_values($options);
    }
}

if (!function_exists('updatefiturnewBuildRequestSummaryRow')) {
    function updatefiturnewBuildRequestSummaryRow(array $row): string
    {
        $statusLabel = updatefiturnewStatusLabel((string) ($row['status'] ?? 'pending'));
        $actionLabel = updatefiturnewActionLabel((string) ($row['action_type'] ?? 'loan'));
        $itemTotal = (int) ($row['item_total'] ?? 0);
        $itemList = trim((string) ($row['item_list'] ?? ''));
        $summary = $actionLabel . ' - ' . $statusLabel . ' - ' . $itemTotal . ' item';
        if ($itemList !== '') {
            $summary .= ' [' . $itemList . ']';
        }
        return $summary;
    }
}

/**
 * Refresh member data from DB in real-time. Prevents stale session data
 * if admin changes member type, expiry, or pending status while user is logged in.
 */
if (!function_exists('updatefiturnewGetMemberFresh')) {
    function updatefiturnewGetMemberFresh(mysqli $dbs, string $memberId): ?array
    {
        $memberId = trim($memberId);
        if ($memberId === '') {
            return null;
        }

        $sql = "SELECT m.member_id, m.member_name, m.member_email,
                       m.member_type_id, mt.member_type_name,
                       m.register_date, m.expire_date,
                       m.is_pending, m.inst_name, m.member_image,
                       m.member_notes
                FROM member AS m
                LEFT JOIN mst_member_type AS mt ON m.member_type_id = mt.member_type_id
                WHERE m.member_id = ?
                LIMIT 1";

        if (!($stmt = $dbs->prepare($sql))) {
            return null;
        }

        $stmt->bind_param('s', $memberId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;
        $stmt->close();

        return $row ?: null;
    }
}

if (!function_exists('updatefiturnewGetMemberFreshByName')) {
    function updatefiturnewGetMemberFreshByName(mysqli $dbs, string $memberName): ?array
    {
        $memberName = trim($memberName);
        if ($memberName === '') {
            return null;
        }

        $sql = "SELECT m.member_id, m.member_name, m.member_email,
                       m.member_type_id, mt.member_type_name,
                       m.register_date, m.expire_date,
                       m.is_pending, m.inst_name, m.member_image,
                       m.member_notes
                FROM member AS m
                LEFT JOIN mst_member_type AS mt ON m.member_type_id = mt.member_type_id
                WHERE LOWER(TRIM(COALESCE(m.member_name, ''))) = LOWER(TRIM(?))
                ORDER BY m.is_pending ASC, m.expire_date DESC, m.member_id ASC
                LIMIT 1";

        if (!($stmt = $dbs->prepare($sql))) {
            return null;
        }

        $stmt->bind_param('s', $memberName);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;
        $stmt->close();

        return $row ?: null;
    }
}

if (!function_exists('updatefiturnewGetMemberStatusMapByIds')) {
    function updatefiturnewGetMemberStatusMapByIds(mysqli $dbs, array $memberIds): array
    {
        $map = [];
        if (count($memberIds) < 1) {
            return $map;
        }

        $cleanIds = [];
        foreach ($memberIds as $memberId) {
            $memberId = trim((string) $memberId);
            if ($memberId === '') {
                continue;
            }
            $cleanIds[$memberId] = $memberId;
        }
        if (count($cleanIds) < 1) {
            return $map;
        }

        $in = [];
        foreach ($cleanIds as $memberId) {
            $in[] = "'" . $dbs->real_escape_string($memberId) . "'";
        }
        if (count($in) < 1) {
            return $map;
        }

        $sql = "SELECT member_id, is_pending, expire_date
                FROM member
                WHERE member_id IN (" . implode(',', $in) . ")";
        if ($query = $dbs->query($sql)) {
            while ($row = $query->fetch_assoc()) {
                $memberId = (string) ($row['member_id'] ?? '');
                if ($memberId === '') {
                    continue;
                }
                $map[$memberId] = [
                    'is_pending' => (int) ($row['is_pending'] ?? 0),
                    'expire_date' => trim((string) ($row['expire_date'] ?? ''))
                ];
            }
            $query->free_result();
        }

        return $map;
    }
}

/**
 * Get item details for status check display - shows biblio title and item location
 * for each request_item row.
 */
if (!function_exists('updatefiturnewGetItemDetailForStatus')) {
    function updatefiturnewGetItemDetailForStatus(mysqli $dbs, int $requestId): array
    {
        $rows = [];
        $sql = "SELECT ri.item_code, ri.loan_id, ri.item_status, ri.process_message,
                       COALESCE(b.title, '-') AS title,
                       COALESCE(loc.location_name, '-') AS item_location,
                       (SELECT COUNT(1) FROM loan AS l2 WHERE l2.item_code = ri.item_code AND l2.is_lent=1 AND l2.is_return=0) AS currently_on_loan
                FROM updatefiturnew_request_item AS ri
                LEFT JOIN item AS i ON ri.item_code = i.item_code
                LEFT JOIN biblio AS b ON i.biblio_id = b.biblio_id
                LEFT JOIN mst_location AS loc ON i.location_id = loc.location_id
                WHERE ri.request_id = ?
                ORDER BY ri.request_item_id ASC";

        if (!($stmt = $dbs->prepare($sql))) {
            return $rows;
        }

        $stmt->bind_param('i', $requestId);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($result && ($row = $result->fetch_assoc())) {
            $rows[] = $row;
        }
        $stmt->close();

        return $rows;
    }
}

if (!function_exists('updatefiturnewGetItemDetailMapForRequests')) {
    function updatefiturnewGetItemDetailMapForRequests(mysqli $dbs, array $requestIds): array
    {
        $map = [];
        if (count($requestIds) < 1) {
            return $map;
        }

        $cleanIds = [];
        foreach ($requestIds as $requestId) {
            $requestId = (int) $requestId;
            if ($requestId > 0) {
                $cleanIds[$requestId] = $requestId;
            }
        }
        if (count($cleanIds) < 1) {
            return $map;
        }

        $idList = implode(',', $cleanIds);
        $sql = "SELECT ri.request_id, ri.item_code, ri.loan_id, ri.item_status, ri.process_message,
                       COALESCE(b.title, '-') AS title,
                       COALESCE(loc.location_name, '-') AS item_location,
                       (SELECT COUNT(1) FROM loan AS l2 WHERE l2.item_code = ri.item_code AND l2.is_lent=1 AND l2.is_return=0) AS currently_on_loan
                FROM updatefiturnew_request_item AS ri
                LEFT JOIN item AS i ON ri.item_code = i.item_code
                LEFT JOIN biblio AS b ON i.biblio_id = b.biblio_id
                LEFT JOIN mst_location AS loc ON i.location_id = loc.location_id
                WHERE ri.request_id IN ({$idList})
                ORDER BY ri.request_id ASC, ri.request_item_id ASC";

        if ($query = $dbs->query($sql)) {
            while ($row = $query->fetch_assoc()) {
                $rid = (int) ($row['request_id'] ?? 0);
                if ($rid < 1) {
                    continue;
                }
                if (!isset($map[$rid])) {
                    $map[$rid] = [];
                }
                $map[$rid][] = $row;
            }
            $query->free_result();
        }

        return $map;
    }
}
