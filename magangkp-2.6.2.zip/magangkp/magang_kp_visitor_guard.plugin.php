<?php
/**
 * Plugin Name: Magangkpfitur - Visitor Menu & Guard (Modular Version)
 * Plugin URI: https://github.com/Isal0192/silsperpus.git
 * Description: Modul buku tamu kustom dengan fitur Rombongan dan akurasi pelaporan admin. Menyembunyikan link slimsinfo di OPAC.
 * Version: 2.6.2
 * Author: Faisal Fajar, Irsyad
 * Author URI: https://github.com/Isal0192
 * Created by: Faisal Fajar (faisalfajar1305@gmail.com), Irsyad
 */

use SLiMS\Plugins;
use MagangKp\Database;
use MagangKp\UI;

if (defined('MAGANGKP_VISITOR_BOOTSTRAPPED')) {
    return;
}
define('MAGANGKP_VISITOR_BOOTSTRAPPED', true);

// Load core logic secara manual (karena plugin SLiMS tidak memiliki autoloader standar untuk subfolder)
require __DIR__ . '/src/Database.php';
require __DIR__ . '/src/UI.php';
require __DIR__ . '/src/VisitorLogic.php';

/**
 * Inisialisasi Plugin
 */

// 1. Jalankan migrasi basis data (cek kolom group_count)
Database::migrate();

// 2. Daftarkan menu Visitor di OPAC
UI::registerVisitorMenu(__DIR__);

// 2b. Daftarkan menu Visitor di admin (Reporting)
UI::registerAdminVisitorMenu(__DIR__);

// 3. Pasang Hook untuk modifikasi tampilan OPAC dan blokir akses slimsinfo
Plugins::getInstance()->register(Plugins::CONTENT_BEFORE_LOAD, function ($opac) {
    UI::tweakOpacInterface($opac);
});

// Pakai modul updateterbaru yang dibundel agar URL mengikuti peminjaman/visitor.
define('MAGANGKPFITUR_USE_UPDATETERBARU', true);
$updateTerbaruModule = __DIR__ . '/updateterbaru/updateterbaru.module.php';
if (is_file($updateTerbaruModule)) {
    require_once $updateTerbaruModule;
}
