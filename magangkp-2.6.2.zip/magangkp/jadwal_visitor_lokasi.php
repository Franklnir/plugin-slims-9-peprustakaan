<?php
/**
 * Visitor Schedule Admin Page
 * Separate page for managing opening hours per location and holidays.
 */

defined('INDEX_AUTH') or die('Direct access not allowed!');

if (!function_exists('do_checkIP')) {
    require LIB . 'ip_based_access.inc.php';
}
do_checkIP('smc');
do_checkIP('smc-reporting');

if (session_status() !== PHP_SESSION_ACTIVE) {
    require SB . 'admin/default/session.inc.php';
}
if (!defined('MAGANGKP_ADMIN_SESSION_CHECKED')) {
    require SB . 'admin/default/session_check.inc.php';
    define('MAGANGKP_ADMIN_SESSION_CHECKED', 1);
}

$canRead = utility::havePrivilege('reporting', 'r');
$canWrite = utility::havePrivilege('reporting', 'w');

if (!$canRead) {
    die('<div class="errorBox">' . __('You don\'t have enough privileges to access this area!') . '</div>');
}

if (!function_exists('magangKpScheduleHasColumn')) {
    function magangKpScheduleHasColumn(mysqli $dbs, string $column): bool
    {
        if ($query = $dbs->query("SHOW COLUMNS FROM visitor_count LIKE '" . $dbs->escape_string($column) . "'")) {
            $exists = $query->num_rows > 0;
            $query->free_result();
            return $exists;
        }
        return false;
    }
}

if (!function_exists('magangKpScheduleLocationOptions')) {
    function magangKpScheduleLocationOptions(mysqli $dbs, bool $hasVisitLocation): array
    {
        $options = [];

        if ($settingQuery = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='lokasimaps_locations' LIMIT 1")) {
            if ($settingRow = $settingQuery->fetch_assoc()) {
                $stored = @unserialize($settingRow['setting_value']);
                if (is_array($stored)) {
                    foreach ($stored as $locationRow) {
                        if (!is_array($locationRow)) {
                            continue;
                        }
                        $label = trim(strip_tags((string)($locationRow['label'] ?? '')));
                        if ($label === '') {
                            continue;
                        }
                        $options[$label] = $label;
                    }
                }
            }
            $settingQuery->free_result();
        }

        if ($hasVisitLocation && ($visitQuery = $dbs->query("SELECT DISTINCT TRIM(visit_location) AS visit_location FROM visitor_count WHERE visit_location IS NOT NULL AND TRIM(visit_location) <> '' ORDER BY visit_location ASC"))) {
            while ($visitRow = $visitQuery->fetch_assoc()) {
                $label = trim((string)($visitRow['visit_location'] ?? ''));
                if ($label === '') {
                    continue;
                }
                $options[$label] = $label;
            }
            $visitQuery->free_result();
        }

        return array_values($options);
    }
}

if (!function_exists('magangKpScheduleSettingName')) {
    function magangKpScheduleSettingName(): string
    {
        return 'magangkp_visit_schedule';
    }
}

if (!function_exists('magangKpScheduleDayLabels')) {
    function magangKpScheduleDayLabels(): array
    {
        return [
            'monday' => 'Senin',
            'tuesday' => 'Selasa',
            'wednesday' => 'Rabu',
            'thursday' => 'Kamis',
            'friday' => 'Jumat',
            'saturday' => 'Sabtu',
            'sunday' => 'Minggu'
        ];
    }
}

if (!function_exists('magangKpScheduleDefaultDayMap')) {
    function magangKpScheduleDefaultDayMap(): array
    {
        $defaults = [];
        foreach (array_keys(magangKpScheduleDayLabels()) as $dayKey) {
            $defaults[$dayKey] = [
                'open' => 1,
                'open_time' => '08:00',
                'close_time' => '16:00'
            ];
        }
        return $defaults;
    }
}

if (!function_exists('magangKpScheduleNormalizeTime')) {
    function magangKpScheduleNormalizeTime(string $value, string $fallback): string
    {
        $value = trim($value);
        if (!preg_match('/^\d{2}:\d{2}$/', $value)) {
            return $fallback;
        }
        $hour = (int)substr($value, 0, 2);
        $minute = (int)substr($value, 3, 2);
        if ($hour < 0 || $hour > 23 || $minute < 0 || $minute > 59) {
            return $fallback;
        }
        return sprintf('%02d:%02d', $hour, $minute);
    }
}

if (!function_exists('magangKpScheduleValidDate')) {
    function magangKpScheduleValidDate(string $value): bool
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return false;
        }
        $dateObj = DateTime::createFromFormat('Y-m-d', $value);
        return $dateObj && $dateObj->format('Y-m-d') === $value;
    }
}

if (!function_exists('magangKpScheduleLoadConfig')) {
    function magangKpScheduleLoadConfig(mysqli $dbs): array
    {
        $nameEsc = $dbs->escape_string(magangKpScheduleSettingName());
        $rawValue = '';
        if ($query = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='{$nameEsc}' LIMIT 1")) {
            if ($row = $query->fetch_assoc()) {
                $rawValue = (string)($row['setting_value'] ?? '');
            }
            $query->free_result();
        }

        if ($rawValue === '') {
            return ['schedules' => [], 'holidays' => []];
        }

        $decoded = @unserialize($rawValue);
        if (!is_array($decoded)) {
            $decoded = json_decode($rawValue, true);
        }
        if (!is_array($decoded)) {
            return ['schedules' => [], 'holidays' => []];
        }

        $dayLabels = magangKpScheduleDayLabels();
        $defaultDay = magangKpScheduleDefaultDayMap();
        $normalized = ['schedules' => [], 'holidays' => []];

        $rawSchedules = is_array($decoded['schedules'] ?? null) ? $decoded['schedules'] : [];
        foreach ($rawSchedules as $location => $dayMap) {
            $locationName = trim(strip_tags((string)$location));
            if ($locationName === '' || !is_array($dayMap)) {
                continue;
            }

            $normalizedDay = $defaultDay;
            foreach ($dayLabels as $dayKey => $dayLabel) {
                $dayConfig = is_array($dayMap[$dayKey] ?? null) ? $dayMap[$dayKey] : [];
                $openRaw = $dayConfig['open'] ?? 0;
                $normalizedDay[$dayKey] = [
                    'open' => ($openRaw === 1 || $openRaw === '1' || $openRaw === true || $openRaw === 'true' || $openRaw === 'on') ? 1 : 0,
                    'open_time' => magangKpScheduleNormalizeTime((string)($dayConfig['open_time'] ?? ''), '08:00'),
                    'close_time' => magangKpScheduleNormalizeTime((string)($dayConfig['close_time'] ?? ''), '16:00')
                ];
            }
            $normalized['schedules'][$locationName] = $normalizedDay;
        }

        $rawHolidays = is_array($decoded['holidays'] ?? null) ? $decoded['holidays'] : [];
        $seenHoliday = [];
        foreach ($rawHolidays as $holidayRow) {
            if (!is_array($holidayRow)) {
                continue;
            }

            $startDate = trim((string)($holidayRow['start_date'] ?? ($holidayRow['date'] ?? '')));
            $endDate = trim((string)($holidayRow['end_date'] ?? ($holidayRow['date'] ?? '')));
            if (!magangKpScheduleValidDate($startDate)) {
                continue;
            }
            if (!magangKpScheduleValidDate($endDate)) {
                $endDate = $startDate;
            }
            if ($endDate < $startDate) {
                $temp = $startDate;
                $startDate = $endDate;
                $endDate = $temp;
            }

            $name = trim(strip_tags((string)($holidayRow['name'] ?? '')));
            if (function_exists('mb_substr')) {
                $name = mb_substr($name, 0, 120, 'UTF-8');
            } else {
                $name = substr($name, 0, 120);
            }

            $location = trim(strip_tags((string)($holidayRow['location'] ?? 'all')));
            if ($location === '') {
                $location = 'all';
            }

            $key = $startDate . '|' . $endDate . '|' . $location . '|' . $name;
            if (isset($seenHoliday[$key])) {
                continue;
            }
            $seenHoliday[$key] = true;

            $normalized['holidays'][] = [
                'start_date' => $startDate,
                'end_date' => $endDate,
                'name' => $name,
                'location' => $location
            ];
        }

        return $normalized;
    }
}

if (!function_exists('magangKpScheduleSaveConfig')) {
    function magangKpScheduleSaveConfig(mysqli $dbs, array $payload): bool
    {
        $nameEsc = $dbs->escape_string(magangKpScheduleSettingName());
        $valueEsc = $dbs->escape_string(serialize($payload));
        $sql = "INSERT INTO setting (setting_name, setting_value) VALUES ('{$nameEsc}', '{$valueEsc}') "
            . "ON DUPLICATE KEY UPDATE setting_value='{$valueEsc}'";
        return (bool)$dbs->query($sql);
    }
}

if (!function_exists('magangKpScheduleSanitizeMap')) {
    function magangKpScheduleSanitizeMap(string $rawJson, array $allowedLocations): array
    {
        $decoded = json_decode($rawJson, true);
        if (!is_array($decoded)) {
            $decoded = [];
        }

        $dayLabels = magangKpScheduleDayLabels();
        $defaultDay = magangKpScheduleDefaultDayMap();
        $allowedMap = [];
        foreach ($allowedLocations as $location) {
            $label = trim((string)$location);
            if ($label !== '') {
                $allowedMap[$label] = $label;
            }
        }

        $result = [];
        foreach ($allowedMap as $locationName) {
            $dayMap = is_array($decoded[$locationName] ?? null) ? $decoded[$locationName] : [];
            $normalizedDay = $defaultDay;
            foreach ($dayLabels as $dayKey => $dayLabel) {
                $dayConfig = is_array($dayMap[$dayKey] ?? null) ? $dayMap[$dayKey] : [];
                $openRaw = $dayConfig['open'] ?? ($defaultDay[$dayKey]['open'] ?? 1);
                $normalizedDay[$dayKey] = [
                    'open' => ($openRaw === 1 || $openRaw === '1' || $openRaw === true || $openRaw === 'true' || $openRaw === 'on') ? 1 : 0,
                    'open_time' => magangKpScheduleNormalizeTime((string)($dayConfig['open_time'] ?? ($defaultDay[$dayKey]['open_time'] ?? '08:00')), '08:00'),
                    'close_time' => magangKpScheduleNormalizeTime((string)($dayConfig['close_time'] ?? ($defaultDay[$dayKey]['close_time'] ?? '16:00')), '16:00')
                ];
            }
            $result[$locationName] = $normalizedDay;
        }

        return $result;
    }
}

if (!function_exists('magangKpScheduleSanitizeHolidays')) {
    function magangKpScheduleSanitizeHolidays(array $holidayStarts, array $holidayEnds, array $holidayNames, array $holidayLocations, array $allowedLocations): array
    {
        $allowedMap = ['all' => 'all'];
        foreach ($allowedLocations as $location) {
            $label = trim((string)$location);
            if ($label !== '') {
                $allowedMap[$label] = $label;
            }
        }

        $total = max(count($holidayStarts), count($holidayEnds), count($holidayNames), count($holidayLocations));
        $result = [];
        $seen = [];

        for ($i = 0; $i < $total; $i++) {
            $startDate = trim((string)($holidayStarts[$i] ?? ''));
            $endDate = trim((string)($holidayEnds[$i] ?? ''));
            if (!magangKpScheduleValidDate($startDate)) {
                continue;
            }
            if (!magangKpScheduleValidDate($endDate)) {
                $endDate = $startDate;
            }
            if ($endDate < $startDate) {
                $temp = $startDate;
                $startDate = $endDate;
                $endDate = $temp;
            }

            $name = trim(strip_tags((string)($holidayNames[$i] ?? '')));
            if (function_exists('mb_substr')) {
                $name = mb_substr($name, 0, 120, 'UTF-8');
            } else {
                $name = substr($name, 0, 120);
            }

            $location = trim(strip_tags((string)($holidayLocations[$i] ?? 'all')));
            if (!isset($allowedMap[$location])) {
                $location = 'all';
            }

            $key = $startDate . '|' . $endDate . '|' . $location . '|' . $name;
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;

            $result[] = [
                'start_date' => $startDate,
                'end_date' => $endDate,
                'name' => $name,
                'location' => $location
            ];
        }

        usort($result, static function (array $a, array $b): int {
            return strcmp($a['start_date'], $b['start_date']);
        });

        return $result;
    }
}

$pluginId = utility::filterData('id', 'get', false, true, true);
$basePageUrl = AWB . 'plugin_container.php';
$formAction = $basePageUrl . '?mod=reporting&id=' . urlencode((string)$pluginId);

$hasVisitLocation = magangKpScheduleHasColumn($dbs, 'visit_location');
$visitLocationOptions = magangKpScheduleLocationOptions($dbs, $hasVisitLocation);
if (count($visitLocationOptions) < 1) {
    $fallbackLocation = trim(strip_tags((string)($sysconf['library_name'] ?? 'Lokasi Utama')));
    if ($fallbackLocation !== '') {
        $visitLocationOptions[] = $fallbackLocation;
    }
}

$dayLabels = magangKpScheduleDayLabels();
$scheduleConfig = magangKpScheduleLoadConfig($dbs);
$visitSchedules = is_array($scheduleConfig['schedules'] ?? null) ? $scheduleConfig['schedules'] : [];
$visitHolidays = is_array($scheduleConfig['holidays'] ?? null) ? $scheduleConfig['holidays'] : [];
$scheduleLocations = array_values($visitLocationOptions);

if (!function_exists('magangKpScheduleCurrentStatuses')) {
    function magangKpScheduleCurrentStatuses(array $locations): array
    {
        $rows = [];
        foreach ($locations as $location) {
            $label = trim((string)$location);
            if ($label === '') {
                continue;
            }

            $window = \MagangKp\VisitorLogic::getVisitWindowStatus($label);
            $rows[] = [
                'location' => $label,
                'allowed' => !empty($window['allowed']),
                'reason' => (string)($window['reason'] ?? ''),
                'time' => (string)($window['time'] ?? date('H:i')),
                'day_label' => (string)($window['day_label'] ?? ''),
                'open_time' => (string)($window['open_time'] ?? ''),
                'close_time' => (string)($window['close_time'] ?? '')
            ];
        }
        return $rows;
    }
}

if ((string)(utility::filterData('ajax', 'get', false, true, true) ?? '') === 'status_now') {
    die(\SLiMS\Json::stringify([
        'status' => true,
        'checked_at' => date('Y-m-d H:i:s'),
        'rows' => magangKpScheduleCurrentStatuses($scheduleLocations)
    ])->withHeader());
}

$flashType = '';
$flashMessage = '';

if (isset($_POST['save_visit_schedule'])) {
    if (!$canWrite) {
        $flashType = 'danger';
        $flashMessage = __('You don\'t have enough privileges to modify visitor schedule!');
    } else {
        $rawScheduleMap = (string)($_POST['schedule_map_json'] ?? '');
        $sanitizedSchedules = magangKpScheduleSanitizeMap($rawScheduleMap, $visitLocationOptions);
        $sanitizedHolidays = magangKpScheduleSanitizeHolidays(
            is_array($_POST['holiday_start_date'] ?? null) ? $_POST['holiday_start_date'] : [],
            is_array($_POST['holiday_end_date'] ?? null) ? $_POST['holiday_end_date'] : [],
            is_array($_POST['holiday_name'] ?? null) ? $_POST['holiday_name'] : [],
            is_array($_POST['holiday_location'] ?? null) ? $_POST['holiday_location'] : [],
            $visitLocationOptions
        );

        $payload = [
            'version' => 1,
            'updated_at' => date('Y-m-d H:i:s'),
            'schedules' => $sanitizedSchedules,
            'holidays' => $sanitizedHolidays
        ];

        if (magangKpScheduleSaveConfig($dbs, $payload)) {
            utility::loadSettings($dbs);
            $scheduleConfig = magangKpScheduleLoadConfig($dbs);
            $visitSchedules = is_array($scheduleConfig['schedules'] ?? null) ? $scheduleConfig['schedules'] : [];
            $visitHolidays = is_array($scheduleConfig['holidays'] ?? null) ? $scheduleConfig['holidays'] : [];
            $flashType = 'success';
            $flashMessage = 'Jadwal visitor berhasil disimpan.';
        } else {
            $flashType = 'danger';
            $flashMessage = 'Gagal menyimpan jadwal visitor.';
        }
    }
}

$scheduleLocationsJson = json_encode($scheduleLocations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$scheduleMapJson = json_encode($visitSchedules, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$defaultDayScheduleJson = json_encode(magangKpScheduleDefaultDayMap(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$initialStatusRowsJson = json_encode(magangKpScheduleCurrentStatuses($scheduleLocations), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$statusNowUrl = $formAction . '&ajax=status_now';
?>

<style>
  .mkp-schedule-wrap .menuBoxInner {
    padding: 18px 20px;
  }
  .mkp-schedule-wrap .mkp-schedule-card {
    border: 1px solid #dbe6ef;
    border-radius: 12px;
    background: #ffffff;
    padding: 16px;
  }
  .mkp-schedule-wrap .mkp-schedule-title {
    margin-bottom: 10px;
  }
  .mkp-schedule-wrap .mkp-schedule-title h5 {
    margin: 0 0 3px;
  }
  .mkp-schedule-wrap .mkp-schedule-title p {
    margin: 0;
    color: #5c6b7a;
  }
  .mkp-schedule-wrap .mkp-schedule-day-table {
    min-width: 650px;
  }
  .mkp-schedule-wrap .mkp-schedule-day-table td,
  .mkp-schedule-wrap .mkp-schedule-day-table th {
    white-space: nowrap;
  }
  .mkp-schedule-wrap .mkp-schedule-day-table .form-control[type="time"] {
    min-width: 120px;
  }
  .mkp-schedule-wrap .mkp-holiday-table {
    min-width: 700px;
  }
  .mkp-schedule-wrap .mkp-holiday-table .mkp-holiday-remove {
    white-space: nowrap;
  }
  .mkp-schedule-wrap .mkp-schedule-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 10px;
  }
  .mkp-schedule-wrap .mkp-status-card {
    border: 1px solid #dbe6ef;
    border-radius: 12px;
    background: #ffffff;
    padding: 16px;
    margin-top: 16px;
  }
  .mkp-schedule-wrap .mkp-status-card h5 {
    margin: 0 0 8px;
  }
  .mkp-schedule-wrap .mkp-status-table {
    min-width: 780px;
  }
  .mkp-schedule-wrap .mkp-status-open {
    color: #166534;
    font-weight: 800;
  }
  .mkp-schedule-wrap .mkp-status-closed {
    color: #b91c1c;
    font-weight: 800;
  }
  .mkp-schedule-wrap .mkp-status-foot {
    margin-top: 8px;
    font-size: 12px;
    color: #64748b;
  }
  @media (max-width: 767px) {
    .mkp-schedule-wrap .menuBoxInner {
      padding: 14px;
    }
  }
</style>

<div class="menuBox mkp-schedule-wrap">
  <div class="menuBoxInner">
    <div class="per_title mb-2">
      <h2>Jadwal Visitor per Lokasi</h2>
    </div>
    <div class="infoBox mb-2">
      Atur jam buka/tutup per hari berdasarkan Location Name. Tambahkan hari libur untuk menonaktifkan tombol Add di halaman visitor.
    </div>
    <div class="mb-3">
      <a class="btn btn-light btn-sm" href="<?php echo htmlspecialchars($basePageUrl . '?mod=reporting&id=' . urlencode((string)$pluginId)); ?>">Kembali ke Kelola Visitor Lengkap</a>
    </div>

    <?php if ($flashMessage !== '') { ?>
      <div class="alert alert-<?php echo $flashType ?: 'info'; ?>">
        <?php echo htmlspecialchars($flashMessage); ?>
      </div>
    <?php } ?>

    <div class="mkp-schedule-card">
      <form method="post" action="<?php echo htmlspecialchars($formAction); ?>" id="mkpScheduleForm">
        <input type="hidden" name="save_visit_schedule" value="1">
        <input type="hidden" name="schedule_map_json" id="mkpScheduleMapJson" value="">

        <div class="form-row mb-3">
          <div class="col-md-4">
            <label for="mkpScheduleLocationPicker">Location Name</label>
            <select id="mkpScheduleLocationPicker" class="form-control"<?php echo $canWrite ? '' : ' disabled'; ?>></select>
          </div>
        </div>

        <div class="table-responsive">
          <table class="table table-bordered mkp-schedule-day-table">
            <thead class="thead-light">
              <tr>
                <th>Hari</th>
                <th>Status</th>
                <th>Jam Buka</th>
                <th>Jam Tutup</th>
              </tr>
            </thead>
            <tbody id="mkpScheduleDayRows">
              <?php foreach ($dayLabels as $dayKey => $dayLabel) { ?>
                <tr data-day="<?php echo htmlspecialchars($dayKey); ?>">
                  <td><strong><?php echo htmlspecialchars($dayLabel); ?></strong></td>
                  <td>
                    <label class="mb-0">
                      <input type="checkbox" class="mkp-day-open"<?php echo $canWrite ? '' : ' disabled'; ?>> Buka
                    </label>
                  </td>
                  <td>
                    <input type="time" class="form-control mkp-day-open-time" value="08:00"<?php echo $canWrite ? '' : ' disabled'; ?>>
                  </td>
                  <td>
                    <input type="time" class="form-control mkp-day-close-time" value="16:00"<?php echo $canWrite ? '' : ' disabled'; ?>>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>

        <h6 class="mt-3 mb-2">Hari Libur</h6>
        <div class="table-responsive">
          <table class="table table-bordered mkp-holiday-table">
            <thead class="thead-light">
              <tr>
                <th style="width: 170px;">Mulai Libur</th>
                <th style="width: 170px;">Selesai Libur</th>
                <th>Keterangan</th>
                <th style="width: 230px;">Lokasi</th>
                <th style="width: 95px;">Aksi</th>
              </tr>
            </thead>
            <tbody id="mkpHolidayRows">
              <?php if (empty($visitHolidays)) { ?>
                <tr>
                  <td><input type="date" class="form-control" name="holiday_start_date[]" value=""<?php echo $canWrite ? '' : ' disabled'; ?>></td>
                  <td><input type="date" class="form-control" name="holiday_end_date[]" value=""<?php echo $canWrite ? '' : ' disabled'; ?>></td>
                  <td><input type="text" class="form-control" name="holiday_name[]" value="" placeholder="Contoh: Libur Nasional"<?php echo $canWrite ? '' : ' disabled'; ?>></td>
                  <td>
                    <select class="form-control" name="holiday_location[]"<?php echo $canWrite ? '' : ' disabled'; ?>>
                      <option value="all">Semua Lokasi</option>
                      <?php foreach ($scheduleLocations as $scheduleLocation) { ?>
                        <option value="<?php echo htmlspecialchars($scheduleLocation); ?>"><?php echo htmlspecialchars($scheduleLocation); ?></option>
                      <?php } ?>
                    </select>
                  </td>
                  <td><button type="button" class="btn btn-danger btn-sm mkp-holiday-remove"<?php echo $canWrite ? '' : ' disabled'; ?>>Hapus</button></td>
                </tr>
              <?php } else { ?>
                <?php foreach ($visitHolidays as $holidayRow) { ?>
                  <?php
                  $holidayStart = htmlspecialchars((string)($holidayRow['start_date'] ?? ($holidayRow['date'] ?? '')));
                  $holidayEnd = htmlspecialchars((string)($holidayRow['end_date'] ?? ($holidayRow['date'] ?? '')));
                  $holidayName = htmlspecialchars((string)($holidayRow['name'] ?? ''));
                  $holidayLocation = (string)($holidayRow['location'] ?? 'all');
                  ?>
                  <tr>
                    <td><input type="date" class="form-control" name="holiday_start_date[]" value="<?php echo $holidayStart; ?>"<?php echo $canWrite ? '' : ' disabled'; ?>></td>
                    <td><input type="date" class="form-control" name="holiday_end_date[]" value="<?php echo $holidayEnd; ?>"<?php echo $canWrite ? '' : ' disabled'; ?>></td>
                    <td><input type="text" class="form-control" name="holiday_name[]" value="<?php echo $holidayName; ?>" placeholder="Contoh: Libur Nasional"<?php echo $canWrite ? '' : ' disabled'; ?>></td>
                    <td>
                      <select class="form-control" name="holiday_location[]"<?php echo $canWrite ? '' : ' disabled'; ?>>
                        <option value="all"<?php echo $holidayLocation === 'all' ? ' selected' : ''; ?>>Semua Lokasi</option>
                        <?php foreach ($scheduleLocations as $scheduleLocation) { ?>
                          <option value="<?php echo htmlspecialchars($scheduleLocation); ?>"<?php echo $holidayLocation === $scheduleLocation ? ' selected' : ''; ?>><?php echo htmlspecialchars($scheduleLocation); ?></option>
                        <?php } ?>
                      </select>
                    </td>
                    <td><button type="button" class="btn btn-danger btn-sm mkp-holiday-remove"<?php echo $canWrite ? '' : ' disabled'; ?>>Hapus</button></td>
                  </tr>
                <?php } ?>
              <?php } ?>
            </tbody>
          </table>
        </div>

        <div class="mkp-schedule-actions">
          <button type="button" id="mkpHolidayAdd" class="btn btn-light btn-sm"<?php echo $canWrite ? '' : ' disabled'; ?>>Tambah Hari Libur</button>
          <?php if ($canWrite) { ?>
            <button type="submit" class="btn btn-primary btn-sm">Simpan Jadwal Visitor</button>
          <?php } ?>
        </div>
      </form>
    </div>

    <div class="mkp-status-card">
      <h5>Status Lokasi Saat Ini</h5>
      <div class="table-responsive">
        <table class="table table-bordered table-sm mkp-status-table">
          <thead class="thead-light">
            <tr>
              <th>Location Name</th>
              <th style="width: 120px;">Status</th>
              <th style="width: 90px;">Jam</th>
              <th style="width: 170px;">Jadwal Hari Ini</th>
              <th>Keterangan</th>
            </tr>
          </thead>
          <tbody id="mkpStatusNowRows"></tbody>
        </table>
      </div>
      <div class="mkp-status-foot">
        Update otomatis setiap 30 detik. Waktu server: <span id="mkpStatusCheckedAt">-</span>
      </div>
    </div>
  </div>
</div>

<script>
  (function () {
    var scheduleForm = document.getElementById('mkpScheduleForm');
    if (!scheduleForm) return;

    var canWrite = <?php echo $canWrite ? 'true' : 'false'; ?>;
    var locationPicker = document.getElementById('mkpScheduleLocationPicker');
    var dayRowsContainer = document.getElementById('mkpScheduleDayRows');
    var holidayRows = document.getElementById('mkpHolidayRows');
    var holidayAddButton = document.getElementById('mkpHolidayAdd');
    var mapJsonField = document.getElementById('mkpScheduleMapJson');
    var statusRowsContainer = document.getElementById('mkpStatusNowRows');
    var statusCheckedAtNode = document.getElementById('mkpStatusCheckedAt');
    var dayLabels = <?php echo json_encode($dayLabels, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?> || {};
    var dayKeys = Object.keys(dayLabels);
    var defaultDayTemplate = <?php echo $defaultDayScheduleJson ?: '{}'; ?> || {};
    var scheduleLocations = <?php echo $scheduleLocationsJson ?: '[]'; ?> || [];
    var scheduleMap = <?php echo $scheduleMapJson ?: '{}'; ?> || {};
    var initialStatusRows = <?php echo $initialStatusRowsJson ?: '[]'; ?> || [];
    var statusNowUrl = <?php echo json_encode($statusNowUrl, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;

    function cloneDefaultDayTemplate() {
      return JSON.parse(JSON.stringify(defaultDayTemplate));
    }

    function escapeHtml(value) {
      return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }

    function normalizeTime(value, fallbackValue) {
      var val = String(value || '').trim();
      if (!/^\d{2}:\d{2}$/.test(val)) return fallbackValue;
      var hour = parseInt(val.substring(0, 2), 10);
      var minute = parseInt(val.substring(3, 5), 10);
      if (isNaN(hour) || isNaN(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) {
        return fallbackValue;
      }
      return (hour < 10 ? '0' : '') + hour + ':' + (minute < 10 ? '0' : '') + minute;
    }

    function renderStatusRows(rows, checkedAt) {
      if (!statusRowsContainer) return;

      if (!Array.isArray(rows) || rows.length < 1) {
        statusRowsContainer.innerHTML = '<tr><td colspan="5" class="text-muted text-center">Belum ada lokasi.</td></tr>';
      } else {
        var html = '';
        rows.forEach(function (row) {
          var isOpen = !!row.allowed;
          var statusClass = isOpen ? 'mkp-status-open' : 'mkp-status-closed';
          var statusText = isOpen ? 'BUKA' : 'TUTUP';
          var reason = escapeHtml(row.reason || '-');
          var timeText = escapeHtml(row.time || '-');
          var scheduleText = '-';
          if (row.open_time && row.close_time) {
            scheduleText = escapeHtml(String(row.open_time) + ' - ' + String(row.close_time));
          }

          html += '<tr>'
            + '<td>' + escapeHtml(row.location || '-') + '</td>'
            + '<td><span class="' + statusClass + '">' + statusText + '</span></td>'
            + '<td>' + timeText + '</td>'
            + '<td>' + scheduleText + '</td>'
            + '<td>' + reason + '</td>'
            + '</tr>';
        });
        statusRowsContainer.innerHTML = html;
      }

      if (statusCheckedAtNode) {
        statusCheckedAtNode.textContent = checkedAt || '-';
      }
    }

    function fetchStatusNow() {
      if (!statusNowUrl) return;
      fetch(statusNowUrl + '&_=' + Date.now(), {credentials: 'same-origin'})
        .then(function (response) {
          return response.json();
        })
        .then(function (json) {
          if (!json || !json.status) return;
          renderStatusRows(Array.isArray(json.rows) ? json.rows : [], json.checked_at || '');
        })
        .catch(function () {
          // Keep latest rendered data when request fails.
        });
    }

    function ensureLocationSchedule(locationName) {
      if (!locationName) return;
      if (!scheduleMap[locationName] || typeof scheduleMap[locationName] !== 'object') {
        scheduleMap[locationName] = cloneDefaultDayTemplate();
        return;
      }

      dayKeys.forEach(function (dayKey) {
        if (!scheduleMap[locationName][dayKey] || typeof scheduleMap[locationName][dayKey] !== 'object') {
          scheduleMap[locationName][dayKey] = JSON.parse(JSON.stringify(defaultDayTemplate[dayKey] || {
            open: 1,
            open_time: '08:00',
            close_time: '16:00'
          }));
        } else {
          scheduleMap[locationName][dayKey].open = scheduleMap[locationName][dayKey].open ? 1 : 0;
          scheduleMap[locationName][dayKey].open_time = normalizeTime(
            scheduleMap[locationName][dayKey].open_time,
            '08:00'
          );
          scheduleMap[locationName][dayKey].close_time = normalizeTime(
            scheduleMap[locationName][dayKey].close_time,
            '16:00'
          );
        }
      });
    }

    function fillDayForm(locationName) {
      ensureLocationSchedule(locationName);
      var locationSchedule = scheduleMap[locationName] || cloneDefaultDayTemplate();
      dayKeys.forEach(function (dayKey) {
        var row = dayRowsContainer.querySelector('tr[data-day="' + dayKey + '"]');
        if (!row) return;
        var openCheckbox = row.querySelector('.mkp-day-open');
        var openInput = row.querySelector('.mkp-day-open-time');
        var closeInput = row.querySelector('.mkp-day-close-time');
        var config = locationSchedule[dayKey] || {open: 1, open_time: '08:00', close_time: '16:00'};

        if (openCheckbox) openCheckbox.checked = !!config.open;
        if (openInput) openInput.value = normalizeTime(config.open_time, '08:00');
        if (closeInput) closeInput.value = normalizeTime(config.close_time, '16:00');
      });
    }

    function saveCurrentLocationFromForm() {
      var locationName = locationPicker.value || '';
      if (!locationName) return;
      ensureLocationSchedule(locationName);

      dayKeys.forEach(function (dayKey) {
        var row = dayRowsContainer.querySelector('tr[data-day="' + dayKey + '"]');
        if (!row) return;
        var openCheckbox = row.querySelector('.mkp-day-open');
        var openInput = row.querySelector('.mkp-day-open-time');
        var closeInput = row.querySelector('.mkp-day-close-time');

        scheduleMap[locationName][dayKey] = {
          open: openCheckbox && openCheckbox.checked ? 1 : 0,
          open_time: normalizeTime(openInput ? openInput.value : '', '08:00'),
          close_time: normalizeTime(closeInput ? closeInput.value : '', '16:00')
        };
      });
    }

    function buildHolidayRow(startDateValue, endDateValue, nameValue, locationValue) {
      var row = document.createElement('tr');
      var locationOptionsHtml = '<option value="all"' + (locationValue === 'all' ? ' selected' : '') + '>Semua Lokasi</option>';
      scheduleLocations.forEach(function (locationName) {
        var selected = locationName === locationValue ? ' selected' : '';
        locationOptionsHtml += '<option value="' + escapeHtml(locationName) + '"' + selected + '>' + escapeHtml(locationName) + '</option>';
      });

      row.innerHTML = ''
        + '<td><input type="date" class="form-control" name="holiday_start_date[]" value="' + escapeHtml(startDateValue || '') + '"' + (canWrite ? '' : ' disabled') + '></td>'
        + '<td><input type="date" class="form-control" name="holiday_end_date[]" value="' + escapeHtml(endDateValue || '') + '"' + (canWrite ? '' : ' disabled') + '></td>'
        + '<td><input type="text" class="form-control" name="holiday_name[]" value="' + escapeHtml(nameValue || '') + '" placeholder="Contoh: Libur Nasional"' + (canWrite ? '' : ' disabled') + '></td>'
        + '<td><select class="form-control" name="holiday_location[]"' + (canWrite ? '' : ' disabled') + '>' + locationOptionsHtml + '</select></td>'
        + '<td><button type="button" class="btn btn-danger btn-sm mkp-holiday-remove"' + (canWrite ? '' : ' disabled') + '>Hapus</button></td>';

      return row;
    }

    if (locationPicker) {
      locationPicker.innerHTML = '';
      scheduleLocations.forEach(function (locationName) {
        var option = document.createElement('option');
        option.value = locationName;
        option.textContent = locationName;
        locationPicker.appendChild(option);
        ensureLocationSchedule(locationName);
      });

      if (scheduleLocations.length > 0) {
        locationPicker.value = scheduleLocations[0];
        fillDayForm(locationPicker.value);
      }

      locationPicker.addEventListener('change', function () {
        saveCurrentLocationFromForm();
        fillDayForm(locationPicker.value || '');
      });
    }

    if (dayRowsContainer) {
      dayRowsContainer.addEventListener('change', function () {
        saveCurrentLocationFromForm();
      });
      dayRowsContainer.addEventListener('input', function () {
        saveCurrentLocationFromForm();
      });
    }

    if (holidayRows) {
      holidayRows.addEventListener('click', function (event) {
        var removeButton = event.target.closest('.mkp-holiday-remove');
        if (!removeButton) return;
        var row = removeButton.closest('tr');
        if (!row) return;
        row.remove();
        if (holidayRows.querySelectorAll('tr').length < 1) {
          holidayRows.appendChild(buildHolidayRow('', '', '', 'all'));
        }
      });
    }

    if (holidayAddButton) {
      holidayAddButton.addEventListener('click', function () {
        if (!holidayRows) return;
        holidayRows.appendChild(buildHolidayRow('', '', '', locationPicker && locationPicker.value ? locationPicker.value : 'all'));
      });
    }

    scheduleForm.addEventListener('submit', function () {
      saveCurrentLocationFromForm();
      if (mapJsonField) {
        mapJsonField.value = JSON.stringify(scheduleMap || {});
      }
    });

    renderStatusRows(initialStatusRows, '<?php echo date('Y-m-d H:i:s'); ?>');
    fetchStatusNow();
    setInterval(fetchStatusNow, 30000);
  })();
</script>
