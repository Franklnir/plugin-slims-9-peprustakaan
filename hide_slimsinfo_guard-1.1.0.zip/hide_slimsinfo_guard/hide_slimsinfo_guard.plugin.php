<?php
/**
 * Plugin Name: Hide About SLiMS + Add Visitor Menu
 * Plugin URI: https://local.custom/slims
 * Description: Hide "About SLiMS" menu in OPAC, add "Visitor" menu after Home, and block direct access to index.php?p=slimsinfo
 * Version: 1.1.0
 * Author: Codex
 * Author URI: https://openai.com
 */

use SLiMS\Plugins;

$plugin = Plugins::getInstance();

// Hide "About SLiMS" menu item from OPAC navigation (template-level menu).
$plugin->register(Plugins::CONTENT_BEFORE_LOAD, function ($opac) {
    $metadata = $opac->metadata ?? '';
    $metadata .= <<<HTML
<style>
  a[href="index.php?p=slimsinfo"],
  a[href="./index.php?p=slimsinfo"],
  a[href$="index.php?p=slimsinfo"] {
    display: none !important;
  }
</style>
HTML;
    $opac->metadata = $metadata;

    // Inject JS after default scripts are loaded to adjust OPAC side menu.
    $labelVisitor = function_exists('__') ? __('Visitor') : 'Visitor';
    $labelVisitorJs = json_encode($labelVisitor, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $js = $opac->js ?? '';
    $js .= <<<HTML
<script>
document.addEventListener('DOMContentLoaded', function () {
  var menu = document.querySelector('.s-menu-content ul');
  if (!menu) return;

  // Remove "About SLiMS" menu item.
  menu.querySelectorAll('a[href*="p=slimsinfo"]').forEach(function (anchor) {
    var li = anchor.closest('li');
    if (li) li.remove();
  });

  // Prevent duplicate visitor menu entry.
  if (menu.querySelector('a[href*="p=visitor"]')) return;

  var visitorLi = document.createElement('li');
  var visitorA = document.createElement('a');
  visitorA.href = 'index.php?p=visitor';
  visitorA.textContent = {$labelVisitorJs};
  visitorLi.appendChild(visitorA);

  var homeAnchor = menu.querySelector('li a[href="index.php"], li a[href="./index.php"]');
  var homeLi = homeAnchor ? homeAnchor.closest('li') : null;

  if (homeLi && homeLi.parentNode) {
    if (homeLi.nextSibling) {
      homeLi.parentNode.insertBefore(visitorLi, homeLi.nextSibling);
    } else {
      homeLi.parentNode.appendChild(visitorLi);
    }
  } else {
    menu.insertBefore(visitorLi, menu.firstChild);
  }
});
</script>
HTML;
    $opac->js = $js;

    // Block direct access to the About SLiMS page.
    $path = strtolower(trim((string) ($_GET['p'] ?? '')));
    if ($path === 'slimsinfo') {
        header('Location: index.php', true, 302);
        exit;
    }
});
